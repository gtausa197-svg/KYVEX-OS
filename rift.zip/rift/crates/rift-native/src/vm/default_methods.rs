//! Resolve maximally specific interface methods after class hierarchy lookup.
use super::*;
impl Runtime {
    pub(super) fn default_method(
        &mut self,
        receiver: &str,
        name: &str,
        descriptor: &str,
    ) -> Result<Option<usize>> {
        let mut pending = vec![receiver.to_owned()];
        let mut seen = BTreeSet::new();
        let mut candidates = Vec::new();
        while let Some(class) = pending.pop() {
            if !seen.insert(class.clone()) {
                continue;
            }
            if seen.len() > 1024 {
                return Err("Interface method resolution hierarchy quota".into());
            }
            self.ensure_class(&class)?;
            let Some(definition) = self
                .dex
                .type_id(&class)
                .and_then(|ty| self.dex.classes.get(&ty))
                .cloned()
            else {
                continue;
            };
            if definition.access & 0x200 != 0
                && let Some(index) = self
                    .dex
                    .find(&class, name, descriptor)
                    .filter(|index| definition.methods.contains(index))
                && let Some(body) = self.dex.bodies.get(&index)
                && body.access & (8 | 2) == 0
            {
                candidates.push((class.clone(), index, body.access & 0x400 == 0));
            }
            if let Some(parent) = definition.parent {
                pending.push(self.dex.ty(parent).to_owned());
            }
            pending.extend(
                definition
                    .interfaces
                    .iter()
                    .map(|ty| self.dex.ty(*ty).to_owned()),
            );
        }
        let mut maximal = Vec::new();
        for (class, index, concrete) in &candidates {
            let mut shadowed = false;
            for (other, _, _) in &candidates {
                if other != class && self.subclass(other, class)? {
                    shadowed = true;
                    break;
                }
            }
            if !shadowed {
                maximal.push((*index, *concrete));
            }
        }
        let concrete: Vec<_> = maximal
            .iter()
            .filter(|(_, concrete)| *concrete)
            .map(|(index, _)| *index)
            .collect();
        if concrete.len() > 1 {
            return Err(fault(
                "Ljava/lang/IncompatibleClassChangeError;",
                "Ambiguous maximally specific interface methods",
            ));
        }
        if let Some(index) = concrete.first() {
            return Ok(Some(*index));
        }
        if !maximal.is_empty() {
            return Err(fault(
                "Ljava/lang/AbstractMethodError;",
                "No concrete maximally specific interface method",
            ));
        }
        Ok(None)
    }
}
