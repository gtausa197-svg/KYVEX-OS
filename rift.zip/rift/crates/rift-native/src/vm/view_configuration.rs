//! Android input thresholds for the single guest display profile.
use super::*;

pub(super) const CLASS: &str = "Landroid/view/ViewConfiguration;";
const CONFIGURATION_REF: usize = usize::MAX - 134;
const TOUCH_SLOP: u64 = 8;
const MIN_FLING: u64 = 50;
const MAX_FLING: u64 = 8000;

fn scale(dp: u64) -> u64 {
    (dp * u64::from(crate::resources::DENSITY) + 80) / 160
}

impl Runtime {
    pub(super) fn view_configuration_api(
        &mut self,
        sig: &str,
        args: &[u32],
    ) -> Result<Option<u64>> {
        let Some(method) = sig.strip_prefix("Landroid/view/ViewConfiguration;->") else {
            return Ok(None);
        };
        let receiver = || args.first().copied().ok_or("ViewConfiguration argument");
        if method == "get(Landroid/content/Context;)Landroid/view/ViewConfiguration;" {
            let context = self.object(receiver()?)?;
            if !self.subclass(&context.class, "Landroid/content/Context;")? {
                return Err(fault("Ljava/lang/ClassCastException;", "Expected Context"));
            }
            let manager = self.guest_window_manager()?;
            if let Some(&existing) = self.object(manager)?.fields.get(&CONFIGURATION_REF) {
                return Ok(Some(existing));
            }
            let id = u64::from(self.allocate(CLASS, Payload::Instance)?);
            self.object_mut(manager)?
                .fields
                .insert(CONFIGURATION_REF, id);
            return Ok(Some(id));
        }
        let value = match method {
            "getDefaultActionModeHideDuration()J" => 2000,
            "getDoubleTapTimeout()I" => 300,
            "getLongPressTimeout()I" => 500,
            "getPressedStateDuration()I" => 64,
            "getTapTimeout()I" => 100,
            "getMaximumFlingVelocity()I" => MAX_FLING,
            "getMinimumFlingVelocity()I" => MIN_FLING,
            "getScrollFriction()F" => u64::from(0.015f32.to_bits()),
            "getTouchSlop()I" => TOUCH_SLOP,
            _ => {
                let value = match method {
                    "getScaledDoubleTapSlop()I" => scale(100),
                    "getScaledHorizontalScrollFactor()F" | "getScaledVerticalScrollFactor()F" => {
                        u64::from((scale(64) as f32).to_bits())
                    }
                    "getScaledHoverSlop()I" => scale(4),
                    "getScaledMaximumFlingVelocity()I" => scale(MAX_FLING),
                    "getScaledMinimumFlingVelocity()I" => scale(MIN_FLING),
                    "getScaledPagingTouchSlop()I" => scale(TOUCH_SLOP) * 2,
                    "getScaledTouchSlop()I" => scale(TOUCH_SLOP),
                    "hasPermanentMenuKey()Z" | "shouldShowMenuShortcutsWhenKeyboardPresent()Z" => 0,
                    _ => return Ok(None),
                };
                if self.object(receiver()?)?.class != CLASS {
                    return Err(fault(
                        "Ljava/lang/ClassCastException;",
                        "Expected ViewConfiguration",
                    ));
                }
                value
            }
        };
        Ok(Some(value))
    }
}
