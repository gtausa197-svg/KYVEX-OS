import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import QtQuick.Window

ApplicationWindow {
 id: studio; visible: true; width: Math.min(1240,Screen.desktopAvailableWidth-32); height: Math.min(800,Screen.desktopAvailableHeight-96); minimumWidth: 1000; minimumHeight: 660
 title: "KYVEX Rift Studio"; color: "#090d15"
 onClosing: rift.closeNative()
 palette { text: "#f0f3ff"; windowText: "#f0f3ff"; buttonText: "#f0f3ff"; base: "#151c2a"; button: "#202a3b"; highlight: "#8163cd"; highlightedText: "white" }
 property color accent: "#7cf5d8"
 property int page: 0
 property int picked: 0
 property var controls: rift.profile.controls || []
 property var chosen: controls[picked] || ({})
 function trText(en,uk) { return rift.ukrainian ? uk : en }
 function keyName(e) {
  var map={};map[Qt.Key_Left]="Left";map[Qt.Key_Right]="Right";map[Qt.Key_Up]="Up";map[Qt.Key_Down]="Down";map[Qt.Key_Space]="Space";map[Qt.Key_Shift]="Shift";map[Qt.Key_Control]="Ctrl"
  return map[e.key] || (e.text && e.text.length===1 ? e.text.toUpperCase() : "Key"+e.key)
 }
 component RButton: Button {
  property bool primary: false
  implicitHeight: 40; implicitWidth: Math.max(100,contentItem.implicitWidth+28)
  background: Rectangle { radius: 10; color: parent.down ? "#3b5c65" : parent.primary ? "#7cf5d8" : parent.hovered ? "#29334a" : "#1b2435"; opacity: parent.enabled?1:0.4; border.color: parent.primary?"#7cf5d8":"#324057" }
  contentItem: Text { text: parent.text; color: parent.primary?"#081c1b":"#e5ebfa"; font.pixelSize:13; font.weight: Font.DemiBold; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; opacity: parent.enabled?1:0.5 }
 }
 component Panel: Rectangle { color:"#111826";radius:18;border.color:"#263146" }
 component Caption: Text { textFormat:Text.PlainText; color:"#90a0bb";font.pixelSize:13;wrapMode:Text.WordWrap }
 component Title: Text { textFormat:Text.PlainText; color:"#f3f6ff";font.pixelSize:30;font.weight:Font.DemiBold }

 FileDialog { id: apkDialog; title: studio.trText("Import an Android application","Імпорт Android-застосунку"); nameFilters:["Android APK (*.apk *.APK)"]; onAccepted:rift.importApk(selectedFile) }
 FileDialog { id: exportDialog; title:"Export control profile"; fileMode:FileDialog.SaveFile; nameFilters:["Rift JSON profile (*.json)"]; onAccepted:rift.exportProfile(selectedFile) }
 FileDialog { id: profileDialog; title:"Import control profile"; nameFilters:["Rift JSON profile (*.json)"]; onAccepted:rift.importProfile(selectedFile) }
 Dialog { id: removeDialog; title:studio.trText("Remove from library?","Видалити з бібліотеки?"); anchors.centerIn:parent; modal:true; standardButtons:Dialog.Yes|Dialog.No; onAccepted:rift.remove(); Label{text:"Your control profile will be retained."} }

 Rectangle {
  id: sidebar; width:220;anchors.top:parent.top;anchors.bottom:parent.bottom;color:"#0d121e";border.color:"#202b3d"
  Column { anchors.left:parent.left;anchors.right:parent.right;anchors.top:parent.top;anchors.margins:22;spacing:12
   Text { text:"K Y V E X";color:studio.accent;font.pixelSize:12;font.letterSpacing:3 }
   Text { text:"RIFT";color:"#f5f4ff";font.pixelSize:48;font.weight:Font.Bold;font.letterSpacing:5 }
   Caption { text:"NATIVE / 0.3";font.pixelSize:10;font.letterSpacing:1.5 }
   Item { width:1;height:28 }
   Repeater { model:[studio.trText("Library","Бібліотека"),studio.trText("Game Controls","Керування"),studio.trText("Runtime","Середовище"),studio.trText("Performance","Продуктивність"),studio.trText("Diagnostics","Діагностика")]
    delegate: Rectangle { required property int index;required property string modelData;width:176;height:46;radius:10;color:studio.page===index?"#203637":"transparent";border.color:studio.page===index?"#417f77":"transparent"
     Text { anchors.verticalCenter:parent.verticalCenter;anchors.left:parent.left;anchors.leftMargin:15;text:parent.modelData;color:studio.page===parent.index?studio.accent:"#9daac0";font.pixelSize:14 }
     MouseArea { anchors.fill:parent;onClicked:studio.page=parent.index;cursorShape:Qt.PointingHandCursor }
    }
   }
  }
  Column { anchors.bottom:parent.bottom;anchors.left:parent.left;anchors.right:parent.right;anchors.margins:22;spacing:12
   Caption { width:176;text:rift.status.runtime && rift.status.runtime.live?studio.trText("LIVE SESSION\nApps and profiles clear after restart.","LIVE-СЕАНС\nЗміни зникнуть після перезапуску."):"LOCAL / YOUR SESSION";font.pixelSize:11;color:rift.status.runtime && rift.status.runtime.live?"#ffc78d":"#8ca7b0" }
   RButton { width:176;text:rift.ukrainian?"English":"Українська";onClicked:rift.ukrainian=!rift.ukrainian }
  }
 }
 ColumnLayout {
  anchors.left:sidebar.right;anchors.right:parent.right;anchors.top:parent.top;anchors.bottom:logPanel.top;anchors.margins:28;spacing:20
  RowLayout { Layout.fillWidth:true
   Text { text:"RIFT STUDIO  /  "+["LIBRARY","INPUT LAB","RUNTIME","PERFORMANCE","DIAGNOSTICS"][studio.page];font.pixelSize:11;font.letterSpacing:2;color:"#8b9ab6";Layout.fillWidth:true }
   BusyIndicator { running:rift.busy;visible:running;implicitWidth:24;implicitHeight:24 }
   Caption { text:"● Local service";color:studio.accent }
   RButton { text:studio.trText("Refresh","Оновити");onClicked:rift.refresh() }
  }
  StackLayout { currentIndex:studio.page;Layout.fillWidth:true;Layout.fillHeight:true
   ColumnLayout {
    spacing:18
    Title { text:studio.trText("Your apps. A new dimension.","Твої програми. Новий вимір.") }
    Caption { Layout.fillWidth:true;text:studio.trText("Import, inspect and launch Android apps. Your library and controls stay in your Linux account.","Імпортуй, перевіряй і запускай Android-програми. Бібліотека та керування зберігаються у твоєму профілі Linux.") }
    Panel { Layout.fillWidth:true;Layout.preferredHeight:116
     RowLayout { anchors.fill:parent;anchors.margins:22;spacing:24
      Text { text:"+";font.pixelSize:48;color:studio.accent }
      ColumnLayout { Layout.fillWidth:true;Text{text:studio.trText("Drop an APK here","Перетягни сюди APK");color:"#eff4ff";font.pixelSize:20}Caption{Layout.fillWidth:true;text:"Manifest · DEX · native ABI · permissions · SHA256"} }
      RButton { primary:true;text:studio.trText("Import APK","Імпорт APK");enabled:!rift.busy;onClicked:apkDialog.open() }
     }
     DropArea { anchors.fill:parent;onDropped:(drop)=>{if(drop.hasUrls && drop.urls.length===1)rift.importApk(drop.urls[0]);} }
    }
    RowLayout { Caption{text:rift.apps.length+" APPLICATIONS";Layout.fillWidth:true}RButton{text:studio.trText("Try Native demo","Демо Native");primary:true;enabled:!rift.busy;onClicked:rift.nativeDemo()}RButton{text:studio.trText("Runtime options","Режими запуску");onClicked:{studio.page=2;}} }
    GridView { Layout.fillWidth:true;Layout.fillHeight:true;clip:true;cellWidth:width/Math.max(1,Math.floor(width/300));cellHeight:238;model:rift.apps
     delegate: Item { required property var modelData; width:GridView.view.cellWidth;height:238
      Panel { anchors.fill:parent;anchors.rightMargin:12;anchors.bottomMargin:12;border.color:rift.selected===modelData.package?"#68bbaa":"#263146"
       ColumnLayout { anchors.fill:parent;anchors.margins:18;spacing:10
        RowLayout { Rectangle{width:42;height:42;radius:12;color:"#25423f";Text{anchors.centerIn:parent;text:modelData.label.substring(0,1).toUpperCase();color:studio.accent;font.pixelSize:24}}Text{Layout.fillWidth:true;text:modelData.label;textFormat:Text.PlainText;color:"#f0f4ff";font.pixelSize:17;elide:Text.ElideRight} }
        Caption{Layout.fillWidth:true;text:modelData.package;font.pixelSize:11;elide:Text.ElideRight;wrapMode:Text.NoWrap}
        Caption{Layout.fillWidth:true;text:"v"+modelData.version+" · "+(modelData.bytes/1048576).toFixed(1)+" MiB\n"+modelData.abis.join(" / ")+"\n"+modelData.dex_files+" DEX · "+modelData.native_libraries+" native libraries"}
        Item { Layout.fillHeight:true }
        RowLayout { RButton{primary:true;text:studio.trText("Launch","Запустити");enabled:!rift.busy;onClicked:{rift.choose(modelData.package);rift.launch();}}RButton{text:studio.trText("Controls","Керування");onClicked:{rift.choose(modelData.package);studio.page=1;studio.picked=0;}} }
       }
      }
     }
     Text { anchors.centerIn:parent;visible:rift.apps.length===0;text:studio.trText("Your library starts with one APK.","Бібліотека починається з першого APK.");color:"#71809c";font.pixelSize:19 }
    }
   }
   ColumnLayout {
    spacing:12
    RowLayout { Title{text:studio.trText("Control every move.","Керуй кожним рухом.");Layout.fillWidth:true}ComboBox{id:appSelector;Layout.preferredWidth:265;model:["org.kyvex.test"].concat(rift.apps.map(a=>a.package));currentIndex:model.indexOf(rift.selected);onActivated:rift.choose(currentText)} }
    Caption { text:studio.trText("Drag bindings in the local test scene. F1 switches editing / capture there. Game input integration is under development.","Перетягуй кнопки в локальній тестовій сцені. F1 перемикає редагування та захоплення в ній. Інтеграція керування іграми ще розробляється.");Layout.fillWidth:true }
    RowLayout { spacing:8;RButton{text:"Test scene";primary:true;onClicked:rift.session(false)}RButton{text:"Undo";implicitWidth:70;onClicked:rift.undo()}RButton{text:"Redo";implicitWidth:70;onClicked:rift.redo()}RButton{text:"Export";implicitWidth:75;onClicked:exportDialog.open()}RButton{text:"Import";implicitWidth:75;onClicked:profileDialog.open()} }
    RowLayout { Layout.fillWidth:true;Layout.fillHeight:true;spacing:14
     Panel { Layout.fillWidth:true;Layout.fillHeight:true
      Item { id:editor; width:rift.profile.orientation==="portrait"?Math.min(parent.width-32,(parent.height-32)*0.5625):parent.width-32;height:rift.profile.orientation==="portrait"?parent.height-32:Math.min(parent.height-32,width*0.5625);anchors.centerIn:parent
       Rectangle{anchors.fill:parent;radius:18;color:"#0b1521";border.color:"#304b60"}
       Canvas { anchors.fill:parent;onPaint:{var c=getContext("2d");c.clearRect(0,0,width,height);c.strokeStyle="#173044";for(var x=0;x<width;x+=28){c.beginPath();c.moveTo(x,0);c.lineTo(x,height);c.stroke();}for(var y=0;y<height;y+=28){c.beginPath();c.moveTo(0,y);c.lineTo(width,y);c.stroke();}} }
       Text{anchors.centerIn:parent;text:"R I F T\nINPUT CANVAS";horizontalAlignment:Text.AlignHCenter;color:"#24495b";font.pixelSize:23;font.letterSpacing:3}
       Repeater { model:studio.controls
        delegate: Rectangle { required property var modelData;required property int index;width:62;height:62;radius:modelData.kind==="joystick"?22:31;x:modelData.x*editor.width-width/2;y:modelData.y*editor.height-height/2;color:studio.picked===index?"#4d7876":"#26374b";border.color:studio.picked===index?studio.accent:"#607894";border.width:2
         Text{anchors.centerIn:parent;text:parent.modelData.key==="RightMouseButton"?"RMB":parent.modelData.key;color:"white";font.pixelSize:11;horizontalAlignment:Text.AlignHCenter;width:parent.width-8;wrapMode:Text.WrapAnywhere}
         MouseArea { anchors.fill:parent;drag.target:parent;drag.minimumX:-parent.width/2;drag.maximumX:editor.width-parent.width/2;drag.minimumY:-parent.height/2;drag.maximumY:editor.height-parent.height/2;onPressed:studio.picked=parent.index;onReleased:{var i=parent.index,x=(parent.x+31)/editor.width,y=(parent.y+31)/editor.height;rift.moveControl(i,x,y);} }
        }
       }
      }
     }
     Panel { Layout.preferredWidth:250;Layout.fillHeight:true
      ScrollView { id:bindingScroll;anchors.fill:parent;anchors.margins:16;contentWidth:availableWidth;clip:true
       ColumnLayout { width:bindingScroll.availableWidth;spacing:10
        Caption{text:"SELECTED BINDING";font.letterSpacing:1.5;font.pixelSize:10}
        Text{Layout.fillWidth:true;text:studio.chosen.id||"Choose a binding";color:"#edf2ff";font.pixelSize:17;elide:Text.ElideRight}
        TextField{Layout.fillWidth:true;placeholderText:"Key: Space, W, Left…";text:studio.chosen.key||"";onEditingFinished:rift.edit(studio.picked,"key",text)}
        ComboBox{Layout.fillWidth:true;model:["tap","hold","swipe","joystick","aim"];currentIndex:model.indexOf(studio.chosen.kind);onActivated:rift.edit(studio.picked,"kind",currentText)}
        Caption{text:"Position X / Y"}
        Slider{Layout.fillWidth:true;from:0;to:1;value:studio.chosen.x||0;onMoved:rift.edit(studio.picked,"x",value)}
        Slider{Layout.fillWidth:true;from:0;to:1;value:studio.chosen.y||0;onMoved:rift.edit(studio.picked,"y",value)}
        Caption{text:"Swipe endpoint X / Y";visible:studio.chosen.kind==="swipe"}
        Slider{Layout.fillWidth:true;visible:studio.chosen.kind==="swipe";from:0;to:1;value:studio.chosen.end_x||0;onMoved:rift.edit(studio.picked,"end_x",value)}
        Slider{Layout.fillWidth:true;visible:studio.chosen.kind==="swipe";from:0;to:1;value:studio.chosen.end_y||0;onMoved:rift.edit(studio.picked,"end_y",value)}
        Caption{text:"Orientation"}
        ComboBox{Layout.fillWidth:true;model:["landscape","portrait"];currentIndex:model.indexOf(rift.profile.orientation);onActivated:rift.orientation(currentText)}
        Caption{text:"Application architecture"}
        ComboBox{Layout.fillWidth:true;model:["auto","armeabi-v7a","arm64-v8a"];currentIndex:model.indexOf(rift.profile.abi||"auto");onActivated:rift.architecture(currentText)}
        Caption{text:studio.trText("Execution backend","Середовище виконання")}
        ComboBox{Layout.fillWidth:true;model:["native"];currentIndex:model.indexOf(rift.profile.backend||"native");onActivated:rift.backend(currentText)}
        Caption{Layout.fillWidth:true;visible:rift.profile.backend==="native";text:studio.trText("Native executes supported Java and ARM JNI. The mapping editor is a local test scene; game touch and graphics are under development. Unsupported APIs stop with an explanation.","Native виконує підтримувані Java та ARM JNI. Редактор керування — локальна тестова сцена. Графіка й сенсорне керування іграми ще розробляються.")}
        ComboBox{Layout.fillWidth:true;visible:rift.profile.backend==="native";model:["light","balanced","large"];currentIndex:model.indexOf(rift.profile.native_memory||"light");onActivated:rift.nativeMemory(currentText)}
        RowLayout{RButton{text:"Add";implicitWidth:98;onClicked:rift.add("tap")}RButton{text:"Delete";implicitWidth:98;onClicked:rift.erase(studio.picked)}}
        Caption{Layout.fillWidth:true;text:"WASD = joystick\nRightMouseButton = aim\nArrow keys = Subway swipes\nProfiles save automatically."}
       }
      }
     }
    }
   }
   ScrollView { id:runtimeScroll;clip:true;contentWidth:availableWidth
    ColumnLayout { width:runtimeScroll.availableWidth;spacing:18
     Title{text:studio.trText("Your Native runtime.","Твоє середовище Native.")}
     Panel{Layout.fillWidth:true;Layout.preferredHeight:245;ColumnLayout{anchors.fill:parent;anchors.margins:22;spacing:12;Text{text:"RIFT NATIVE / RUST + DYNARMIC";color:"#c3a5ff";font.pixelSize:13}Caption{Layout.fillWidth:true;text:studio.trText("Our lightweight Rust runtime loads DEX, JNI and ARM32 / ARM64 code, and displays a small Android UI API as a Linux window. It needs no Android image. The worker has memory and instruction limits plus a Linux syscall filter.","Наш легкий Rust runtime завантажує DEX, JNI та ARM32 / ARM64 і відображає базовий Android UI у вікні Linux. Образ Android не потрібен. Процес має ліміти пам’яті й інструкцій та фільтр системних викликів.")}Caption{Layout.fillWidth:true;text:"Experimental 0.3: lazy multidex, typed exceptions, numerical operations and registered JNI. Only the implemented API subset runs. Full Android Framework, Unity graphics, media and online services remain under development.";color:"#ffc997"}RowLayout{RButton{primary:true;text:studio.trText("Run Native APK demo","Запустити Native APK");enabled:!rift.busy;onClicked:rift.nativeDemo()}RButton{text:"Multidex + JNI demo";onClicked:rift.nativeAdvanced()}}} }
     Caption{Layout.fillWidth:true;text:"Native works offline in Live, including the bundled demo. Light limits memory; Large allows larger DEX applications and requires available RAM. Unsupported applications do not switch to another backend. Live data clears after restart.";color:"#ffc997"}
    }
   }
   ColumnLayout { spacing:18
    Title{text:studio.trText("Set the stage.","Підготуй гру.")}
    Caption{Layout.fillWidth:true;text:"Native applications use a Qt desktop window. The CPU translator does not depend on the GPU vendor. Physical NVIDIA hardware and advanced Android graphics are not certified."}
    Panel{Layout.fillWidth:true;Layout.preferredHeight:155;ColumnLayout{anchors.fill:parent;anchors.margins:22;Text{text:"CPU / GPU POWER";color:"#c3a5ff";font.pixelSize:13}Caption{Layout.fillWidth:true;text:"Open KYVEX Control Center to use the bounded CPU/GPU controls and optimization profiles. Hardware support depends on your driver."}RButton{text:"Open KYVEX controls";onClicked:rift.action("power")}}}
    Item{Layout.fillHeight:true}
   }
   ColumnLayout { spacing:14
    Title{text:studio.trText("Evidence, not guesses.","Факти замість припущень.")}
    Caption{Layout.fillWidth:true;text:"Inspection does not execute APK code. Every app uses Native in an unprivileged worker with memory limits and a syscall filter. A launch error identifies the first unsupported operation; it is not a compatibility certificate."}
    ScrollView{Layout.fillWidth:true;Layout.fillHeight:true;clip:true;TextArea{readOnly:true;textFormat:TextEdit.PlainText;text:rift.message+"\n\n"+JSON.stringify(rift.status,null,2);font.family:"monospace";font.pixelSize:12;wrapMode:TextEdit.WrapAnywhere;color:"#b5cdd7";background:Rectangle{color:"#101826";radius:12}}}
    RowLayout{RButton{text:"Stop selected app";onClicked:rift.stopApp()}RButton{text:"Remove from library";onClicked:removeDialog.open()}RButton{text:"Release all input";onClicked:rift.release()}}
   }
  }
 }
 Panel { id:logPanel;anchors.left:sidebar.right;anchors.right:parent.right;anchors.bottom:parent.bottom;anchors.margins:18;height:82
  Column{anchors.fill:parent;anchors.margins:12;spacing:6;Text{text:"RIFT / ACTIVITY";color:studio.accent;font.pixelSize:10;font.letterSpacing:2}Text{width:parent.width;text:rift.message;textFormat:Text.PlainText;color:"#a9b8d0";font.pixelSize:12;maximumLineCount:2;elide:Text.ElideRight;wrapMode:Text.WrapAnywhere}}
 }
 Connections { target:rift;function onSessionReady(android){game.androidMode=android;game.visible=true;game.requestActivate();capture.forceActiveFocus();} }
 Connections { target:rift;function onNativeReady(){nativeWindow.visible=true;nativeWindow.requestActivate();} }
 Window {
  id:nativeWindow;width:760;height:640;minimumWidth:600;minimumHeight:420
  objectName:"nativeApplicationWindow"
  flags:scene.no_title?(Qt.Window|Qt.FramelessWindowHint):Qt.Window
  property var runtimeData:rift.nativeData
  property var scene:runtimeData.scene||({})
  property var metrics:runtimeData.metrics||({})
  function argb(v){return Qt.rgba(((v>>>16)&255)/255,((v>>>8)&255)/255,(v&255)/255,((v>>>24)&255)/255)}
  title:(scene.title||"Application")+" / Rift Native";color:argb(scene.background||0xff101a2a)
  onClosing:rift.closeNative()
  ColumnLayout { anchors.fill:parent;anchors.margins:24;spacing:18
   RowLayout { Layout.fillWidth:true;Text{text:"RIFT NATIVE";color:studio.accent;font.pixelSize:12;font.letterSpacing:2;Layout.fillWidth:true}Text{text:(nativeWindow.metrics.abi||"ARM")+" · ISOLATED WORKER";color:"#a9b8d0";font.pixelSize:11} }
   Rectangle{Layout.fillWidth:true;height:1;color:"#324057"}
   ScrollView { id:nativeScroll;Layout.fillWidth:true;Layout.fillHeight:true;clip:true;contentWidth:availableWidth
    Item { width:nativeScroll.availableWidth;implicitHeight:nativeLayout.implicitHeight+(nativeWindow.scene.padding||[0,0,0,0])[1]+(nativeWindow.scene.padding||[0,0,0,0])[3]
    ColumnLayout { id:nativeLayout;x:(nativeWindow.scene.padding||[0,0,0,0])[0];y:(nativeWindow.scene.padding||[0,0,0,0])[1];width:parent.width-x-(nativeWindow.scene.padding||[0,0,0,0])[2];spacing:18
     Repeater { model:nativeWindow.scene.widgets||[]
      delegate:Item {
       required property var modelData
       Layout.fillWidth:true;visible:modelData.kind!=="column"
       implicitHeight:modelData.kind==="button"?52:appText.implicitHeight
       Text { id:appText;visible:parent.modelData.kind==="text";width:parent.width;text:parent.modelData.text;textFormat:Text.PlainText;wrapMode:Text.WordWrap;color:nativeWindow.argb(parent.modelData.color);font.pixelSize:parent.modelData.size }
       Button { visible:parent.modelData.kind==="button";anchors.fill:parent;text:parent.modelData.text;enabled:!rift.busy;onClicked:rift.nativeClick(parent.modelData.id)
        contentItem:Text{text:parent.text;textFormat:Text.PlainText;color:"#081c1b";font.pixelSize:16;font.weight:Font.DemiBold;horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter;wrapMode:Text.WordWrap}
        background:Rectangle{radius:12;color:parent.down?"#4cbda8":parent.hovered?"#a3ffe8":"#7cf5d8"}
       }
      }
     }
    }
    }
   }
   Rectangle{Layout.fillWidth:true;height:1;color:"#324057"}
   Text{Layout.fillWidth:true;text:((nativeWindow.metrics.peak_rss_kib||0)/1024).toFixed(1)+" MiB worker peak · "+(nativeWindow.metrics.jni_calls||0)+" native calls · "+(nativeWindow.metrics.events||0)+" events";color:"#91a7b7";font.pixelSize:12;textFormat:Text.PlainText;wrapMode:Text.WordWrap}
   Text{Layout.fillWidth:true;text:rift.message;color:"#b7c7d9";font.pixelSize:11;textFormat:Text.PlainText;wrapMode:Text.WordWrap;maximumLineCount:3;elide:Text.ElideRight}
  }
 }
 Window {
  id:game;property bool androidMode:false;property bool editing:false
  title:androidMode?"Rift / Android input overlay":"Rift / Touch laboratory"
  width:androidMode?Screen.desktopAvailableWidth:960;height:androidMode?Screen.desktopAvailableHeight:620
  x:androidMode?0:100;y:androidMode?0:100
  flags:androidMode?(Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint):Qt.Window
  color:androidMode?"transparent":"#091421"
  onActiveChanged:if(!active)rift.release()
  onClosing:{rift.release();rift.disconnectInput();}
  Item { id:content;anchors.centerIn:parent;width:rift.profile.orientation==="portrait"?Math.min(parent.width,parent.height*0.5625):Math.min(parent.width,parent.height/0.5625);height:rift.profile.orientation==="portrait"?width/0.5625:width*0.5625
   Rectangle{anchors.fill:parent;color:game.androidMode?"transparent":"#142d3c";border.color:game.androidMode?"#2d635f":"#418d86";radius:game.androidMode?0:20}
   Text{anchors.centerIn:parent;visible:!game.androidMode;text:"R I F T\nTOUCH LAB";horizontalAlignment:Text.AlignHCenter;color:"#376978";font.pixelSize:36;font.letterSpacing:4}
   Repeater{model:game.editing?studio.controls:[];delegate:Rectangle{required property var modelData;width:58;height:58;radius:29;x:modelData.x*content.width-29;y:modelData.y*content.height-29;color:"#8a385767";border.color:studio.accent;Text{anchors.centerIn:parent;text:parent.modelData.key;color:"white";font.pixelSize:10}}}
   Repeater{model:rift.contacts;delegate:Rectangle{required property var modelData;width:54;height:54;radius:27;x:modelData.x*content.width-27;y:modelData.y*content.height-27;color:"#457cf5d8";border.color:studio.accent;border.width:2;Text{anchors.centerIn:parent;text:"P"+parent.modelData.pointer;color:"white";font.pixelSize:12}}}
   MouseArea { anchors.fill:parent;acceptedButtons:Qt.LeftButton|Qt.RightButton;property real lastX:0;property real lastY:0
    onPressed:(m)=>{capture.forceActiveFocus();lastX=m.x;lastY=m.y;if(game.editing)return;if(m.button===Qt.RightButton)rift.key("RightMouseButton",true);else rift.touch("down",m.x/width,m.y/height);}
    onReleased:(m)=>{if(m.button===Qt.RightButton)rift.key("RightMouseButton",false);else rift.touch("up",m.x/width,m.y/height);}
    onCanceled:rift.release()
    onPositionChanged:(m)=>{if(game.editing)return;if(pressedButtons&Qt.RightButton)rift.aim((m.x-lastX)/width,(m.y-lastY)/height);else if(pressed)rift.touch("move",m.x/width,m.y/height);lastX=m.x;lastY=m.y;}
   }
  }
  Item { id:capture;anchors.fill:parent;focus:true
   Keys.onPressed:(e)=>{if(e.isAutoRepeat){e.accepted=true;return;}if(e.key===Qt.Key_Escape){game.close();e.accepted=true;return;}if(e.key===Qt.Key_F1){game.editing=!game.editing;rift.release();e.accepted=true;return;}if(!game.editing)rift.key(studio.keyName(e),true);e.accepted=true;}
   Keys.onSpacePressed:(e)=>{if(!e.isAutoRepeat&&!game.editing)rift.key("Space",true);e.accepted=true;}
   Keys.onReleased:(e)=>{if(!e.isAutoRepeat&&!game.editing)rift.key(studio.keyName(e),false);e.accepted=true;}
  }
  Rectangle{anchors.top:parent.top;anchors.horizontalCenter:parent.horizontalCenter;width:Math.min(parent.width-40,660);height:46;radius:12;color:"#e9162734";border.color:"#477a7a"
   RowLayout{anchors.fill:parent;anchors.margins:7;Text{Layout.fillWidth:true;text:(game.editing?"EDIT PREVIEW":"INPUT CAPTURE")+" · F1 mode · Esc close · "+rift.contacts.length+" fingers";color:studio.accent;font.pixelSize:12;horizontalAlignment:Text.AlignHCenter}RButton{text:"Close";implicitHeight:30;implicitWidth:70;onClicked:game.close()}}
  }
 }
}
