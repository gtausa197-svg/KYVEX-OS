//! Local Android Messenger endpoints backed by the Native Handler queue.
use super::*;

impl Runtime {
    fn messenger_binder(&mut self, handler_id: u32) -> Result<u32> {
        let Payload::Handler(handler) = &self.object(handler_id)?.payload else {
            return Err("Messenger target must be a Handler".into());
        };
        if handler.looper == 0 {
            return Err("Messenger target Handler is uninitialized".into());
        }
        if handler.messenger_binder != 0 {
            return Ok(handler.messenger_binder);
        }
        let binder = self.allocate(LOCAL_MESSENGER_BINDER, Payload::MessengerBinder(handler_id))?;
        let Payload::Handler(handler) = &mut self.object_mut(handler_id)?.payload else {
            unreachable!();
        };
        handler.messenger_binder = binder;
        Ok(binder)
    }

    fn messenger_target(&self, binder: u32) -> Result<u32> {
        let Payload::MessengerBinder(handler) = self.object(binder)?.payload else {
            return Err("Messenger requires a Native local Binder endpoint".into());
        };
        Ok(handler)
    }

    pub(super) fn messenger_api(&mut self, signature: &str, args: &[u32]) -> Result<Option<u64>> {
        let (class, method) = signature.split_once("->").ok_or("Messenger signature")?;
        let argument = |index: usize| args.get(index).copied().ok_or("Messenger argument count");
        if class == "Landroid/os/Messenger;"
            && matches!(
                method,
                "<init>(Landroid/os/Handler;)V" | "<init>(Landroid/os/IBinder;)V"
            )
        {
            let receiver = argument(0)?;
            if !matches!(self.object(receiver)?.payload, Payload::Messenger(_)) {
                return Err("Expected Messenger receiver".into());
            }
            let target = argument(1)?;
            let binder = if method == "<init>(Landroid/os/Handler;)V" {
                self.messenger_binder(target)?
            } else {
                if target != 0 {
                    self.messenger_target(target)?;
                }
                target
            };
            self.object_mut(receiver)?.payload = Payload::Messenger(binder);
            return Ok(Some(0));
        }

        let Some(&receiver) = args.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&receiver) else {
            return Ok(None);
        };
        match object.payload {
            Payload::Messenger(binder) => Ok(Some(match method {
                "getBinder()Landroid/os/IBinder;" | "hashCode()I" => {
                    self.messenger_target(binder)?;
                    binder as u64
                }
                "equals(Ljava/lang/Object;)Z" => {
                    let other = argument(1)?;
                    if other == 0 {
                        return Ok(Some(0));
                    }
                    self.messenger_target(binder)?;
                    if let Payload::Messenger(other_binder) = self.object(other)?.payload {
                        self.messenger_target(other_binder)?;
                        (binder == other_binder) as u64
                    } else {
                        0
                    }
                }
                "describeContents()I" => 0,
                "send(Landroid/os/Message;)V" => {
                    let handler = self.messenger_target(binder)?;
                    let message = argument(1)?;
                    self.message_set(message, "sendingUid", crate::identity::UID as u64)?;
                    let time = self.uptime_millis();
                    self.collection_dispatch(
                        handler,
                        "Landroid/os/Handler;",
                        "sendMessageAtTime(Landroid/os/Message;J)Z",
                        &[message, time as u32, (time >> 32) as u32],
                    )?;
                    0
                }
                _ => return Ok(None),
            })),
            Payload::MessengerBinder(handler) => Ok(Some(match method {
                "hashCode()I" => receiver as u64,
                "equals(Ljava/lang/Object;)Z" => (receiver == argument(1)?) as u64,
                "getInterfaceDescriptor()Ljava/lang/String;" => {
                    self.string("android.os.IMessenger")? as u64
                }
                "pingBinder()Z" | "isBinderAlive()Z" => {
                    self.object(handler)?;
                    1
                }
                _ => return Ok(None),
            })),
            _ => Ok(None),
        }
    }
}
