//! Owned atomic arrays; operations are indivisible in the serialized guest engine.
use super::*;
pub(super) fn kind(class: &str) -> Option<char> {
    Some(match class {
        "Ljava/util/concurrent/atomic/AtomicReferenceArray;" => 'R',
        "Ljava/util/concurrent/atomic/AtomicIntegerArray;" => 'I',
        "Ljava/util/concurrent/atomic/AtomicLongArray;" => 'J',
        _ => return None,
    })
}
impl Runtime {
    pub(super) fn atomic_array_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Atomic array signature")?;
        let Some(kind) = kind(class) else {
            return Ok(None);
        };
        let arg = |i: usize| a.get(i).copied().ok_or("Atomic array argument count");
        let name = method.split('(').next().ok_or("Atomic array method name")?;
        if !matches!(
            name,
            "<init>"
                | "length"
                | "get"
                | "set"
                | "lazySet"
                | "compareAndSet"
                | "weakCompareAndSet"
                | "getAndSet"
                | "getAndAdd"
                | "addAndGet"
                | "getAndIncrement"
                | "incrementAndGet"
                | "getAndDecrement"
                | "decrementAndGet"
        ) {
            return Ok(None);
        }
        let id = arg(0)?;
        let Payload::AtomicArray { values, .. } = &self.object(id)?.payload else {
            return Err("Expected atomic array".into());
        };
        if name == "<init>" {
            if values.is_some() {
                return Err("Atomic array is already initialized".into());
            }
            let values = if method == "<init>(I)V" {
                let count = arg(1)? as i32;
                if count < 0 {
                    return Err(fault(
                        "Ljava/lang/NegativeArraySizeException;",
                        "Negative atomic array length",
                    ));
                }
                if count > 65536 {
                    return Err("Atomic array length quota".into());
                }
                vec![0; count as usize]
            } else {
                let expected = match kind {
                    'R' => "<init>([Ljava/lang/Object;)V",
                    'I' => "<init>([I)V",
                    _ => "<init>([J)V",
                };
                if method != expected {
                    return Ok(None);
                }
                let source = self.object(arg(1)?)?;
                if !(if kind == 'R' {
                    source.class.starts_with("[L") || source.class.starts_with("[[")
                } else {
                    source.class == format!("[{kind}")
                }) {
                    return Err("Atomic array source type".into());
                }
                let Payload::Array(values) = &source.payload else {
                    return Err("Atomic array source payload".into());
                };
                if values.len() > 65536 {
                    return Err("Atomic array length quota".into());
                }
                values.clone()
            };
            if self.heap_bytes().saturating_add(values.capacity() * 8) > self.heap_limit {
                return Err("Atomic array heap quota".into());
            }
            self.object_mut(id)?.payload = Payload::AtomicArray {
                kind,
                values: Some(values),
            };
            return Ok(Some(0));
        }
        let values = values.as_ref().ok_or("Uninitialized atomic array")?;
        if method == "length()I" {
            return Ok(Some(values.len() as u64));
        }
        let index = arg(1)? as usize;
        let old = *values.get(index).ok_or_else(|| {
            fault(
                "Ljava/lang/ArrayIndexOutOfBoundsException;",
                "Atomic array index",
            )
        })?;
        if name == "get" {
            return Ok(Some(old));
        }
        let wide = kind == 'J';
        let input = |i: usize| -> Result<u64> {
            Ok(arg(i)? as u64 | if wide { (arg(i + 1)? as u64) << 32 } else { 0 })
        };
        let mut expected = None;
        let mut result = 0;
        let value = match name {
            "set" | "lazySet" => input(2)?,
            "getAndSet" => {
                result = old;
                input(2)?
            }
            "compareAndSet" | "weakCompareAndSet" => {
                expected = Some(input(2)?);
                input(if wide { 4 } else { 3 })?
            }
            _ if kind != 'R' => {
                let delta = match name {
                    "getAndIncrement" | "incrementAndGet" => 1,
                    "getAndDecrement" | "decrementAndGet" => u64::MAX,
                    _ => input(2)?,
                };
                let value = old.wrapping_add(delta);
                let value = if wide { value } else { value as u32 as u64 };
                result = if name.starts_with("getAnd") {
                    old
                } else {
                    value
                };
                value
            }
            _ => return Ok(None),
        };
        if kind == 'R' && value != 0 {
            self.object(u32::try_from(value)?)?;
        }
        if let Some(expected) = expected {
            if expected != old {
                return Ok(Some(0));
            }
            result = 1;
        }
        let Payload::AtomicArray {
            values: Some(values),
            ..
        } = &mut self.object_mut(id)?.payload
        else {
            unreachable!();
        };
        values[index] = value;
        Ok(Some(result))
    }
}
