use super::*;
impl Runtime {
    pub(in crate::vm) fn monitor_available(&self, id: u32, owner: u32) -> bool {
        self.monitors.get(&id).is_none_or(|m| m.owner == owner)
    }
    pub(in crate::vm) fn enter_monitor(&mut self, id: u32) -> Result<()> {
        self.object(id)?;
        self.ensure_main_thread()?;
        if !self.monitor_available(id, self.current_thread) {
            return self.suspend(Wait::Monitor(id)).map(|_| ());
        }
        let monitor = self.monitors.entry(id).or_insert(Monitor {
            owner: self.current_thread,
            holds: 0,
        });
        monitor.holds = monitor
            .holds
            .checked_add(1)
            .filter(|n| *n <= 100_000)
            .ok_or("Monitor depth quota")?;
        Ok(())
    }
    pub(in crate::vm) fn exit_monitor(&mut self, id: u32) -> Result<()> {
        self.object(id)?;
        let monitor = self
            .monitors
            .get_mut(&id)
            .filter(|m| m.owner == self.current_thread)
            .ok_or_else(|| {
                fault(
                    "Ljava/lang/IllegalMonitorStateException;",
                    "Current thread does not own monitor",
                )
            })?;
        monitor.holds -= 1;
        if monitor.holds == 0 {
            self.monitors.remove(&id);
        }
        Ok(())
    }
    pub(in crate::vm) fn acquire_lock_for(
        &mut self,
        id: u32,
        thread: u32,
        respect_fairness: bool,
    ) -> Result<bool> {
        if let Payload::RwView(view) = self.object(id)?.payload {
            return self.acquire_rw_for(view, thread, respect_fairness);
        }
        if respect_fairness
            && matches!(
                self.object(id)?.payload,
                Payload::Lock {
                    fair: true,
                    holds: 0,
                    ..
                }
            )
        {
            let head = self
                .scheduler
                .records
                .iter()
                .filter(
                    |(_, r)| matches!(&r.state,State::Waiting(Wait::Lock{object,..})if *object==id),
                )
                .min_by_key(|(_, r)| r.wait_order)
                .map(|(thread, _)| *thread);
            if head.is_some_and(|head| head != thread) {
                return Ok(false);
            }
        }
        let Payload::Lock { owner, holds, .. } = &mut self.object_mut(id)?.payload else {
            return Err("Expected ReentrantLock".into());
        };
        if *holds != 0 && *owner != thread {
            return Ok(false);
        }
        *holds = holds
            .checked_add(1)
            .filter(|n| *n <= 100_000)
            .ok_or("ReentrantLock depth quota")?;
        *owner = thread;
        Ok(true)
    }
    pub(in crate::vm) fn wait_for_lock(&mut self, method: &str, a: &[u32]) -> Result<Option<u64>> {
        if !matches!(
            method,
            "lock()V"
                | "lockInterruptibly()V"
                | "tryLock()Z"
                | "tryLock(JLjava/util/concurrent/TimeUnit;)Z"
        ) {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Lock argument");
        let id = arg(0)?;
        self.ensure_main_thread()?;
        let timed = method == "tryLock(JLjava/util/concurrent/TimeUnit;)Z";
        let interruptible = timed || method == "lockInterruptibly()V";
        if interruptible {
            self.check_interrupted()?;
        }
        let nanos = if timed {
            let time = u64::from(arg(1)?) | (u64::from(arg(2)?) << 32);
            self.timeout_nanos(time as i64, arg(3)?)?
        } else {
            0
        };
        let boolean = timed || method == "tryLock()Z";
        if self.acquire_lock_for(id, self.current_thread, method != "tryLock()Z")? {
            return Ok(Some(u64::from(boolean)));
        }
        if method == "tryLock()Z" || (timed && nanos <= 0) {
            return Ok(Some(0));
        }
        self.suspend(Wait::Lock {
            object: id,
            until: if timed {
                Self::deadline(nanos as u64)
            } else {
                None
            },
            interruptible,
            boolean,
        })
        .map(Some)
    }

    pub(in crate::vm) fn lock_api(&mut self, method: &str, a: &[u32]) -> Result<Option<u64>> {
        if let Some(result) = self.wait_for_lock(method, a)? {
            return Ok(Some(result));
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Lock argument");
        let id = arg(0)?;
        self.ensure_main_thread()?;
        let Payload::Lock { owner, holds, fair } = self.object(id)?.payload else {
            return Err("Expected ReentrantLock".into());
        };
        let value = match method {
            "<init>()V" | "<init>(Z)V" => {
                self.object_mut(id)?.payload = Payload::Lock {
                    owner: 0,
                    holds: 0,
                    fair: if a.len() > 1 { arg(1)? != 0 } else { false },
                };
                0
            }
            "unlock()V" => {
                if holds == 0 || owner != self.current_thread {
                    return Err(fault(
                        "Ljava/lang/IllegalMonitorStateException;",
                        "Current thread does not own lock",
                    ));
                }
                self.object_mut(id)?.payload = Payload::Lock {
                    owner: if holds == 1 { 0 } else { owner },
                    holds: holds - 1,
                    fair,
                };
                0
            }
            "getHoldCount()I" => {
                if owner == self.current_thread {
                    holds as u64
                } else {
                    0
                }
            }
            "isLocked()Z" => (holds != 0) as u64,
            "isHeldByCurrentThread()Z" => (holds != 0 && owner == self.current_thread) as u64,
            "isFair()Z" => fair as u64,
            "hasQueuedThreads()Z" | "getQueueLength()I" => {
                let count = self
                    .scheduler
                    .records
                    .values()
                    .filter(
                        |r| matches!(&r.state,State::Waiting(Wait::Lock{object,..})if *object==id),
                    )
                    .count();
                if method.starts_with("has") {
                    (count != 0) as u64
                } else {
                    count as u64
                }
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}
