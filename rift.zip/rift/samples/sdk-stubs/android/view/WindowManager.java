package android.view;
public interface WindowManager extends ViewManager { Display getDefaultDisplay(); }
