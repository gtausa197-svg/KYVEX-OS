/* ARM ELF/JNI fixture for Bionic calendar, multibyte and floating conversion. */
typedef __SIZE_TYPE__ Size;
typedef __WCHAR_TYPE__ Wide;
typedef struct {
    int sec, min, hour, mday, mon, year, wday, yday, isdst;
    long gmtoff;
    const char *zone;
} GuestTime;
typedef struct {
    unsigned char sequence[4];
#ifdef __aarch64__
    unsigned char reserved[4];
#endif
} GuestMultibyte;

extern Size strftime(char *, Size, const char *, const GuestTime *);
extern Size mbrlen(const char *, Size, GuestMultibyte *);
extern Size mbrtowc(Wide *, const char *, Size, GuestMultibyte *);
extern int strcmp(const char *, const char *);
extern double strtod(const char *, char **);
extern float strtof(const char *, char **);
extern int *__errno(void);

int Java_org_kyvex_extra_LinkChecks_nativeCLocale(void *env, void *type) {
    (void)env;
    (void)type;
    GuestTime date = { 3, 2, 1, 1, 0, 70, 4, 0, 0, 19800, "Test%TZ" };
    char text[112];
    const char expected[] = "1970-01-01 01:02:03 +0530 Test%TZ 3723";
    Size count = strftime(text, sizeof(text), "%F %T %z %Z %s", &date);
    if (count != sizeof(expected) - 1 || strcmp(text, expected)) return -1;

    date.year = 121;
    date.wday = 5;
    date.hour = 13;
    if (!strftime(text, sizeof(text), "%a %#B %_d %-H %P %G-W%V-%u %j", &date) ||
        strcmp(text, "Fri jANUARY  1 13 pm 2020-W53-5 001"))
        return -2;
    if (!strftime(text, sizeof(text), "%+ %v %% %Q", &date) ||
        strcmp(text, "Fri Jan  1 13:02:03 Test%TZ 2021  1-Jan-2021 % Q"))
        return -3;
    if (strftime(text, sizeof(text), 0, &date) != 24 ||
        strcmp(text, "Fri Jan  1 13:02:03 2021") ||
        strftime(text, 3, "%Y", &date) || strftime(0, 0, 0, 0))
        return -4;
    date.gmtoff = -12600;
    date.zone = 0;
    if (!strftime(text, sizeof(text), "%z/%Z", &date) || strcmp(text, "-0330/UTC")) return -5;
    date.isdst = -1;
    if (strftime(text, sizeof(text), "%z%Z", &date) || text[0]) return -6;

    GuestMultibyte state = { 0 };
#ifdef __aarch64__
    state.reserved[0] = 73;
#endif
    if (mbrlen("\xe2", 1, &state) != (Size)-2 || state.sequence[0] != 0xe2 ||
        mbrlen("\x82\xac!", 3, &state) != 2 || state.sequence[0] ||
        mbrlen("x", 0, &state) || mbrlen("", 1, &state))
        return -7;
    Wide wide = 99;
    if (mbrtowc(&wide, "\xf0\x9f", 2, &state) != (Size)-2 || wide != 99 ||
        mbrtowc(&wide, "\x9a\x80!", 3, &state) != 2 || wide != 0x1f680 || state.sequence[0] ||
        mbrtowc(&wide, "", 1, &state) || wide)
        return -8;
#ifdef __aarch64__
    if (state.reserved[0] != 73) return -8;
#endif
    if (mbrlen("\xe2", 1, 0) != (Size)-2 || mbrtowc(&wide, "x", 1, 0) != 1 || wide != 'x' ||
        mbrlen("\x82\xac", 2, 0) != 2 || mbrlen(0, 0, 0))
        return -9;
    *__errno() = 0;
    if (mbrlen("\xc0\x80", 2, &state) != (Size)-1 || *__errno() != 84 || state.sequence[0])
        return -10;
    state.sequence[3] = 1;
    if (mbrlen("x", 1, &state) != (Size)-1 || *__errno() != 22 || state.sequence[3])
        return -10;

    const char hex[] = " \t-0x1.8p+3tail";
    const char no_value[] = "!!";
    char *end = 0;
    *__errno() = 5;
    if (strtod(hex, &end) != -12.0 || strcmp(end, "tail") || *__errno() != 5 ||
        strtod(no_value, &end) != 0.0 || end != no_value || *__errno() != 5 ||
        strtod("1.25", 0) != 1.25)
        return -11;
    if (!__builtin_isinf(strtod("1e9999!", &end)) || *end != '!' || *__errno() != 34 ||
        !__builtin_isnan(strtod("NaN(done)", &end)) || *end)
        return -12;
    const char small[] = " -1e-9999x";
    *__errno() = 0;
    float value = strtof(small, &end);
    if (value != 0.0f || !__builtin_signbit(value) || *end != 'x' || *__errno() != 34 ||
        strtof("0x1.4p2,", &end) != 5.0f || *end != ',')
        return -13;
    return 13;
}

#ifdef RIFT_LOCALE_STANDALONE
__attribute__((noreturn)) void rift_locale_entry(void) {
    int result = Java_org_kyvex_extra_LinkChecks_nativeCLocale(0, 0);
    int code = result == 13 ? 0 : -result;
#ifdef __aarch64__
    register long argument __asm__("x0") = code;
    register long number __asm__("x8") = 93;
#else
    register long argument __asm__("r0") = code;
    register long number __asm__("r7") = 1;
#endif
    __asm__ volatile("svc #0" : : "r"(argument), "r"(number) : "memory");
    __builtin_unreachable();
}
#endif
