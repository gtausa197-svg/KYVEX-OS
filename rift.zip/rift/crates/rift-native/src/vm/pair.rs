//! Android's immutable two-reference tuple.
use super::*;

pub(super) const PAIR: &str = "Landroid/util/Pair;";
const FIRST: usize = usize::MAX - 140;
const SECOND: usize = usize::MAX - 141;

pub(super) fn declared_field(class: &str, name: &str) -> Option<(&'static str, u32)> {
    field_slot(class, name).map(|_| ("Ljava/lang/Object;", 1 | 16))
}

pub(super) fn field_slot(class: &str, name: &str) -> Option<usize> {
    match (class, name) {
        (PAIR, "first") => Some(FIRST),
        (PAIR, "second") => Some(SECOND),
        _ => None,
    }
}

pub(super) fn has_members(object: &Object) -> bool {
    object.class == PAIR || object.fields.contains_key(&FIRST)
}

impl Runtime {
    fn pair_members(&self, id: u32) -> Result<(u32, u32)> {
        let object = self.object(id)?;
        if !self.subclass(&object.class, PAIR)? {
            return Err("Expected Android Pair".into());
        }
        let read = |slot| object.fields.get(&slot).copied().unwrap_or(0) as u32;
        Ok((read(FIRST), read(SECOND)))
    }

    fn initialize_pair(&mut self, id: u32, first: u32, second: u32) -> Result<()> {
        self.pair_members(id)?;
        for member in [first, second].into_iter().filter(|member| *member != 0) {
            self.object(member)?;
        }
        let fields = &mut self.object_mut(id)?.fields;
        if fields.contains_key(&FIRST) {
            return Err("Pair has already been initialized".into());
        }
        fields.insert(FIRST, u64::from(first));
        fields.insert(SECOND, u64::from(second));
        Ok(())
    }

    pub(super) fn pair_equal(&mut self, id: u32, other: u32) -> Result<bool> {
        let (first, second) = self.pair_members(id)?;
        if other == 0 || !self.subclass(&self.object(other)?.class, PAIR)? {
            return Ok(false);
        }
        let (other_first, other_second) = self.pair_members(other)?;
        let _roots =
            self.scoped_library_roots(&[id, other, first, second, other_first, other_second])?;
        // Pair.equals invokes the other tuple's values as receivers.
        Ok(self.pair_member_equal(other_first, first)?
            && self.pair_member_equal(other_second, second)?)
    }

    fn pair_member_equal(&mut self, receiver: u32, argument: u32) -> Result<bool> {
        if receiver != 0
            && argument == 0
            && let Some(method) =
                self.callback_method(receiver, "equals", "(Ljava/lang/Object;)Z")?
        {
            return Ok(self.invoke(method, &[receiver, argument], true)? != 0);
        }
        self.value_equal(receiver, argument)
    }

    fn pair_member_units(&mut self, id: u32) -> Result<Vec<u16>> {
        if id != 0
            && let Some(method) = self.callback_method(id, "toString", "()Ljava/lang/String;")?
        {
            let value = self.invoke(method, &[id], true)? as u32;
            return if value == 0 {
                Ok("null".encode_utf16().collect())
            } else {
                self.units(value)
            };
        }
        self.object_units(id)
    }

    pub(super) fn pair_units(&mut self, id: u32) -> Result<Vec<u16>> {
        let (first, second) = self.pair_members(id)?;
        let _roots = self.scoped_library_roots(&[id, first, second])?;
        let mut units: Vec<_> = "Pair{".encode_utf16().collect();
        units.extend(self.pair_member_units(first)?);
        units.push(b' ' as u16);
        units.extend(self.pair_member_units(second)?);
        units.push(b'}' as u16);
        if units.len() > 16384 {
            return Err("Java string quota (16 KiB)".into());
        }
        Ok(units)
    }

    pub(super) fn pair_api(&mut self, signature: &str, args: &[u32]) -> Result<Option<u64>> {
        let Some(method) = signature.strip_prefix("Landroid/util/Pair;->") else {
            return Ok(None);
        };
        let arg = |index: usize| args.get(index).copied().ok_or("Pair argument count");
        let value = match method {
            "<init>(Ljava/lang/Object;Ljava/lang/Object;)V" => {
                self.initialize_pair(arg(0)?, arg(1)?, arg(2)?)?;
                0
            }
            "create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;" => {
                let (first, second) = (arg(0)?, arg(1)?);
                let id = self.allocate(PAIR, Payload::Instance)?;
                self.initialize_pair(id, first, second)?;
                u64::from(id)
            }
            "equals(Ljava/lang/Object;)Z" => u64::from(self.pair_equal(arg(0)?, arg(1)?)?),
            "hashCode()I" => {
                let id = arg(0)?;
                let (first, second) = self.pair_members(id)?;
                let _roots = self.scoped_library_roots(&[id, first, second])?;
                u64::from(self.java_key_hash(first)? ^ self.java_key_hash(second)?)
            }
            "toString()Ljava/lang/String;" => {
                let units = self.pair_units(arg(0)?)?;
                u64::from(self.string_units(units)?)
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}
