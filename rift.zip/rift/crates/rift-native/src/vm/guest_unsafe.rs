//! Unsafe operations on issued guest field capabilities and guest arrays only.
//! No offset is a host pointer; each operation is atomic on the one guest lane.
use super::*;
pub(super) const CLASS: &str = "Lsun/misc/Unsafe;";
const FIELD_BASE: u64 = 0x5246_0000_0000_0000;
const ARRAY_BASE: u64 = 16;
#[derive(Default)]
pub(super) struct State {
    pub singleton: u32,
    fields: Vec<reflection::Field>,
}
impl State {
    pub fn bytes(&self) -> usize {
        self.fields
            .iter()
            .map(|f| 64 + f.owner.len() + f.name.len() + f.descriptor.len())
            .sum()
    }
}
enum Location {
    Instance(usize),
    Static(usize),
    Array(usize),
}
#[derive(Clone, Copy)]
enum Operation {
    Read,
    Write,
    Cas,
    Add,
    Swap,
}
fn kind(descriptor: &str) -> char {
    if descriptor.starts_with(['L', '[']) {
        'R'
    } else {
        descriptor.chars().next().unwrap_or('?')
    }
}
fn scale(descriptor: &str) -> Result<u64> {
    Ok(
        match kind(
            descriptor
                .strip_prefix('[')
                .ok_or("Unsafe array Class required")?,
        ) {
            'Z' | 'B' => 1,
            'S' | 'C' => 2,
            'I' | 'F' | 'R' => 4,
            'J' | 'D' => 8,
            _ => return Err("Unsupported guest array component".into()),
        },
    )
}
fn normalize(kind: char, bits: u64) -> u64 {
    match kind {
        'Z' => (bits != 0) as u64,
        'B' => bits as i8 as i32 as u32 as u64,
        'S' => bits as i16 as i32 as u32 as u64,
        'C' => bits as u16 as u64,
        'I' | 'F' | 'R' => bits as u32 as u64,
        _ => bits,
    }
}
impl Runtime {
    pub(super) fn guest_unsafe_singleton(&mut self) -> Result<u32> {
        if self.guest_unsafe.singleton == 0 {
            self.guest_unsafe.singleton = self.allocate(CLASS, Payload::Instance)?;
        }
        Ok(self.guest_unsafe.singleton)
    }
    fn unsafe_field_offset(&mut self, field: reflection::Field, static_field: bool) -> Result<u64> {
        if (field.access & 8 != 0) != static_field {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Unsafe field storage kind",
            ));
        }
        if field.index.is_none() {
            return Err("Unsafe offsets for native field layouts are not implemented".into());
        }
        let index = if let Some(index) = self.guest_unsafe.fields.iter().position(|f| {
            f.owner == field.owner && f.name == field.name && f.descriptor == field.descriptor
        }) {
            index
        } else {
            if self.guest_unsafe.fields.len() >= 4096
                || self.heap_bytes().saturating_add(
                    128 + field.owner.len() + field.name.len() + field.descriptor.len(),
                ) > self.heap_limit
            {
                return Err("Unsafe field capability quota".into());
            }
            let index = self.guest_unsafe.fields.len();
            self.guest_unsafe.fields.push(field);
            index
        };
        Ok(FIELD_BASE + index as u64 * 16)
    }
    fn unsafe_location(
        &self,
        object: u32,
        offset: u64,
        requested: char,
    ) -> Result<(Location, String)> {
        let receiver = self.object(object)?;
        if let Payload::Array(values) = &receiver.payload {
            let component = receiver
                .class
                .strip_prefix('[')
                .ok_or("Unsafe array descriptor")?
                .to_owned();
            let width = scale(&receiver.class)?;
            let relative = offset
                .checked_sub(ARRAY_BASE)
                .ok_or("Unsafe array offset below base")?;
            let index = usize::try_from(relative / width)?;
            if !relative.is_multiple_of(width)
                || index >= values.len()
                || kind(&component) != requested
            {
                return Err("Unsafe array offset, bounds or component type invalid".into());
            }
            return Ok((Location::Array(index), component));
        }
        let relative = offset
            .checked_sub(FIELD_BASE)
            .ok_or("Unissued Unsafe field offset")?;
        if !relative.is_multiple_of(16) {
            return Err("Misaligned Unsafe field capability".into());
        }
        let field = self
            .guest_unsafe
            .fields
            .get(usize::try_from(relative / 16)?)
            .ok_or("Unknown Unsafe field capability")?;
        if kind(&field.descriptor) != requested {
            return Err("Unsafe field access type invalid".into());
        }
        let index = field.index.ok_or("Unsafe native layout unavailable")?;
        let location = if field.access & 8 != 0 {
            if !matches!(&receiver.payload, Payload::Class(owner) if *owner == field.owner) {
                return Err("Unsafe static base does not match declaring class".into());
            }
            Location::Static(index)
        } else {
            if !self.subclass(&receiver.class, &field.owner)? {
                return Err("Unsafe receiver does not match declaring class".into());
            }
            Location::Instance(index)
        };
        Ok((location, field.descriptor.clone()))
    }
    fn unsafe_read(&self, object: u32, location: &Location) -> Result<u64> {
        Ok(match location {
            Location::Instance(index) => self.load_field(object, *index)?,
            Location::Static(index) => *self.statics.get(index).unwrap_or(&0),
            Location::Array(index) => {
                let Payload::Array(values) = &self.object(object)?.payload else {
                    return Err("Unsafe array storage".into());
                };
                values[*index]
            }
        })
    }
    fn unsafe_write(
        &mut self,
        object: u32,
        location: &Location,
        descriptor: &str,
        value: u64,
    ) -> Result<()> {
        if kind(descriptor) == 'R'
            && value != 0
            && !self.subclass(&self.object(u32::try_from(value)?)?.class, descriptor)?
        {
            return Err("Unsafe reference assignment type invalid".into());
        }
        let value = normalize(kind(descriptor), value);
        match location {
            Location::Instance(index) => self.store_field(object, *index, value)?,
            Location::Static(index) => {
                self.statics.insert(*index, value);
            }
            Location::Array(index) => {
                let Payload::Array(values) = &mut self.object_mut(object)?.payload else {
                    return Err("Unsafe array storage".into());
                };
                values[*index] = value;
            }
        }
        Ok(())
    }
    pub(super) fn guest_unsafe_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Unsafe signature")?;
        if class != CLASS {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Unsafe argument count");
        if method == "getUnsafe()Lsun/misc/Unsafe;" {
            return Err(fault("Ljava/lang/SecurityException;", "Unsafe"));
        }
        let id = arg(0)?;
        self.object(id)?;
        if id != self.guest_unsafe_singleton()? {
            return Err("Invalid guest Unsafe instance".into());
        }
        match method {
            "objectFieldOffset(Ljava/lang/reflect/Field;)J"
            | "staticFieldOffset(Ljava/lang/reflect/Field;)J"
            | "staticFieldBase(Ljava/lang/reflect/Field;)Ljava/lang/Object;" => {
                let Payload::ReflectedField(field) = &self.object(arg(1)?)?.payload else {
                    return Err("Unsafe requires reflected Field".into());
                };
                let field = field.clone();
                if method.starts_with("staticFieldBase") {
                    if field.access & 8 == 0 {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Unsafe static Field required",
                        ));
                    }
                    return self.class_object(&field.owner).map(|id| Some(id as u64));
                }
                return self
                    .unsafe_field_offset(field, method.starts_with("staticFieldOffset"))
                    .map(Some);
            }
            "arrayBaseOffset(Ljava/lang/Class;)I" | "arrayIndexScale(Ljava/lang/Class;)I" => {
                let Payload::Class(class) = &self.object(arg(1)?)?.payload else {
                    return Err("Unsafe requires array Class".into());
                };
                let width = scale(class)?;
                return Ok(Some(if method.starts_with("arrayBase") {
                    ARRAY_BASE
                } else {
                    width
                }));
            }
            "addressSize()I" => return Ok(Some(if self.machine.arch == 64 { 8 } else { 4 })),
            "loadFence()V" | "storeFence()V" | "fullFence()V" => {
                std::sync::atomic::fence(std::sync::atomic::Ordering::SeqCst);
                return Ok(Some(0));
            }
            _ => {}
        }
        for (name, descriptor) in [
            ("Int", "I"),
            ("Long", "J"),
            ("Object", "Ljava/lang/Object;"),
            ("Boolean", "Z"),
            ("Byte", "B"),
            ("Short", "S"),
            ("Char", "C"),
            ("Float", "F"),
            ("Double", "D"),
        ] {
            let prefix = "Ljava/lang/Object;J";
            let operation = if method == format!("get{name}({prefix}){descriptor}")
                || method == format!("get{name}Volatile({prefix}){descriptor}")
            {
                Some(Operation::Read)
            } else if method == format!("put{name}({prefix}{descriptor})V")
                || method == format!("put{name}Volatile({prefix}{descriptor})V")
                || (matches!(name, "Int" | "Long" | "Object")
                    && method == format!("putOrdered{name}({prefix}{descriptor})V"))
            {
                Some(Operation::Write)
            } else if matches!(name, "Int" | "Long" | "Object")
                && method == format!("compareAndSwap{name}({prefix}{descriptor}{descriptor})Z")
            {
                Some(Operation::Cas)
            } else if matches!(name, "Int" | "Long" | "Object")
                && method == format!("getAndSet{name}({prefix}{descriptor}){descriptor}")
            {
                Some(Operation::Swap)
            } else if matches!(name, "Int" | "Long")
                && method == format!("getAndAdd{name}({prefix}{descriptor}){descriptor}")
            {
                Some(Operation::Add)
            } else {
                None
            };
            let Some(operation) = operation else {
                continue;
            };
            let kind = kind(descriptor);
            let object = arg(1)?;
            let (location, actual) = self.unsafe_location(object, wide(a, 2)?, kind)?;
            let old = normalize(kind, self.unsafe_read(object, &location)?);
            let read = |at: usize| -> Result<u64> {
                Ok(normalize(
                    kind,
                    if matches!(kind, 'J' | 'D') {
                        wide(a, at)?
                    } else {
                        arg(at)? as u64
                    },
                ))
            };
            let result = match operation {
                Operation::Read => old,
                Operation::Write => {
                    self.unsafe_write(object, &location, &actual, read(4)?)?;
                    0
                }
                Operation::Cas => {
                    let expected = read(4)?;
                    let value = read(if kind == 'J' { 6 } else { 5 })?;
                    if old == expected {
                        self.unsafe_write(object, &location, &actual, value)?;
                        1
                    } else {
                        0
                    }
                }
                Operation::Swap => {
                    self.unsafe_write(object, &location, &actual, read(4)?)?;
                    old
                }
                Operation::Add => {
                    let delta = read(4)?;
                    let value = if kind == 'I' {
                        (old as u32).wrapping_add(delta as u32) as u64
                    } else {
                        old.wrapping_add(delta)
                    };
                    self.unsafe_write(object, &location, &actual, value)?;
                    old
                }
            };
            return Ok(Some(result));
        }
        Err(format!("Unsupported guest Unsafe operation {method}").into())
    }
}
