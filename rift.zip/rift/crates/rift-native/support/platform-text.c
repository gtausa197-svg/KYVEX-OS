/* C ABI for the system ICU and HarfBuzz headers. The VM owns policy and quotas. */
#include <harfbuzz/hb.h>
#include <harfbuzz/hb-ot.h>
#include <unicode/uchar.h>
#include <unicode/unum.h>
#include <unicode/uregex.h>
#include <unicode/ustring.h>
#include <unicode/utf16.h>

URegularExpression *rift_regex_compile(const UChar *pattern, int32_t length, uint32_t flags,
                                       int32_t *groups, int32_t *offset, int32_t *error) {
    UParseError parse = {0};
    UErrorCode status = U_ZERO_ERROR;
    /* Android always uses Unicode classes and Unicode case folding. */
    uint32_t options = (flags & 0x3f) | UREGEX_ERROR_ON_UNKNOWN_ESCAPES;
    URegularExpression *regex = uregex_open(pattern, length, options, &parse, &status);
    if (U_SUCCESS(status)) *groups = uregex_groupCount(regex, &status);
    *offset = parse.offset;
    *error = status;
    if (U_FAILURE(status)) {
        uregex_close(regex);
        return NULL;
    }
    return regex;
}

void rift_regex_close(URegularExpression *regex) {
    uregex_close(regex);
}

URegularExpression *rift_regex_bind(const URegularExpression *code, const UChar *text,
                                    int32_t length, int32_t *error) {
    UErrorCode status = U_ZERO_ERROR;
    URegularExpression *regex = uregex_clone(code, &status);
    if (U_SUCCESS(status)) {
        uregex_setTimeLimit(regex, 32, &status);
        uregex_setStackLimit(regex, 256 * 1024, &status);
        uregex_setText(regex, text, length, &status);
    }
    *error = status;
    if (U_FAILURE(status)) {
        uregex_close(regex);
        return NULL;
    }
    return regex;
}

int32_t rift_regex_search(URegularExpression *regex, int32_t start, int32_t full,
                          int32_t groups, int32_t *ranges) {
    UErrorCode status = U_ZERO_ERROR;
    UBool matched = full ? uregex_matches(regex, start, &status)
                         : uregex_find(regex, start, &status);
    if (U_FAILURE(status)) return -status;
    if (!matched) return 0;
    for (int32_t group = 0; group < groups; group++) {
        ranges[2 * group] = uregex_start(regex, group, &status);
        ranges[2 * group + 1] = uregex_end(regex, group, &status);
    }
    return U_FAILURE(status) ? -status : 1;
}

int32_t rift_regex_group(URegularExpression *regex, const UChar *name, int32_t length) {
    UErrorCode status = U_ZERO_ERROR;
    int32_t group = uregex_groupNumberFromName(regex, name, length, &status);
    return U_FAILURE(status) ? 0 : group;
}

int32_t rift_case_map(const UChar *text, int32_t length, const char *locale,
                      int32_t upper, UChar *out, int32_t capacity) {
    UErrorCode status = U_ZERO_ERROR;
    int32_t written = upper ? u_strToUpper(out, capacity, text, length, locale, &status)
                            : u_strToLower(out, capacity, text, length, locale, &status);
    return U_FAILURE(status) ? -status : written;
}

UNumberFormat *rift_decimal_open(int32_t style, const UChar *pattern, int32_t length,
                                const char *locale, int32_t *error) {
    UNumberFormatStyle styles[] = {UNUM_DECIMAL, UNUM_DECIMAL, UNUM_PERCENT, UNUM_CURRENCY,
                                   UNUM_PATTERN_DECIMAL};
    UErrorCode status = U_ZERO_ERROR;
    UNumberFormat *format = unum_open(styles[style], pattern, length, locale, NULL, &status);
    if (U_SUCCESS(status) && style == 1) {
        unum_setAttribute(format, UNUM_MAX_FRACTION_DIGITS, 0);
        unum_setAttribute(format, UNUM_PARSE_INT_ONLY, 1);
    }
    *error = status;
    if (U_FAILURE(status)) {
        unum_close(format);
        return NULL;
    }
    return format;
}

void rift_decimal_close(UNumberFormat *format) {
    unum_close(format);
}

UNumberFormat *rift_decimal_apply(const UNumberFormat *current, const UChar *pattern,
                                 int32_t length, int32_t *error) {
    UErrorCode status = U_ZERO_ERROR;
    UNumberFormat *format = unum_clone(current, &status);
    if (U_SUCCESS(status)) unum_applyPattern(format, 0, pattern, length, NULL, &status);
    *error = status;
    if (U_FAILURE(status)) {
        unum_close(format);
        return NULL;
    }
    return format;
}

int32_t rift_decimal_format(const UNumberFormat *format, int32_t integer, int64_t bits,
                            double floating, UChar *out, int32_t capacity) {
    UErrorCode status = U_ZERO_ERROR;
    int32_t length = integer ? unum_formatInt64(format, bits, out, capacity, NULL, &status)
                             : unum_formatDouble(format, floating, out, capacity, NULL, &status);
    if (status == U_FORMAT_INEXACT_ERROR) return INT32_MIN;
    return U_FAILURE(status) ? -status : length;
}

static const UNumberFormatRoundingMode rounding_modes[] = {
    UNUM_ROUND_UP, UNUM_ROUND_DOWN, UNUM_ROUND_CEILING, UNUM_ROUND_FLOOR,
    UNUM_ROUND_HALFUP, UNUM_ROUND_HALFDOWN, UNUM_ROUND_HALFEVEN, UNUM_ROUND_UNNECESSARY,
};

int32_t rift_decimal_rounding(const UNumberFormat *format) {
    int32_t mode = unum_getAttribute(format, UNUM_ROUNDING_MODE);
    for (int32_t i = 0; i < 8; i++) {
        if (mode == (int32_t)rounding_modes[i]) return i;
    }
    return -1;
}

void rift_decimal_set_rounding(UNumberFormat *format, int32_t ordinal) {
    unum_setAttribute(format, UNUM_ROUNDING_MODE, rounding_modes[ordinal]);
}

static const UNumberFormatAttribute decimal_attributes[] = {
    UNUM_GROUPING_USED, UNUM_MIN_INTEGER_DIGITS, UNUM_MAX_INTEGER_DIGITS,
    UNUM_MIN_FRACTION_DIGITS, UNUM_MAX_FRACTION_DIGITS, UNUM_PARSE_INT_ONLY,
    UNUM_DECIMAL_ALWAYS_SHOWN, UNUM_GROUPING_SIZE, UNUM_MULTIPLIER,
};

int32_t rift_decimal_get(const UNumberFormat *format, int32_t attribute) {
    return unum_getAttribute(format, decimal_attributes[attribute]);
}

void rift_decimal_set(UNumberFormat *format, int32_t attribute, int32_t value) {
    unum_setAttribute(format, decimal_attributes[attribute], value);
}

hb_font_t *rift_font_open(const char *path) {
    hb_blob_t *blob = hb_blob_create_from_file_or_fail(path);
    if (!blob) return NULL;
    if (hb_blob_get_length(blob) > 16 * 1024 * 1024) {
        hb_blob_destroy(blob);
        return NULL;
    }
    hb_face_t *face = hb_face_create(blob, 0);
    hb_blob_destroy(blob);
    hb_font_t *font = hb_face_get_glyph_count(face) ? hb_font_create(face) : NULL;
    hb_face_destroy(face);
    if (font) {
        hb_ot_font_set_funcs(font);
        hb_font_make_immutable(font);
    }
    return font;
}

void rift_font_close(hb_font_t *font) {
    hb_font_destroy(font);
}

static hb_codepoint_t ligature(hb_font_t *font, const uint16_t *text, int32_t length) {
    hb_buffer_t *buffer = hb_buffer_create();
    hb_buffer_set_flags(buffer, HB_BUFFER_FLAG_REMOVE_DEFAULT_IGNORABLES);
    hb_buffer_add_utf16(buffer, text, length, 0, length);
    hb_buffer_guess_segment_properties(buffer);
    hb_shape(font, buffer, NULL, 0);
    unsigned count;
    const hb_glyph_info_t *info = hb_buffer_get_glyph_infos(buffer, &count);
    hb_codepoint_t glyph = count == 1 ? info[0].codepoint : 0;
    hb_buffer_destroy(buffer);
    return glyph;
}

static int regional_indicator(UChar32 code) {
    return 0x1f1e6 <= code && code <= 0x1f1ff;
}

int32_t rift_font_has_glyph(hb_font_t *font, const uint16_t *text, int32_t length) {
    UChar32 first = -1, previous = -1;
    int32_t count = 0;
    hb_codepoint_t glyph = 0;
    for (int32_t cursor = 0; cursor < length; count++) {
        UChar32 code;
        U16_NEXT(text, cursor, length, code);
        if (!U_IS_UNICODE_CHAR(code)) return 0;
        if (u_hasBinaryProperty(code, UCHAR_VARIATION_SELECTOR)) {
            if (previous < 0 || !hb_font_get_variation_glyph(font, previous, code, &glyph)) return 0;
            if (count == 1 && cursor == length) return glyph != 0;
        }
        if (count == 0) first = code;
        previous = code;
    }
    if (count == 1) {
        return !u_hasBinaryProperty(first, UCHAR_DEFAULT_IGNORABLE_CODE_POINT)
            && hb_font_get_nominal_glyph(font, first, &glyph) && glyph != 0;
    }
    glyph = ligature(font, text, length);
    if (glyph && count == 2 && regional_indicator(first) && regional_indicator(previous)) {
        const uint16_t unknown[] = {0xd83c, 0xddff, 0xd83c, 0xddff};
        if (glyph == ligature(font, unknown, 4)) return 0;
    }
    return glyph != 0;
}

/* The ordinal values are shared with WideOp in machine/c_strings.rs. */
enum rift_wide_op {
    WIDE_ALNUM, WIDE_ALPHA, WIDE_BLANK, WIDE_CONTROL, WIDE_DIGIT, WIDE_GRAPH,
    WIDE_LOWER, WIDE_PRINT, WIDE_PUNCT, WIDE_SPACE, WIDE_UPPER, WIDE_HEX,
    WIDE_TO_LOWER, WIDE_TO_UPPER
};

int32_t rift_bionic_wctype(int32_t code, uint32_t operation) {
    switch (operation) {
    case WIDE_ALNUM: return u_hasBinaryProperty(code, UCHAR_POSIX_ALNUM);
    case WIDE_ALPHA: return u_isUAlphabetic(code);
    case WIDE_BLANK: return u_hasBinaryProperty(code, UCHAR_POSIX_BLANK);
    case WIDE_CONTROL: return u_charType(code) == U_CONTROL_CHAR;
    case WIDE_DIGIT: return u_isdigit(code);
    case WIDE_GRAPH: return u_hasBinaryProperty(code, UCHAR_POSIX_GRAPH);
    case WIDE_LOWER: return u_isULowercase(code);
    case WIDE_PRINT: return u_hasBinaryProperty(code, UCHAR_POSIX_PRINT);
    case WIDE_PUNCT: return u_ispunct(code);
    case WIDE_SPACE: return u_isUWhiteSpace(code);
    case WIDE_UPPER: return u_isUUppercase(code);
    case WIDE_HEX: return u_hasBinaryProperty(code, UCHAR_POSIX_XDIGIT);
    case WIDE_TO_LOWER: return u_tolower(code);
    case WIDE_TO_UPPER: return u_toupper(code);
    default: return 0;
    }
}
