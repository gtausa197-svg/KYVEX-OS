use super::*;
impl Runtime {
    fn sql_cursor(&self, id: u32) -> Result<&Cursor> {
        let Payload::SqliteCursor(cursor) = &self.object(id)?.payload else {
            return Err("Expected SQL cursor".into());
        };
        if cursor.closed {
            return Err(fault(
                "Ljava/lang/IllegalStateException;",
                "Cursor is closed",
            ));
        }
        Ok(cursor)
    }
    fn sql_cell(&self, id: u32, column: u32) -> Result<Cell> {
        let cursor = self.sql_cursor(id)?;
        cursor
            .rows
            .values
            .get(cursor.position as usize)
            .and_then(|row| row.get(column as usize))
            .cloned()
            .ok_or_else(|| {
                fault(
                    "Landroid/database/CursorIndexOutOfBoundsException;",
                    "Cursor row or column is out of bounds",
                )
            })
    }
    pub(super) fn sqlite_cursor_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Cursor signature")?;
        if object_method(method) {
            return Ok(None);
        }
        if !matches!(
            class,
            "Landroid/database/Cursor;"
                | "Landroid/database/AbstractCursor;"
                | "Landroid/database/sqlite/SQLiteCursor;"
                | "Lorg/kyvex/rift/SqliteCursor;"
                | "Ljava/io/Closeable;"
                | "Ljava/lang/AutoCloseable;"
        ) {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Cursor argument count");
        let id = arg(0)?;
        if !matches!(self.object(id)?.payload, Payload::SqliteCursor(_)) {
            return Ok(None);
        }
        if method == "close()V" {
            let Payload::SqliteCursor(cursor) = &mut self.object_mut(id)?.payload else {
                unreachable!()
            };
            cursor.closed = true;
            cursor.rows.values = Vec::new();
            cursor.rows.columns = Vec::new();
            return Ok(Some(0));
        }
        if method == "isClosed()Z" {
            let Payload::SqliteCursor(cursor) = &self.object(id)?.payload else {
                unreachable!()
            };
            return Ok(Some(cursor.closed as u64));
        }
        let cursor = self.sql_cursor(id)?;
        let count = cursor.rows.values.len() as i32;
        let position = cursor.position;
        let result = match method {
            "getCount()I" => count as u64,
            "getPosition()I" => position as u32 as u64,
            "getColumnCount()I" => cursor.rows.columns.len() as u64,
            "isBeforeFirst()Z" => (position == -1 || count == 0) as u64,
            "isAfterLast()Z" => (position == count || count == 0) as u64,
            "isFirst()Z" => (position == 0 && count > 0) as u64,
            "isLast()Z" => (position == count - 1 && count > 0) as u64,
            "moveToFirst()Z" | "moveToLast()Z" | "moveToNext()Z" | "moveToPrevious()Z"
            | "moveToPosition(I)Z" | "move(I)Z" => {
                let target = match method {
                    "moveToFirst()Z" => 0,
                    "moveToLast()Z" => count - 1,
                    "moveToNext()Z" => position + 1,
                    "moveToPrevious()Z" => position - 1,
                    "moveToPosition(I)Z" => arg(1)? as i32,
                    _ => position.saturating_add(arg(1)? as i32),
                };
                let Payload::SqliteCursor(cursor) = &mut self.object_mut(id)?.payload else {
                    unreachable!()
                };
                cursor.position = target.clamp(-1, count);
                (target >= 0 && target < count) as u64
            }
            "getColumnIndex(Ljava/lang/String;)I"
            | "getColumnIndexOrThrow(Ljava/lang/String;)I" => {
                let name = self.text(arg(1)?)?;
                let name = name.rsplit('.').next().unwrap_or(&name);
                let index = cursor
                    .rows
                    .columns
                    .iter()
                    .position(|column| column.eq_ignore_ascii_case(name));
                match index {
                    Some(index) => index as u64,
                    None => {
                        if method.starts_with("getColumnIndexOrThrow") {
                            return Err(fault(
                                "Ljava/lang/IllegalArgumentException;",
                                "Cursor column does not exist",
                            ));
                        }
                        u32::MAX as u64
                    }
                }
            }
            "getColumnName(I)Ljava/lang/String;" => {
                let name = cursor
                    .rows
                    .columns
                    .get(arg(1)? as usize)
                    .ok_or_else(|| {
                        fault(
                            "Landroid/database/CursorIndexOutOfBoundsException;",
                            "Cursor column index",
                        )
                    })?
                    .clone();
                self.string(&name)? as u64
            }
            "getColumnNames()[Ljava/lang/String;" => {
                let names = cursor.rows.columns.clone();
                let mut values = Vec::new();
                for name in names {
                    values.push(self.string(&name)? as u64);
                }
                self.allocate("[Ljava/lang/String;", Payload::Array(values))? as u64
            }
            "getType(I)I" => match self.sql_cell(id, arg(1)?)? {
                Cell::Null => 0,
                Cell::Integer(_) => 1,
                Cell::Real(_) => 2,
                Cell::Text(_) => 3,
                Cell::Blob(_) => 4,
            },
            "isNull(I)Z" => matches!(self.sql_cell(id, arg(1)?)?, Cell::Null) as u64,
            "getString(I)Ljava/lang/String;" => match self.sql_cell(id, arg(1)?)? {
                Cell::Null => 0,
                Cell::Integer(value) => self.string(&value.to_string())? as u64,
                Cell::Real(value) => self.string(&value.to_string())? as u64,
                Cell::Text(value) => {
                    self.string_units(charsets::Encoding::Utf8.decode(&value))? as u64
                }
                Cell::Blob(_) => {
                    return Err(fault(
                        "Landroid/database/sqlite/SQLiteException;",
                        "BLOB cannot be read as a String",
                    ));
                }
            },
            "getBlob(I)[B" => match self.sql_cell(id, arg(1)?)? {
                Cell::Null => 0,
                Cell::Blob(bytes) | Cell::Text(bytes) => {
                    if bytes.len() > 16384 {
                        return Err("Cursor byte array quota".into());
                    }
                    self.allocate(
                        "[B",
                        Payload::Array(bytes.into_iter().map(|v| v as i8 as i64 as u64).collect()),
                    )? as u64
                }
                _ => {
                    return Err(fault(
                        "Landroid/database/sqlite/SQLiteException;",
                        "Numeric value cannot be read as a BLOB",
                    ));
                }
            },
            "getLong(I)J" | "getInt(I)I" | "getShort(I)S" | "getFloat(I)F" | "getDouble(I)D" => {
                let value = self.sql_cell(id, arg(1)?)?;
                let (integer, real) = match value {
                    Cell::Null => (0, 0.0),
                    Cell::Integer(v) => (v, v as f64),
                    Cell::Real(v) => (v as i64, v),
                    Cell::Text(bytes) => {
                        let text = String::from_utf8_lossy(&bytes);
                        let v = text.trim().parse::<f64>().unwrap_or(0.0);
                        let i = text.trim().parse::<i64>().unwrap_or(v as i64);
                        (i, v)
                    }
                    Cell::Blob(_) => {
                        return Err(fault(
                            "Landroid/database/sqlite/SQLiteException;",
                            "BLOB numeric conversion is unsupported",
                        ));
                    }
                };
                match method {
                    "getLong(I)J" => integer as u64,
                    "getInt(I)I" => integer as u32 as u64,
                    "getShort(I)S" => integer as i16 as i32 as u32 as u64,
                    "getFloat(I)F" => (real as f32).to_bits() as u64,
                    _ => real.to_bits(),
                }
            }
            _ => return Ok(None),
        };
        Ok(Some(result))
    }
}
