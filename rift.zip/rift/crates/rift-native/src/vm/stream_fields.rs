//! Java serialization field descriptions, not an object serialization engine.
//! Types/signatures/names are real guest metadata; no host reflection is exposed.
use super::*;
pub(super) struct Field {
    pub name: u32,
    pub ty: u32,
    pub signature: u32,
    offset: i32,
    unshared: bool,
    code: u16,
}
impl Field {
    fn primitive(&self) -> bool {
        self.code != b'L' as u16 && self.code != b'[' as u16
    }
}
impl Runtime {
    fn stream_field(&self, id: u32) -> Result<&Field> {
        match &self.object(id)?.payload {
            Payload::StreamField(field) => Ok(field),
            _ => Err("Uninitialized ObjectStreamField".into()),
        }
    }
    pub(super) fn stream_field_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("ObjectStreamField signature")?;
        if class != "Ljava/io/ObjectStreamField;" {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("ObjectStreamField argument count");
        let id = arg(0)?;
        self.object(id)?;
        if matches!(
            method,
            "<init>(Ljava/lang/String;Ljava/lang/Class;)V"
                | "<init>(Ljava/lang/String;Ljava/lang/Class;Z)V"
        ) {
            let name = arg(1)?;
            self.units(name)?; // A null name must fail, preserving raw guest UTF16 otherwise.
            let ty = arg(2)?;
            let Payload::Class(descriptor) = &self.object(ty)?.payload else {
                return Err("ObjectStreamField requires a guest Class".into());
            };
            let descriptor = descriptor.clone();
            let code = *descriptor
                .as_bytes()
                .first()
                .ok_or("Empty field type descriptor")? as u16;
            let units = self
                .dex
                .type_id(&descriptor)
                .and_then(|ty| self.dex.utf16.get(&self.dex.types[ty]))
                .cloned()
                .unwrap_or_else(|| descriptor.encode_utf16().collect());
            let signature = self.literal(units)?;
            self.object_mut(id)?.payload = Payload::StreamField(Field {
                name,
                ty,
                signature,
                code,
                unshared: a.get(3).is_some_and(|v| *v != 0),
                offset: 0,
            });
            return Ok(Some(0));
        }
        let field = self.stream_field(id)?;
        let value = match method {
            "getName()Ljava/lang/String;" => field.name as u64,
            "getType()Ljava/lang/Class;" => field.ty as u64,
            "getTypeCode()C" => field.code as u64,
            "getTypeString()Ljava/lang/String;" => {
                if field.primitive() {
                    0
                } else {
                    field.signature as u64
                }
            }
            "getOffset()I" => field.offset as u32 as u64,
            "setOffset(I)V" => {
                let offset = arg(1)? as i32;
                let Payload::StreamField(field) = &mut self.object_mut(id)?.payload else {
                    unreachable!()
                };
                field.offset = offset;
                0
            }
            "isPrimitive()Z" => field.primitive() as u64,
            "isUnshared()Z" => field.unshared as u64,
            "equals(Ljava/lang/Object;)Z" => (id == arg(1)?) as u64,
            "hashCode()I" => id as u64,
            "compareTo(Ljava/lang/Object;)I" => {
                let other = arg(1)?;
                if !self.subclass(&self.object(other)?.class, "Ljava/io/ObjectStreamField;")? {
                    return Err(fault(
                        "Ljava/lang/ClassCastException;",
                        "ObjectStreamField comparison type",
                    ));
                }
                let other = self.stream_field(other)?;
                let result = if field.primitive() != other.primitive() {
                    if field.primitive() { -1 } else { 1 }
                } else {
                    let first = self.units(field.name)?;
                    let second = self.units(other.name)?;
                    first
                        .iter()
                        .zip(&second)
                        .find_map(|(a, b)| (a != b).then_some(*a as i32 - *b as i32))
                        .unwrap_or(first.len() as i32 - second.len() as i32)
                };
                result as u32 as u64
            }
            "toString()Ljava/lang/String;" => {
                let mut units = self.units(field.signature)?;
                units.push(b' ' as u16);
                units.extend(self.units(field.name)?);
                self.string_units(units)? as u64
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}
