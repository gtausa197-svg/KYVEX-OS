//! One-lane cooperative guest Java threads. Execution frames are owned, never borrowed across switches.
use super::*;
use std::{
    collections::VecDeque,
    time::{Duration, Instant},
};
mod api;
mod driver;
mod handoff;
mod sync;
pub(super) const HANDOFF_QUEUE: &str = "Ljava/util/concurrent/SynchronousQueue;";
#[derive(Clone, Debug)]
pub(super) enum Wait {
    Yield,
    Sleep(Option<Instant>),
    Join {
        target: u32,
        until: Option<Instant>,
    },
    Monitor(u32),
    Initialization(usize),
    Object {
        object: u32,
        holds: u32,
        until: Option<Instant>,
        notified: bool,
        interrupted: bool,
    },
    Lock {
        object: u32,
        until: Option<Instant>,
        interruptible: bool,
        boolean: bool,
    },
    Latch {
        object: u32,
        until: Option<Instant>,
        boolean: bool,
    },
    Executor {
        worker: u32,
        until: Option<Instant>,
    },
    ExecutorTermination {
        pool: u32,
        until: Option<Instant>,
    },
    Future {
        task: u32,
        until: Option<Instant>,
    },
    Handoff {
        queue: u32,
        value: u32,
        until: Option<Instant>,
    },
    Park {
        until: Option<Instant>,
        blocker: u32,
    },
}
impl Wait {
    fn reference(&self) -> u32 {
        match self {
            Self::Join { target, .. } => *target,
            Self::Monitor(id) => *id,
            Self::Object { object, .. }
            | Self::Lock { object, .. }
            | Self::Latch { object, .. } => *object,
            Self::Park { blocker, .. } => *blocker,
            Self::Executor { worker, .. } => *worker,
            Self::ExecutorTermination { pool, .. } => *pool,
            Self::Future { task, .. } => *task,
            Self::Handoff { queue, .. } => *queue,
            _ => 0,
        }
    }
    fn timed(&self) -> bool {
        match self {
            Self::Sleep(_) => true,
            Self::Join { until, .. }
            | Self::Object { until, .. }
            | Self::Lock { until, .. }
            | Self::Latch { until, .. }
            | Self::Park { until, .. }
            | Self::Executor { until, .. }
            | Self::ExecutorTermination { until, .. }
            | Self::Handoff { until, .. }
            | Self::Future { until, .. } => until.is_some(),
            _ => false,
        }
    }
}
#[derive(Debug)]
pub(super) struct Signal(pub Wait);
impl std::fmt::Display for Signal {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "guest thread suspension: {:?}", self.0)
    }
}
impl std::error::Error for Signal {}
#[derive(Clone)]
pub(super) enum State {
    New,
    Runnable,
    Waiting(Wait),
    Terminated,
}
#[derive(Clone)]
pub(super) enum Completion {
    Value(u64),
    Reference(u32),
    Retry,
    Interrupted,
    FutureTimeout,
}
pub(super) struct Record {
    pub state: State,
    pub execution: Option<execution::Execution>,
    pub entry: Option<(usize, Vec<u32>)>,
    pub locals: BTreeMap<u32, u32>,
    pub interrupted: bool,
    pub permit: bool,
    pub ready: Option<Completion>,
    pub jni_exception: u32,
    pub uncaught_handler: bool,
    pub strict_mask: u32,
    pub(super) wait_order: u64,
}
impl Record {
    fn new(state: State) -> Self {
        Self {
            state,
            execution: None,
            entry: None,
            locals: BTreeMap::new(),
            interrupted: false,
            permit: false,
            ready: None,
            jni_exception: 0,
            uncaught_handler: false,
            strict_mask: 0,
            wait_order: 0,
        }
    }
    pub fn alive(&self) -> bool {
        matches!(self.state, State::Runnable | State::Waiting(_))
    }
}
#[derive(Default)]
pub(super) struct Scheduler {
    pub records: BTreeMap<u32, Record>,
    queue: VecDeque<u32>,
    pub constants: BTreeMap<u32, u32>,
    pub switches: u64,
    next_wait: u64,
}
#[derive(Clone, Copy)]
pub(super) struct Monitor {
    pub owner: u32,
    pub holds: u32,
}
impl Runtime {
    fn mark_guest_waiting(&mut self, id: u32, wait: Wait) -> Result<()> {
        self.scheduler.next_wait = self
            .scheduler
            .next_wait
            .checked_add(1)
            .ok_or("Guest wait sequence exhausted")?;
        let record = self
            .scheduler
            .records
            .get_mut(&id)
            .ok_or("Waiting thread record")?;
        record.wait_order = self.scheduler.next_wait;
        record.state = State::Waiting(wait);
        Ok(())
    }
    fn ready_guest_thread(&mut self, id: u32, completion: Completion) -> Result<()> {
        let record = self
            .scheduler
            .records
            .get_mut(&id)
            .ok_or("Waiting guest Thread")?;
        record.ready = Some(completion);
        record.state = State::Runnable;
        if id != self.main_thread {
            self.scheduler.queue.push_back(id);
        }
        Ok(())
    }
    pub(super) fn scheduler_bytes(&self) -> usize {
        self.scheduler
            .records
            .values()
            .map(|r| {
                128 + r.locals.len() * 48 + r.entry.as_ref().map_or(0, |(_, args)| args.len() * 4)
            })
            .sum::<usize>()
            + self.scheduler.queue.len() * 4
    }
    pub(super) fn ensure_main_thread(&mut self) -> Result<u32> {
        if self.main_thread == 0 {
            self.ensure_thread_groups()?;
            let thread = self.allocate("Ljava/lang/Thread;", Payload::Instance)?;
            let name = self.string("main")?;
            let group = self.main_group;
            self.object_mut(thread)?.fields.extend([
                (threads::NAME, name as u64),
                (threads::ID, 1),
                (threads::PRIORITY, 5),
                (threads::DAEMON, 0),
                (threads::GROUP, group as u64),
            ]);
            self.main_thread = thread;
            self.current_thread = thread;
            self.scheduler
                .records
                .insert(thread, Record::new(State::Runnable));
        }
        Ok(self.main_thread)
    }
    pub(super) fn current_guest_tid(&self) -> u32 {
        self.heap
            .get(&self.current_thread)
            .and_then(|o| o.fields.get(&threads::ID))
            .copied()
            .unwrap_or(1) as u32
    }
    pub(super) fn can_suspend(&self) -> bool {
        self.suspension_allowed
    }
    pub(super) fn suspend(&self, wait: Wait) -> Result<u64> {
        if !self.can_suspend() {
            return Err("Blocking inside synchronous library callbacks is not implemented".into());
        }
        Err(Box::new(Signal(wait)))
    }
    pub(super) fn check_interrupted(&mut self) -> Result<()> {
        self.ensure_main_thread()?;
        let record = self
            .scheduler
            .records
            .get_mut(&self.current_thread)
            .ok_or("Current guest thread record")?;
        if record.interrupted {
            record.interrupted = false;
            return Err(fault(
                "Ljava/lang/InterruptedException;",
                "Guest thread interrupted",
            ));
        }
        Ok(())
    }
    pub(super) fn register_thread(&mut self, id: u32) -> Result<()> {
        if self.scheduler.records.len() >= 256 {
            return Err("Guest thread object quota (256)".into());
        }
        let mut record = Record::new(State::New);
        let inherited: Vec<_> = self
            .thread_local_values
            .iter()
            .map(|(k, v)| (*k, *v))
            .collect();
        for (key, value) in inherited {
            if !self.heap.contains_key(&key)
                || !self.subclass(
                    &self.object(key)?.class,
                    "Ljava/lang/InheritableThreadLocal;",
                )?
            {
                continue;
            }
            let value = if let Some(method) =
                self.callback_method(key, "childValue", "(Ljava/lang/Object;)Ljava/lang/Object;")?
            {
                self.invoke(method, &[key, value], true)? as u32
            } else {
                value
            };
            record.locals.insert(key, value);
        }
        self.scheduler.records.insert(id, record);
        Ok(())
    }
    fn switch_guest_thread(&mut self, id: u32) -> Result<()> {
        if id == self.current_thread {
            return Ok(());
        }
        if !self.callers.is_empty() {
            return Err("Guest thread switch requires a detached execution stack".into());
        }
        let tid = self
            .object(id)?
            .fields
            .get(&threads::ID)
            .copied()
            .ok_or("Guest thread id")? as u32;
        self.machine.activate_thread(tid)?;
        let old = self
            .scheduler
            .records
            .get_mut(&self.current_thread)
            .ok_or("Previous guest thread record")?;
        old.locals = std::mem::take(&mut self.thread_local_values);
        old.jni_exception = std::mem::replace(&mut self.pending_jni_exception, 0);
        let next = self
            .scheduler
            .records
            .get_mut(&id)
            .ok_or("Next guest thread record")?;
        self.thread_local_values = std::mem::take(&mut next.locals);
        self.pending_jni_exception = std::mem::replace(&mut next.jni_exception, 0);
        self.current_thread = id;
        self.scheduler.switches += 1;
        Ok(())
    }
    pub(super) fn start_guest_thread(&mut self, id: u32) -> Result<u64> {
        self.ensure_main_thread()?;
        let record = self
            .scheduler
            .records
            .get(&id)
            .ok_or("Uninitialized guest Thread")?;
        if !matches!(record.state, State::New) {
            return Err(fault(
                "Ljava/lang/IllegalThreadStateException;",
                "Thread has already been started",
            ));
        }
        if self
            .scheduler
            .records
            .values()
            .filter(|r| r.alive())
            .count()
            >= 64
        {
            return Err("Live guest thread quota (64)".into());
        }
        let entry = if let Some(method) = self.callback_method(id, "run", "()V")? {
            Some((method, vec![id]))
        } else {
            let target = self
                .object(id)?
                .fields
                .get(&threads::TARGET)
                .copied()
                .unwrap_or(0) as u32;
            if target == 0 {
                None
            } else {
                Some((
                    self.callback_method(target, "run", "()V")?
                        .ok_or("Guest Runnable.run implementation absent")?,
                    vec![target],
                ))
            }
        };
        let record = self.scheduler.records.get_mut(&id).unwrap();
        record.entry = entry;
        record.state = State::Runnable;
        let group = self.thread_group(id)?;
        if let Err(error) = self.group_thread_started(group) {
            let record = self.scheduler.records.get_mut(&id).unwrap();
            record.entry = None;
            record.state = State::New;
            return Err(error);
        }
        self.scheduler.queue.push_back(id);
        if self.can_suspend() {
            self.suspend(Wait::Yield)
        } else {
            Ok(0)
        }
    }
    fn finish_guest_thread(&mut self, id: u32) -> Result<()> {
        let record = self
            .scheduler
            .records
            .get_mut(&id)
            .ok_or("Terminating guest thread")?;
        record.state = State::Terminated;
        record.execution = None;
        record.entry = None;
        record.locals.clear();
        record.interrupted = false;
        record.ready = None;
        record.jni_exception = 0;
        if id == self.current_thread {
            self.thread_local_values.clear();
            self.pending_jni_exception = 0;
        }
        let group = self.thread_group(id)?;
        self.object_mut(id)?.fields.extend([
            (threads::TARGET, 0),
            (threads::GROUP, 0),
            (threads::HANDLER, 0),
        ]);
        self.group_maybe_destroy(group)?;
        Ok(())
    }
    fn take_completion(&mut self, id: u32) -> Result<Option<Completion>> {
        Ok(self
            .scheduler
            .records
            .get_mut(&id)
            .ok_or("Guest thread completion record")?
            .ready
            .take())
    }
    pub(super) fn state_object(&mut self, id: u32) -> Result<u32> {
        let state = match &self
            .scheduler
            .records
            .get(&id)
            .ok_or("Guest Thread state")?
            .state
        {
            State::New => 0,
            State::Runnable => 1,
            State::Terminated => 5,
            State::Waiting(Wait::Monitor(_)) => 2,
            State::Waiting(wait) => {
                if wait.timed() {
                    4
                } else {
                    3
                }
            }
        };
        self.thread_state_constant(state)
    }
    pub(super) fn thread_state_constant(&mut self, ordinal: u32) -> Result<u32> {
        if let Some(id) = self.scheduler.constants.get(&ordinal) {
            return Ok(*id);
        }
        let names = [
            "NEW",
            "RUNNABLE",
            "BLOCKED",
            "WAITING",
            "TIMED_WAITING",
            "TERMINATED",
        ];
        let name = self.literal(
            names
                .get(ordinal as usize)
                .ok_or("Thread.State ordinal")?
                .encode_utf16()
                .collect(),
        )?;
        let id = self.allocate("Ljava/lang/Thread$State;", Payload::Enum { name, ordinal })?;
        self.scheduler.constants.insert(ordinal, id);
        Ok(id)
    }
    pub(super) fn deadline(nanos: u64) -> Option<Instant> {
        Instant::now().checked_add(Duration::from_nanos(nanos))
    }
    pub(super) fn scheduler_roots(&self) -> Vec<u32> {
        let mut roots: Vec<u32> = self
            .scheduler
            .records
            .iter()
            .filter(|(_, r)| r.alive())
            .map(|(id, _)| *id)
            .collect();
        roots.extend(self.scheduler.constants.values());
        roots
    }
    pub(super) fn scheduler_object_roots(&self, id: u32) -> Vec<u32> {
        let Some(record) = self.scheduler.records.get(&id) else {
            return Vec::new();
        };
        let mut roots: Vec<_> = record.locals.values().copied().collect();
        if let Some((_, args)) = &record.entry {
            roots.extend(args);
        }
        if let State::Waiting(wait) = &record.state {
            roots.push(wait.reference());
            if let Wait::Handoff { value, .. } = wait {
                roots.push(*value);
            }
        }
        if let Some(Completion::Reference(reference)) = record.ready {
            roots.push(reference);
        }
        roots.push(record.jni_exception);
        roots
    }
}
