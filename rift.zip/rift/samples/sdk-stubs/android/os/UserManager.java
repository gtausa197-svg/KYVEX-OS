package android.os;
/** Compile-only signature; excluded from APK. */
public class UserManager {public boolean isUserUnlocked(){return false;}}
