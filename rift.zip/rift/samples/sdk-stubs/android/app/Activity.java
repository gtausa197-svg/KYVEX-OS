package android.app;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
public class Activity extends Context {
    protected void onCreate(Bundle state) {}
    public void setContentView(View view) {}
    public void setTitle(CharSequence text) {}
    public android.content.Intent getIntent(){return null;}
    public void setIntent(android.content.Intent intent){}
}
