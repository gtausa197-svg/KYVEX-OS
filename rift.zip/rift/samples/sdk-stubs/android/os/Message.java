package android.os;
public final class Message {
    public int what,arg1,arg2;
    public Object obj;
    public int sendingUid;
    public Messenger replyTo;
    public Handler getTarget(){return null;}
}
