package org.kyvex.extra;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Identical assertions run on stock Java8 and in the real DEX worker. */
public final class LoggingChecks {
 private static int checks;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 public static final class Custom extends Level {
  public Custom(String name,int value){super(name,value);}
 }
 public static int verify(){
  checks=0;
  Level[] levels={Level.OFF,Level.SEVERE,Level.WARNING,Level.INFO,Level.CONFIG,Level.FINE,Level.FINER,Level.FINEST,Level.ALL};
  int[] values={Integer.MAX_VALUE,1000,900,800,700,500,400,300,Integer.MIN_VALUE};
  String[] names={"OFF","SEVERE","WARNING","INFO","CONFIG","FINE","FINER","FINEST","ALL"};
  for(int i=0;i<levels.length;i++){
   check(levels[i].intValue()==values[i]&&levels[i].hashCode()==values[i],"Exact standard Level value");
   check(names[i].equals(levels[i].getName())&&names[i].equals(levels[i].toString()),"Canonical Level name");
  }
  Level custom=new Custom("CUSTOM",750),alias=new Custom("ALIAS",750),different=new Custom("CUSTOM",751);
  check(custom!=alias&&custom.equals(alias)&&alias.equals(custom)&&!custom.equals(different),"Level equality uses the integer value");
  check(!custom.equals(null)&&!custom.equals("CUSTOM")&&custom.hashCode()==750,"Level equality type and hash");
  check(custom instanceof Serializable&&"CUSTOM".equals(String.valueOf(custom)),"Level class ancestry and object string");
  boolean rejected=false;try{new Custom(null,1);}catch(NullPointerException expected){rejected=true;}check(rejected,"Null Level name rejected");
  Logger root=Logger.getLogger("");Level previousRoot=root.getLevel();root.setLevel(Level.INFO);
  check("".equals(root.getName())&&root.getParent()==null&&root.getLevel()==Level.INFO,"Actual root Logger");
  Logger global=Logger.getGlobal();
  check(global==Logger.global&&global==Logger.getLogger(Logger.GLOBAL_LOGGER_NAME)&&"global".equals(global.getName()),"One canonical global Logger");
  check(global.getParent()==root&&global.getLevel()==null&&global.getResourceBundleName()==null,"Global parent and default state");
  String name="org.kyvex.jul.parent.child";
  Logger leaf=Logger.getLogger(name);
  check(leaf==Logger.getLogger(new String(name))&&leaf!=global&&name.equals(leaf.getName()),"Named identity uses UTF16 string contents");
  check(leaf.getParent()==root&&leaf.getLevel()==null,"Initial root inheritance");
  Logger parent=Logger.getLogger("org.kyvex.jul.parent");
  check(leaf.getParent()==parent&&parent.getParent()==root,"Late parent registration reparents child");
  Logger ancestor=Logger.getLogger("org.kyvex.jul");
  check(parent.getParent()==ancestor&&leaf.getParent()==parent,"Nearest ancestor remains parent");
  check(Logger.getLogger("org.kyvex.jul.parental").getParent()==ancestor,"Namespace boundaries require a dot");
  Logger unicode=Logger.getLogger("\u043a\u0438\u0457\u0432.\ud83d\ude00");
  Logger unicodeParent=Logger.getLogger("\u043a\u0438\u0457\u0432");
  check(unicode.getParent()==unicodeParent&&"\u043a\u0438\u0457\u0432.\ud83d\ude00".equals(unicode.getName()),"Unicode hierarchy and exact name");
  Logger anonymous=Logger.getAnonymousLogger(),second=Logger.getAnonymousLogger();
  check(anonymous!=second&&anonymous.getName()==null&&anonymous.getParent()==root&&anonymous.getLevel()==null,"Independent anonymous loggers");
  check(leaf.isLoggable(Level.INFO)&&!leaf.isLoggable(Level.FINE),"Default inherited INFO level");
  ancestor.setLevel(Level.FINE);check(leaf.isLoggable(Level.FINE)&&!leaf.isLoggable(Level.FINER),"Dynamic ancestor level");
  parent.setLevel(Level.WARNING);check(!leaf.isLoggable(Level.INFO)&&leaf.isLoggable(Level.SEVERE),"Nearest explicit level");
  leaf.setLevel(custom);check(leaf.getLevel()==custom&&leaf.isLoggable(Level.INFO)&&!leaf.isLoggable(Level.CONFIG),"Custom level retained and applied");
  leaf.setLevel(null);check(leaf.getLevel()==null&&!leaf.isLoggable(Level.INFO),"Null restores parent inheritance");
  parent.setLevel(null);ancestor.setLevel(null);check(leaf.isLoggable(Level.INFO)&&!leaf.isLoggable(Level.FINE),"Null ancestors restore root inheritance");
  for(int i=0;i<levels.length;i++){
   leaf.setLevel(levels[i]);
   for(int j=0;j<levels.length;j++)check(leaf.isLoggable(levels[j])==(values[i]!=Integer.MAX_VALUE&&values[j]>=values[i]),"All Level thresholds including OFF/ALL");
  }
  leaf.setLevel(new Custom("CUSTOM_OFF",Integer.MAX_VALUE));check(!leaf.isLoggable(Level.OFF)&&!leaf.isLoggable(Level.ALL),"Custom maximum value disables logging");
  root.setLevel(null);leaf.setLevel(null);check(leaf.isLoggable(Level.INFO)&&!leaf.isLoggable(Level.FINE),"Null root falls back to INFO");root.setLevel(Level.INFO);
  rejected=false;try{Logger.getLogger(null);}catch(NullPointerException expected){rejected=true;}check(rejected,"Null Logger name rejected");
  rejected=false;try{leaf.isLoggable(null);}catch(NullPointerException expected){rejected=true;}check(rejected,"Null requested Level rejected");
  leaf.setLevel(Level.INFO);
  for(int i=0;i<35;i++)leaf.info("bounded-probe-"+i);
  leaf.setLevel(Level.FINE);leaf.fine("fine-probe");
  leaf.setLevel(Level.OFF);leaf.warning("must-not-appear");leaf.setLevel(Level.INFO);
  leaf.log(Level.WARNING,"diagnostic-probe",new IllegalStateException("log-cause"));
  leaf.log(Level.INFO,(String)null);
  leaf.info("unicode-\u043a\u0438\u0457\u0432-\ud83d\ude00");
  StringBuilder large=new StringBuilder("long-probe-");for(int i=0;i<3000;i++)large.append('x');leaf.info(large.toString());
  root.setLevel(previousRoot);
  return checks;
 }
 public static void main(String[] args){System.out.println("Logging checks: "+verify());}
}
