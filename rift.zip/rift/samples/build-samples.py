#!/usr/bin/env python3
"""Build the first-party Java + JNI APK with official D8, and ARM ELF fixtures."""
import argparse,hashlib,json,pathlib,struct,subprocess,tempfile,zipfile
p=argparse.ArgumentParser();p.add_argument('--r8',required=True);p.add_argument('--output',required=True);a=p.parse_args()
here=pathlib.Path(__file__).resolve().parent;out=pathlib.Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
toolchain=json.loads((here/'TOOLCHAIN.json').read_text())
if hashlib.sha256(pathlib.Path(a.r8).read_bytes()).hexdigest()!=toolchain['r8_sha256']:raise SystemExit('D8/R8 build tool digest differs from the pinned version')
def run(*args):subprocess.run([str(v) for v in args],check=True)
for abi,target,arch in [('arm64-v8a','aarch64-linux-android23','a64'),('armeabi-v7a','armv7a-linux-androideabi23','a32')]:
    directory=out/abi;directory.mkdir(exist_ok=True)
    run('clang','--target='+target,'-nostdlib','-shared','-fuse-ld=lld','-Wl,--hash-style=sysv','-Wl,-z,max-page-size=4096','-Wl,-soname,libkyvexdemo.so',here/'asm'/('jni-'+arch+'.S'),'-o',directory/'libkyvexdemo.so')
    run('clang','--target='+target,'-nostdlib','-static','-fuse-ld=lld','-Wl,-z,max-page-size=4096',here/'asm'/('elf-'+arch+'.S'),'-o',out/('hello-'+arch+'.elf'))
    run('clang','--target='+target,'-nostdlib','-static','-fuse-ld=lld','-Wl,-z,max-page-size=4096',here/'asm'/('simd-'+arch+'.S'),'-o',out/('simd-'+arch+'.elf'))
    run('clang','--target='+target,'-nostdlib','-shared','-fuse-ld=lld','-Wl,--hash-style=sysv','-Wl,--pack-dyn-relocs=none','-Wl,-e,_start','-Wl,-z,max-page-size=4096',here/'asm'/('import-'+arch+'.S'),'-o',out/('import-'+arch+'.elf'))
    run('clang','--target='+target,'-nostdlib','-shared','-fuse-ld=lld','-Wl,--hash-style=sysv','-Wl,--pack-dyn-relocs=android','-Wl,-e,_start','-Wl,-z,max-page-size=4096',here/'asm'/('import-'+arch+'.S'),'-o',out/('packed-'+arch+'.elf'))
from manifest import manifest
with tempfile.TemporaryDirectory(prefix='rift-sample-') as temp:
    temp=pathlib.Path(temp);sdk=temp/'sdk';sdk.mkdir();classes=temp/'classes';classes.mkdir();dex=temp/'dex';dex.mkdir()
    run('javac','--release','8','-d',sdk,*sorted((here/'sdk-stubs').rglob('*.java')))
    run('jar','cf',temp/'sdk.jar','-C',sdk,'.')
    run('javac','--release','8','-classpath',temp/'sdk.jar','-d',classes,*sorted((here/'native-demo').rglob('*.java')))
    run('java','-cp',a.r8,'com.android.tools.r8.D8','--release','--min-api','23','--lib','/usr/lib/jvm/default','--classpath',temp/'sdk.jar','--output',dex,*sorted(classes.rglob('*.class')))
    apk=out/'rift-native-demo.apk'
    with zipfile.ZipFile(apk,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('AndroidManifest.xml',manifest());z.write(dex/'classes.dex','classes.dex')
        for abi in ['arm64-v8a','armeabi-v7a']:z.write(out/abi/'libkyvexdemo.so','lib/'+abi+'/libkyvexdemo.so')
    # Disposable test certificate; the private key is never included in a release.
    run('keytool','-genkeypair','-keystore',temp/'test.keystore','-storepass','kyvex-native-demo','-keypass','kyvex-native-demo','-alias','sample','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=KYVEX Native Sample')
    run('jarsigner','-keystore',temp/'test.keystore','-storepass','kyvex-native-demo','-keypass','kyvex-native-demo','-sigalg','SHA256withRSA','-digestalg','SHA-256',apk,'sample')
    (out/'sample-build.json').write_text(json.dumps(dict(package='org.kyvex.nativehello',sha256=hashlib.sha256(apk.read_bytes()).hexdigest(),r8_sha256=hashlib.sha256(pathlib.Path(a.r8).read_bytes()).hexdigest(),sdk_stubs_in_apk=False),indent=2)+'\n')
    with zipfile.ZipFile(apk) as z:assert z.testzip() is None
print('Built signed standard Java/DEX APK and real ARM32/ARM64 JNI libraries:',out)
