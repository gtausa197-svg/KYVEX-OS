//! Guest machine, narrow syscall/HLE dispatch and JNI trap interface.
use crate::{
    Result,
    cpu::{Cpu, State},
    elf::{self, Image},
    memory::{EXEC, Memory, READ, WRITE},
};
use std::{
    collections::BTreeMap,
    time::{Instant, SystemTime, UNIX_EPOCH},
};
mod apk_link;
mod c_format;
mod c_locale;
mod c_scan;
mod c_strings;
mod heap;
mod integer;
mod native_log;
mod pthreads;
mod stdio;

const IMAGE_BASE: u64 = 0x01000000;
const MAX_IMAGES: usize = ((elf::ADDRESS_LIMIT - IMAGE_BASE) / elf::SHARED_SLOT) as usize;

fn image_bias(slot: usize) -> u64 {
    IMAGE_BASE + slot as u64 * elf::SHARED_SLOT
}
pub const JNI_ENV: u64 = 0x70000000;
pub const JAVA_VM: u64 = 0x70006000;
const VM_TABLE: u64 = 0x70007000;
const VM_CODE: u64 = 0x70008000;
const TLS: u64 = 0x7000a000;
const JNI_TABLE: u64 = 0x70001000;
const JNI_CODE: u64 = 0x70002000;
const RETURN: u64 = 0x70004000;
const ONCE_RETURN: u64 = RETURN + 16;
const C_CODE: u64 = 0x70005000;
const THREAD_CONTEXT_BASE: u64 = 0x70010000;
const THREAD_CONTEXT_SLOTS: u32 = 63;
const THREAD_CONTEXT_END: u64 = THREAD_CONTEXT_BASE + THREAD_CONTEXT_SLOTS as u64 * 8192;
const STACK_TOP: u64 = 0x7ff00000;
const JNI_SVC: u32 = 0x4000;
const C_SVC: u32 = 0x2000;
const RETURN_SVC: u32 = 0x7fff;
const ONCE_RETURN_SVC: u32 = 0x7ffe;
#[derive(Debug)]
pub enum Trap {
    Returned(u64),
    Jni(u32),
    Vm(u32),
    Exit(i32),
}
const C_FUNCTIONS: &[(&str, &str)] = &[
    ("libc.so", "strlen"),
    ("libc.so", "memcpy"),
    ("libc.so", "memmove"),
    ("libc.so", "memset"),
    ("libc.so", "memcmp"),
    ("libc.so", "__stack_chk_fail"),
    ("libc.so", "abort"),
    ("libc.so", "__cxa_finalize"),
    ("libc.so", "__cxa_atexit"),
    ("libc.so", "__aeabi_memcpy"),
    ("libc.so", "__aeabi_memcpy4"),
    ("libc.so", "__aeabi_memcpy8"),
    ("libc.so", "__aeabi_memmove"),
    ("libc.so", "__aeabi_memmove4"),
    ("libc.so", "__aeabi_memmove8"),
    ("libc.so", "__aeabi_memset"),
    ("libc.so", "__aeabi_memset4"),
    ("libc.so", "__aeabi_memset8"),
    ("libc.so", "__aeabi_memclr"),
    ("libc.so", "__aeabi_memclr4"),
    ("libc.so", "__aeabi_memclr8"),
    ("liblog.so", "__android_log_write"),
    ("liblog.so", "__android_log_print"),
    ("liblog.so", "__android_log_assert"),
    ("libz.so", "adler32"),
    ("libc.so", "malloc"),
    ("libc.so", "calloc"),
    ("libc.so", "realloc"),
    ("libc.so", "free"),
    ("libc.so", "memalign"),
    ("libc.so", "malloc_usable_size"),
    ("libc.so", "__errno"),
    ("libc.so", "strtol"),
    ("libc.so", "strtoll"),
    ("libc.so", "strtoul"),
    ("libc.so", "strtoull"),
    ("libc.so", "strtoimax"),
    ("libc.so", "strtoumax"),
    ("libc.so", "fwrite"),
    ("libc.so", "fread"),
    ("libc.so", "fputc"),
    ("libc.so", "fgetc"),
    ("libc.so", "fputs"),
    ("libc.so", "puts"),
    ("libc.so", "putchar"),
    ("libc.so", "getchar"),
    ("libc.so", "fflush"),
    ("libc.so", "fileno"),
    ("libc.so", "feof"),
    ("libc.so", "ferror"),
    ("libc.so", "clearerr"),
    ("libc.so", "fprintf"),
    ("libc.so", "vfprintf"),
    ("libc.so", "snprintf"),
    ("libc.so", "vsnprintf"),
    ("libc.so", "__vsprintf_chk"),
    ("libc.so", "__vsnprintf_chk"),
    ("libc.so", "sscanf"),
    ("libc.so", "vsscanf"),
    ("libc.so", "asprintf"),
    ("libc.so", "vasprintf"),
    ("libc.so", "pthread_create"),
    ("libc.so", "pthread_self"),
    ("libc.so", "pthread_equal"),
    ("libc.so", "pthread_join"),
    ("libc.so", "pthread_detach"),
    ("libc.so", "pthread_exit"),
    ("libc.so", "pthread_once"),
    ("libc.so", "pthread_mutexattr_init"),
    ("libc.so", "pthread_mutexattr_destroy"),
    ("libc.so", "pthread_mutexattr_settype"),
    ("libc.so", "pthread_mutex_init"),
    ("libc.so", "pthread_mutex_destroy"),
    ("libc.so", "pthread_mutex_lock"),
    ("libc.so", "pthread_mutex_trylock"),
    ("libc.so", "pthread_mutex_unlock"),
    ("libc.so", "sched_yield"),
    ("libc.so", "isalnum"),
    ("libc.so", "isalpha"),
    ("libc.so", "isblank"),
    ("libc.so", "iscntrl"),
    ("libc.so", "isdigit"),
    ("libc.so", "isgraph"),
    ("libc.so", "islower"),
    ("libc.so", "isprint"),
    ("libc.so", "ispunct"),
    ("libc.so", "isspace"),
    ("libc.so", "isupper"),
    ("libc.so", "isxdigit"),
    ("libc.so", "tolower"),
    ("libc.so", "toupper"),
    ("libc.so", "iswalnum"),
    ("libc.so", "iswalpha"),
    ("libc.so", "iswblank"),
    ("libc.so", "iswcntrl"),
    ("libc.so", "iswdigit"),
    ("libc.so", "iswgraph"),
    ("libc.so", "iswlower"),
    ("libc.so", "iswprint"),
    ("libc.so", "iswpunct"),
    ("libc.so", "iswspace"),
    ("libc.so", "iswupper"),
    ("libc.so", "iswxdigit"),
    ("libc.so", "towlower"),
    ("libc.so", "towupper"),
    ("libc.so", "strcmp"),
    ("libc.so", "strcoll"),
    ("libc.so", "strncmp"),
    ("libc.so", "strxfrm"),
    ("libc.so", "strncpy"),
    ("libc.so", "strstr"),
    ("libc.so", "memchr"),
    ("libc.so", "wcscoll"),
    ("libc.so", "wcslen"),
    ("libc.so", "wcsxfrm"),
    ("libc.so", "wmemchr"),
    ("libc.so", "wmemcmp"),
    ("libc.so", "wmemcpy"),
    ("libc.so", "wmemmove"),
    ("libc.so", "wmemset"),
    ("libc.so", "btowc"),
    ("libc.so", "wctob"),
    ("libc.so", "strtoll_l"),
    ("libc.so", "strtoull_l"),
    ("libc.so", "strftime"),
    ("libc.so", "mbrlen"),
    ("libc.so", "mbrtowc"),
    ("libc.so", "strtod"),
    ("libc.so", "strtof"),
];
const _: () = assert!(C_FUNCTIONS.len() * 16 <= 4096);

enum NativeStep {
    Resume,
    Yield,
    Quantum,
    Trap(Trap),
    Wait(pthreads::Wait),
    ThreadExit(u64),
}

pub struct Machine {
    pub cpu: Cpu,
    pub arch: u32,
    pub images: BTreeMap<String, Image>,
    platforms: BTreeMap<&'static str, BTreeMap<String, u64>>,
    heap: heap::Heap,
    pub(crate) pending_logs: Vec<String>,
    pub stdout: Vec<u8>,
    console_lines: [Vec<u8>; 2],
    pub unsupported_syscalls: Vec<u64>,
    started: Instant,
    brk: u64,
    mmap: u64,
    fuel: u64,
    pub calls: u64,
    pub ticks: u64,
    pub jni_env: u64,
    current_tid: u32,
    thread_slots: BTreeMap<u32, u32>,
    pthreads: pthreads::Pthreads,
}
impl Machine {
    pub fn new(arch: u32, memory_mib: usize, cache_mib: usize) -> Result<Self> {
        if !matches!(arch, 32 | 64)
            || !(8..=256).contains(&memory_mib)
            || !(2..=32).contains(&cache_mib)
        {
            return Err("Invalid native machine budget".into());
        }
        let mut m = Memory::new(memory_mib * 1024 * 1024);
        m.map(JNI_ENV, 4096, READ)?;
        m.map(JNI_TABLE, 4096, READ)?;
        m.map(JNI_CODE, 8192, READ | EXEC)?;
        m.map(RETURN, 4096, READ | EXEC)?;
        m.map(C_CODE, 4096, READ | EXEC)?;
        m.map(JAVA_VM, 4096, READ)?;
        m.map(VM_TABLE, 4096, READ)?;
        m.map(VM_CODE, 4096, READ | EXEC)?;
        m.map(TLS, 4096, READ | WRITE)?;
        m.map(STACK_TOP - 65536, 65536, READ | WRITE)?;
        let pointer = |p: u64| {
            if arch == 64 {
                p.to_le_bytes().to_vec()
            } else {
                (p as u32).to_le_bytes().to_vec()
            }
        };
        let stub = |imm: u32| {
            if arch == 64 {
                [0xd4000001u32 | (imm << 5), 0xd65f03c0]
                    .iter()
                    .flat_map(|v| v.to_le_bytes())
                    .collect::<Vec<_>>()
            } else {
                [0xef000000u32 | imm, 0xe12fff1e]
                    .iter()
                    .flat_map(|v| v.to_le_bytes())
                    .collect::<Vec<_>>()
            }
        };
        m.initialize(JNI_ENV, &pointer(JNI_TABLE))?;
        m.initialize(JAVA_VM, &pointer(VM_TABLE))?;
        for i in 3..8 {
            let at = VM_CODE + i * 16;
            m.initialize(at, &stub(0x5000 + i as u32))?;
            m.initialize(VM_TABLE + i * if arch == 64 { 8 } else { 4 }, &pointer(at))?;
        }
        for i in 0..234 {
            let addr = JNI_CODE + i * 16;
            m.initialize(addr, &stub(JNI_SVC + i as u32))?;
            m.initialize(
                JNI_TABLE + i * if arch == 64 { 8 } else { 4 },
                &pointer(addr),
            )?;
        }
        m.initialize(RETURN, &stub(RETURN_SVC))?;
        m.initialize(ONCE_RETURN, &stub(ONCE_RETURN_SVC))?;
        // These names select guest platform namespaces. An empty export table
        // supplies no APIs. Every strong import still has to resolve.
        let mut platforms = [
            "libc.so",
            "libandroid.so",
            "liblog.so",
            "libm.so",
            "libdl.so",
            "libz.so",
        ]
        .into_iter()
        .map(|library| (library, BTreeMap::new()))
        .collect::<BTreeMap<_, _>>();
        let mut guard = [0u8; 8];
        if unsafe { libc::getrandom(guard.as_mut_ptr().cast(), guard.len(), 0) } != 8 {
            return Err("Cannot initialize guest stack guard".into());
        }
        let width = if arch == 64 { 8 } else { 4 };
        m.initialize(TLS, &pointer(TLS))?;
        m.initialize(TLS + 5 * width as u64, &guard[..width])?;
        platforms
            .get_mut("libc.so")
            .unwrap()
            .insert("__stack_chk_guard".into(), TLS + 5 * width as u64);
        stdio::initialize(&mut m, arch, platforms.get_mut("libc.so").unwrap())?;
        for (i, (library, name)) in C_FUNCTIONS.iter().enumerate() {
            if arch != 32 && name.starts_with("__aeabi_") {
                continue;
            }
            let addr = C_CODE + i as u64 * 16;
            m.initialize(addr, &stub(C_SVC + i as u32))?;
            platforms
                .get_mut(library)
                .unwrap()
                .insert(name.to_string(), addr);
        }
        let mut cpu = Cpu::new(arch, m, cache_mib * 1024 * 1024)?;
        cpu.set_thread_pointer(TLS);
        Ok(Self {
            cpu,
            arch,
            images: BTreeMap::new(),
            platforms,
            heap: heap::Heap::default(),
            pending_logs: Vec::new(),
            stdout: Vec::new(),
            console_lines: [Vec::new(), Vec::new()],
            unsupported_syscalls: Vec::new(),
            started: Instant::now(),
            brk: 0x40000000,
            mmap: 0x50000000,
            fuel: 0,
            calls: 0,
            ticks: 0,
            jni_env: JNI_ENV,
            current_tid: crate::identity::MAIN_TID,
            thread_slots: BTreeMap::new(),
            pthreads: pthreads::Pthreads::default(),
        })
    }
    pub fn activate_thread(&mut self, tid: u32) -> Result<()> {
        let (env, tls) = self.thread_context(tid)?;
        self.cpu.set_thread_pointer(tls);
        self.jni_env = env;
        self.current_tid = tid;
        Ok(())
    }
    fn thread_context(&mut self, tid: u32) -> Result<(u64, u64)> {
        if tid == 0 {
            return Err("Guest thread id must be nonzero".into());
        }
        let (env, tls) = if tid == crate::identity::MAIN_TID {
            (JNI_ENV, TLS)
        } else {
            let slot = if let Some(slot) = self.thread_slots.get(&tid) {
                *slot
            } else {
                let slot = (0..THREAD_CONTEXT_SLOTS)
                    .find(|s| !self.thread_slots.values().any(|used| used == s))
                    .ok_or("Guest native thread context quota")?;
                let env = THREAD_CONTEXT_BASE + slot as u64 * 8192;
                let tls = env + 4096;
                let width = if self.arch == 64 { 8 } else { 4 };
                let mut guard = vec![0; width];
                self.cpu
                    .memory()
                    .read(TLS + 5 * width as u64, &mut guard, READ)?;
                let memory = self.cpu.memory_mut();
                memory.map(env, 4096, READ)?;
                if let Err(error) = memory.map(tls, 4096, READ | WRITE) {
                    memory.unmap(env, 4096)?;
                    return Err(error);
                }
                memory.initialize(env, &JNI_TABLE.to_le_bytes()[..width])?;
                memory.initialize(tls, &tls.to_le_bytes()[..width])?;
                memory.initialize(tls + 5 * width as u64, &guard)?;
                self.thread_slots.insert(tid, slot);
                slot
            };
            let env = THREAD_CONTEXT_BASE + slot as u64 * 8192;
            (env, env + 4096)
        };
        Ok((env, tls))
    }
    pub fn release_thread(&mut self, tid: u32) -> Result<()> {
        if tid == crate::identity::MAIN_TID {
            return Ok(());
        }
        if self.current_tid == tid {
            return Err("Cannot release the active native thread context".into());
        }
        self.reset_pthread_once(tid);
        if let Some(slot) = self.thread_slots.remove(&tid) {
            self.cpu
                .memory_mut()
                .unmap(THREAD_CONTEXT_BASE + slot as u64 * 8192, 8192)?;
        }
        Ok(())
    }
    pub fn load(&mut self, name: &str, bytes: &[u8]) -> Result<()> {
        if self.images.contains_key(name) {
            return Ok(());
        }
        if self.images.len() >= MAX_IMAGES {
            return Err("Native library count quota".into());
        }
        let plan = elf::plan(bytes)?;
        if plan.arch != self.arch {
            return Err("ELF architecture does not match the selected native ABI".into());
        }
        let image = elf::link_standalone(
            plan,
            self.cpu.memory_mut(),
            image_bias(self.images.len()),
            &self.platforms["libc.so"],
        )?;
        self.cpu.clear_cache();
        self.images.insert(name.to_owned(), image);
        Ok(())
    }
    pub fn symbol(&self, name: &str) -> Result<u64> {
        self.images
            .values()
            .find_map(|v| v.exports.get(name).copied())
            .ok_or_else(|| format!("Native JNI symbol is unavailable: {name}").into())
    }
    pub fn prepare(&mut self, address: u64, args: &[u64]) -> Result<State> {
        let maximum = if self.arch == 64 { 8 } else { 4 };
        if args.len() > 64 {
            return Err("Native argument count quota (64)".into());
        }
        let mut state = State {
            pc: if self.arch == 32 {
                address & !1
            } else {
                address
            },
            ..Default::default()
        };
        for (i, a) in args.iter().take(maximum).enumerate() {
            state.regs[i] = *a;
        }
        let width = if self.arch == 64 { 8 } else { 4 };
        let alignment = if self.arch == 64 { 16 } else { 8 };
        let used = (args.len().saturating_sub(maximum) * width).div_ceil(alignment) * alignment;
        let stack = STACK_TOP - used as u64;
        for (i, value) in args.iter().skip(maximum).enumerate() {
            let b = if self.arch == 64 {
                value.to_le_bytes().to_vec()
            } else {
                (*value as u32).to_le_bytes().to_vec()
            };
            self.cpu
                .memory_mut()
                .write(stack + (i * width) as u64, &b)?;
        }
        if self.arch == 64 {
            state.regs[31] = stack;
            state.regs[30] = RETURN;
        } else {
            state.flags = if address & 1 != 0 { 0x30 } else { 0x10 };
            state.regs[13] = stack;
            state.regs[14] = RETURN;
        }
        self.fuel = 250000;
        self.calls += 1;
        Ok(state)
    }
    pub fn prepare_abi(
        &mut self,
        address: u64,
        gp: &[u64],
        fp: &[u64],
        stack: &[u8],
    ) -> Result<State> {
        if gp.len() > if self.arch == 64 { 8 } else { 4 } || fp.len() > 8 || stack.len() > 4096 {
            return Err("Native scalar ABI budget".into());
        }
        let mut state = self.prepare(address, gp)?;
        let alignment = if self.arch == 64 { 16 } else { 8 };
        let address = STACK_TOP - (stack.len().div_ceil(alignment) * alignment) as u64;
        self.cpu.memory_mut().write(address, stack)?;
        state.regs[if self.arch == 64 { 31 } else { 13 }] = address;
        for (i, value) in fp.iter().enumerate() {
            state.vectors[i * 2] = *value;
        }
        Ok(state)
    }
    pub fn advance(&mut self, state: &mut State) -> Result<Trap> {
        let result = self.advance_caller(state);
        if result.is_err() {
            self.reset_pthread_once(self.current_tid);
        }
        result
    }
    fn advance_caller(&mut self, state: &mut State) -> Result<Trap> {
        loop {
            if self.fuel == 0 {
                return Err("Native instruction budget exhausted".into());
            }
            let budget = if self.has_native_workers() {
                self.fuel.min(pthreads::QUANTUM)
            } else {
                self.fuel
            };
            let (used, step) = self.native_slice(state, budget)?;
            self.fuel = self.fuel.saturating_sub(used);
            match step {
                NativeStep::Quantum | NativeStep::Yield => self.pump_native_threads(1)?,
                NativeStep::Wait(wait) => state.regs[0] = self.drive_native_wait(wait)?,
                NativeStep::Trap(trap) => {
                    if matches!(trap, Trap::Returned(_)) {
                        self.pump_native_threads(1)?;
                    }
                    return Ok(trap);
                }
                NativeStep::ThreadExit(_) => {
                    return Err("pthread_exit on a Java-owned guest thread".into());
                }
                NativeStep::Resume => unreachable!("native_slice handles Resume"),
            }
        }
    }
    fn native_slice(&mut self, state: &mut State, budget: u64) -> Result<(u64, NativeStep)> {
        let mut remaining = budget;
        while remaining != 0 {
            self.cpu.run(state, remaining, false)?;
            remaining = remaining.saturating_sub(state.ticks.max(1));
            self.ticks = self.ticks.saturating_add(state.ticks);
            if state.reason == 1 {
                break;
            }
            if state.reason != 2 {
                return Err(format!("Unexpected native stop reason {}", state.reason).into());
            }
            let step = self.native_trap(state)?;
            if !matches!(step, NativeStep::Resume) {
                return Ok((budget - remaining, step));
            }
        }
        Ok((budget - remaining, NativeStep::Quantum))
    }
    fn native_trap(&mut self, state: &mut State) -> Result<NativeStep> {
        let trap = match state.svc {
            RETURN_SVC => Trap::Returned(state.regs[0]),
            ONCE_RETURN_SVC => {
                self.finish_pthread_once(state)?;
                return Ok(NativeStep::Resume);
            }
            svc if (JNI_SVC..JNI_SVC + 234).contains(&svc) => Trap::Jni(svc - JNI_SVC),
            svc if (0x5000..0x5008).contains(&svc) => Trap::Vm(svc - 0x5000),
            svc if (C_SVC..C_SVC + C_FUNCTIONS.len() as u32).contains(&svc) => {
                let index = svc - C_SVC;
                if let Some(step) = self.pthread_call(C_FUNCTIONS[index as usize].1, state)? {
                    return Ok(step);
                }
                self.c_function(index, state)?;
                return Ok(NativeStep::Resume);
            }
            0 => match self.syscall(state)? {
                Some(code) => Trap::Exit(code),
                None => return Ok(NativeStep::Resume),
            },
            svc => return Err(format!("Unsupported guest SVC {svc}").into()),
        };
        Ok(NativeStep::Trap(trap))
    }
    pub fn cbytes(&self, address: u64, max: usize) -> Result<Vec<u8>> {
        let mut out = Vec::new();
        for i in 0..max.min(16384) {
            let b = self.cpu.memory().bytes(
                address
                    .checked_add(i as u64)
                    .ok_or("Guest string address overflow")?,
                1,
            )?[0];
            if b == 0 {
                return Ok(out);
            }
            out.push(b);
        }
        Err("Guest C string quota".into())
    }
    fn c_function(&mut self, index: u32, state: &mut State) -> Result<()> {
        let a = state.regs;
        let (_, function) = C_FUNCTIONS[index as usize];
        let result = match function {
            "strlen" => self.cbytes(a[0], 16384)?.len() as u64,
            "memcpy" | "memmove" | "__aeabi_memcpy" | "__aeabi_memcpy4" | "__aeabi_memcpy8"
            | "__aeabi_memmove" | "__aeabi_memmove4" | "__aeabi_memmove8" => {
                let n = usize::try_from(a[2])?;
                if n > 1024 * 1024 {
                    return Err("Native memcpy quota".into());
                }
                let bytes = self.cpu.memory().bytes(a[1], n)?;
                self.cpu.memory_mut().write(a[0], &bytes)?;
                a[0]
            }
            "memset" | "__aeabi_memset" | "__aeabi_memset4" | "__aeabi_memset8"
            | "__aeabi_memclr" | "__aeabi_memclr4" | "__aeabi_memclr8" => {
                let (size, byte) = if function == "memset" {
                    (a[2], a[1] as u8)
                } else if function.starts_with("__aeabi_memset") {
                    (a[1], a[2] as u8)
                } else {
                    (a[1], 0)
                };
                let n = usize::try_from(size)?;
                if n > 1024 * 1024 {
                    return Err("Native memset quota".into());
                }
                self.cpu.memory_mut().fill(a[0], n, byte)?;
                a[0]
            }
            "memcmp" => {
                let n = usize::try_from(a[2])?;
                let left = self.cpu.memory().bytes(a[0], n)?;
                let right = self.cpu.memory().bytes(a[1], n)?;
                let result = left
                    .iter()
                    .zip(&right)
                    .find_map(|(a, b)| {
                        if a != b {
                            Some(*a as i32 - *b as i32)
                        } else {
                            None
                        }
                    })
                    .unwrap_or(0);
                result as i64 as u64
            }
            "__stack_chk_fail" | "abort" => return Err("The guest native library aborted".into()),
            "__android_log_write" | "__android_log_print" | "__android_log_assert" => {
                self.native_log(function, state)?
            }
            "adler32" => self.adler32(a[0] as u32, a[1], a[2] as u32)?,
            "malloc" | "calloc" | "realloc" | "free" | "memalign" | "malloc_usable_size"
            | "__errno" => self.heap_call(function, &a)?,
            "strtol" | "strtoll" | "strtoul" | "strtoull" | "strtoimax" | "strtoumax"
            | "strtoll_l" | "strtoull_l" => self.integer_call(function, state)?,
            "fwrite" | "fread" | "fputc" | "fgetc" | "fputs" | "puts" | "putchar" | "getchar"
            | "fflush" | "fileno" | "feof" | "ferror" | "clearerr" | "fprintf" | "vfprintf" => {
                self.stdio_call(function, state)?
            }
            "snprintf" | "vsnprintf" | "__vsprintf_chk" | "__vsnprintf_chk" => {
                self.stdio_format_buffer(function, state)?
            }
            "sscanf" | "vsscanf" => self.scanf_call(function, state)?,
            "asprintf" | "vasprintf" => self.stdio_format_alloc(function, state)?,
            "strftime" | "mbrlen" | "mbrtowc" | "strtod" | "strtof" => {
                self.c_locale_function(function, state)?
            }
            _ => self
                .c_string_function(function, state)?
                .ok_or_else(|| format!("Unsupported Bionic C function {function}"))?,
        };
        state.regs[0] = if self.arch == 32 {
            u64::from(result as u32)
        } else {
            result
        };
        Ok(())
    }
    fn syscall(&mut self, state: &mut State) -> Result<Option<i32>> {
        let a = state.regs;
        let nr = if self.arch == 64 { a[8] } else { a[7] };
        let code = if self.arch == 64 {
            nr
        } else {
            match nr {
                1 => 93,
                248 => 94,
                4 => 64,
                3 => 63,
                5 | 322 => 56,
                6 => 57,
                45 => 214,
                192 => 222,
                91 => 215,
                125 => 226,
                263 => 113,
                384 => 278,
                122 => 160,
                20 => 172,
                224 => 178,
                24 | 199 => 174,
                49 | 201 => 175,
                47 | 200 => 176,
                50 | 202 => 177,
                _ => u64::MAX,
            }
        };
        let neg = |errno: i32| (-(errno as i64)) as u64;
        let result = match code {
            93 | 94 => return Ok(Some(a[0] as i32)),
            64 => self
                .console_write_guest(a[0], a[1], a[2])
                .map_or_else(neg, |()| a[2]),
            63 => {
                if a[0] == 0 {
                    0
                } else {
                    neg(libc::EBADF)
                }
            }
            56 => neg(libc::EACCES),
            57 => neg(libc::EBADF),
            172 => crate::identity::PID as u64,
            178 => self.current_tid as u64,
            174 | 175 => crate::identity::UID as u64,
            176 | 177 => crate::identity::GID as u64,
            214 => {
                if !(0x40000000..=0x41000000).contains(&a[0]) {
                    self.brk
                } else {
                    let old = (self.brk + 4095) & !4095;
                    let new = (a[0] + 4095) & !4095;
                    if new > old
                        && self
                            .cpu
                            .memory_mut()
                            .map(old, (new - old) as usize, READ | WRITE)
                            .is_err()
                    {
                        self.brk
                    } else {
                        self.brk = a[0];
                        self.brk
                    }
                }
            }
            222 => {
                if a[1] == 0
                    || a[1] > 16 * 1024 * 1024
                    || a[2] & !7 != 0
                    || a[3] & 0x20 == 0
                    || a[3] & 0x10 != 0
                {
                    neg(libc::EINVAL)
                } else if self.mmap + ((a[1] + 4095) & !4095) > 0x60000000 {
                    neg(libc::ENOMEM)
                } else {
                    let address = self.mmap;
                    let permissions = (if a[2] & 1 != 0 { READ } else { 0 })
                        | (if a[2] & 2 != 0 { WRITE } else { 0 })
                        | (if a[2] & 4 != 0 { EXEC } else { 0 });
                    match self
                        .cpu
                        .memory_mut()
                        .map(address, a[1] as usize, permissions)
                    {
                        Ok(()) => {
                            self.mmap = self
                                .mmap
                                .checked_add((a[1] + 4095) & !4095)
                                .ok_or("Guest mmap address overflow")?;
                            address
                        }
                        Err(_) => neg(libc::ENOMEM),
                    }
                }
            }
            215 if heap::overlaps(a[0], a[1])
                || stdio::overlaps(a[0], a[1])
                || pthreads::overlaps(a[0], a[1]) =>
            {
                neg(libc::EINVAL)
            }
            215 => match self.cpu.memory_mut().unmap(a[0], a[1] as usize) {
                Ok(()) => {
                    self.cpu.clear_cache();
                    0
                }
                Err(_) => neg(libc::EINVAL),
            },
            226 => {
                let permissions = (if a[2] & 1 != 0 { READ } else { 0 })
                    | (if a[2] & 2 != 0 { WRITE } else { 0 })
                    | (if a[2] & 4 != 0 { EXEC } else { 0 });
                if a[2] & !7 != 0
                    || heap::overlaps(a[0], a[1])
                    || stdio::overlaps(a[0], a[1])
                    || pthreads::overlaps(a[0], a[1])
                {
                    neg(libc::EINVAL)
                } else {
                    match self
                        .cpu
                        .memory_mut()
                        .protect(a[0], a[1] as usize, permissions)
                    {
                        Ok(()) => {
                            self.cpu.clear_cache();
                            0
                        }
                        Err(_) => neg(libc::EINVAL),
                    }
                }
            }
            113 => {
                let elapsed = if a[0] == 0 {
                    SystemTime::now().duration_since(UNIX_EPOCH)?
                } else if a[0] == 1 {
                    self.started.elapsed()
                } else {
                    state.regs[0] = neg(libc::EINVAL);
                    return Ok(None);
                };
                let mut bytes = Vec::new();
                if self.arch == 64 {
                    bytes.extend_from_slice(&elapsed.as_secs().to_le_bytes());
                    bytes.extend_from_slice(&(elapsed.subsec_nanos() as u64).to_le_bytes());
                } else {
                    bytes.extend_from_slice(&(elapsed.as_secs() as u32).to_le_bytes());
                    bytes.extend_from_slice(&elapsed.subsec_nanos().to_le_bytes());
                }
                if self.cpu.memory_mut().write(a[1], &bytes).is_ok() {
                    0
                } else {
                    neg(libc::EFAULT)
                }
            }
            278 => {
                if a[1] > 4096 || a[2] & !3 != 0 {
                    neg(libc::EINVAL)
                } else {
                    let mut b = vec![0; a[1] as usize];
                    let n = unsafe { libc::getrandom(b.as_mut_ptr().cast(), b.len(), 0) };
                    if n < 0 {
                        neg(libc::EIO)
                    } else if self.cpu.memory_mut().write(a[0], &b[..n as usize]).is_err() {
                        neg(libc::EFAULT)
                    } else {
                        n as u64
                    }
                }
            }
            160 => {
                let mut b = vec![0; 65 * 6];
                for (i, s) in [
                    "Linux",
                    "rift-native",
                    "0.2",
                    "KYVEX",
                    if self.arch == 64 { "aarch64" } else { "armv7l" },
                    "local",
                ]
                .iter()
                .enumerate()
                {
                    b[i * 65..i * 65 + s.len()].copy_from_slice(s.as_bytes());
                }
                if self.cpu.memory_mut().write(a[0], &b).is_ok() {
                    0
                } else {
                    neg(libc::EFAULT)
                }
            }
            _ => {
                if self.unsupported_syscalls.len() < 16 && !self.unsupported_syscalls.contains(&nr)
                {
                    self.unsupported_syscalls.push(nr);
                }
                neg(libc::ENOSYS)
            }
        };
        state.regs[0] = if self.arch == 32 {
            result as u32 as u64
        } else {
            result
        };
        Ok(None)
    }
}

#[cfg(test)]
mod identity_tests {
    use super::*;
    #[test]
    fn process_ids_match_on_both_guest_syscall_abis() {
        for arch in [32, 64] {
            let mut m = Machine::new(arch, 32, 8).unwrap();
            for (arm32, arm64, expected) in [
                (20, 172, crate::identity::PID),
                (224, 178, crate::identity::MAIN_TID),
                (199, 174, crate::identity::UID),
                (201, 175, crate::identity::UID),
                (200, 176, crate::identity::GID),
                (202, 177, crate::identity::GID),
            ] {
                let mut state = State::default();
                state.regs[if arch == 32 { 7 } else { 8 }] = if arch == 32 { arm32 } else { arm64 };
                assert_eq!(m.syscall(&mut state).unwrap(), None);
                assert_eq!(state.regs[0], expected as u64);
            }
        }
    }
}
