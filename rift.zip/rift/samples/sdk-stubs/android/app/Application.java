package android.app;
public class Application extends android.content.ContextWrapper {
 public Application(){super(null);}
 public void onCreate(){}
 public static String getProcessName(){return null;}
 public interface ActivityLifecycleCallbacks {
  void onActivityCreated(Activity activity,android.os.Bundle state);
  void onActivityStarted(Activity activity);
  void onActivityResumed(Activity activity);
  void onActivityPaused(Activity activity);
  void onActivityStopped(Activity activity);
  void onActivitySaveInstanceState(Activity activity,android.os.Bundle state);
  void onActivityDestroyed(Activity activity);
 }
 public void registerActivityLifecycleCallbacks(ActivityLifecycleCallbacks listener){}
 public void unregisterActivityLifecycleCallbacks(ActivityLifecycleCallbacks listener){}
 public void registerComponentCallbacks(android.content.ComponentCallbacks listener){}
 public void unregisterComponentCallbacks(android.content.ComponentCallbacks listener){}
}
