//! Information about this guest VM, never the desktop JVM/host process heap.
use super::*;
impl Runtime {
    pub(super) fn runtime_info_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        // This guest never installs a Java SecurityManager. OS containment is
        // provided separately by the worker; this query does not change it.
        if sig == "Ljava/lang/System;->getSecurityManager()Ljava/lang/SecurityManager;" {
            return Ok(Some(0));
        }
        if sig == "Ljava/lang/System;->gc()V" {
            self.gc_requested = true;
            return Ok(Some(0));
        }
        let Some(method) = sig.strip_prefix("Ljava/lang/Runtime;->") else {
            return Ok(None);
        };
        if method == "getRuntime()Ljava/lang/Runtime;" {
            if self.java_runtime == 0 {
                self.java_runtime = self.allocate("Ljava/lang/Runtime;", Payload::Instance)?;
            }
            return Ok(Some(self.java_runtime as u64));
        }
        if !matches!(
            method,
            "availableProcessors()I"
                | "maxMemory()J"
                | "totalMemory()J"
                | "freeMemory()J"
                | "gc()V"
        ) {
            return Ok(None);
        }
        let id = *a.first().ok_or("Runtime receiver missing")?;
        self.object(id)?;
        if id != self.java_runtime || id == 0 {
            return Err("Unknown guest Runtime".into());
        }
        Ok(Some(match method {
            // The current guest has one interpreter/ARM execution lane.
            "availableProcessors()I" => 1,
            "maxMemory()J" | "totalMemory()J" => self.heap_limit as u64,
            "freeMemory()J" => self.heap_limit.saturating_sub(self.heap_bytes()) as u64,
            // gc() is advisory. Actual collection runs at the next safe point.
            "gc()V" => {
                self.gc_requested = true;
                0
            }
            _ => unreachable!(),
        }))
    }
}
