pub mod apk;
pub mod archive;
pub mod dex;
pub mod input;
pub type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;
