package android.os;
/** Compile-only API signatures; this class is excluded from every sample APK. */
public final class Build {
    public static final class VERSION { public static int SDK_INT; }
}
