package org.kyvex.extra;

import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.RemoteException;
import android.widget.TextView;

/** Uses real local endpoint identities and the main message queue. */
public final class MessengerChecks {
    private static int checks;
    private static int deliveries;
    private static int timeCalls;

    private static void check(boolean ok, String message) {
        if (!ok) throw new IllegalStateException(message);
        checks++;
    }

    public static void schedule(final TextView label) {
        checks = deliveries = timeCalls = 0;
        final Looper main = Looper.getMainLooper();
        final Object token = new Object();
        Handler replyHandler = new Handler(main, null) {
            public void handleMessage(Message reply) {
                check(deliveries == 1 && reply.what == 42 && reply.arg1 == 20
                        && reply.arg2 == 9 && reply.obj == token, "Reply data and delivery order");
                check(reply.getTarget() == this && reply.sendingUid == Process.myUid()
                        && Looper.myLooper() == main, "Reply target, sender and Looper");
                label.setText("Messenger checks: " + checks + " delivered");
            }
        };
        final Messenger reply = new Messenger(replyHandler);
        final Handler target = new Handler(main, null) {
            public boolean sendMessageAtTime(Message message, long uptimeMillis) {
                timeCalls++;
                return super.sendMessageAtTime(message, uptimeMillis);
            }
            public void handleMessage(Message request) {
                deliveries++;
                check(request.what == 41 && request.arg1 == 9 && request.arg2 == 20
                        && request.obj == token, "Request object and arguments");
                check(request.getTarget() == this && request.sendingUid == Process.myUid()
                        && Looper.myLooper() == main && Thread.currentThread() == main.getThread(),
                        "Request dispatched on the target Looper with the local sender UID");
                check(request.replyTo == reply, "Reply endpoint survived in the message");
                try {
                    request.replyTo.send(obtainMessage(42, request.arg2, request.arg1, request.obj));
                } catch (RemoteException error) {
                    throw new IllegalStateException(error);
                }
            }
        };
        final Messenger route = new Messenger(target);
        final IBinder binder = route.getBinder();
        final Messenger alias = new Messenger(binder);
        Messenger sameTarget = new Messenger(target);
        check(binder == alias.getBinder() && binder == sameTarget.getBinder(), "One Binder per Handler");
        check(route.equals(alias) && alias.equals(sameTarget) && route.hashCode() == alias.hashCode()
                && route.hashCode() == binder.hashCode(), "Alias equality and hash follow the endpoint");
        check(!route.equals(reply) && !route.equals(null) && !route.equals("other"), "Different endpoints and types");
        try {
            check("android.os.IMessenger".equals(binder.getInterfaceDescriptor())
                    && binder.isBinderAlive() && binder.pingBinder(), "Local Binder descriptor and liveness");
        } catch (RemoteException error) {
            throw new IllegalStateException(error);
        }
        check(route.describeContents() == 0, "Messenger has no file descriptors");
        Messenger empty = new Messenger((IBinder) null);
        check(empty.describeContents() == 0, "Null endpoint construction");
        boolean rejected = false;
        try { empty.getBinder(); } catch (NullPointerException expected) { rejected = true; }
        check(rejected, "A missing endpoint cannot return a Binder");
        rejected = false;
        try { new Messenger((Handler) null); } catch (NullPointerException expected) { rejected = true; }
        check(rejected, "A missing Handler cannot create an endpoint");
        rejected = false;
        try { reply.send(null); }
        catch (NullPointerException expected) { rejected = true; }
        catch (RemoteException error) { throw new IllegalStateException(error); }
        check(rejected, "A missing Message cannot be sent");
        label.setText("Messenger checks: " + checks + " pending");

        Handler timer = new Handler(main, null);
        if (!timer.postDelayed(new Runnable() {
            public void run() {
                Message request = target.obtainMessage(41, 9, 20, token);
                request.replyTo = reply;
                check(request.sendingUid == -1, "Initial sender is unset");
                try {
                    alias.send(request);
                    check(request.sendingUid == Process.myUid() && request.getTarget() == target,
                            "Send sets the actual sender and queues the message for its Handler");
                    check(deliveries == 0, "Sending is asynchronous");
                    boolean duplicate = false;
                    try { route.send(request); }
                    catch (IllegalStateException expected) { duplicate = true; }
                    check(duplicate && timeCalls == 2, "Duplicate send fails through the real Handler override");
                } catch (RemoteException error) {
                    throw new IllegalStateException(error);
                }
            }
        }, 1000)) throw new IllegalStateException("Could not queue the fixture timer");
    }
}
