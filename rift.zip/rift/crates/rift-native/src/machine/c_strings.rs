//! Bionic character operations and bounded strings in guest memory.
use super::{Machine, Memory, READ, Result, State};
use crate::memory::PAGE;

const STRING_LIMIT: usize = 16 * 1024;
const BUFFER_LIMIT: u64 = 1024 * 1024;
const WIDE_BYTES: usize = 4;
const WEOF: u32 = u32::MAX;

// These are the masks returned by API 28's narrow ctype predicates.
const UPPER: u8 = 0x01;
const LOWER: u8 = 0x02;
const DIGIT: u8 = 0x04;
const SPACE: u8 = 0x08;
const PUNCT: u8 = 0x10;
const CONTROL: u8 = 0x20;
const HEX: u8 = 0x40;
const PRINT_SPACE: u8 = 0x80;

fn int_result(value: i32) -> u64 {
    u64::from(value as u32)
}

fn narrow_class(value: i32) -> u8 {
    if value == -1 {
        return 0;
    }
    match value as u8 {
        b'A'..=b'F' => UPPER | HEX,
        b'G'..=b'Z' => UPPER,
        b'a'..=b'f' => LOWER | HEX,
        b'g'..=b'z' => LOWER,
        b'0'..=b'9' => DIGIT,
        b'\t'..=b'\r' => SPACE | CONTROL,
        b' ' => SPACE | PRINT_SPACE,
        byte if byte.is_ascii_punctuation() => PUNCT,
        byte if byte.is_ascii_control() => CONTROL,
        _ => 0,
    }
}

fn narrow_ctype(function: &str, value: i32) -> Option<u64> {
    let mask = match function {
        "isalnum" => UPPER | LOWER | DIGIT,
        "isalpha" => UPPER | LOWER,
        "isblank" => return Some(u64::from(matches!(value, 9 | 32))),
        "iscntrl" => CONTROL,
        "isdigit" => DIGIT,
        "isgraph" => UPPER | LOWER | DIGIT | PUNCT,
        "islower" => LOWER,
        "isprint" => UPPER | LOWER | DIGIT | PUNCT | PRINT_SPACE,
        "ispunct" => PUNCT,
        "isspace" => SPACE,
        "isupper" => UPPER,
        "isxdigit" => DIGIT | HEX,
        "tolower" => {
            let folded =
                u8::try_from(value).map_or(value, |byte| i32::from(byte.to_ascii_lowercase()));
            return Some(int_result(folded));
        }
        "toupper" => {
            let folded =
                u8::try_from(value).map_or(value, |byte| i32::from(byte.to_ascii_uppercase()));
            return Some(int_result(folded));
        }
        _ => return None,
    };
    Some(u64::from(narrow_class(value) & mask))
}

// The operation order is shared with the enum in support/platform-text.c.
#[repr(u32)]
enum WideOp {
    Alnum,
    Alpha,
    Blank,
    Control,
    Digit,
    Graph,
    Lower,
    Print,
    Punct,
    Space,
    Upper,
    Hex,
    ToLower,
    ToUpper,
}

unsafe extern "C" {
    fn rift_bionic_wctype(code: i32, operation: u32) -> i32;
}

fn wide_ctype(function: &str, value: u32) -> Option<u64> {
    let operation = match function {
        "iswalnum" => WideOp::Alnum,
        "iswalpha" => WideOp::Alpha,
        "iswblank" => WideOp::Blank,
        "iswcntrl" => WideOp::Control,
        "iswdigit" => WideOp::Digit,
        "iswgraph" => WideOp::Graph,
        "iswlower" => WideOp::Lower,
        "iswprint" => WideOp::Print,
        "iswpunct" => WideOp::Punct,
        "iswspace" => WideOp::Space,
        "iswupper" => WideOp::Upper,
        "iswxdigit" => WideOp::Hex,
        "towlower" => WideOp::ToLower,
        "towupper" => WideOp::ToUpper,
        _ => return None,
    };
    // ICU receives a scalar by value, including WEOF, and no guest address.
    Some(int_result(unsafe {
        rift_bionic_wctype(value as i32, operation as u32)
    }))
}

fn buffer_size(count: u64, width: usize) -> Result<usize> {
    count
        .checked_mul(width as u64)
        .filter(|&bytes| bytes <= BUFFER_LIMIT)
        .map(|bytes| bytes as usize)
        .ok_or_else(|| "Guest C buffer quota".into())
}

fn read_unit(memory: &Memory, address: u64, index: usize, width: usize) -> Result<u32> {
    let mut unit = [0; WIDE_BYTES];
    let address = address
        .checked_add((index * width) as u64)
        .ok_or("Guest C string address overflow")?;
    memory.read(address, &mut unit[..width], READ)?;
    Ok(u32::from_le_bytes(unit))
}

fn string_prefix(memory: &Memory, address: u64, limit: usize, width: usize) -> Result<Vec<u8>> {
    let mut bytes = Vec::new();
    for index in 0..limit {
        let unit = read_unit(memory, address, index, width)?;
        if unit == 0 {
            break;
        }
        bytes.extend_from_slice(&unit.to_le_bytes()[..width]);
    }
    Ok(bytes)
}

fn terminated_string(memory: &Memory, address: u64, width: usize) -> Result<Vec<u8>> {
    let bytes = string_prefix(memory, address, STRING_LIMIT, width)?;
    if bytes.len() / width == STRING_LIMIT {
        return Err("Guest C string quota".into());
    }
    Ok(bytes)
}

fn compare_strings(
    memory: &Memory,
    left: u64,
    right: u64,
    count: u64,
    width: usize,
) -> Result<u64> {
    let limit = count.min(STRING_LIMIT as u64) as usize;
    for index in 0..limit {
        let a = read_unit(memory, left, index, width)?;
        let b = read_unit(memory, right, index, width)?;
        if a != b || a == 0 {
            return Ok(u64::from(a.wrapping_sub(b)));
        }
    }
    if (limit as u64) < count {
        return Err("Guest C string quota".into());
    }
    Ok(0)
}

fn find_units(memory: &Memory, address: u64, value: u32, count: u64, width: usize) -> Result<u64> {
    let size = buffer_size(count, width)?;
    let needle = value.to_le_bytes();
    let mut bytes = [0; PAGE as usize];
    let mut offset = 0;
    while offset < size {
        let cursor = address
            .checked_add(offset as u64)
            .ok_or("Guest C buffer address overflow")?;
        let remaining_in_page = (PAGE - cursor % PAGE) as usize;
        // Search through one readable page at a time and stop at the first match.
        // An unaligned wide unit can span two adjacent pages.
        let available = (size - offset).min(remaining_in_page);
        let span = ((available / width) * width).max(width);
        memory.read(cursor, &mut bytes[..span], READ)?;
        if let Some(hit) = bytes[..span]
            .chunks_exact(width)
            .position(|unit| unit == &needle[..width])
        {
            return Ok(cursor + (hit * width) as u64);
        }
        offset += span;
    }
    Ok(0)
}

fn compare_wide_buffers(memory: &Memory, left: u64, right: u64, count: u64) -> Result<u64> {
    let size = buffer_size(count, WIDE_BYTES)?;
    let left = memory.bytes(left, size)?;
    let right = memory.bytes(right, size)?;
    let (left, _) = left.as_chunks::<WIDE_BYTES>();
    let (right, _) = right.as_chunks::<WIDE_BYTES>();
    for (&a, &b) in left.iter().zip(right) {
        if a != b {
            let a = u32::from_le_bytes(a);
            let b = u32::from_le_bytes(b);
            return Ok(int_result(if a > b { 1 } else { -1 }));
        }
    }
    Ok(0)
}

impl Machine {
    pub(super) fn c_string_function(
        &mut self,
        function: &str,
        state: &State,
    ) -> Result<Option<u64>> {
        let [first, second, third, ..] = state.regs;
        let memory = self.cpu.memory();
        let result = match function {
            "strcmp" | "strcoll" => compare_strings(memory, first, second, u64::MAX, 1)?,
            "strncmp" => compare_strings(memory, first, second, third, 1)?,
            "wcscoll" => compare_strings(memory, first, second, u64::MAX, WIDE_BYTES)?,
            "wcslen" => (terminated_string(memory, first, WIDE_BYTES)?.len() / WIDE_BYTES) as u64,
            "strxfrm" | "wcsxfrm" => {
                // API 28 has binary collation, so the sort key is the original string.
                let width = if function == "strxfrm" { 1 } else { WIDE_BYTES };
                let mut bytes = terminated_string(memory, second, width)?;
                let length = bytes.len() / width;
                if third != 0 {
                    let copied = (length as u64).min(third - 1) as usize;
                    bytes.truncate(copied * width);
                    bytes.resize((copied + 1) * width, 0);
                    self.cpu.memory_mut().write(first, &bytes)?;
                }
                length as u64
            }
            "strncpy" => {
                let size = buffer_size(third, 1)?;
                let mut bytes = string_prefix(memory, second, size, 1)?;
                bytes.resize(size, 0);
                self.cpu.memory_mut().write(first, &bytes)?;
                first
            }
            "strstr" => {
                let needle = terminated_string(memory, second, 1)?;
                if needle.is_empty() {
                    return Ok(Some(first));
                }
                let haystack = terminated_string(memory, first, 1)?;
                // The host search sees only bounded Rust buffers. Return a guest offset.
                let hit = unsafe {
                    libc::memmem(
                        haystack.as_ptr().cast(),
                        haystack.len(),
                        needle.as_ptr().cast(),
                        needle.len(),
                    )
                };
                if hit.is_null() {
                    0
                } else {
                    first + (hit as usize - haystack.as_ptr() as usize) as u64
                }
            }
            "memchr" => find_units(memory, first, second as u32, third, 1)?,
            "wmemchr" => find_units(memory, first, second as u32, third, WIDE_BYTES)?,
            "wmemcmp" => compare_wide_buffers(memory, first, second, third)?,
            "wmemcpy" | "wmemmove" => {
                let bytes = memory.bytes(second, buffer_size(third, WIDE_BYTES)?)?;
                self.cpu.memory_mut().write(first, &bytes)?;
                first
            }
            "wmemset" => {
                let size = buffer_size(third, WIDE_BYTES)?;
                let bytes = (second as u32).to_le_bytes().repeat(size / WIDE_BYTES);
                self.cpu.memory_mut().write(first, &bytes)?;
                first
            }
            "btowc" => {
                let byte = first as u8;
                if first as i32 == -1 {
                    u64::from(WEOF)
                } else if byte.is_ascii() {
                    u64::from(byte)
                } else {
                    if matches!(byte, 0x80..=0xbf | 0xf8..=0xff) {
                        self.set_guest_errno(libc::EILSEQ)?;
                    }
                    u64::from(WEOF)
                }
            }
            "wctob" => {
                let code = first as u32;
                if code <= 0x7f {
                    u64::from(code)
                } else {
                    if code > 0x1f_ffff && code != WEOF {
                        self.set_guest_errno(libc::EILSEQ)?;
                    }
                    int_result(-1)
                }
            }
            _ => {
                return Ok(narrow_ctype(function, first as i32)
                    .or_else(|| wide_ctype(function, first as u32)));
            }
        };
        Ok(Some(result))
    }
}
