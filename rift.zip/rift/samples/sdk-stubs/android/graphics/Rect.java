package android.graphics;
public final class Rect implements android.os.Parcelable {
    public int left, top, right, bottom;
    public Rect() {}
    public Rect(int left, int top, int right, int bottom) {}
    public Rect(Rect rect) {}
    public void set(int left, int top, int right, int bottom) {}
    public void set(Rect rect) {}
    public void setEmpty() {}
    public void inset(int x, int y) {}
    public void offset(int x, int y) {}
    public void offsetTo(int x, int y) {}
    public int width() { return 0; }
    public int height() { return 0; }
    public int centerX() { return 0; }
    public int centerY() { return 0; }
    public float exactCenterX() { return 0; }
    public float exactCenterY() { return 0; }
    public boolean isEmpty() { return false; }
    public boolean contains(int x, int y) { return false; }
    public boolean intersect(Rect rect) { return false; }
    public int describeContents() { return 0; }
}
