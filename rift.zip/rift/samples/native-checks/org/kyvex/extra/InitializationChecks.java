package org.kyvex.extra;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
/** Runs unchanged on a stock Java 8+ VM and the owned Native interpreter. */
public final class InitializationChecks {
 private static int checks,trace,badCalls,parentBadCalls,ctorCalls,forNameCalls;
 private static final Object lock=new Object(),failureLock=new Object();
 private static final CountDownLatch entered=new CountDownLatch(1),failureEntered=new CountDownLatch(1);
 private static boolean release,failureRelease;
 private static int stamp(int n){trace=trace*10+n;return n;}
 private static void check(boolean value,String why){if(!value)throw new IllegalStateException(why);checks++;}
 private static void pause(){try{Thread.sleep(1);}catch(InterruptedException e){throw new IllegalStateException(e);}}
 private static void await(CountDownLatch latch){try{latch.await();}catch(InterruptedException e){throw new IllegalStateException(e);}}
 private static void join(Thread thread){try{thread.join();}catch(InterruptedException e){throw new IllegalStateException(e);}}
 public static class Parent {static int value=stamp(1);}
 public static class Child extends Parent {static int other=stamp(2);}
 public static class Grandchild extends Child {static int tail=stamp(3);}
 public interface Top {int MARK=stamp(4);default int top(){return 4;}}
 public interface Middle extends Top {int MARK=stamp(5);default int middle(){return 5;}}
 public interface Passive {int MARK=stamp(6);}
 public static class Defaults implements Middle,Passive {static int mark=stamp(7);}
 public static class Recursive {static int before=readLater();static int later=19;static int readLater(){return later;}}
 public static class Slow {
  static int value;
  static {Object keep=new Object();synchronized(lock){entered.countDown();try{while(!release)lock.wait();}catch(InterruptedException e){throw new IllegalStateException(e);}}
   if(keep.getClass()!=Object.class)throw new IllegalStateException("Initializer lost a paused local");value=73;}
 }
 private static int explode(){badCalls++;throw new IllegalArgumentException("expected-clinit-fault");}
 public static class Broken {static int value=explode();}
 private static int explodeParent(){parentBadCalls++;throw new IllegalArgumentException("expected-parent-fault");}
 public static class BrokenParent {static int value=explodeParent();}
 public static class BrokenChild extends BrokenParent {static int value=stamp(9);}
 private static int explicitError(){throw new UnsatisfiedLinkError("expected-link-error");}
 public static class ErrorClass {static int value=explicitError();}
 public static class ForName {public static int value;static{pause();forNameCalls++;value=81;}}
 public static class ReflectCtor {static{pause();}public ReflectCtor(){ctorCalls++;}}
 public static class PrivateCtor {private PrivateCtor(){}}
 public static class FieldOnly {public static int value;static{pause();value=84;}}
 public interface BaseDefault {default int number(){return 1;}}
 public interface SpecificDefault extends BaseDefault {default int number(){return 2;}}
 public static class Specific implements BaseDefault,SpecificDefault {}
 public static class SlowFailure {static int value=fail();private static int fail(){synchronized(failureLock){failureEntered.countDown();try{while(!failureRelease)failureLock.wait();}catch(InterruptedException e){throw new IllegalStateException(e);}}throw new IllegalArgumentException("expected-slow-fault");}}
 private static void gcWhilePaused(){System.gc();int sum=0;for(int i=0;i<700;i++)sum+=i;if(sum!=244650)throw new IllegalStateException("Loop did not execute");}
 public static int verify()throws Exception {
  trace=0;check(Grandchild.value==1,"Inherited static field initializes its actual declaring class");check(trace==1,"Subclass must stay uninitialized after inherited field access");
  new Grandchild();check(trace==123,"Superclass-before-subclass order");new Grandchild();check(trace==123,"Initializers run once");
  trace=0;Defaults defaults=new Defaults();check(trace==457,"Default-method interface dependency order");check(defaults.top()+defaults.middle()==9,"Default methods really execute");
  check(Passive.MARK==6&&trace==4576,"Passive interface is initialized only on its own active use");
  check(new Specific().number()==2,"Maximally specific interface override wins");
  check(Recursive.before==0&&Recursive.later==19,"Same-thread recursion sees prepared defaults and does not rerun clinit");
  final AtomicInteger first=new AtomicInteger(),second=new AtomicInteger();final CountDownLatch attempted=new CountDownLatch(1);
  Thread owner=new Thread(new Runnable(){public void run(){first.set(Slow.value);}},"clinit-owner");owner.start();await(entered);
  Thread reader=new Thread(new Runnable(){public void run(){attempted.countDown();int value=Slow.value;second.set(Thread.currentThread().isInterrupted()?value:-value);}},"clinit-reader");reader.start();await(attempted);
  check(first.get()==0&&second.get()==0&&owner.isAlive()&&reader.isAlive(),"Other thread cannot observe a partly initialized class");
  reader.interrupt();gcWhilePaused();synchronized(lock){release=true;lock.notifyAll();}join(owner);join(reader);
  check(first.get()==73&&second.get()==73,"wait/notify in clinit resumes; class wait retains interruption");
  try{int value=Broken.value;throw new IllegalStateException("Broken class accepted: "+value);}catch(ExceptionInInitializerError e){check(e.getCause() instanceof IllegalArgumentException&&e.getException()==e.getCause(),"Non-Error is wrapped with its actual cause");check(e.getMessage()==null,"Initializer wrapper Throwable constructor semantics");}
  gcWhilePaused();try{new Broken();throw new IllegalStateException("Failed class restarted");}catch(NoClassDefFoundError e){check(badCalls==1&&e.getCause()!=null,"Erroneous state persists and roots its cause");}
  trace=0;try{new BrokenChild();throw new IllegalStateException("Failed parent accepted");}catch(ExceptionInInitializerError e){check(parentBadCalls==1&&trace==0,"Superclass failure prevents child initializer");}
  try{int value=BrokenChild.value;throw new IllegalStateException("Child restarted: "+value);}catch(NoClassDefFoundError e){check(parentBadCalls==1,"Dependent child remains erroneous");}
  try{int value=ErrorClass.value;throw new IllegalStateException("Error swallowed: "+value);}catch(UnsatisfiedLinkError expected){checks++;}
  try{Class.forName("org.kyvex.extra.InitializationChecks$ErrorClass");throw new IllegalStateException("Error class restarted");}catch(NoClassDefFoundError expected){checks++;}
  String name="org.kyvex.extra.InitializationChecks$ForName";
  Class<?> unloaded=Class.forName(name,false,InitializationChecks.class.getClassLoader());check(forNameCalls==0,"Loading without initialization");
  Class<?> initialized=Class.forName(name);check(initialized==unloaded&&forNameCalls==1&&initialized.getDeclaredField("value").getInt(null)==81,"Class.forName can wait in clinit without replaying caller");
  Class<?> constructor=Class.forName("org.kyvex.extra.InitializationChecks$ReflectCtor",false,InitializationChecks.class.getClassLoader());
  Object instance=constructor.getConstructor().newInstance();check(instance.getClass()==constructor&&ctorCalls==1,"Reflective constructor preflight initializes once before construction");
  try{PrivateCtor.class.getConstructor();throw new IllegalStateException("Private constructor exposed as public");}catch(NoSuchMethodException expected){checks++;}
  try{Class.forName("org.kyvex.extra.InitializationChecks$PrivateCtor",false,null);throw new IllegalStateException("Bootstrap loader exposed APK class");}catch(ClassNotFoundException expected){checks++;}
  Class<?> fieldOnly=Class.forName("org.kyvex.extra.InitializationChecks$FieldOnly",false,InitializationChecks.class.getClassLoader());check(fieldOnly.getDeclaredField("value").getInt(null)==84,"Reflective static field can suspend for class initialization");
  final AtomicInteger failures=new AtomicInteger();final CountDownLatch failureAttempt=new CountDownLatch(1);
  Thread failedOwner=new Thread(new Runnable(){public void run(){try{int value=SlowFailure.value;failures.set(-value);}catch(ExceptionInInitializerError e){failures.incrementAndGet();}}});
  failedOwner.start();await(failureEntered);
  Thread failedReader=new Thread(new Runnable(){public void run(){failureAttempt.countDown();try{int value=SlowFailure.value;failures.set(-value);}catch(NoClassDefFoundError e){failures.addAndGet(2);}}});
  failedReader.start();await(failureAttempt);synchronized(failureLock){failureRelease=true;failureLock.notifyAll();}join(failedOwner);join(failedReader);
  check(failures.get()==3,"Failed initializer wakes other threads into erroneous state");return checks;
 }
 public static int report(){try{return verify();}catch(Exception e){throw new IllegalStateException(e);}}
 public static class Pending {static int value=waitForever();private static int waitForever(){synchronized(lock){for(;;){try{lock.wait();}catch(InterruptedException e){throw new IllegalStateException(e);}}}}}
 public static void beginPending(){new Thread(new Runnable(){public void run(){int value=Pending.value;if(value!=0)throw new IllegalStateException("Unexpected pending value");}},"pending-initializer").start();}
 public static int touchPending(){return Pending.value;}
 public static void main(String[] args)throws Exception{System.out.println("Initialization checks: "+verify());}
}
