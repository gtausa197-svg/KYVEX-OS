//! Guest weak references are traced by the Java heap collector, not host pointers.
use super::*;
pub(super) fn payload(class: &str) -> Option<Payload> {
    match class {
        "Ljava/lang/ref/WeakReference;" => Some(Payload::Reference {
            target: 0,
            queue: 0,
            enqueued: false,
        }),
        "Ljava/lang/ref/ReferenceQueue;" => Some(Payload::ReferenceQueue(Vec::new())),
        _ => None,
    }
}
impl Runtime {
    pub(super) fn references_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Reference signature")?;
        if !class.starts_with("Ljava/lang/ref/") {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Reference argument count");
        let id = arg(0)?;
        if let Payload::ReferenceQueue(v) = &self.object(id)?.payload {
            match method {
                "<init>()V" => return Ok(Some(0)),
                "poll()Ljava/lang/ref/Reference;" => {
                    let value = v.first().copied().unwrap_or(0);
                    if value != 0 {
                        let Payload::ReferenceQueue(v) = &mut self.object_mut(id)?.payload else {
                            unreachable!()
                        };
                        v.remove(0);
                    }
                    if value != 0
                        && let Payload::Reference {
                            queue, enqueued, ..
                        } = &mut self.object_mut(value)?.payload
                    {
                        *queue = 0;
                        *enqueued = false;
                    }
                    return Ok(Some(value as u64));
                }
                _ => return Ok(None),
            }
        }
        let Payload::Reference {
            mut target,
            mut queue,
            mut enqueued,
        } = self.object(id)?.payload
        else {
            return Ok(None);
        };
        let result = match method {
            "<init>(Ljava/lang/Object;)V"
            | "<init>(Ljava/lang/Object;Ljava/lang/ref/ReferenceQueue;)V" => {
                target = arg(1)?;
                if target != 0 {
                    self.object(target)?;
                }
                queue = a.get(2).copied().unwrap_or(0);
                if queue != 0 && !matches!(self.object(queue)?.payload, Payload::ReferenceQueue(_))
                {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "reference queue type",
                    ));
                }
                enqueued = false;
                0
            }
            "get()Ljava/lang/Object;" => target as u64,
            "clear()V" => {
                target = 0;
                0
            }
            "isEnqueued()Z" => enqueued as u64,
            "refersTo(Ljava/lang/Object;)Z" => (target == arg(1)?) as u64,
            "enqueue()Z" => {
                if queue == 0 || enqueued {
                    0
                } else {
                    target = 0;
                    let Payload::ReferenceQueue(v) = &mut self.object_mut(queue)?.payload else {
                        unreachable!()
                    };
                    v.push(id);
                    enqueued = true;
                    1
                }
            }
            _ => return Ok(None),
        };
        self.object_mut(id)?.payload = Payload::Reference {
            target,
            queue,
            enqueued,
        };
        Ok(Some(result))
    }
}
