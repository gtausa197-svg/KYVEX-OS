//! Java collections with actual contents, weak keys and snapshot iterators.
//! Guest operations are serialized by the interpreter. Guest threads are separate work.
use super::*;
const LIMIT: usize = 4096;
pub(super) const QUEUE_CAPACITY: usize = usize::MAX - 200;
#[derive(Clone)]
pub(super) struct IteratorState {
    pub source: u32,
    pub snapshot: Option<Vec<u32>>,
    at: usize,
    expected: u64,
    last: Option<usize>,
    weakly_consistent: bool,
}

pub(super) fn payload(class: &str) -> Option<Payload> {
    Some(match class {
        "Ljava/util/concurrent/LinkedBlockingQueue;"
        | "Ljava/util/concurrent/LinkedBlockingDeque;"
        | "Ljava/util/concurrent/ConcurrentLinkedQueue;"
        | "Ljava/util/ArrayDeque;" => Payload::List(Vec::new()),
        "Ljava/util/ArrayList;"
        | "Ljava/util/LinkedList;"
        | "Ljava/util/Vector;"
        | "Ljava/util/concurrent/CopyOnWriteArrayList;" => Payload::List(Vec::new()),
        "Ljava/util/HashSet;"
        | "Ljava/util/LinkedHashSet;"
        | "Ljava/util/concurrent/CopyOnWriteArraySet;" => Payload::Set(Vec::new()),
        "Ljava/util/HashMap;" | "Ljava/util/LinkedHashMap;" => {
            Payload::HashedMap(hash_maps::HashMapData::default())
        }
        "Ljava/util/Hashtable;" | "Ljava/util/concurrent/ConcurrentHashMap;" => {
            Payload::Map(Vec::new())
        }
        "Ljava/util/WeakHashMap;" => Payload::WeakMap(Vec::new()),
        _ => return None,
    })
}
pub(super) fn inherits(class: &str, base: &str) -> bool {
    if class == "Ljava/util/AbstractMap;" && base == "Ljava/util/Map;" {
        return true;
    }
    if class == "Ljava/util/AbstractCollection;"
        && matches!(base, "Ljava/util/Collection;" | "Ljava/lang/Iterable;")
    {
        return true;
    }
    if class == "Ljava/util/AbstractSet;" && base == "Ljava/util/Set;" {
        return true;
    }
    if class == "Ljava/util/Collections$SetFromMap;" && base == "Ljava/io/Serializable;" {
        return true;
    }
    if class == "Lorg/kyvex/rift/ReadOnlyIterator;" && base == "Ljava/util/Iterator;" {
        return true;
    }
    if class == "Ljava/util/Arrays$ArrayList;" && base == "Ljava/io/Serializable;" {
        return true;
    }
    if matches!(
        class,
        "Ljava/util/concurrent/LinkedBlockingQueue;" | "Ljava/util/concurrent/LinkedBlockingDeque;"
    ) && matches!(
        base,
        "Ljava/util/concurrent/BlockingQueue;"
            | "Ljava/util/Queue;"
            | "Ljava/util/Collection;"
            | "Ljava/lang/Iterable;"
    ) {
        return true;
    }
    if class.starts_with("Ljava/util/Collections$Synchronized")
        || class.starts_with("Ljava/util/Collections$Unmodifiable")
    {
        if class.ends_with("Set;") && base == "Ljava/util/Set;"
            || class.ends_with("List;") && base == "Ljava/util/List;"
            || class.ends_with("Map;") && base == "Ljava/util/Map;"
        {
            return true;
        }
        if !class.ends_with("Map;")
            && matches!(base, "Ljava/util/Collection;" | "Ljava/lang/Iterable;")
        {
            return true;
        }
    }
    if matches!(
        class,
        "Ljava/util/concurrent/ConcurrentLinkedQueue;"
            | "Ljava/util/ArrayDeque;"
            | "Ljava/util/LinkedList;"
    ) && matches!(
        base,
        "Ljava/util/Queue;" | "Ljava/util/Collection;" | "Ljava/lang/Iterable;"
    ) {
        return true;
    }
    if matches!(class, "Ljava/util/ArrayDeque;" | "Ljava/util/LinkedList;")
        && base == "Ljava/util/Deque;"
    {
        return true;
    }
    let list = matches!(
        class,
        "Ljava/util/ArrayList;"
            | "Ljava/util/LinkedList;"
            | "Ljava/util/Vector;"
            | "Ljava/util/Arrays$ArrayList;"
            | "Ljava/util/concurrent/CopyOnWriteArrayList;"
            | "Ljava/util/Collections$EmptyList;"
            | "Ljava/util/Collections$SingletonList;"
    );
    let set = matches!(
        class,
        "Ljava/util/HashSet;"
            | "Ljava/util/LinkedHashSet;"
            | "Ljava/util/concurrent/CopyOnWriteArraySet;"
            | "Ljava/util/HashMap$KeySet;"
            | "Ljava/util/HashMap$EntrySet;"
            | "Ljava/util/Collections$EmptySet;"
    );
    let map = matches!(
        class,
        "Ljava/util/HashMap;"
            | "Ljava/util/LinkedHashMap;"
            | "Ljava/util/Hashtable;"
            | "Ljava/util/WeakHashMap;"
            | "Ljava/util/concurrent/ConcurrentHashMap;"
            | "Ljava/util/Collections$EmptyMap;"
    );
    (list && matches!(base, "Ljava/util/List;" | "Ljava/util/AbstractList;"))
        || (set && base == "Ljava/util/Set;")
        || ((list || set || class == "Ljava/util/HashMap$Values;")
            && matches!(
                base,
                "Ljava/util/Collection;"
                    | "Ljava/lang/Iterable;"
                    | "Ljava/util/AbstractCollection;"
            ))
        || (map && matches!(base, "Ljava/util/Map;" | "Ljava/util/AbstractMap;"))
        || (class == "Ljava/util/concurrent/ConcurrentHashMap;"
            && base == "Ljava/util/concurrent/ConcurrentMap;")
        || (class == "Ljava/util/ArrayList$Itr;" && base == "Ljava/util/Iterator;")
        || (class == "Ljava/util/HashMap$Node;" && base == "Ljava/util/Map$Entry;")
        || (matches!(
            class,
            "Ljava/util/ArrayList;"
                | "Ljava/util/Vector;"
                | "Ljava/util/Arrays$ArrayList;"
                | "Ljava/util/concurrent/CopyOnWriteArrayList;"
        ) && base == "Ljava/util/RandomAccess;")
}
impl Runtime {
    pub(super) fn empty_collection(&mut self, kind: usize) -> Result<u32> {
        if self.empty_collections[kind] == 0 {
            let (class, payload) = match kind {
                0 => (
                    "Ljava/util/Collections$EmptyList;",
                    Payload::List(Vec::new()),
                ),
                1 => ("Ljava/util/Collections$EmptySet;", Payload::Set(Vec::new())),
                2 => ("Ljava/util/Collections$EmptyMap;", Payload::Map(Vec::new())),
                _ => return Err("Empty collection kind".into()),
            };
            self.empty_collections[kind] = self.allocate(class, payload)?;
        }
        Ok(self.empty_collections[kind])
    }
    fn map_entries(&self, id: u32) -> Result<&[(u32, u32)]> {
        match &self.object(id)?.payload {
            Payload::Map(v) | Payload::WeakMap(v) => Ok(v),
            Payload::HashedMap(map) => Ok(&map.entries),
            Payload::CollectionWrapper { target, .. } => self.map_entries(*target),
            _ => Err("Expected Java Map".into()),
        }
    }
    fn map_at(&mut self, id: u32, key: u32) -> Result<(Option<usize>, u32)> {
        let _roots = self.scoped_library_roots(&[id, key])?;
        let hash = if matches!(self.object(id)?.payload, Payload::HashedMap(_)) {
            self.java_key_hash(key)?
        } else {
            0
        };
        let version = self.object(id)?.version;
        let candidates = match &self.object(id)?.payload {
            Payload::HashedMap(map) => map.candidates(hash).to_vec(),
            _ => (0..self.map_entries(id)?.len()).collect(),
        };
        for index in candidates {
            let candidate = self.map_entries(id)?[index].0;
            let equal = self.value_equal(key, candidate)?;
            self.check_map_version(id, version)?;
            if equal {
                return Ok((Some(index), hash));
            }
        }
        Ok((None, hash))
    }
    fn check_map_version(&self, id: u32, version: u64) -> Result<()> {
        if self.collection_version(id)? != version {
            return Err(fault(
                "Ljava/util/ConcurrentModificationException;",
                "Map modified during a guest callback",
            ));
        }
        Ok(())
    }
    fn map_insert(&mut self, id: u32, key: u32, value: u32, hash: u32) -> Result<()> {
        if self.map_entries(id)?.len() >= LIMIT {
            return Err("Java map quota".into());
        }
        let object = self.object_mut(id)?;
        match &mut object.payload {
            Payload::HashedMap(map) => map.push(key, value, hash),
            Payload::Map(entries) | Payload::WeakMap(entries) => entries.push((key, value)),
            _ => return Err("Expected Java Map storage".into()),
        }
        object.version = object.version.wrapping_add(1);
        Ok(())
    }
    fn map_replace(&mut self, id: u32, index: usize, value: u32) -> Result<u32> {
        let entries = match &mut self.object_mut(id)?.payload {
            Payload::HashedMap(map) => &mut map.entries,
            Payload::Map(entries) | Payload::WeakMap(entries) => entries,
            _ => return Err("Expected Java Map storage".into()),
        };
        let (_, old) = entries.get_mut(index).ok_or("Map entry index")?;
        Ok(std::mem::replace(old, value))
    }
    fn map_remove_index(&mut self, id: u32, index: usize) -> Result<()> {
        if index >= self.map_entries(id)?.len() {
            return Err("Map entry index".into());
        }
        let object = self.object_mut(id)?;
        match &mut object.payload {
            Payload::HashedMap(map) => map.remove(index),
            Payload::Map(entries) | Payload::WeakMap(entries) => entries.remove(index),
            _ => return Err("Expected Java Map storage".into()),
        };
        object.version = object.version.wrapping_add(1);
        Ok(())
    }
    fn map_clear(&mut self, id: u32) -> Result<()> {
        if self.map_entries(id)?.is_empty() {
            return Ok(());
        }
        let object = self.object_mut(id)?;
        match &mut object.payload {
            Payload::HashedMap(map) => map.clear(),
            Payload::Map(entries) | Payload::WeakMap(entries) => entries.clear(),
            _ => return Err("Expected Java Map storage".into()),
        }
        object.version = object.version.wrapping_add(1);
        Ok(())
    }
    fn map_entry_position(
        &mut self,
        map: u32,
        key: u32,
        insertion_hash: Option<u32>,
    ) -> Result<Option<usize>> {
        if let Payload::HashedMap(data) = &self.object(map)?.payload
            && let Some(hash) = insertion_hash
        {
            return Ok(data
                .candidates(hash)
                .iter()
                .copied()
                .find(|&index| data.entries[index].0 == key));
        }
        self.map_at(map, key).map(|(index, _)| index)
    }
    fn collection_len(&self, id: u32) -> Result<usize> {
        match &self.object(id)?.payload {
            Payload::List(v) | Payload::Set(v) => Ok(v.len()),
            Payload::ArrayListView(array) => match &self.object(*array)?.payload {
                Payload::Array(values) => Ok(values.len()),
                _ => Err("Array list backing object type".into()),
            },
            Payload::MapView { map, .. } => Ok(self.map_entries(*map)?.len()),
            Payload::BundleKeys(bundle) => match &self.object(*bundle)?.payload {
                Payload::Bundle(values) => Ok(values.len()),
                _ => Err("Bundle key view target".into()),
            },
            Payload::CollectionWrapper { target, .. } => self.collection_len(*target),
            _ => Err("Expected Java Collection".into()),
        }
    }
    fn collection_version(&self, id: u32) -> Result<u64> {
        let o = self.object(id)?;
        if let Payload::MapView { map, .. } = o.payload {
            Ok(self.object(map)?.version)
        } else if let Payload::BundleKeys(bundle) = o.payload {
            Ok(self.object(bundle)?.version)
        } else if let Payload::CollectionWrapper { target, .. } = o.payload {
            self.collection_version(target)
        } else {
            Ok(o.version)
        }
    }
    fn array_list_remove_if(&mut self, id: u32, predicate: u32) -> Result<u64> {
        self.object(predicate)?;
        let _roots = self.scoped_library_roots(&[id, predicate])?;
        let version = self.collection_version(id)?;
        let size = self.collection_len(id)?;
        let mut remove = Vec::with_capacity(size);
        for index in 0..size {
            let value = self.collection_at(id, index)?;
            remove.push(
                self.collection_dispatch(
                    predicate,
                    "Ljava/util/function/Predicate;",
                    "test(Ljava/lang/Object;)Z",
                    &[value],
                )? != 0,
            );
            if self.collection_version(id)? != version {
                return Err(fault(
                    "Ljava/util/ConcurrentModificationException;",
                    "ArrayList modified during removeIf",
                ));
            }
        }
        if !remove.contains(&true) {
            return Ok(0);
        }
        let list = self.object_mut(id)?;
        let Payload::List(values) = &mut list.payload else {
            return Err("Expected ArrayList storage".into());
        };
        if values.len() != remove.len() {
            return Err(fault(
                "Ljava/util/ConcurrentModificationException;",
                "ArrayList size changed during removeIf",
            ));
        }
        let mut index = 0;
        values.retain(|_| {
            let keep = !remove[index];
            index += 1;
            keep
        });
        list.version = list.version.wrapping_add(1);
        Ok(1)
    }
    fn collection_at(&mut self, id: u32, index: usize) -> Result<u32> {
        if let Payload::ArrayListView(array) = self.object(id)?.payload {
            let Payload::Array(values) = &self.object(array)?.payload else {
                return Err("Array list backing object type".into());
            };
            return values.get(index).map(|v| *v as u32).ok_or_else(|| {
                fault(
                    "Ljava/lang/ArrayIndexOutOfBoundsException;",
                    "Array list index",
                )
            });
        }
        if let Payload::CollectionWrapper { target, .. } = self.object(id)?.payload {
            let protected_entry =
                self.object(id)?.class == "Ljava/util/Collections$UnmodifiableEntrySet;";
            let value = self.collection_at(target, index)?;
            if protected_entry
                && let Payload::MapEntry { readonly, .. } = &mut self.object_mut(value)?.payload
            {
                *readonly = true;
            }
            return Ok(value);
        }
        if let Payload::BundleKeys(bundle) = self.object(id)?.payload {
            let Payload::Bundle(values) = &self.object(bundle)?.payload else {
                return Err("Bundle key view target".into());
            };
            let key = values.keys().nth(index).cloned().ok_or_else(|| {
                fault(
                    "Ljava/lang/IndexOutOfBoundsException;",
                    "Bundle key view index",
                )
            })?;
            return if let Some(key) = key {
                self.string_units(key)
            } else {
                Ok(0)
            };
        }
        let (map, kind) = match &self.object(id)?.payload {
            Payload::List(v) | Payload::Set(v) => {
                return v.get(index).copied().ok_or_else(|| {
                    fault("Ljava/lang/IndexOutOfBoundsException;", "collection index")
                });
            }
            Payload::MapView { map, kind } => (*map, *kind),
            Payload::CollectionWrapper { target, .. } => return self.collection_at(*target, index),
            _ => return Err("Expected Java Collection".into()),
        };
        let (key, value) = *self.map_entries(map)?.get(index).ok_or("Map view index")?;
        Ok(match kind {
            0 => key,
            1 => value,
            _ => self.allocate(
                "Ljava/util/HashMap$Node;",
                Payload::MapEntry {
                    map,
                    key,
                    insertion_hash: match &self.object(map)?.payload {
                        Payload::HashedMap(data) => Some(data.insertion_hash(index)),
                        _ => None,
                    },
                    readonly: false,
                },
            )?,
        })
    }
    pub(super) fn collection_values(&mut self, id: u32) -> Result<Vec<u32>> {
        if self.delegated_collection(id)? {
            let mut roots = self.scoped_library_roots(&[id])?;
            let iterator = self.collection_dispatch(
                id,
                "Ljava/util/Collection;",
                "iterator()Ljava/util/Iterator;",
                &[],
            )? as u32;
            roots.keep(iterator)?;
            let mut values = Vec::new();
            while self.collection_dispatch(iterator, "Ljava/util/Iterator;", "hasNext()Z", &[])?
                != 0
            {
                if values.len() >= LIMIT {
                    return Err("Collection snapshot quota".into());
                }
                let value = self.collection_dispatch(
                    iterator,
                    "Ljava/util/Iterator;",
                    "next()Ljava/lang/Object;",
                    &[],
                )? as u32;
                roots.keep(value)?;
                values.push(value);
            }
            return Ok(values);
        }
        let n = self.collection_len(id)?;
        let mut out = Vec::with_capacity(n);
        for i in 0..n {
            out.push(self.collection_at(id, i)?);
        }
        Ok(out)
    }
    fn collection_remove_index(&mut self, id: u32, index: usize) -> Result<u32> {
        if matches!(self.object(id)?.payload, Payload::ArrayListView(_)) {
            return Err(fault(
                "Ljava/lang/UnsupportedOperationException;",
                "Fixed-size array list",
            ));
        }
        if let Payload::CollectionWrapper {
            target, readonly, ..
        } = self.object(id)?.payload
        {
            if readonly {
                return Err(fault(
                    "Ljava/lang/UnsupportedOperationException;",
                    "Read-only collection iterator",
                ));
            }
            return self.collection_remove_index(target, index);
        }
        if let Payload::BundleKeys(bundle) = self.object(id)?.payload {
            let value = self.collection_at(id, index)?;
            let key = if value == 0 {
                None
            } else {
                Some(self.units(value)?)
            };
            let object = self.object_mut(bundle)?;
            let Payload::Bundle(values) = &mut object.payload else {
                return Err("Bundle key view target".into());
            };
            values.remove(&key);
            object.version = object.version.wrapping_add(1);
            return Ok(value);
        }
        let map = match &self.object(id)?.payload {
            Payload::MapView { map, .. } => Some(*map),
            _ => None,
        };
        if let Some(map) = map {
            let value = self.collection_at(id, index)?;
            self.map_remove_index(map, index)?;
            return Ok(value);
        }
        let o = self.object_mut(id)?;
        let values = match &mut o.payload {
            Payload::List(v) | Payload::Set(v) => v,
            _ => return Err("Expected Java Collection".into()),
        };
        if index >= values.len() {
            return Err(fault(
                "Ljava/lang/IndexOutOfBoundsException;",
                "remove index",
            ));
        }
        let old = values.remove(index);
        o.version = o.version.wrapping_add(1);
        Ok(old)
    }
    pub(super) fn collections_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Collection signature")?;
        if !(class.starts_with("Ljava/util/") || class == "Ljava/lang/Iterable;") {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Collection argument count");
        if sig == "Ljava/util/AbstractCollection;->isEmpty()Z" {
            let size =
                self.collection_dispatch(arg(0)?, "Ljava/util/Collection;", "size()I", &[])?;
            return Ok(Some((size == 0) as u64));
        }
        if sig == "Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;" {
            let array = arg(0)?;
            let object = self.object(array)?;
            if !object.class.starts_with("[L") && !object.class.starts_with("[[") {
                return Err("Arrays.asList requires a reference array".into());
            }
            let Payload::Array(values) = &object.payload else {
                return Err("Arrays.asList payload type".into());
            };
            if values.len() > LIMIT {
                return Err("Array list entry quota".into());
            }
            return Ok(Some(self.allocate(
                "Ljava/util/Arrays$ArrayList;",
                Payload::ArrayListView(array),
            )? as u64));
        }
        if class == "Ljava/util/Collections;" {
            if method == "addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z" {
                let target = arg(0)?;
                self.collection_dispatch(target, "Ljava/util/Collection;", "size()I", &[])?;
                let array = self.object(arg(1)?)?;
                if !array.class.starts_with("[L") && !array.class.starts_with("[[") {
                    return Err("Collections.addAll requires Object[]".into());
                }
                let Payload::Array(values) = &array.payload else {
                    return Err("Collections.addAll array payload".into());
                };
                let values = values.clone();
                if values.len() > LIMIT {
                    return Err("Collections.addAll element quota".into());
                }
                let mut changed = false;
                let mut roots = self.scoped_library_roots(&[target, arg(1)?])?;
                for value in &values {
                    roots.keep(u32::try_from(*value)?)?;
                }
                for value in values {
                    changed |= self.collection_dispatch(
                        target,
                        "Ljava/util/Collection;",
                        "add(Ljava/lang/Object;)Z",
                        &[u32::try_from(value)?],
                    )? != 0;
                }
                return Ok(Some(changed as u64));
            }
            let wrapper = match method {
                "synchronizedSet(Ljava/util/Set;)Ljava/util/Set;" => {
                    Some("Ljava/util/Collections$SynchronizedSet;")
                }
                "synchronizedList(Ljava/util/List;)Ljava/util/List;" => {
                    Some("Ljava/util/Collections$SynchronizedList;")
                }
                "synchronizedCollection(Ljava/util/Collection;)Ljava/util/Collection;" => {
                    Some("Ljava/util/Collections$SynchronizedCollection;")
                }
                "synchronizedMap(Ljava/util/Map;)Ljava/util/Map;" => {
                    Some("Ljava/util/Collections$SynchronizedMap;")
                }
                "unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;" => {
                    Some("Ljava/util/Collections$UnmodifiableSet;")
                }
                "unmodifiableList(Ljava/util/List;)Ljava/util/List;" => {
                    Some("Ljava/util/Collections$UnmodifiableList;")
                }
                "unmodifiableCollection(Ljava/util/Collection;)Ljava/util/Collection;" => {
                    Some("Ljava/util/Collections$UnmodifiableCollection;")
                }
                "unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;" => {
                    Some("Ljava/util/Collections$UnmodifiableMap;")
                }
                _ => None,
            };
            if let Some(class) = wrapper {
                let target = arg(0)?;
                if class.ends_with("Map;") {
                    self.map_entries(target)?;
                } else {
                    if self.delegated_collection(target)? {
                        self.collection_dispatch(target, "Ljava/util/Collection;", "size()I", &[])?;
                    } else {
                        self.collection_len(target)?;
                    }
                }
                return Ok(Some(self.allocate(
                    class,
                    Payload::CollectionWrapper {
                        target,
                        readonly: method.starts_with("unmodifiable"),
                        mutex: 0,
                    },
                )? as u64));
            }
            let empty = match method {
                "emptyList()Ljava/util/List;" => Some(0),
                "emptySet()Ljava/util/Set;" => Some(1),
                "emptyMap()Ljava/util/Map;" => Some(2),
                _ => None,
            };
            if let Some(kind) = empty {
                return Ok(Some(self.empty_collection(kind)? as u64));
            }
            if method == "singletonList(Ljava/lang/Object;)Ljava/util/List;" {
                return Ok(Some(self.allocate(
                    "Ljava/util/Collections$SingletonList;",
                    Payload::List(vec![arg(0)?]),
                )? as u64));
            }
        }
        let Some(&id) = a.first() else {
            return Ok(None);
        };
        if let Payload::CollectionWrapper {
            target, readonly, ..
        } = self.object(id)?.payload
        {
            // Object.getClass describes the wrapper, never its backing data.
            if method == "getClass()Ljava/lang/Class;" {
                return Ok(None);
            }
            if readonly {
                let name = method.split('(').next().unwrap_or("");
                if matches!(
                    name,
                    "add"
                        | "addAll"
                        | "addIfAbsent"
                        | "remove"
                        | "removeAll"
                        | "removeIf"
                        | "retainAll"
                        | "clear"
                        | "set"
                        | "put"
                        | "putAll"
                        | "putIfAbsent"
                        | "replace"
                        | "replaceAll"
                        | "compute"
                        | "computeIfAbsent"
                        | "computeIfPresent"
                        | "merge"
                        | "sort"
                ) {
                    return Err(fault(
                        "Ljava/lang/UnsupportedOperationException;",
                        "Read-only collection mutation",
                    ));
                }
            }
            let mut args = a.to_vec();
            args[0] = target;
            let value = Some(self.collection_dispatch(target, class, method, &args[1..])?);
            if readonly && let Some(value) = value {
                let value_id = u32::try_from(value).unwrap_or(0);
                if method == "iterator()Ljava/util/Iterator;" {
                    let protect_entries =
                        self.object(id)?.class == "Ljava/util/Collections$UnmodifiableEntrySet;";
                    return Ok(Some(self.allocate(
                        "Lorg/kyvex/rift/ReadOnlyIterator;",
                        Payload::ReadOnlyIterator {
                            iterator: value_id,
                            protect_entries,
                        },
                    )? as u64));
                }
                if self.object(id)?.class == "Ljava/util/Collections$UnmodifiableEntrySet;"
                    && method.starts_with("toArray(")
                {
                    let Payload::Array(entries) = &self.object(value_id)?.payload else {
                        return Err("Entry array result type".into());
                    };
                    let count = self.collection_len(target)?;
                    let entries: Vec<u64> = entries.iter().take(count).copied().collect();
                    for entry in entries.into_iter().filter(|v| *v != 0) {
                        if let Payload::MapEntry { readonly, .. } =
                            &mut self.object_mut(u32::try_from(entry)?)?.payload
                        {
                            *readonly = true;
                        }
                    }
                }
                if matches!(
                    method,
                    "keySet()Ljava/util/Set;"
                        | "entrySet()Ljava/util/Set;"
                        | "values()Ljava/util/Collection;"
                ) {
                    let class = if method.starts_with("entrySet") {
                        "Ljava/util/Collections$UnmodifiableEntrySet;"
                    } else if method.starts_with("keySet") {
                        "Ljava/util/Collections$UnmodifiableSet;"
                    } else {
                        "Ljava/util/Collections$UnmodifiableCollection;"
                    };
                    return Ok(Some(self.allocate(
                        class,
                        Payload::CollectionWrapper {
                            target: value_id,
                            readonly: true,
                            mutex: 0,
                        },
                    )? as u64));
                }
            }
            return Ok(value);
        }
        if let Payload::Iterator(state) = &self.object(id)?.payload {
            let mut s = state.clone();
            if s.snapshot.is_none()
                && !s.weakly_consistent
                && self.collection_version(s.source)? != s.expected
            {
                return Err(fault(
                    "Ljava/util/ConcurrentModificationException;",
                    "collection changed during iteration",
                ));
            }
            let n = if let Some(values) = &s.snapshot {
                values.len()
            } else {
                self.collection_len(s.source)?
            };
            let result = match method {
                "hasNext()Z" => return Ok(Some((s.at < n) as u64)),
                "next()Ljava/lang/Object;" => {
                    if s.at >= n {
                        return Err(fault(
                            "Ljava/util/NoSuchElementException;",
                            "iterator exhausted",
                        ));
                    }
                    let value = if let Some(v) = &s.snapshot {
                        v[s.at]
                    } else {
                        self.collection_at(s.source, s.at)?
                    };
                    s.last = Some(s.at);
                    s.at += 1;
                    value as u64
                }
                "remove()V" => {
                    if s.snapshot.is_some() {
                        return Err(fault(
                            "Ljava/lang/UnsupportedOperationException;",
                            "snapshot iterator is immutable",
                        ));
                    }
                    let index = s.last.take().ok_or_else(|| {
                        fault(
                            "Ljava/lang/IllegalStateException;",
                            "next must precede remove",
                        )
                    })?;
                    self.collection_remove_index(s.source, index)?;
                    s.at = index;
                    s.expected = self.collection_version(s.source)?;
                    0
                }
                _ => return Ok(None),
            };
            self.object_mut(id)?.payload = Payload::Iterator(s);
            return Ok(Some(result));
        }
        if let Payload::MapEntry {
            map,
            key,
            insertion_hash,
            readonly,
        } = self.object(id)?.payload
        {
            return Ok(Some(match method {
                "getKey()Ljava/lang/Object;" => key as u64,
                "getValue()Ljava/lang/Object;" => {
                    if let Some(index) = self.map_entry_position(map, key, insertion_hash)? {
                        self.map_entries(map)?[index].1 as u64
                    } else {
                        0
                    }
                }
                "setValue(Ljava/lang/Object;)Ljava/lang/Object;" => {
                    if readonly {
                        return Err(fault(
                            "Ljava/lang/UnsupportedOperationException;",
                            "Read-only map entry",
                        ));
                    }
                    if arg(1)? == 0
                        && self.object(map)?.class == "Ljava/util/concurrent/ConcurrentHashMap;"
                    {
                        return Err(fault(
                            "Ljava/lang/NullPointerException;",
                            "concurrent map null entry value",
                        ));
                    }
                    let at = self
                        .map_entry_position(map, key, insertion_hash)?
                        .ok_or("Entry no longer in map")?;
                    self.map_replace(map, at, arg(1)?)? as u64
                }
                _ => return Ok(None),
            }));
        }
        let is_collection = matches!(
            self.object(id)?.payload,
            Payload::List(_)
                | Payload::Set(_)
                | Payload::MapView { .. }
                | Payload::BundleKeys(_)
                | Payload::ArrayListView(_)
        );
        let immutable = self
            .object(id)?
            .class
            .starts_with("Ljava/util/Collections$Empty")
            || self.object(id)?.class == "Ljava/util/Collections$SingletonList;";
        if is_collection {
            let concrete = self.object(id)?.class.clone();
            let copy = concrete.contains("CopyOnWrite");
            let is_list = matches!(
                self.object(id)?.payload,
                Payload::List(_) | Payload::ArrayListView(_)
            );
            let n = self.collection_len(id)?;
            match method {
                "removeIf(Ljava/util/function/Predicate;)Z"
                    if self.subclass(&concrete, "Ljava/util/ArrayList;")? =>
                {
                    return self.array_list_remove_if(id, arg(1)?).map(Some);
                }
                "iterator()Ljava/util/Iterator;" => {
                    let snapshot = if copy {
                        Some(self.collection_values(id)?)
                    } else {
                        None
                    };
                    let state = IteratorState {
                        source: if copy { 0 } else { id },
                        snapshot,
                        at: 0,
                        expected: self.collection_version(id)?,
                        last: None,
                        weakly_consistent: concrete
                            == "Ljava/util/concurrent/ConcurrentLinkedQueue;"
                            || matches!(self.object(id)?.payload, Payload::MapView {map,..} if self.object(map)?.class=="Ljava/util/concurrent/ConcurrentHashMap;"),
                    };
                    return Ok(Some(
                        self.allocate("Ljava/util/ArrayList$Itr;", Payload::Iterator(state))?
                            as u64,
                    ));
                }
                "remainingCapacity()I"
                    if matches!(
                        concrete.as_str(),
                        "Ljava/util/concurrent/LinkedBlockingQueue;"
                            | "Ljava/util/concurrent/LinkedBlockingDeque;"
                    ) =>
                {
                    let capacity = self
                        .object(id)?
                        .fields
                        .get(&QUEUE_CAPACITY)
                        .copied()
                        .unwrap_or(i32::MAX as u64);
                    return Ok(Some(capacity.saturating_sub(n as u64)));
                }
                "size()I" => return Ok(Some(n as u64)),
                "isEmpty()Z" => return Ok(Some((n == 0) as u64)),
                "get(I)Ljava/lang/Object;" if is_list => {
                    return Ok(Some(self.collection_at(id, arg(1)? as usize)? as u64));
                }
                "peek()Ljava/lang/Object;"
                | "peekFirst()Ljava/lang/Object;"
                | "peekLast()Ljava/lang/Object;"
                | "poll()Ljava/lang/Object;"
                | "pollFirst()Ljava/lang/Object;"
                | "pollLast()Ljava/lang/Object;"
                | "remove()Ljava/lang/Object;"
                | "element()Ljava/lang/Object;"
                | "getFirst()Ljava/lang/Object;"
                | "getLast()Ljava/lang/Object;" => {
                    if n == 0 {
                        if method.starts_with("remove")
                            || method.starts_with("element")
                            || method.starts_with("get")
                        {
                            return Err(fault("Ljava/util/NoSuchElementException;", "empty queue"));
                        }
                        return Ok(Some(0));
                    }
                    let index = if method.contains("Last") { n - 1 } else { 0 };
                    let value = if method.starts_with("poll") || method.starts_with("remove") {
                        self.collection_remove_index(id, index)?
                    } else {
                        self.collection_at(id, index)?
                    };
                    return Ok(Some(value as u64));
                }
                "toArray()[Ljava/lang/Object;"
                | "toArray([Ljava/lang/Object;)[Ljava/lang/Object;" => {
                    let values = self.collection_values(id)?;
                    if method.contains("([") {
                        let target = arg(1)?;
                        let o = self.object(target)?;
                        let Payload::Array(_) = &o.payload else {
                            return Err("toArray destination type".into());
                        };
                        if !o.class.starts_with("[L") && !o.class.starts_with("[[") {
                            return Err("toArray destination must be a reference array".into());
                        }
                        let component = o
                            .class
                            .strip_prefix('[')
                            .ok_or("toArray array class")?
                            .to_owned();
                        for value in &values {
                            if *value != 0
                                && !self.subclass(&self.object(*value)?.class, &component)?
                            {
                                return Err(fault(
                                    "Ljava/lang/ArrayStoreException;",
                                    "toArray destination component",
                                ));
                            }
                        }
                        let Payload::Array(array) = &self.object(target)?.payload else {
                            unreachable!()
                        };
                        if array.len() >= n {
                            let Payload::Array(array) = &mut self.object_mut(target)?.payload
                            else {
                                unreachable!()
                            };
                            for (i, v) in values.iter().enumerate() {
                                array[i] = *v as u64;
                            }
                            if array.len() > n {
                                array[n] = 0;
                            }
                            return Ok(Some(target as u64));
                        }
                        let class = self.object(target)?.class.clone();
                        return Ok(Some(self.allocate(
                            &class,
                            Payload::Array(values.iter().map(|v| *v as u64).collect()),
                        )? as u64));
                    }
                    return Ok(Some(self.allocate(
                        "[Ljava/lang/Object;",
                        Payload::Array(values.iter().map(|v| *v as u64).collect()),
                    )? as u64));
                }
                "contains(Ljava/lang/Object;)Z"
                | "indexOf(Ljava/lang/Object;)I"
                | "lastIndexOf(Ljava/lang/Object;)I"
                | "remove(Ljava/lang/Object;)Z" => {
                    let mut found = None;
                    for i in 0..n {
                        let value = self.collection_at(id, i)?;
                        if self.value_equal(value, arg(1)?)? {
                            found = Some(i);
                            if !method.starts_with("lastIndex") {
                                break;
                            }
                        }
                    }
                    if method.starts_with("remove") {
                        if immutable {
                            return Err(fault(
                                "Ljava/lang/UnsupportedOperationException;",
                                "immutable collection",
                            ));
                        }
                        if let Some(at) = found {
                            self.collection_remove_index(id, at)?;
                        }
                    }
                    return Ok(Some(
                        if method.starts_with("indexOf") || method.starts_with("lastIndexOf") {
                            found.map_or(u32::MAX, |i| i as u32) as u64
                        } else {
                            found.is_some() as u64
                        },
                    ));
                }
                _ => {}
            }
            if let Payload::BundleKeys(bundle) = self.object(id)?.payload {
                if method == "clear()V" {
                    return self.object_api("Landroid/os/Bundle;->clear()V", &[bundle]);
                }
                if matches!(
                    method,
                    "add(Ljava/lang/Object;)Z" | "addAll(Ljava/util/Collection;)Z"
                ) {
                    return Err(fault(
                        "Ljava/lang/UnsupportedOperationException;",
                        "Cannot add a Bundle key without a value",
                    ));
                }
                return Ok(None);
            }
            if matches!(self.object(id)?.payload, Payload::MapView { .. }) {
                if method == "clear()V" {
                    let Payload::MapView { map, .. } = self.object(id)?.payload else {
                        unreachable!()
                    };
                    self.map_clear(map)?;
                    return Ok(Some(0));
                }
                return Ok(None);
            }
            if let Payload::ArrayListView(array) = self.object(id)?.payload {
                let result = match method {
                    "set(ILjava/lang/Object;)Ljava/lang/Object;" => {
                        let at = arg(1)? as usize;
                        if at >= n {
                            return Err(fault(
                                "Ljava/lang/ArrayIndexOutOfBoundsException;",
                                "Array list set index",
                            ));
                        }
                        let value = arg(2)?;
                        let component = self
                            .object(array)?
                            .class
                            .strip_prefix('[')
                            .ok_or("Array list component")?
                            .to_owned();
                        if value != 0
                            && !self.class_assignable(&component, &self.object(value)?.class)?
                        {
                            return Err(fault(
                                "Ljava/lang/ArrayStoreException;",
                                "Array list backing component type",
                            ));
                        }
                        let Payload::Array(values) = &mut self.object_mut(array)?.payload else {
                            unreachable!();
                        };
                        let old = values[at];
                        values[at] = value as u64;
                        old
                    }
                    "clear()V" if n == 0 => 0,
                    "addAll(Ljava/util/Collection;)Z" if self.collection_len(arg(1)?)? == 0 => 0,
                    "add(Ljava/lang/Object;)Z"
                    | "add(ILjava/lang/Object;)V"
                    | "remove(I)Ljava/lang/Object;"
                    | "clear()V"
                    | "addAll(Ljava/util/Collection;)Z" => {
                        return Err(fault(
                            "Ljava/lang/UnsupportedOperationException;",
                            "Fixed-size array list",
                        ));
                    }
                    _ => return Ok(None),
                };
                return Ok(Some(result));
            }
            let mut values = self.collection_values(id)?;
            let mut structural = false;
            let modifying = method.starts_with("add(")
                || method.starts_with("addAll(")
                || method.starts_with("addIfAbsent(")
                || method.starts_with("remove(")
                || method.starts_with("set(")
                || method == "clear()V";
            if immutable && modifying {
                return Err(fault(
                    "Ljava/lang/UnsupportedOperationException;",
                    "immutable collection",
                ));
            }
            let result = match method {
                "<init>()V" => {
                    if matches!(
                        concrete.as_str(),
                        "Ljava/util/concurrent/LinkedBlockingQueue;"
                            | "Ljava/util/concurrent/LinkedBlockingDeque;"
                    ) {
                        self.object_mut(id)?
                            .fields
                            .insert(QUEUE_CAPACITY, i32::MAX as u64);
                    }
                    0
                }
                "<init>(I)V" => {
                    if matches!(
                        concrete.as_str(),
                        "Ljava/util/concurrent/LinkedBlockingQueue;"
                            | "Ljava/util/concurrent/LinkedBlockingDeque;"
                    ) {
                        let capacity = arg(1)? as i32;
                        if capacity <= 0 {
                            return Err(fault(
                                "Ljava/lang/IllegalArgumentException;",
                                "Blocking queue capacity must be positive",
                            ));
                        }
                        self.object_mut(id)?
                            .fields
                            .insert(QUEUE_CAPACITY, capacity as u64);
                    }
                    if (arg(1)? as i32) < 0 {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "negative capacity",
                        ));
                    }
                    0
                }
                "<init>(Ljava/util/Collection;)V" | "addAll(Ljava/util/Collection;)Z" => {
                    let incoming = self.collection_values(arg(1)?)?;
                    if matches!(
                        concrete.as_str(),
                        "Ljava/util/concurrent/LinkedBlockingQueue;"
                            | "Ljava/util/concurrent/LinkedBlockingDeque;"
                    ) {
                        if method == "addAll(Ljava/util/Collection;)Z" {
                            if id == arg(1)? {
                                return Err(fault(
                                    "Ljava/lang/IllegalArgumentException;",
                                    "Blocking queue cannot add itself",
                                ));
                            }
                            let before = values.len();
                            let capacity = self
                                .object(id)?
                                .fields
                                .get(&QUEUE_CAPACITY)
                                .copied()
                                .unwrap_or(i32::MAX as u64)
                                as usize;
                            for value in incoming {
                                let error = if value == 0 {
                                    Some(fault(
                                        "Ljava/lang/NullPointerException;",
                                        "Blocking queue null element",
                                    ))
                                } else if values.len() >= capacity {
                                    Some(fault(
                                        "Ljava/lang/IllegalStateException;",
                                        "Blocking queue full",
                                    ))
                                } else if values.len() >= LIMIT {
                                    Some("Java collection quota".into())
                                } else {
                                    None
                                };
                                if let Some(error) = error {
                                    let changed = values.len() != before;
                                    let object = self.object_mut(id)?;
                                    object.payload = Payload::List(values);
                                    if changed {
                                        object.version = object.version.wrapping_add(1);
                                    }
                                    return Err(error);
                                }
                                values.push(value);
                            }
                            let changed = values.len() != before;
                            let object = self.object_mut(id)?;
                            object.payload = Payload::List(values);
                            if changed {
                                object.version = object.version.wrapping_add(1);
                            }
                            return Ok(Some(changed as u64));
                        }
                        if incoming.contains(&0) {
                            return Err(fault(
                                "Ljava/lang/NullPointerException;",
                                "Blocking queue null element",
                            ));
                        }
                        if method.starts_with("<init>") {
                            self.object_mut(id)?
                                .fields
                                .insert(QUEUE_CAPACITY, i32::MAX as u64);
                        }
                    }
                    let before = values.len();
                    if method.starts_with("<init>") {
                        values.clear();
                    }
                    for value in incoming {
                        let mut exists = false;
                        if !is_list {
                            for old in &values {
                                if self.value_equal(*old, value)? {
                                    exists = true;
                                    break;
                                }
                            }
                        }
                        if !exists {
                            values.push(value);
                        }
                    }
                    structural = before != values.len();
                    if method.starts_with("<init>") {
                        0
                    } else {
                        structural as u64
                    }
                }
                "add(Ljava/lang/Object;)Z"
                | "addIfAbsent(Ljava/lang/Object;)Z"
                | "offer(Ljava/lang/Object;)Z" => {
                    let value = arg(1)?;
                    if value == 0
                        && matches!(
                            concrete.as_str(),
                            "Ljava/util/concurrent/ConcurrentLinkedQueue;"
                                | "Ljava/util/concurrent/LinkedBlockingQueue;"
                                | "Ljava/util/concurrent/LinkedBlockingDeque;"
                                | "Ljava/util/ArrayDeque;"
                        )
                    {
                        return Err(fault(
                            "Ljava/lang/NullPointerException;",
                            "queue null element",
                        ));
                    }
                    if matches!(
                        concrete.as_str(),
                        "Ljava/util/concurrent/LinkedBlockingQueue;"
                            | "Ljava/util/concurrent/LinkedBlockingDeque;"
                    ) {
                        let capacity =
                            self.object(id)?
                                .fields
                                .get(&QUEUE_CAPACITY)
                                .copied()
                                .unwrap_or(i32::MAX as u64) as usize;
                        if values.len() >= capacity {
                            if method == "offer(Ljava/lang/Object;)Z" {
                                return Ok(Some(0));
                            }
                            return Err(fault(
                                "Ljava/lang/IllegalStateException;",
                                "Blocking queue full",
                            ));
                        }
                    }
                    let mut exists = false;
                    if !is_list || method.starts_with("addIfAbsent") {
                        for old in &values {
                            if self.value_equal(*old, value)? {
                                exists = true;
                                break;
                            }
                        }
                    }
                    if !exists {
                        values.push(value);
                        structural = true;
                    }
                    (!exists) as u64
                }
                "add(ILjava/lang/Object;)V" if is_list => {
                    let at = arg(1)? as usize;
                    if at > n {
                        return Err(fault(
                            "Ljava/lang/IndexOutOfBoundsException;",
                            "insert index",
                        ));
                    }
                    values.insert(at, arg(2)?);
                    structural = true;
                    0
                }
                "set(ILjava/lang/Object;)Ljava/lang/Object;" if is_list => {
                    let at = arg(1)? as usize;
                    let old = values.get_mut(at).ok_or_else(|| {
                        fault("Ljava/lang/IndexOutOfBoundsException;", "set index")
                    })?;
                    let result = *old;
                    *old = arg(2)?;
                    result as u64
                }
                "remove(I)Ljava/lang/Object;" if is_list => {
                    let at = arg(1)? as usize;
                    if at >= n {
                        return Err(fault(
                            "Ljava/lang/IndexOutOfBoundsException;",
                            "remove index",
                        ));
                    }
                    structural = true;
                    values.remove(at) as u64
                }
                "clear()V" => {
                    structural = !values.is_empty();
                    values.clear();
                    0
                }
                _ => return Ok(None),
            };
            if values.len() > LIMIT {
                return Err("Java collection quota".into());
            }
            let o = self.object_mut(id)?;
            o.payload = if is_list {
                Payload::List(values)
            } else {
                Payload::Set(values)
            };
            if structural {
                o.version = o.version.wrapping_add(1);
            }
            return Ok(Some(result));
        }
        if !matches!(
            self.object(id)?.payload,
            Payload::Map(_) | Payload::HashedMap(_) | Payload::WeakMap(_)
        ) {
            return Ok(None);
        }
        let nonnull = matches!(
            self.object(id)?.class.as_str(),
            "Ljava/util/concurrent/ConcurrentHashMap;" | "Ljava/util/Hashtable;"
        );
        let size = self.map_entries(id)?.len();
        match method {
            "keySet()Ljava/util/Set;"
            | "values()Ljava/util/Collection;"
            | "entrySet()Ljava/util/Set;" => {
                let (kind, name) = if method.starts_with("keySet") {
                    (0, "Ljava/util/HashMap$KeySet;")
                } else if method.starts_with("values") {
                    (1, "Ljava/util/HashMap$Values;")
                } else {
                    (2, "Ljava/util/HashMap$EntrySet;")
                };
                return Ok(Some(
                    self.allocate(name, Payload::MapView { map: id, kind })? as u64,
                ));
            }
            "size()I" => return Ok(Some(size as u64)),
            "isEmpty()Z" => return Ok(Some((size == 0) as u64)),
            _ => {}
        }
        let result = match method {
            "<init>()V" => 0,
            "<init>(I)V" | "<init>(IF)V" | "<init>(IFI)V" => {
                if (arg(1)? as i32) < 0
                    || (a.len() > 2
                        && (f32::from_bits(arg(2)?).is_nan() || f32::from_bits(arg(2)?) <= 0.0))
                    || (a.len() > 3 && (arg(3)? as i32) <= 0)
                {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "invalid map capacity/load factor/concurrency",
                    ));
                }
                0
            }
            "<init>(Ljava/util/Map;)V" | "putAll(Ljava/util/Map;)V" => {
                let source = arg(1)?;
                let _roots = self.scoped_library_roots(&[id, source])?;
                let source_version = self.collection_version(source)?;
                let incoming = self.map_entries(source)?.to_vec();
                for (key, value) in incoming {
                    self.check_map_version(source, source_version)?;
                    if nonnull && (key == 0 || value == 0) {
                        return Err(fault(
                            "Ljava/lang/NullPointerException;",
                            "concurrent map null",
                        ));
                    }
                    let _entry = self.scoped_library_roots(&[key, value])?;
                    let (at, hash) = self.map_at(id, key)?;
                    self.check_map_version(source, source_version)?;
                    if let Some(i) = at {
                        self.map_replace(id, i, value)?;
                    } else {
                        self.map_insert(id, key, value, hash)?;
                    }
                }
                0
            }
            "clear()V" => {
                if immutable {
                    return Err(fault(
                        "Ljava/lang/UnsupportedOperationException;",
                        "immutable map",
                    ));
                }
                self.map_clear(id)?;
                0
            }
            "containsValue(Ljava/lang/Object;)Z" => {
                let value = arg(1)?;
                if nonnull && value == 0 {
                    return Err(fault(
                        "Ljava/lang/NullPointerException;",
                        "concurrent map null",
                    ));
                }
                let _roots = self.scoped_library_roots(&[id, value])?;
                let version = self.object(id)?.version;
                for i in 0..size {
                    let current = self.map_entries(id)?[i].1;
                    let equal = self.value_equal(value, current)?;
                    self.check_map_version(id, version)?;
                    if equal {
                        return Ok(Some(1));
                    }
                }
                return Ok(Some(0));
            }
            "get(Ljava/lang/Object;)Ljava/lang/Object;"
            | "getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"
            | "containsKey(Ljava/lang/Object;)Z"
            | "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"
            | "putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"
            | "remove(Ljava/lang/Object;)Ljava/lang/Object;"
            | "remove(Ljava/lang/Object;Ljava/lang/Object;)Z"
            | "replace(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"
            | "replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z" => {
                let key = arg(1)?;
                if nonnull && key == 0 {
                    return Err(fault(
                        "Ljava/lang/NullPointerException;",
                        "concurrent map null key",
                    ));
                }
                let (at, hash) = self.map_at(id, key)?;
                let old = if let Some(index) = at {
                    self.map_entries(id)?[index].1
                } else {
                    0
                };
                if method.starts_with("containsKey") {
                    return Ok(Some(at.is_some() as u64));
                }
                if method.starts_with("getOrDefault") {
                    return Ok(Some(if at.is_some() { old } else { arg(2)? } as u64));
                }
                if method.starts_with("get(") {
                    return Ok(Some(old as u64));
                }
                if immutable {
                    return Err(fault(
                        "Ljava/lang/UnsupportedOperationException;",
                        "immutable map",
                    ));
                }
                if method.starts_with("put") {
                    let value = arg(2)?;
                    if nonnull && value == 0 {
                        return Err(fault(
                            "Ljava/lang/NullPointerException;",
                            "concurrent map null value",
                        ));
                    }
                    if !method.starts_with("putIfAbsent") || old == 0 {
                        if let Some(i) = at {
                            self.map_replace(id, i, value)?;
                        } else {
                            self.map_insert(id, key, value, hash)?;
                        }
                    }
                    old as u64
                } else if method.starts_with("remove") {
                    let conditional = method.ends_with(")Z");
                    let version = self.object(id)?.version;
                    let matched =
                        at.is_some() && (!conditional || self.value_equal(arg(2)?, old)?);
                    self.check_map_version(id, version)?;
                    if let Some(index) = at.filter(|_| matched) {
                        self.map_remove_index(id, index)?;
                    }
                    if conditional {
                        matched as u64
                    } else {
                        old as u64
                    }
                } else {
                    let conditional = a.len() == 4;
                    let new = arg(if conditional { 3 } else { 2 })?;
                    if nonnull && (new == 0 || (conditional && arg(2)? == 0)) {
                        return Err(fault(
                            "Ljava/lang/NullPointerException;",
                            "concurrent map null replacement",
                        ));
                    }
                    let version = self.object(id)?.version;
                    let matched =
                        at.is_some() && (!conditional || self.value_equal(arg(2)?, old)?);
                    self.check_map_version(id, version)?;
                    if let Some(index) = at.filter(|_| matched) {
                        self.map_replace(id, index, new)?;
                    }
                    if conditional {
                        matched as u64
                    } else {
                        old as u64
                    }
                }
            }
            _ => return Ok(None),
        };
        Ok(Some(result))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn vm() -> Runtime {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/rift-native-demo.apk");
        let p = crate::package::Package::open(&path, "auto").unwrap();
        Runtime::new(
            p.dex,
            Machine::new(64, 32, 8).unwrap(),
            p.libraries,
            4 * 1024 * 1024,
        )
    }
    fn call(v: &mut Runtime, c: &str, m: &str, a: &[u32]) -> u64 {
        v.collections_api(&format!("L{c};->{m}"), a)
            .unwrap()
            .unwrap()
    }
    #[test]
    fn concurrent_map_has_conditional_updates_and_rejects_nulls() {
        let mut v = vm();
        let map = v
            .instantiate("Ljava/util/concurrent/ConcurrentHashMap;")
            .unwrap();
        let key = v.string("key").unwrap();
        let otherkey = v.string("key").unwrap();
        let x = v.string("x").unwrap();
        let y = v.string("y").unwrap();
        let c = "java/util/concurrent/ConcurrentHashMap";
        assert_eq!(
            call(
                &mut v,
                c,
                "putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
                &[map, key, x]
            ),
            0
        );
        assert_eq!(
            call(
                &mut v,
                c,
                "putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
                &[map, otherkey, y]
            ),
            x as u64
        );
        assert_eq!(
            call(
                &mut v,
                c,
                "replace(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z",
                &[map, key, x, y]
            ),
            1
        );
        assert_eq!(
            call(
                &mut v,
                c,
                "remove(Ljava/lang/Object;Ljava/lang/Object;)Z",
                &[map, key, x]
            ),
            0
        );
        assert_eq!(
            call(
                &mut v,
                c,
                "get(Ljava/lang/Object;)Ljava/lang/Object;",
                &[map, key]
            ),
            y as u64
        );
        for args in [[map, 0, x], [map, key, 0]] {
            assert!(
                v.collections_api(
                    &format!("L{c};->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"),
                    &args
                )
                .unwrap_err()
                .is::<JavaFault>()
            );
        }
    }
    #[test]
    fn copy_on_write_iterator_keeps_its_snapshot() {
        let mut v = vm();
        let list = v
            .instantiate("Ljava/util/concurrent/CopyOnWriteArrayList;")
            .unwrap();
        let x = v.string("x").unwrap();
        let y = v.string("y").unwrap();
        let c = "java/util/concurrent/CopyOnWriteArrayList";
        call(&mut v, c, "add(Ljava/lang/Object;)Z", &[list, x]);
        let it = call(&mut v, c, "iterator()Ljava/util/Iterator;", &[list]) as u32;
        call(
            &mut v,
            c,
            "set(ILjava/lang/Object;)Ljava/lang/Object;",
            &[list, 0, y],
        );
        call(&mut v, c, "add(Ljava/lang/Object;)Z", &[list, y]);
        assert_eq!(
            call(
                &mut v,
                "java/util/Iterator",
                "next()Ljava/lang/Object;",
                &[it]
            ),
            x as u64
        );
        assert_eq!(call(&mut v, "java/util/Iterator", "hasNext()Z", &[it]), 0);
        assert!(
            v.collections_api("Ljava/util/Iterator;->remove()V", &[it])
                .unwrap_err()
                .is::<JavaFault>()
        );
        v.statics.insert(0, it as u64);
        v.collect().unwrap();
        assert!(v.heap.contains_key(&x));
        assert!(!v.heap.contains_key(&list));
    }
    #[test]
    fn weak_keys_are_collected_but_values_and_null_key_are_strong() {
        let mut v = vm();
        let map = v.instantiate("Ljava/util/WeakHashMap;").unwrap();
        let key = v.string("temporary").unwrap();
        let value = v.string("value").unwrap();
        let c = "java/util/WeakHashMap";
        call(
            &mut v,
            c,
            "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
            &[map, key, value],
        );
        call(
            &mut v,
            c,
            "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
            &[map, 0, value],
        );
        v.statics.insert(0, map as u64);
        v.collect().unwrap();
        assert!(!v.heap.contains_key(&key));
        assert!(v.heap.contains_key(&value));
        assert_eq!(call(&mut v, c, "size()I", &[map]), 1);
        assert_eq!(
            call(
                &mut v,
                c,
                "get(Ljava/lang/Object;)Ljava/lang/Object;",
                &[map, 0]
            ),
            value as u64
        );
        let key = v.instantiate("Ljava/lang/Object;").unwrap();
        let list = v.instantiate("Ljava/util/ArrayList;").unwrap();
        call(
            &mut v,
            "java/util/ArrayList",
            "add(Ljava/lang/Object;)Z",
            &[list, key],
        );
        call(
            &mut v,
            c,
            "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
            &[map, key, list],
        );
        v.collect().unwrap();
        assert!(v.heap.contains_key(&key));
    }
    #[test]
    fn live_map_views_and_fail_fast_iterators_follow_modifications() {
        let mut v = vm();
        let map = v.instantiate("Ljava/util/HashMap;").unwrap();
        let key = v.string("k").unwrap();
        let value = v.string("v").unwrap();
        let c = "java/util/HashMap";
        let view = call(&mut v, c, "keySet()Ljava/util/Set;", &[map]) as u32;
        call(
            &mut v,
            c,
            "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
            &[map, key, value],
        );
        assert_eq!(call(&mut v, "java/util/Set", "size()I", &[view]), 1);
        let it = call(
            &mut v,
            "java/util/Set",
            "iterator()Ljava/util/Iterator;",
            &[view],
        ) as u32;
        assert_eq!(
            call(
                &mut v,
                "java/util/Iterator",
                "next()Ljava/lang/Object;",
                &[it]
            ),
            key as u64
        );
        call(&mut v, "java/util/Iterator", "remove()V", &[it]);
        assert_eq!(call(&mut v, c, "size()I", &[map]), 0);
        call(
            &mut v,
            c,
            "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
            &[map, key, value],
        );
        assert!(
            v.collections_api("Ljava/util/Iterator;->next()Ljava/lang/Object;", &[it])
                .unwrap_err()
                .is::<JavaFault>()
        );
    }
}
