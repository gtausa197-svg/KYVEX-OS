//! Checked signed integer parsing on Java UTF16 code units, never object handles.
use super::*;
// BMP digit ranges independently emitted by the pinned Java8 Character.digit oracle.
const DIGITS: &[(u16, u16, u8)] = &[
    (48, 57, 0),
    (65, 90, 10),
    (97, 122, 10),
    (1632, 1641, 0),
    (1776, 1785, 0),
    (1984, 1993, 0),
    (2406, 2415, 0),
    (2534, 2543, 0),
    (2662, 2671, 0),
    (2790, 2799, 0),
    (2918, 2927, 0),
    (3046, 3055, 0),
    (3174, 3183, 0),
    (3302, 3311, 0),
    (3430, 3439, 0),
    (3664, 3673, 0),
    (3792, 3801, 0),
    (3872, 3881, 0),
    (4160, 4169, 0),
    (4240, 4249, 0),
    (6112, 6121, 0),
    (6160, 6169, 0),
    (6470, 6479, 0),
    (6608, 6617, 0),
    (6784, 6793, 0),
    (6800, 6809, 0),
    (6992, 7001, 0),
    (7088, 7097, 0),
    (7232, 7241, 0),
    (7248, 7257, 0),
    (42528, 42537, 0),
    (43216, 43225, 0),
    (43264, 43273, 0),
    (43472, 43481, 0),
    (43600, 43609, 0),
    (44016, 44025, 0),
    (65296, 65305, 0),
    (65313, 65338, 10),
    (65345, 65370, 10),
];
fn digit(unit: u16, radix: u32) -> Option<i128> {
    DIGITS.iter().find_map(|(first, last, start)| {
        if (*first..=*last).contains(&unit) {
            let value = (unit - *first) as u32 + *start as u32;
            (value < radix).then_some(value as i128)
        } else {
            None
        }
    })
}
fn parse(units: &[u16], radix: u32, width: u32) -> Option<i64> {
    if !(2..=36).contains(&radix) || units.is_empty() {
        return None;
    }
    let negative = units[0] == b'-' as u16;
    let signed = negative || units[0] == b'+' as u16;
    let input = &units[usize::from(signed)..];
    if input.is_empty() {
        return None;
    }
    let edge = 1i128 << (width - 1);
    let limit = if negative { edge } else { edge - 1 };
    let mut value = 0i128;
    for unit in input {
        value = value
            .checked_mul(radix as i128)?
            .checked_add(digit(*unit, radix)?)?;
        if value > limit {
            return None;
        }
    }
    Some((if negative { -value } else { value }) as i64)
}
impl Runtime {
    pub(super) fn number_parse_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (width, explicit_radix) = match sig {
            "Ljava/lang/Byte;->parseByte(Ljava/lang/String;)B" => (8, false),
            "Ljava/lang/Byte;->parseByte(Ljava/lang/String;I)B" => (8, true),
            "Ljava/lang/Short;->parseShort(Ljava/lang/String;)S" => (16, false),
            "Ljava/lang/Short;->parseShort(Ljava/lang/String;I)S" => (16, true),
            "Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I" => (32, false),
            "Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I" => (32, true),
            "Ljava/lang/Long;->parseLong(Ljava/lang/String;)J" => (64, false),
            "Ljava/lang/Long;->parseLong(Ljava/lang/String;I)J" => (64, true),
            _ => return Ok(None),
        };
        let input = *a.first().ok_or("Number parse argument")?;
        let radix = if explicit_radix {
            *a.get(1).ok_or("Number parse radix")?
        } else {
            10
        };
        let units = if input == 0 {
            None
        } else {
            Some(self.units(input)?)
        };
        let value = units
            .as_deref()
            .and_then(|s| parse(s, radix, width))
            .ok_or_else(|| {
                fault(
                    "Ljava/lang/NumberFormatException;",
                    "Invalid or overflowing signed integer",
                )
            })?;
        Ok(Some(if width == 64 {
            value as u64
        } else {
            value as u32 as u64
        }))
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn signed_parsing_matches_3712_stock_java8_boundary_unicode_and_radix_cases() {
        let rows: serde_json::Value = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../tests/fixtures/number-parse.json"
        )))
        .unwrap();
        let cases = rows["cases"].as_array().unwrap();
        assert_eq!(cases.len(), 3712);
        for (index, row) in cases.iter().enumerate() {
            let units = row["input"].as_str().map(|s| {
                s.as_bytes()
                    .as_chunks::<4>()
                    .0
                    .iter()
                    .map(|v| u16::from_str_radix(std::str::from_utf8(v).unwrap(), 16).unwrap())
                    .collect::<Vec<_>>()
            });
            let actual = units.as_deref().and_then(|s| {
                parse(
                    s,
                    row["radix"].as_i64().unwrap() as u32,
                    row["width"].as_u64().unwrap() as u32,
                )
            });
            assert_eq!(
                actual,
                row.get("value").and_then(|v| v.as_i64()),
                "parse vector {index}: {row}"
            );
        }
        let ranges = rows["digit_ranges"].as_array().unwrap();
        assert_eq!(ranges.len(), DIGITS.len());
        for (row, (lo, hi, start)) in ranges.iter().zip(DIGITS) {
            assert_eq!(
                [*lo as u64, *hi as u64, *start as u64],
                [
                    row[0].as_u64().unwrap(),
                    row[1].as_u64().unwrap(),
                    row[2].as_u64().unwrap()
                ]
            );
        }
    }
    #[test]
    fn vm_null_failures_and_narrow_wide_returns_preserve_java_types_without_allocating_results() {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/rift-native-demo.apk");
        let p = crate::package::Package::open(&path, "auto").unwrap();
        let mut vm = Runtime::new(
            p.dex,
            Machine::new(64, 32, 8).unwrap(),
            p.libraries,
            4 * 1024 * 1024,
        );
        for (owner, method, result, text, expected) in [
            ("Byte", "parseByte", "B", "-128", (-128i32) as u32 as u64),
            (
                "Short",
                "parseShort",
                "S",
                "-32768",
                (-32768i32) as u32 as u64,
            ),
            (
                "Integer",
                "parseInt",
                "I",
                "-2147483648",
                i32::MIN as u32 as u64,
            ),
            (
                "Long",
                "parseLong",
                "J",
                "-9223372036854775808",
                i64::MIN as u64,
            ),
        ] {
            let signature = format!("Ljava/lang/{owner};->{method}(Ljava/lang/String;){result}");
            let input = vm.string(text).unwrap();
            let before = vm.heap.len();
            assert_eq!(vm.hle(&signature, &[input]).unwrap(), expected);
            let error = vm.hle(&signature, &[0]).unwrap_err();
            assert!(error.to_string().contains("NumberFormatException"));
            assert_eq!(vm.heap.len(), before);
        }
    }
}
