//! Guest-owned snapshots of actual logical Java calls, never host stack/process data.
use super::*;
use std::{cell::RefCell, rc::Rc};
pub(super) struct Context {
    pub thread: u32,
    pub baseline: usize,
    pub methods: Vec<usize>,
}
pub(super) type Registry = Rc<RefCell<BTreeMap<u64, Context>>>;
pub(super) const TRACE: usize = usize::MAX - 110;
pub(super) const WRITABLE: usize = usize::MAX - 111;
pub(super) const SUPPRESSED: usize = usize::MAX - 112;
pub(super) const SUPPRESSION: usize = usize::MAX - 113;
const CLASS: usize = usize::MAX - 120;
const METHOD: usize = usize::MAX - 121;
const FILE: usize = usize::MAX - 122;
const LINE: usize = usize::MAX - 123;
const ELEMENT: &str = "Ljava/lang/StackTraceElement;";
const ARRAY: &str = "[Ljava/lang/StackTraceElement;";
impl Runtime {
    pub(super) fn pin_fault(
        &mut self,
        error: Box<dyn std::error::Error + Send + Sync>,
    ) -> Box<dyn std::error::Error + Send + Sync> {
        let Some(exception) = error.downcast_ref::<JavaFault>().filter(|e| e.object == 0) else {
            return error;
        };
        match self.materialize_fault(exception) {
            Ok(object) => Box::new(JavaFault {
                class: exception.class.clone(),
                object,
                message: exception.message.clone(),
            }),
            Err(error) => error,
        }
    }
    pub(super) fn capture_throwable_stack(&mut self, id: u32) -> Result<()> {
        if self.object(id)?.fields.get(&WRITABLE) == Some(&0) {
            return Ok(());
        }
        let mut methods = self.callers.clone();
        while let Some(index) = methods.last().copied() {
            let method = &self.dex.methods[index];
            let name = &self.dex.strings[method.name];
            if matches!(name.as_str(), "<init>" | "fillInStackTrace")
                && self.subclass(self.dex.ty(method.class), "Ljava/lang/Throwable;")?
            {
                methods.pop();
            } else {
                break;
            }
        }
        let array = self.stack_snapshot(&methods)?;
        self.object_mut(id)?.fields.insert(TRACE, array as u64);
        Ok(())
    }
    fn stack_snapshot(&mut self, methods: &[usize]) -> Result<u32> {
        if methods.len() > 64 {
            return Err("Guest stack snapshot depth quota".into());
        }
        let mut values = Vec::with_capacity(methods.len());
        for index in methods.iter().rev() {
            let method = self
                .dex
                .methods
                .get(*index)
                .ok_or("Stack snapshot method index")?;
            let class_index = self.dex.types[method.class];
            let mut class = self
                .dex
                .utf16
                .get(&class_index)
                .cloned()
                .unwrap_or_else(|| self.dex.strings[class_index].encode_utf16().collect());
            if class.first() == Some(&76) && class.last() == Some(&59) {
                class.remove(0);
                class.pop();
            }
            for unit in &mut class {
                if *unit == 47 {
                    *unit = 46;
                }
            }
            let name = self
                .dex
                .utf16
                .get(&method.name)
                .cloned()
                .unwrap_or_else(|| self.dex.strings[method.name].encode_utf16().collect());
            let line = if self
                .dex
                .bodies
                .get(index)
                .is_some_and(|body| body.access & 0x100 != 0)
            {
                -2i32
            } else {
                -1i32
            };
            let declaring = self.string_units(class)?;
            let method_name = self.string_units(name)?;
            let element = self.allocate(ELEMENT, Payload::Instance)?;
            self.object_mut(element)?.fields.extend([
                (CLASS, declaring as u64),
                (METHOD, method_name as u64),
                (FILE, 0),
                (LINE, line as u32 as u64),
            ]);
            values.push(element as u64);
        }
        self.allocate(ARRAY, Payload::Array(values))
    }
    fn cloned_trace(&mut self, id: u32, key: usize, class: &str) -> Result<u32> {
        let array = self.object(id)?.fields.get(&key).copied().unwrap_or(0) as u32;
        let values = if array == 0 {
            Vec::new()
        } else {
            let Payload::Array(values) = &self.object(array)?.payload else {
                return Err("Throwable snapshot array payload".into());
            };
            values.clone()
        };
        self.allocate(class, Payload::Array(values))
    }
    fn validate_trace(&self, array: u32) -> Result<Vec<u64>> {
        let Payload::Array(values) = &self.object(array)?.payload else {
            return Err("Stack trace input must be an array".into());
        };
        if values.len() > 16384 {
            return Err("Stack trace element quota".into());
        }
        for value in values {
            let object = self.object(u32::try_from(*value)?)?;
            if object.class != ELEMENT {
                return Err("Stack trace input has a non-StackTraceElement".into());
            }
        }
        Ok(values.clone())
    }
    pub(super) fn element_equal(&self, left: u32, right: u32) -> Result<bool> {
        if left == right {
            return Ok(true);
        }
        if right == 0 || self.object(right)?.class != ELEMENT {
            return Ok(false);
        }
        let a = &self.object(left)?.fields;
        let b = &self.object(right)?.fields;
        if a.get(&LINE) != b.get(&LINE) {
            return Ok(false);
        }
        for key in [CLASS, METHOD, FILE] {
            let x = *a.get(&key).ok_or("Uninitialized stack element")? as u32;
            let y = *b.get(&key).ok_or("Uninitialized stack element")? as u32;
            if x == 0 || y == 0 {
                if x != y {
                    return Ok(false);
                }
            } else if !self.string_equals(x, y)? {
                return Ok(false);
            }
        }
        Ok(true)
    }
    fn element_hash(&self, id: u32) -> Result<u32> {
        let object = self.object(id)?;
        let mut hash = 0u32;
        for key in [CLASS, METHOD, FILE] {
            let value = *object
                .fields
                .get(&key)
                .ok_or("Uninitialized stack element")? as u32;
            let part = if value == 0 {
                0
            } else {
                self.units(value)?.iter().fold(0u32, |hash, unit| {
                    hash.wrapping_mul(31).wrapping_add(*unit as u32)
                })
            };
            hash = hash.wrapping_mul(31).wrapping_add(part);
        }
        Ok(hash.wrapping_mul(31).wrapping_add(
            *object
                .fields
                .get(&LINE)
                .ok_or("Uninitialized stack element")? as u32,
        ))
    }
    fn element_units(&self, id: u32) -> Result<Vec<u16>> {
        let fields = &self.object(id)?.fields;
        let declaring = *fields.get(&CLASS).ok_or("Uninitialized stack element")? as u32;
        let method = *fields.get(&METHOD).ok_or("Uninitialized stack element")? as u32;
        let file = *fields.get(&FILE).ok_or("Uninitialized stack element")? as u32;
        let line = *fields.get(&LINE).ok_or("Uninitialized stack element")? as u32 as i32;
        let mut units = self.units(declaring)?;
        units.push(46);
        units.extend(self.units(method)?);
        units.push(40);
        if line == -2 {
            units.extend("Native Method".encode_utf16());
        } else if file == 0 {
            units.extend("Unknown Source".encode_utf16());
        } else {
            units.extend(self.units(file)?);
            if line >= 0 {
                units.push(58);
                units.extend(line.to_string().encode_utf16());
            }
        }
        units.push(41);
        Ok(units)
    }

    fn element_text(&mut self, id: u32) -> Result<u32> {
        self.string_units(self.element_units(id)?)
    }

    pub(super) fn diagnostic_stack(&self, mut id: u32) -> Result<String> {
        let mut output = String::new();
        let mut visited = BTreeSet::new();
        while id != 0 && visited.len() < 8 && visited.insert(id) {
            let object = self.object(id)?;
            if self.subclass(&object.class, "Ljava/net/UnknownHostException;")? {
                return Ok(String::new());
            }
            if visited.len() > 1 {
                output.push_str("\nCaused by: ");
            }
            output.push_str(
                &object
                    .class
                    .strip_prefix('L')
                    .unwrap_or(&object.class)
                    .trim_end_matches(';')
                    .replace('/', "."),
            );
            let message = object.fields.get(&throwable::MESSAGE).copied().unwrap_or(0) as u32;
            if message != 0 {
                output.push_str(": ");
                output.extend(self.text(message)?.chars().take(512));
            }
            let trace = object.fields.get(&TRACE).copied().unwrap_or(0) as u32;
            if trace != 0
                && let Payload::Array(frames) = &self.object(trace)?.payload
            {
                for &frame in frames.iter().take(8) {
                    output.push_str("\n\tat ");
                    output.extend(
                        String::from_utf16_lossy(&self.element_units(frame as u32)?)
                            .chars()
                            .take(256),
                    );
                }
            }
            id = object.fields.get(&throwable::CAUSE).copied().unwrap_or(0) as u32;
        }
        Ok(output.chars().take(4096).collect())
    }
    fn thread_snapshot(&mut self, thread: u32) -> Result<u32> {
        self.object(thread)?;
        let methods = if thread == self.current_thread {
            self.callers.clone()
        } else if !self
            .scheduler
            .records
            .get(&thread)
            .is_some_and(scheduler::Record::alive)
        {
            Vec::new()
        } else {
            self.trace_contexts
                .borrow()
                .iter()
                .filter(|(_, context)| context.thread == thread && context.baseline == 0)
                .max_by_key(|(id, _)| *id)
                .map_or_else(Vec::new, |(_, context)| context.methods.clone())
        };
        self.stack_snapshot(&methods)
    }
    pub(super) fn stack_trace_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Stack trace signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Stack trace argument count");
        if class == "Ljava/lang/Thread;" {
            self.ensure_main_thread()?;
            if method == "getStackTrace()[Ljava/lang/StackTraceElement;" {
                return self
                    .thread_snapshot(arg(0)?)
                    .map(|array| Some(array as u64));
            }
            if method == "getAllStackTraces()Ljava/util/Map;" {
                let threads: Vec<_> = self
                    .scheduler
                    .records
                    .iter()
                    .filter(|(_, record)| record.alive())
                    .map(|(id, _)| *id)
                    .collect();
                let mut entries = Vec::new();
                for thread in threads {
                    entries.push((thread, self.thread_snapshot(thread)?));
                }
                return Ok(Some(self.new_hash_map(entries)? as u64));
            }
        }
        if class == ELEMENT {
            let id = arg(0)?;
            if method == "<init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V" {
                let declaring = arg(1)?;
                let name = arg(2)?;
                let file = arg(3)?;
                self.units(declaring)?;
                self.units(name)?;
                if file != 0 {
                    self.units(file)?;
                }
                self.object_mut(id)?.fields.extend([
                    (CLASS, declaring as u64),
                    (METHOD, name as u64),
                    (FILE, file as u64),
                    (LINE, arg(4)? as u64),
                ]);
                return Ok(Some(0));
            }
            let fields = &self.object(id)?.fields;
            let key = match method {
                "getClassName()Ljava/lang/String;" => Some(CLASS),
                "getMethodName()Ljava/lang/String;" => Some(METHOD),
                "getFileName()Ljava/lang/String;" => Some(FILE),
                "getLineNumber()I" => Some(LINE),
                _ => None,
            };
            if let Some(key) = key {
                return Ok(Some(
                    *fields.get(&key).ok_or("Uninitialized stack element")?,
                ));
            }
            return Ok(Some(match method {
                "isNativeMethod()Z" => {
                    (*fields.get(&LINE).ok_or("Uninitialized stack element")? as u32 as i32 == -2)
                        as u64
                }
                "toString()Ljava/lang/String;" => self.element_text(id)? as u64,
                "equals(Ljava/lang/Object;)Z" => self.element_equal(id, arg(1)?)? as u64,
                "hashCode()I" => self.element_hash(id)? as u64,
                _ => return Ok(None),
            }));
        }
        if !matches!(
            method,
            "getStackTrace()[Ljava/lang/StackTraceElement;"
                | "setStackTrace([Ljava/lang/StackTraceElement;)V"
                | "fillInStackTrace()Ljava/lang/Throwable;"
                | "getSuppressed()[Ljava/lang/Throwable;"
                | "addSuppressed(Ljava/lang/Throwable;)V"
        ) {
            return Ok(None);
        }
        if !self.subclass(class, "Ljava/lang/Throwable;")? {
            return Ok(None);
        }
        let id = arg(0)?;
        self.object(id)?;
        Ok(Some(match method {
            "getStackTrace()[Ljava/lang/StackTraceElement;" => {
                self.cloned_trace(id, TRACE, ARRAY)? as u64
            }
            "setStackTrace([Ljava/lang/StackTraceElement;)V" => {
                let values = self.validate_trace(arg(1)?)?;
                if self.object(id)?.fields.get(&WRITABLE) != Some(&0) {
                    let array = self.allocate(ARRAY, Payload::Array(values))?;
                    self.object_mut(id)?.fields.insert(TRACE, array as u64);
                }
                0
            }
            "fillInStackTrace()Ljava/lang/Throwable;" => {
                self.capture_throwable_stack(id)?;
                id as u64
            }
            "getSuppressed()[Ljava/lang/Throwable;" => {
                self.cloned_trace(id, SUPPRESSED, "[Ljava/lang/Throwable;")? as u64
            }
            "addSuppressed(Ljava/lang/Throwable;)V" => {
                let exception = arg(1)?;
                if exception == id {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Self-suppression not permitted",
                    ));
                }
                self.object(exception)?;
                if !self.subclass(&self.object(exception)?.class, "Ljava/lang/Throwable;")? {
                    return Err("Suppressed object must be Throwable".into());
                }
                if self.object(id)?.fields.get(&SUPPRESSION) != Some(&0) {
                    let mut array = self
                        .object(id)?
                        .fields
                        .get(&SUPPRESSED)
                        .copied()
                        .unwrap_or(0) as u32;
                    if array == 0 {
                        array =
                            self.allocate("[Ljava/lang/Throwable;", Payload::Array(Vec::new()))?;
                        self.object_mut(id)?.fields.insert(SUPPRESSED, array as u64);
                    }
                    if self.heap_bytes().saturating_add(8) > self.heap_limit {
                        return Err("Suppressed exceptions memory quota".into());
                    }
                    let Payload::Array(values) = &mut self.object_mut(array)?.payload else {
                        return Err("Suppressed exception array payload".into());
                    };
                    if values.len() >= 16384 {
                        return Err("Suppressed exception count quota".into());
                    }
                    values.push(exception as u64);
                }
                0
            }
            _ => return Ok(None),
        }))
    }
}
