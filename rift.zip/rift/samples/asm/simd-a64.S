.text
.global _start
_start:
    movi v0.4s, #6
    movi v1.4s, #7
    mul v0.4s, v0.4s, v1.4s
    umov w0, v0.s[2]
    mov x8, #93
    svc #0
