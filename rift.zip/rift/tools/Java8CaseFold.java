import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

/** Generates the BMP character equivalence table for Java 8 String comparison. */
public final class Java8CaseFold {
    public static void main(String[] args) throws Exception {
        if (!System.getProperty("java.specification.version").equals("1.8")) {
            throw new IllegalStateException("Run with the pinned Java 8 runtime");
        }
        try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(Paths.get(args[0])))) {
            for (int value = 0; value <= 0xffff; value++) {
                char unit = (char) value;
                char folded = Character.toLowerCase(Character.toUpperCase(unit));
                if (folded != unit) {
                    out.write(unit & 255);
                    out.write(unit >> 8);
                    out.write(folded & 255);
                    out.write(folded >> 8);
                }
            }
        }
    }
}
