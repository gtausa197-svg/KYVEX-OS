package org.kyvex.extra;

/** Ordinary D8 input; this class is deliberately stored in classes2.dex. */
public final class RuntimeChecks {
    static class Parent {public int inherited=7;}
    static final class Child extends Parent {}
    public static int verify(int input) {
        int checks=0;
        int[] data={11,23,37,41};
        if(data[2]==37 && data.length==4)checks++;
        try {int zero=input-input;int ignored=input/zero;checks+=ignored;}catch(ArithmeticException correct){checks++;}
        try {int ignored=data[input+30];checks+=ignored;}catch(ArrayIndexOutOfBoundsException correct){checks++;}
        try {int[] empty=null;checks+=empty.length;}catch(NullPointerException correct){checks++;}
        try {throw new IllegalArgumentException("expected");}catch(RuntimeException correct){checks++;}
        long large=0x123456789L+input;
        if(((large<<35)>>>35)==(large&0x1fffffffL))checks++;
        double value=(input+0.5)*2.0;
        if((int)value==input*2+1)checks++;
        float small=(float)value/2.0f;
        if((double)small==input+0.5)checks++;
        Object string="cast";
        if(string instanceof String && ((String)string).length()==4)checks++;
        String surrogate="\ud800";
        if(surrogate.length()==1 && surrogate.charAt(0)==0xd800)checks++;
        switch(input){case 1:checks++;break;case 2:checks+=2;break;case 3:checks+=3;break;default:checks+=5;}
        switch(input*100){case 10:checks+=9;break;case 100:checks++;break;case 1000:checks+=8;break;default:checks+=7;}
        Object[] objects={"first","second"};
        if(objects.length==2 && objects[1].equals("second"))checks++;
        synchronized(data){checks++;}
        java.util.HashSet<String> set=new java.util.HashSet<String>();set.add("key");set.add("key");
        if(set.size()==1 && set.contains("key"))checks++;
        java.util.HashMap<String,String> map=new java.util.HashMap<String,String>();map.put("key","value");
        if(map.get("key").equals("value") && map.containsKey("key"))checks++;
        java.util.ArrayList<String> list=new java.util.ArrayList<String>();list.add("item");
        if(list.get(0).equals("item") && list.toArray().length==1)checks++;
        System.arraycopy(data,0,data,1,3);
        if(data[1]==11 && data[3]==37)checks++;
        if("abcdef".substring(1,4).concat("!").equals("bcd!") && "key".startsWith("ke"))checks++;
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("(?<=id=)([0-9]+)").matcher("id=42");
        if(matcher.find() && matcher.group(1).equals("42") && matcher.start()==3 && matcher.end()==5 && matcher.groupCount()==1)checks++;
        if(java.util.regex.Pattern.matches("(ab)\\1","abab"))checks++;
        matcher=java.util.regex.Pattern.compile("[0-9]+").matcher("\ud83e\udd8042");
        if(matcher.find() && matcher.start()==2 && matcher.group().equals("42"))checks++;
        matcher.reset();try {matcher.group();}catch(IllegalStateException correct){checks++;}
        if(Integer.parseInt("ff",16)==255 && Long.parseLong("12345678901")==12345678901L)checks++;
        System.setProperty("kyvex.test","native");
        if(System.getProperty("kyvex.test").equals("native") && System.clearProperty("kyvex.test").equals("native") && System.getProperty("kyvex.test")==null)checks++;
        if(RuntimeChecks.class.getName().equals("org.kyvex.extra.RuntimeChecks"))checks++;
        if(android.os.Build.VERSION.SDK_INT==28)checks++;
        if(new Child().inherited==7)checks++;
        java.util.concurrent.locks.ReentrantLock lock=new java.util.concurrent.locks.ReentrantLock(true);
        lock.lock();lock.lock();boolean held=lock.isHeldByCurrentThread() && lock.getHoldCount()==2 && lock.isFair();lock.unlock();lock.unlock();
        try{lock.unlock();}catch(IllegalMonitorStateException correct){if(held&&!lock.isLocked())checks++;}
        android.os.Bundle bundle=new android.os.Bundle();bundle.putString(null,"null key");bundle.putString("name","native");bundle.putLong("wide",12345678901L);
        if(bundle.getString(null).equals("null key") && bundle.getString("name").equals("native") && bundle.getLong("wide")==12345678901L && bundle.getInt("wide",7)==7 && bundle.containsKey("wide"))checks++;
        java.util.concurrent.atomic.AtomicReference<String> atomic=new java.util.concurrent.atomic.AtomicReference<String>("first");
        java.util.concurrent.atomic.AtomicLong number=new java.util.concurrent.atomic.AtomicLong(0x100000000L);
        if(atomic.compareAndSet("first","second")&&atomic.get().equals("second")&&number.incrementAndGet()==0x100000001L&&number.getAndAdd(3)==0x100000001L&&number.get()==0x100000004L)checks++;
        if(checks!=31)throw new IllegalArgumentException("Core checks failed");
        return 42;
    }
}
