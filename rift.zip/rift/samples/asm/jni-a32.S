.syntax unified
.arm
.text
.global Java_org_kyvex_nativehello_MainActivity_timesSeven
.type Java_org_kyvex_nativehello_MainActivity_timesSeven,%function
Java_org_kyvex_nativehello_MainActivity_timesSeven:
    mov r3,#7
    mul r0,r2,r3
    bx lr
.global Java_org_kyvex_nativehello_MainActivity_nativeMessage
.type Java_org_kyvex_nativehello_MainActivity_nativeMessage,%function
Java_org_kyvex_nativehello_MainActivity_nativeMessage:
    ldr r3,[r0]
    ldr r12,[r3,#(167*4)]
    adr r1,message
    bx r12
message: .asciz "Rust + Dynarmic / ARM32"
