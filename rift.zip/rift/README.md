# Rift Native 0.3

Original Rust APK/DEX/ELF loaders, guest memory, interpreter, selected Java and
Android APIs, JNI bridge, containment, supervisor and Qt presentation. The ARM
CPU recompiler is upstream Dynarmic 6.7.0, pinned to
a41c380246d3d9f9874f0f792d234dc0cc17c180 (0BSD), not a KYVEX invention.
Text XML tokenization uses upstream quick-xml 0.42.0 (MIT), pinned with its
registry checksum in Cargo.lock. KYVEX implements the XMLPull event/namespace
facade; it does not claim authorship of the tokenizer.

Native is the only execution backend. There is no Android image, container,
Waydroid, libndk/Houdini download or silent fallback. Old Compatibility profiles
migrate to Native and x86 ABI selections become Auto; touch bindings remain.
APK import records content-addressed snapshots and does not execute code.
Signatures are not authenticated as a trust decision.

Android JSON uses the Apache-licensed `org.json` sources from AOSP libcore at
`android-9.0.0_r61`. The 24,796-byte module loads on first use and executes as
guest DEX under the existing VM quotas. It supplies platform definitions for
its eight classes. The fixture covers nested parsing, mutation and iteration,
compact and indented output, Unicode, typed errors, and Java 8 Double parsing
and case folding. Additional `org.json` paths still depend on the VM's Java
API coverage. The source, license and pins are under
`crates/rift-native/support`. The `tools/build-android-json.py` tool verifies
the module against the pinned D8 toolchain and upstream source hashes.

The native loader resolves `DT_NEEDED` within the selected APK ABI and Rift's
guest platform namespaces. It stages pages against the remaining guest memory
budget and commits the group after all strong relocations resolve. ELF
constructors run in dependency order. An explicit Java library load invokes its
`JNI_OnLoad` once and restores earlier registrations if initialization fails.
The current scope covers acyclic dependencies and breadth-first symbol search.
Android logging records and Adler-32 operate on guest bytes. ARM32 EABI memory
aliases share the existing bounded memory routines. Further Bionic symbols,
full printf formatting, symbol versions and native threads remain partial.

Native `malloc`, `calloc`, `realloc`, `memalign` and `free` use an isolated
guest allocation arena. The arena coalesces freed ranges, releases trailing
pages and preserves the old allocation when growth fails. C `errno` uses one
slot per guest thread. Both ABIs run the allocation and errno fixture through
ARM instructions and the normal JNI path.

The C-locale integer conversions return ABI-sized values, update the guest end
pointer, and report range errors through that thread's `errno`. Bionic's legacy
`__sF` and standard stream pointers refer to virtual console streams. Output
uses bounded diagnostics and unattached input signals EOF. Scalar `fprintf` and
`snprintf` variants read ARM call frames and guest `va_list` structures. The
formatter handles integer, pointer, character and byte-string arguments.
`sscanf` and `vsscanf` decode bounded C-locale numeric and byte fields and
write the results through guest pointers. `asprintf` and `vasprintf` allocate
formatted scalar output in the guest heap.

## Actual implemented path

- APKs up to 2 GiB, 1–128 contiguous classes*.dex, selected ARM32 or ARM64 ABI.
  Archive names, duplicates, size expansion and individual reads are bounded.
  Native Android x86 libraries and split-install APK sets remain unsupported.
- Lazy DEX class lookup and library reads from one preopened, read-only APK.
  Each method retains its own DEX reference mapping; global pools may exceed
  65,536 methods. Loaded method/string pools have a one-million-entry cap.
  DEX integrity is checked before interpreting loaded code. Individual DEX
  files are capped at 32 MiB. The whole APK is not expanded into RAM.
- Real Java application/activity lifecycle subset, typed try/catch, explicit
  throw, null/bounds/arithmetic faults, arrays, switch payloads, integer/long/
  float/double operations and conversions, casts, interfaces and owned reentrant
  monitors. Unsupported bytecode fails explicitly.
- Java strings preserve UTF-16 code units, including unpaired surrogates. The
  desktop presentation alone uses replacement glyphs for invalid Unicode.
  String interning and Class identity, String/StringBuilder subset,
  bounded ArrayList/HashSet/HashMap, guest locks/atomics, typed Bundles,
  arraycopy, selected Math/time/TextUtils/Log methods. This is not the full JDK.
  Selected String indexOf/lastIndexOf (substring and code point), contains,
  offset startsWith and literal replace preserve UTF-16 offsets and surrogate
  units; searches have linear work bounds and replacement output has a quota.
  Arrays.asList is a fixed-size view of the original reference array; set writes
  to that array and enforces its component type. Unmodifiable collections are
  live views and protect iterators, map entries and array conversions. Bundle
  keySet is backed by the Bundle and detects structural changes during iteration.
- ApplicationInfo.dataDir points to the private guest filesystem. A stable
  PackageManager exposes the current APK's version/SDK information and typed
  application-level manifest metadata. Unknown packages raise NameNotFoundException;
  GET_META_DATA is respected for package-manager snapshots. android:resource is
  an integer ID; android:value resource references still require resource resolution.
- Class.getDeclaredField and selected Field metadata/read/write methods use actual
  DEX declarations and known native fields. Declared lookup does not search parents.
  Class.getDeclaredConstructor and Constructor.newInstance execute tested DEX/native
  constructors, check argument types and retain InvocationTargetException causes.
  Abstract/enum construction is rejected. Method invocation, annotations and the
  complete Java access-control/reflection model remain outside this subset.
  Class.isAssignableFrom/isInstance use actual guest type relationships, including
  reference-array covariance, primitive-array rules and primitive Class identity.
  Class equality/hash preserve identity. getSuperclass/isInterface use DEX class
  metadata and the known native type hierarchy; complete reflection is absent.
- Reference/integer/long field updaters operate on real volatile instance fields,
  checking declared types and selected caller/package/protected/private access.
  Failed factories retain reflection causes. Atomic reference/integer/long arrays
  copy constructor input, check indices and perform indivisible updates with
  wrapping primitive arithmetic in the serialized guest engine. Functional update
  operators and the complete Java memory model are not implemented.
- Thread constructors create distinct unstarted objects with names, IDs, daemon
  status and inherited priority. Direct run() executes the target on the current
  event thread. Thread.start still requires the guest scheduler. CountDownLatch
  has a real count and terminal-zero behavior; nonzero blocking waits are rejected.
  Java-to-Java calls now use owned resumable frame stacks, including registers,
  PC, call results and exception continuations. Contexts can be detached/interleaved;
  root leases retain paused locals and results through GC. The synchronous entry
  yields every 4096 DEX instructions and honors advisory GC at top-level safe points.
  Thread states, wait queues, monitor ownership and native/TLS thread contexts
  still need integration. Library callbacks and class initialization stay synchronous.
- Manifest ContentProviders run in initOrder after base-context attachment and
  before Application.onCreate. Disabled and other-process providers do not run.
  ProviderInfo and ServiceInfo expose actual scoped manifest metadata; this does
  not implement starting Android services. Activity callbacks receive real
  create/start/resume and close pause/stop/destroy transitions. Component callback
  registrations do not invent memory-pressure or configuration notifications.
  ProviderInfo.grantUriPermissions comes from the manifest or a boolean resource.
  PackageManager.resolveContentProvider searches current-APK authorities and
  respects disabled/metadata flags. Resolving metadata does not grant URI access.
- Resources reads bounded compiled APK tables, including string pools, scalar
  values, arrays, references and resource names. Selection currently uses an
  en-US API28 portrait 360x640dp / 320dpi virtual display. This is a fixed guest
  profile, not host monitor detection. Layout inflation, styles, themes and the
  full Android qualifier and resource behavior are not implemented.
- UUIDv4 uses real OS entropy. SparseIntArray stores sorted signed keys.
  ThreadLocal runs actual initialValue callbacks for each guest thread;
  storage has weak keys and thread-owned values with stale cleanup. Throwable
  messages and cause chains survive DEX catch and JNI boundaries.
  Throwable snapshots preserve actual logical Java frames at construction or
  fault origin before unwinding. get/set/fillInStackTrace, StackTraceElement
  values/equality/text, constructor virtual fill dispatch, writable/suppression
  flags and suppressed exceptions use guest-owned data with independent returned
  arrays. Thread.getStackTrace/getAllStackTraces inspect only this VM's live or
  paused guest execution contexts. Native JNI frames carry the native marker.
  DEX source/debug line tables are not parsed yet: captured file/line information
  is null/-1 (native -2), rather than fabricated source locations. Supplied element
  source locations and UTF16 units are preserved. Stack traces never expose the
  host Rust stack or desktop threads.
- ActivityManager describes only the isolated guest PID/UID and process name;
  no host processes or accounts are exposed. ContextWrapper service lookup before
  attachment raises NullPointerException. Other core desktop services remain
  explicit capability errors; unavailable optional devices return null.
  Class-based service lookup shares the same registry. UserManager.isUserUnlocked
  describes the single guest user: this VM has no credential-encrypted storage or
  lock state. It does not expose or authenticate desktop users.
  Device-protected Context instances use `/data/user_de/0/<package>` for
  private files, caches and SQLite. Ordinary storage uses `/data/user/0/<package>`.
  SharedPreferences journal groups distinguish the two namespaces and read
  earlier journals with the original ordinary group format. Both guest
  namespaces are available in the same session. General files and database
  images have the lifetime of the worker, and preferences use the journal.
  Android 28 `StrictMode.ThreadPolicy` builders retain their detector bits and
  produce immutable snapshots of per-thread policy. The log penalty handles
  explicit slow calls and instrumented private file streams, including repeated
  small I/O. Network and resource mismatch flags are retained for those APIs.
  java.lang.Runtime exposes one cached guest runtime, one execution lane and
  memory figures derived from the configured heap budget/estimated usage. gc()
  requests collection at a safe point. These are not host CPU/RAM figures.
  System.getSecurityManager reports null because this VM has no installed Java
  SecurityManager; that query does not alter the separate worker containment.
- String.split/Pattern.split implement positive/negative/zero limits, leading and
  trailing empty handling, bounded result size and UTF-16 empty-pattern splitting.
  Common literal delimiters preserve unpaired UTF-16 units. The existing regex
  subset limits still apply; nonliteral zero-width splits on surrogate input fail
  explicitly. String.contentEquals supports the implemented String/builder inputs.
- Main Looper identity and a bounded Handler/Message queue with real Java
  runnable/message callbacks, ordered immediate/delayed delivery and cancellation.
  Studio polls the worker so callbacks update its window without a mouse click.
  Worker Loopers, executors running tasks and synchronization barriers remain
  unsupported. Handler construction without a Looper on a worker raises an error.
- Cooperative Java threads execute actual Runnable/Thread.run DEX code on one
  guest lane, with owned resumable frames and 512-instruction scheduling quanta.
  start/join/sleep/yield, interruption, thread states, wait/notify, reentrant
  owner-checked monitors/locks, fair lock queue order, CountDownLatch and
  LockSupport permits resume the blocked call or instruction without replaying
  completed work. InheritableThreadLocal snapshots childValue at construction.
  Paused frame and local-map roots survive GC; terminated threads can be collected.
  Uncaught Java faults run the actual handler and terminate the worker thread;
  unsupported runtime capabilities still fail explicitly. Closed wait cycles
  without runnable tasks or timers report a deadlock, rather than invent progress.
  Each thread has its own virtual tid, JNIEnv, pending JNI exception and ARM TLS
  page; JavaVM.GetEnv returns that thread's environment. Native calls execute
  serially to completion, and synchronized native methods acquire their monitor.
  There are at most 64 live threads and 256 retained thread objects. Java stacks
  have frame/depth quotas. This does not implement a complete Java memory model,
  host-parallel execution, Bionic pthreads, worker Loopers, or blocking within
  synchronous library callbacks. Blocking across those Rust callbacks fails explicitly.
- Class initializers run as owned continuations, including their dependency order,
  static-field/new/static-call/reflection triggers and same-thread recursion.
  Other threads wait without observing partially initialized data. A paused
  initializer can wait/notify, sleep or use a latch while other guest threads run.
  Java failures publish persistent erroneous state: non-Error causes are wrapped
  once in ExceptionInInitializerError, later uses raise NoClassDefFoundError,
  and waiting threads wake. Capability failures remain explicit capability errors.
  Cancelling an initializer releases its frames and records the failed state.
  Default-method interface initialization and maximally specific method selection
  are supported for the tested Java 8 subset. Class.forName supports the current
  APK loader and the native bootstrap namespace, not custom ClassLoaders.
- Private session-local File, FileInputStream and FileOutputStream subset,
  Context file/cache directories, byte ranges, append, seek, rename/unlink and
  open-handle lifetime. In-memory files count toward the application memory budget;
  files do not survive worker exit. Guest paths never resolve to host paths.
  Native Bionic file calls, symlinks, FileDescriptor/FileChannel and java.nio.file
  are not connected to this Java file layer yet.
  Typed SharedPreferences use a separately preopened two-slot persistent journal;
  apply currently flushes synchronously.
- AssetManager.open and Resources.openRawResource read the APK through its
  preopened descriptor. Read-only native library directories support metadata and
  lazy byte reads without putting an entire library into the Java heap.
  System.load resolves the APK library namespace only. Failed initializers and
  rejected JNI_OnLoad versions remain failures on subsequent load attempts.
  Archive streams currently re-decompress the prefix on each range read; they
  are bounded by member size and operation deadlines, not a high-throughput cache.
- StringReader, InputStreamReader, FileReader and a BufferedReader subset read
  real guest strings/files, including readonly virtual /proc process metadata.
  UTF-8 decoding preserves Java replacement behavior across buffer boundaries;
  ISO-8859-1 and US-ASCII support their tested byte mappings. Buffered lines handle
  CR/LF/CRLF. BufferedReader mark/reset, other encodings/Charset overloads and
  custom Java Reader/InputStream adapters remain unsupported.
- android.util.Xml.newPullParser creates KYVEX's namespace-aware XMLPull facade
  over quick-xml. It reads actual APK assets/guest Readers, reports tags, attributes,
  namespace scopes, text/CDATA/entities/comments/processing instructions, and
  supports next/nextToken/nextTag/nextText/require. Input is bounded to 1 MiB and
  the heap budget, and is loaded into the tokenizer on the first advance. Depth,
  token, attribute and output limits reject excessive input. Byte input is UTF-8;
  DTD processing, custom entities, binary resource XML and full XMLPull factories/
  properties are unsupported. Parse failures are Java XmlPullParserException;
  setInput resets state and dropping/resetting the parser releases its input root.
- ARM32/Thumb/ARM64, NEON, ELF REL/RELA + Android APS2 + RELR, selected Bionic
  imports, per-thread ARM32/ARM64 thread pointers and stack protector guard. General TLS
  modules, native pthreads, the full Bionic/C++ runtime and arbitrary dependencies are
  not implemented.
- JNI static exports and JNI_OnLoad, JavaVM.GetEnv, RegisterNatives /
  UnregisterNatives, selected class/reference/exception/string/primitive array
  operations. Scalar integer/reference/long/float/double signatures use AAPCS registers and
  the aligned ABI stack, including FP register overflow. JNI calls into Java
  and full JNI remain unsupported.
- Native Qt windows for Activity, vertical LinearLayout, TextView and Button.
  Real Java listeners receive click events. No simulated game splash screens.
  Android layout inflation, Surface/Canvas/GLES/Vulkan, audio/video,
  most services, WebView, Play services, general network APIs and durable general app files are
  absent. Therefore complex Android apps and Unity games are not certified.

The virtual identity profile reports API 28 and selected Build/System values.
`java.vm.version=2.1.0` is the native-multidex compatibility marker used by
AndroidX; `java.vm.name` identifies KYVEX Rift Native and `rift.version` is 0.3.0.
These values route compatibility code and do not certify Android API coverage.
Class metadata and the one Native DEX class loader have selected implementations.

Pattern and Matcher use system ICU with UTF-16 offsets, Android Unicode POSIX
classes, character-class intersections, quoted literals and bounded match
work. String and Matcher replacements handle literal escapes and numbered or
named captures. Canonical equivalence is outside the supported API surface.

System ICU supplies DecimalFormat patterns, decimal, integer, percent and
currency NumberFormat factories, and case mapping for the virtual US locale.
Format operations preserve signed 64-bit integer values. Paint and TextPaint
store text size and flags. HarfBuzz checks single glyphs, ligatures and
variation selectors across the available Noto Sans, DejaVu Sans and Noto Color
Emoji faces opened before isolation. These APIs use the installed Linux font
data and provide coverage checks for the current fallback chain.

RoundingMode constants are stable guest enums and control DecimalFormat
rounding. ReentrantReadWriteLock shares the cooperative scheduler's timed and
interruptible wait queue. It tracks each reader, the exclusive writer,
reentrancy, fair acquisition and write-to-read downgrades.

The guest PackageManager reports features from its virtual display profile.
Point stores mutable integer coordinates. Local Binder objects support
interface attachment and descriptor lookup inside the APK process. Android
exception logs use bounded guest stack snapshots and cause chains.

System.arraycopy supports covariant and overlapping copies. When a reference
array contains an incompatible element, the valid prefix is copied before
the ArrayStoreException.

## Use

Open Studio → Runtime → **Run Native APK demo** or **Multidex + JNI demo**.
The advanced APK executes a second DEX, 31 core Java checks plus four native ABI checks, C JNI_OnLoad registration,
ARM computation and JNI array/string transfers. Both demos work offline in Live.
The mapping editor remains a local test scene; it is not a working game input
adapter. Unsupported apps show an explicit error and never switch backend.

APK files open Studio via their file association. --import-only imports without
launching. Application profiles select Auto/ARM32/ARM64 and a memory budget:

| Profile | Guest mappings | Java heap estimate | JIT cache | Process address space |
| --- | ---: | ---: | ---: | ---: |
| light | 32 MiB | 4 MiB | 8 MiB | 192 MiB |
| balanced | 96 MiB | 16 MiB | 16 MiB | 768 MiB |
| large | 256 MiB | 64 MiB | 32 MiB | 3072 MiB |

These are distinct caps, not total RSS or minimum system RAM promises. Host DEX
tables and Qt also use RAM. A small memory profile can reject a larger APK;
do not interpret rejection as successful compatibility. Interactive APK workers
have per-operation instruction budgets, a 45-second startup deadline and 2-second
event deadline, enforced in the worker and supervisor. They have no cumulative
30-second CPU expiration. Standalone ELF/probe workers retain the CPU cap.
Closing the window kills/reaps its worker.

## Containment

Non-root worker, RLIMITs, no_new_privs, x86-64 Linux seccomp allowlist, W^X sparse
guest pages, checked guest addresses. All inherited descriptors are closed except
stdin/stdout/stderr, the APK capability and optional private preferences journal.
Read/seek allow lazy APK reads; journal writes use only its preopened capability.
Open, sockets and exec remain denied. Guest syscalls
never receive host file descriptors. This prototype has not had a security audit.

The private daemon socket is mode 0600 with peer-UID checks, bounded JSON lines,
owner/session generation checks and one native app per user. Schema 1 profiles
default to Native. No shell or arbitrary worker path is accepted through IPC.

## Reproduce

On Arch x86-64 with Rust, C++20, CMake/Ninja, Qt6 Quick/SVG and SQLite:

```sh
cmake -S rift/native-shim -B /build/rift-dynarmic -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_VERSION_MINIMUM=3.5
cmake --build /build/rift-dynarmic -j4
export CARGO_TARGET_DIR=/build/rift-target
export KYVEX_DYNARMIC_LIB_DIR=/build/rift-dynarmic
export LD_LIBRARY_PATH=/build/rift-dynarmic
cargo test --manifest-path rift/Cargo.toml --workspace --locked
cargo clippy --manifest-path rift/Cargo.toml --workspace --all-targets -- -D warnings
bash scripts/stage-rift.sh PROFILE/airootfs
python rift/tests/native-workers.py
python rift/tests/native-apis.py
python rift/tools/test-apk-corpus.py /path/to/apks --report report.json
```

The actual-process test harness alone runs as root and drops uid/gid for every
worker. Ordinary use never needs root. CPU library and executables must be staged
together. Build directories must be on a Linux filesystem. Sample build tools
are pinned in samples/TOOLCHAIN.json; build-advanced.py creates the new multidex
fixture with Google's D8 and clang/lld. Compile-only SDK signatures and signing
private keys are excluded from APKs. All sample APKs are original KYVEX fixtures.
Optional --platform-checks, --event-checks, --file-checks, --bridge-checks,
--resource-checks, --provider-checks, --reader-checks, --xml-checks and
--concurrency-checks, --thread-checks, --initialization-checks and --stack-checks build the API fixtures;
they never package the compile-only framework signatures as implementations.
The API process suite runs both ARM ABIs with seccomp enabled and validates
persisted preferences, actual deferred Java UI updates, 20 file checks, 123
bridge/library checks, 36 compiled-resource checks, provider/lifecycle callbacks,
17 reader checks and 20 XML checks. Test numbers refer to own fixtures, not to
certified real-world applications. Stock-JDK oracle fixtures independently check
UTF-8 decoding and 1,024 UTF-16 search/replacement input combinations.
The concurrency fixture runs 27 atomic-field/array checks unchanged on the stock
JDK and Native, four guest Runtime checks and a Java call/exception sequence.
Rust tests interleave two complete Java call stacks and collect while paused,
including between allocation, calls, exception delivery and object return.
The thread fixture runs 32 stock-JDK-comparable checks and seven actual JNI/TLS
checks on each ARM ABI, then verifies a background worker posting a main Handler
update after sleep. The initialization fixture targets API24+ for default methods
and runs 25 checks unchanged on the stock JDK and Native, including wait/notify
inside clinit, competing readers, error propagation/retention and reflection.
The stack fixture runs 40 checks unchanged on stock Java and Native, plus a real
JNI ThrowNew/native-frame check on each ARM ABI. It verifies construction/rethrow/
fault origins, virtual constructor callbacks, array copies, UTF16 preservation,
disabled stack/suppression flags, paused-thread snapshots and collection ownership.

For the actual Qt event-loop/window check, configure the Studio CMake project with
RIFT_BUILD_TESTS=ON and run rift-studio-event-test EVENT_APK SCREENSHOT.png in an
isolated desktop or Qt offscreen test session with the matching daemon/worker.
The test executable is not installed with the desktop app.

See top-level VALIDATION-v07.md and the release corpus report for actual results.
An initial UI scene alone is not a gameplay, networking or login certificate.

Current Native development adds live `Collections.newSetFromMap` views over native
or DEX maps. Real map/key-iterator callbacks execute with scoped GC roots; read-only
iterators reject removal. The original Java8/DEX fixture has 42 checks on both ARM
ABIs. Unknown operations remain explicit errors; this is a collection API subset.

The six standard charsets support canonical names/aliases, lookup and String byte
conversion. 960 independent stock-Java8 vectors verify 1,920 encoding/decoding
results, including malformed input. A 41-check Java/DEX fixture also exercises
the original-array-backed ByteArrayInputStream and its mark/reset/skip/close/EOF
behavior. InputStreamReader accepts Charset objects for UTF-8, ASCII and Latin-1;
UTF-16 streaming readers and NIO CharsetEncoder/Decoder objects remain unsupported.
These fixtures establish library behavior, not compatibility of the five user APKs.

Android Base64 encoding/decoding uses the actual guest bytes, with standard or URL
alphabet, optional padding, LF/CRLF wrapping and checked input slices. 4,248 vectors
from the unmodified Android API28 reference verify our Rust implementation; a
40-check original APK runs the same assertions on both ARM ABIs. Framework SDK
signatures are compile-only, and the Android reference is used only as an oracle.

Byte/Short/Integer/Long signed parsing handles explicit radix, signed limits and
Java8 BMP digit ranges, including Arabic and fullwidth digits. 3,712 independent
stock-Java8 cases cover successful parses and failures; 36 actual DEX assertions
run on each ARM ABI. Null/empty values, invalid digits/radices and overflow throw
NumberFormatException; primitive results never enter boxed-receiver dispatch.
The owned interpreter supports 128 active calls and 320 continuation records,
with the existing half-heap stack-memory guard and instruction budget. Tests
pause/collect/resume beyond 64 Java calls and verify bounded recursion cleanup.

SQLite uses the real system engine through pinned rusqlite 0.32.1. Guest SQL runs
in memory, with checked private SQLite images, bound parameters, typed cursor
snapshots and resource limits. SQLiteOpenHelper executes actual DEX configure,
create/upgrade/open callbacks; failures roll back data/version, including failed
commits and unsuccessful nested transactions. A 48-check APK executes these
operations under both ARM worker processes. GC retains helper/database references
and releases a dead database's reserved file capacity; last committed images remain
in the guest filesystem. Host attachment, extensions, unsafe pragmas and multiple
statements are rejected before execution. No database host path is opened.

General guest files, including SQLite images, currently last for one worker
session. Cross-process database persistence, WAL, custom cursor factories/error
handlers and simultaneous helpers for the same named database remain unsupported.
This implementation does not certify the five user applications.

Selected java.util.logging APIs use guest-owned Logger and Level objects. Named
lookups preserve identity while a logger is live, retain actual parent links and
reparent children when a nearer ancestor is registered. Null levels inherit from
parents; OFF/ALL and custom integer levels filter actual messages. A 123-assertion
fixture runs unchanged on pinned stock Java8 and on both ARM worker processes.
The Native diagnostic sink retains at most 32 messages, 2,048 characters per
message and 16 KiB estimated escaped JSON bytes in total. Android Log and uncaught
thread diagnostics use the same bound, preventing a log flood from filling the
64-KiB worker packet. Named lookups are weak, while live parents/levels/names
survive GC. Custom Handlers/Filters, ResourceBundles, LogRecords, Suppliers and
Level parsing are not implemented; this is not a complete JUL implementation.

Runnable executor tasks use reusable cooperative guest threads and an own
DEX worker loop backed by checked private Rust queue and lifecycle operations.
The loop runs each task in a separate owned frame, allowing waits and releasing
completed task references before idle waiting. Actual custom ThreadFactory
wrappers and before/after/terminated hooks execute; failed tasks reach the guest
uncaught handler and their workers are replaced. Native linked blocking queues
enforce capacity, preserve pending work and reject nulls. Core/maximum size,
keepalive and core-timeout changes affect live workers; shutdownNow interrupts
active waits and returns the real pending tasks. A 47-assertion fixture runs
unchanged on stock Java8 and both ARM workers. GC tests cover queued work, private
bridge ownership, completed-task release and shutdown cycles.

The small loop is our source, compiled with pinned D8 by
`tools/build-pool-worker.py`; the compile-only bridge class is excluded. Its bytes,
Java sources and toolchain are fingerprinted, and APKs cannot supply its reserved
namespace. Execution stays in the existing single guest lane with the 64-thread
limit. Standalone FutureTask, submit on ordinary pools, custom blocking queues
and blocking inside synchronous hooks or factories require further implementation.
Unconfigurable executor views delegate the `ExecutorService` and
`ScheduledExecutorService` interfaces to their real targets, including overrides
written by the app. The VM resolves the call on the target's Java frames so
delegate methods can wait and resume through the guest scheduler.

Scheduled pools reuse these workers with a monotonic deadline queue. Runnable
and Callable callbacks run in owned DEX frames and can suspend. Scheduled
futures preserve real results and causes, support interruptible and timed
get, and can interrupt running work on cancellation. Fixed-rate tasks repeat
from their prior deadline. Fixed-delay tasks repeat from completion. Shutdown
applies the pool's separate delayed and periodic policies. A pool accepts up
to 1024 queued tasks within the guest heap limit. Replacement decorators,
external additions to the delay queue and the full blocking queue API require
further implementation. The same 44 fixture assertions run on stock Java 8
and both ARM workers.

The static `String.format(String, Object[])` API supports selected Java 8 en-US
conversions over UTF-16. It validates the pattern before guest callbacks and
reads each argument at the time of use. It preserves unpaired surrogates,
uppercase expansions, signed integer bounds, and typed format exceptions.
The implementation is checked against 6,981 stock Java 8 cases and a 36-check
APK on ARM32 and ARM64. Formatter objects, locale overloads, date/time, floating
conversions and arbitrary precision numbers require further implementation.

Local `android.os.Messenger` instances share a Binder endpoint per Handler.
Sending enqueues the actual Message through the target Handler and records the
virtual sender UID. A reply uses the same queue and retains its endpoint through
`Message.replyTo`. The ARM32 and ARM64 fixture exercises endpoint identity,
the Handler override, typed errors, delayed request delivery and the reply.
Remote Binder transactions and parceling require further implementation.

Cached pools start with zero core workers and a 60-second idle lifetime.
`SynchronousQueue` transfers the actual object to a waiting guest or idle
executor worker, with no stored elements. Fair waits preserve arrival order.
Blocking and timed transfers suspend owned frames, and interruption withdraws
the unmatched wait. A matched value stays rooted until the receiver resumes.
The ordinary pool retains its reusable worker, lifecycle and thread limits.

The Java library subset includes wide integer and floating absolute values,
integer minima and maxima, three `Objects.requireNonNull` overloads, and
`ArrayList.removeIf` with actual predicates and fail-fast structural checks.
`Date` stores signed epoch milliseconds and supports comparison, mutation,
hashing and cloning. Locale and calendar operations require further work.
The same 48 scenarios run on stock Java 8, ARM32 and ARM64.

`Resources.getXml` and provider XML metadata open compiled resources from the
current APK. The bounded cursor preserves start/end depth, text, typed
attributes and attribute resource IDs, and releases its buffers at end or
close. Provider lookup by component reads the same manifest metadata as
lookup by authority.

The session filesystem includes one private emulated volume at
`/storage/emulated/0` with app files, cache and media directories. Each worker
has its own volume and uses the existing file quota. The provider fixture
checks real AAPT2 resources and file I/O in 44 assertions on both ARM ABIs.

HashMap and LinkedHashMap store the Java hash at insertion and find candidates
by that hash. Collisions invoke the lookup key's actual equality method. Live
views retain the inserted key and its stored hash, and callback errors
propagate before insertion or structural edits. The fixture verifies 256
distinct keys without insertion-time equality calls.

Arrays.copyOf and copyOfRange preserve primitive words and the real reference
array class. They support explicit reference targets with type checks, range
and length errors, and zero or null padding within the guest array limits.
The combined 39 checks run on stock Java 8 and both ARM workers.
