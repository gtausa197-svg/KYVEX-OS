package android.content.pm;
/** Compile-only SDK signature; the real implementation is in the Rust runtime. */
public class ApplicationInfo extends PackageItemInfo {
    public String dataDir,className,nativeLibraryDir;
    public int minSdkVersion,targetSdkVersion;
}
