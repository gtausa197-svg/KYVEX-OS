//! Guest-only Java 8 ThreadGroup identities, membership and lifecycle.
//! No host tasks are enumerated, reprioritized or interrupted here.
use super::*;
pub(super) const UNCAUGHT: &str = "(Ljava/lang/Thread;Ljava/lang/Throwable;)V";
pub(super) struct Group {
    pub name: u32,
    pub parent: u32,
    pub max_priority: u32,
    pub daemon: bool,
    pub destroyed: bool,
    pub children: Vec<u32>,
    pub unstarted: u32,
}
impl Runtime {
    pub(super) fn group(&self, id: u32) -> Result<&Group> {
        match &self.object(id)?.payload {
            Payload::ThreadGroup(g) => Ok(g),
            _ => Err("Uninitialized guest ThreadGroup".into()),
        }
    }
    fn group_mut(&mut self, id: u32) -> Result<&mut Group> {
        match &mut self.object_mut(id)?.payload {
            Payload::ThreadGroup(g) => Ok(g),
            _ => Err("Uninitialized guest ThreadGroup".into()),
        }
    }
    pub(super) fn ensure_thread_groups(&mut self) -> Result<()> {
        if self.system_group == 0 {
            let name = self.string("system")?;
            self.system_group = self.allocate(
                "Ljava/lang/ThreadGroup;",
                Payload::ThreadGroup(Group {
                    name,
                    parent: 0,
                    max_priority: 10,
                    daemon: false,
                    destroyed: false,
                    children: Vec::new(),
                    unstarted: 0,
                }),
            )?;
        }
        if self.main_group == 0 {
            let name = self.string("main")?;
            self.main_group = self.allocate(
                "Ljava/lang/ThreadGroup;",
                Payload::ThreadGroup(Group {
                    name,
                    parent: self.system_group,
                    max_priority: 10,
                    daemon: false,
                    destroyed: false,
                    children: Vec::new(),
                    unstarted: 0,
                }),
            )?;
            let main = self.main_group;
            self.group_mut(self.system_group)?.children.push(main);
        }
        Ok(())
    }
    pub(super) fn thread_group(&self, id: u32) -> Result<u32> {
        Ok(self
            .object(id)?
            .fields
            .get(&threads::GROUP)
            .copied()
            .unwrap_or(0) as u32)
    }
    pub(super) fn thread_handler(&self, id: u32) -> Result<u32> {
        let handler = self
            .object(id)?
            .fields
            .get(&threads::HANDLER)
            .copied()
            .unwrap_or(0) as u32;
        if handler != 0 {
            Ok(handler)
        } else {
            self.thread_group(id)
        }
    }
    fn direct_group_threads(&self, id: u32) -> Vec<u32> {
        self.scheduler
            .records
            .iter()
            .filter_map(|(thread, r)| {
                (r.alive() && self.thread_group(*thread).ok() == Some(id)).then_some(*thread)
            })
            .collect()
    }
    fn group_tree(&self, id: u32, recurse: bool) -> Result<Vec<u32>> {
        let mut result = Vec::new();
        let mut todo = vec![id];
        while let Some(next) = todo.pop() {
            let g = self.group(next)?;
            if g.destroyed {
                continue;
            }
            if result.len() >= 128 {
                return Err("Guest ThreadGroup tree quota (128)".into());
            }
            result.push(next);
            if recurse {
                todo.extend(g.children.iter().rev());
            }
        }
        Ok(result)
    }
    pub(super) fn group_add_unstarted(&mut self, id: u32) -> Result<()> {
        let g = self.group_mut(id)?;
        if g.destroyed {
            return Err(fault(
                "Ljava/lang/IllegalThreadStateException;",
                "ThreadGroup is destroyed",
            ));
        }
        g.unstarted = g
            .unstarted
            .checked_add(1)
            .ok_or("ThreadGroup unstarted counter overflow")?;
        Ok(())
    }
    pub(super) fn group_thread_started(&mut self, id: u32) -> Result<()> {
        let g = self.group_mut(id)?;
        if g.destroyed {
            return Err(fault(
                "Ljava/lang/IllegalThreadStateException;",
                "ThreadGroup is destroyed",
            ));
        }
        g.unstarted = g
            .unstarted
            .checked_sub(1)
            .ok_or("ThreadGroup missing unstarted Thread")?;
        Ok(())
    }
    fn set_group_priority(&mut self, id: u32, priority: u32) -> Result<()> {
        let parent = self.group(id)?.parent;
        let limit = if parent == 0 {
            10
        } else {
            self.group(parent)?.max_priority
        };
        self.group_mut(id)?.max_priority = priority.min(limit);
        for child in self.group(id)?.children.clone() {
            self.set_group_priority(child, priority)?;
        }
        Ok(())
    }
    fn destroy_group(&mut self, id: u32) -> Result<()> {
        if self.group(id)?.destroyed || !self.direct_group_threads(id).is_empty() {
            return Err(fault(
                "Ljava/lang/IllegalThreadStateException;",
                "ThreadGroup is destroyed or has live threads",
            ));
        }
        let parent = self.group(id)?.parent;
        let children = self.group(id)?.children.clone();
        // Java 8 marks a non-root group before recursively destroying children.
        // A live descendant can therefore cause partial destruction, as on the JDK.
        if parent != 0 {
            let g = self.group_mut(id)?;
            g.destroyed = true;
            g.children.clear();
        }
        for child in children {
            self.destroy_group(child)?;
        }
        if parent != 0 {
            self.group_mut(parent)?
                .children
                .retain(|child| *child != id);
            self.group_maybe_destroy(parent)?;
        }
        Ok(())
    }
    pub(super) fn group_maybe_destroy(&mut self, id: u32) -> Result<()> {
        if id == 0 {
            return Ok(());
        }
        let g = self.group(id)?;
        if !g.destroyed
            && g.daemon
            && g.unstarted == 0
            && g.children.is_empty()
            && self.direct_group_threads(id).is_empty()
        {
            self.destroy_group(id)?;
        }
        Ok(())
    }
    /// Resolve real DEX callbacks without invoking user Java on a Rust stack.
    /// `native_body` handles an explicit super.uncaughtException call by skipping
    /// this group's override and continuing with its parent/default handler.
    pub(super) fn uncaught_target(
        &mut self,
        mut handler: u32,
        thread: u32,
        throwable: u32,
        mut native_body: bool,
    ) -> Result<Option<(usize, Vec<u32>)>> {
        self.object(thread)?;
        self.object(throwable)?;
        for _ in 0..64 {
            if handler == 0 {
                return Ok(None);
            }
            if !native_body
                && let Some(method) =
                    self.callback_method(handler, "uncaughtException", UNCAUGHT)?
            {
                return Ok(Some((method, vec![handler, thread, throwable])));
            }
            native_body = false;
            if !matches!(self.object(handler)?.payload, Payload::ThreadGroup(_)) {
                return Err("UncaughtExceptionHandler implementation absent".into());
            }
            let parent = self.group(handler)?.parent;
            handler = if parent != 0 {
                parent
            } else {
                self.default_uncaught
            };
        }
        Err("Guest uncaught handler delegation quota".into())
    }
    pub(super) fn thread_group_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("ThreadGroup signature")?;
        if class != "Ljava/lang/ThreadGroup;" {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("ThreadGroup argument count");
        let id = arg(0)?;
        self.object(id)?;
        if matches!(
            method,
            "<init>(Ljava/lang/String;)V" | "<init>(Ljava/lang/ThreadGroup;Ljava/lang/String;)V"
        ) {
            if matches!(self.object(id)?.payload, Payload::ThreadGroup(_)) {
                return Err("ThreadGroup already initialized".into());
            }
            self.ensure_main_thread()?;
            let (parent, name) = if a.len() == 3 {
                (arg(1)?, arg(2)?)
            } else {
                (self.thread_group(self.current_thread)?, arg(1)?)
            };
            let g = self.group(parent)?;
            if g.destroyed {
                return Err(fault(
                    "Ljava/lang/IllegalThreadStateException;",
                    "ThreadGroup parent is destroyed",
                ));
            }
            if name != 0 {
                self.units(name)?;
            }
            if self
                .heap
                .values()
                .filter(|o| matches!(o.payload, Payload::ThreadGroup(_)))
                .count()
                >= 128
            {
                return Err("Guest ThreadGroup object quota (128)".into());
            }
            let mut ancestor = parent;
            for depth in 0..64 {
                ancestor = self.group(ancestor)?.parent;
                if ancestor == 0 {
                    break;
                }
                if depth == 63 {
                    return Err("Guest ThreadGroup nesting quota (64)".into());
                }
            }
            let g = self.group(parent)?;
            let group = Group {
                name,
                parent,
                max_priority: g.max_priority,
                daemon: g.daemon,
                destroyed: false,
                children: Vec::new(),
                unstarted: 0,
            };
            self.object_mut(id)?.payload = Payload::ThreadGroup(group);
            self.group_mut(parent)?.children.push(id);
            return Ok(Some(0));
        }
        let g = self.group(id)?;
        let value = match method {
            "getName()Ljava/lang/String;" => g.name as u64,
            "getParent()Ljava/lang/ThreadGroup;" => g.parent as u64,
            "getMaxPriority()I" => g.max_priority as u64,
            "isDaemon()Z" => g.daemon as u64,
            "isDestroyed()Z" => g.destroyed as u64,
            "setDaemon(Z)V" => {
                self.group_mut(id)?.daemon = arg(1)? != 0;
                0
            }
            "setMaxPriority(I)V" => {
                let priority = arg(1)?;
                if (1..=10).contains(&priority) {
                    self.set_group_priority(id, priority)?;
                }
                0
            }
            "parentOf(Ljava/lang/ThreadGroup;)Z" => {
                let mut other = arg(1)?;
                let mut found = false;
                for _ in 0..65 {
                    if other == 0 {
                        break;
                    }
                    if other == id {
                        found = true;
                        break;
                    }
                    other = self.group(other)?.parent;
                }
                found as u64
            }
            "activeCount()I" => self
                .group_tree(id, true)?
                .iter()
                .map(|g| self.direct_group_threads(*g).len())
                .sum::<usize>() as u64,
            "activeGroupCount()I" => self.group_tree(id, true)?.len().saturating_sub(1) as u64,
            "enumerate([Ljava/lang/Thread;)I"
            | "enumerate([Ljava/lang/Thread;Z)I"
            | "enumerate([Ljava/lang/ThreadGroup;)I"
            | "enumerate([Ljava/lang/ThreadGroup;Z)I" => {
                let array = arg(1)?;
                let object = self.object(array)?;
                let Payload::Array(values) = &object.payload else {
                    return Err("ThreadGroup enumeration requires an object array".into());
                };
                let limit = values.len();
                let component = object
                    .class
                    .strip_prefix('[')
                    .ok_or("ThreadGroup enumeration array class")?
                    .to_owned();
                let groups = self.group_tree(id, a.get(2).is_none_or(|v| *v != 0))?;
                let values: Vec<u32> = if method.starts_with("enumerate([Ljava/lang/ThreadGroup;") {
                    // The immediate children are included even for recurse=false.
                    if groups.is_empty() {
                        Vec::new()
                    } else if a.get(2) == Some(&0) {
                        self.group(id)?.children.clone()
                    } else {
                        groups.into_iter().skip(1).collect()
                    }
                } else {
                    groups
                        .into_iter()
                        .flat_map(|g| self.direct_group_threads(g))
                        .collect()
                };
                let count = values.len().min(limit);
                for (index, value) in values.into_iter().take(count).enumerate() {
                    if !self.subclass(&self.object(value)?.class, &component)? {
                        return Err(fault(
                            "Ljava/lang/ArrayStoreException;",
                            "ThreadGroup enumeration array component",
                        ));
                    }
                    let Payload::Array(array) = &mut self.object_mut(array)?.payload else {
                        unreachable!()
                    };
                    array[index] = value as u64;
                }
                count as u64
            }
            "interrupt()V" => {
                for group in self.group_tree(id, true)? {
                    for thread in self.direct_group_threads(group) {
                        self.scheduler.records.get_mut(&thread).unwrap().interrupted = true;
                    }
                }
                0
            }
            "destroy()V" => {
                self.destroy_group(id)?;
                0
            }
            "checkAccess()V" => 0, // No Java SecurityManager is installed in this guest.
            "toString()Ljava/lang/String;" => {
                let priority = g.max_priority;
                let name = if g.name == 0 {
                    "null".encode_utf16().collect()
                } else {
                    self.units(g.name)?
                };
                let class = self
                    .object(id)?
                    .class
                    .trim_start_matches('L')
                    .trim_end_matches(';')
                    .replace('/', ".");
                let mut units: Vec<u16> = format!("{class}[name=").encode_utf16().collect();
                units.extend(name);
                units.extend(format!(",maxpri={priority}]").encode_utf16());
                self.string_units(units)? as u64
            }
            "uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V" => {
                if let Some((method, args)) = self.uncaught_target(id, arg(1)?, arg(2)?, true)? {
                    self.invoke(method, &args, true)?;
                } else {
                    self.log_unhandled_thread(arg(1)?, arg(2)?)?;
                }
                0
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
    pub(super) fn log_unhandled_thread(&mut self, thread: u32, throwable: u32) -> Result<()> {
        let class = self.object(throwable)?.class.clone();
        self.log_guest_thread_fault(format!(
            "Uncaught guest Thread {thread:#x}: {class} ({throwable:#x})"
        ));
        Ok(())
    }
}
