//! Small read-only system font fallback chain prepared before sandbox activation.
use crate::Result;
use std::{
    ffi::{c_char, c_void},
    ptr::NonNull,
};

unsafe extern "C" {
    fn rift_font_open(path: *const c_char) -> *mut c_void;
    fn rift_font_close(font: *mut c_void);
    fn rift_font_has_glyph(font: *mut c_void, text: *const u16, length: i32) -> i32;
}

struct Font(NonNull<c_void>);

impl Drop for Font {
    fn drop(&mut self) {
        unsafe { rift_font_close(self.0.as_ptr()) }
    }
}

#[derive(Default)]
pub(crate) struct Fonts(Vec<Font>);

impl Fonts {
    pub(crate) fn system() -> Self {
        let fonts = [
            c"/usr/share/fonts/noto/NotoSans-Regular.ttf",
            c"/usr/share/fonts/TTF/DejaVuSans.ttf",
            c"/usr/share/fonts/noto/NotoColorEmoji.ttf",
        ]
        .into_iter()
        .filter_map(|path| NonNull::new(unsafe { rift_font_open(path.as_ptr()) }).map(Font))
        .collect();
        Self(fonts)
    }

    pub(crate) fn has_glyph(&self, text: &[u16]) -> Result<bool> {
        if text.is_empty() {
            return Ok(false);
        }
        if text.len() > 256 {
            return Err("Paint glyph sequence quota".into());
        }
        if self.0.is_empty() {
            return Err("No system fonts available for Paint.hasGlyph".into());
        }
        Ok(self.0.iter().any(|font| unsafe {
            rift_font_has_glyph(font.0.as_ptr(), text.as_ptr(), text.len() as i32) != 0
        }))
    }
}
