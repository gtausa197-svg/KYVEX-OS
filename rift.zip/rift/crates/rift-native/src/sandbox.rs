//! Linux worker resource limits and a fail-closed x86-64 seccomp filter.
use crate::Result;
pub fn resources(address_space_mib: u64, cpu_seconds: Option<u64>) -> Result<()> {
    if !(128..=3072).contains(&address_space_mib)
        || cpu_seconds.is_some_and(|seconds| !(1..=60).contains(&seconds))
    {
        return Err("Invalid native worker resource budget".into());
    }
    for (resource, value) in [
        (libc::RLIMIT_AS, address_space_mib * 1024 * 1024),
        (libc::RLIMIT_CPU, cpu_seconds.unwrap_or(libc::RLIM_INFINITY)),
        (libc::RLIMIT_CORE, 0),
        (libc::RLIMIT_FSIZE, 262144),
        (libc::RLIMIT_NOFILE, 32),
    ] {
        let r = libc::rlimit {
            rlim_cur: value,
            rlim_max: value,
        };
        if unsafe { libc::setrlimit(resource, &r) } != 0 {
            return Err(std::io::Error::last_os_error().into());
        }
    }
    if unsafe { libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) } != 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    Ok(())
}
#[cfg(target_arch = "x86_64")]
pub fn restrict() -> Result<()> {
    restrict_with_apk(None)
}
#[cfg(target_arch = "x86_64")]
pub fn restrict_with_apk(apk: Option<i32>) -> Result<()> {
    restrict_with_files(&apk.into_iter().collect::<Vec<_>>())
}
#[cfg(target_arch = "x86_64")]
pub fn restrict_with_files(files: &[i32]) -> Result<()> {
    // APK parsing has completed. No file descriptor except the protocol pipes
    // is needed during guest execution; inherited host descriptors are closed.
    if files.len() > 2 || files.iter().any(|fd| *fd < 3) {
        return Err("Invalid worker descriptor capabilities".into());
    }
    let mut preserved = files.to_vec();
    preserved.sort_unstable();
    preserved.dedup();
    let mut ranges = Vec::new();
    let mut next = 3;
    for fd in preserved {
        ranges.push((next, fd as u32 - 1));
        next = fd as u32 + 1;
    }
    ranges.push((next, u32::MAX));
    for (first, last) in ranges {
        if first <= last && unsafe { libc::syscall(libc::SYS_close_range, first, last, 0u32) } < 0 {
            return Err("The native worker needs Linux close_range support".into());
        }
    }
    const LD: u16 = 0x20;
    const EQ: u16 = 0x15;
    const RET: u16 = 0x06;
    let statement = |code, k| libc::sock_filter {
        code,
        jt: 0,
        jf: 0,
        k,
    };
    let mut filter = vec![
        statement(LD, 4),
        libc::sock_filter {
            code: EQ,
            jt: 1,
            jf: 0,
            k: 0xc000003e,
        },
        statement(RET, 0x80000000),
        statement(LD, 0),
    ];
    let allowed = [
        libc::SYS_read,
        libc::SYS_lseek,
        libc::SYS_write,
        libc::SYS_readv,
        libc::SYS_writev,
        libc::SYS_pread64,
        libc::SYS_pwrite64,
        libc::SYS_fdatasync,
        libc::SYS_close,
        libc::SYS_poll,
        libc::SYS_ppoll,
        libc::SYS_exit,
        libc::SYS_exit_group,
        libc::SYS_futex,
        libc::SYS_mmap,
        libc::SYS_mprotect,
        libc::SYS_munmap,
        libc::SYS_mremap,
        libc::SYS_madvise,
        libc::SYS_brk,
        libc::SYS_clock_gettime,
        libc::SYS_alarm,
        libc::SYS_rt_sigaction,
        libc::SYS_rt_sigprocmask,
        libc::SYS_rt_sigreturn,
        libc::SYS_sigaltstack,
        libc::SYS_getrandom,
        libc::SYS_sched_yield,
        libc::SYS_getpid,
        libc::SYS_gettid,
        libc::SYS_getrusage,
        libc::SYS_prctl,
        libc::SYS_restart_syscall,
    ];
    for nr in allowed {
        filter.push(libc::sock_filter {
            code: EQ,
            jt: 0,
            jf: 1,
            k: nr as u32,
        });
        filter.push(statement(RET, 0x7fff0000));
    }
    filter.push(statement(RET, 0x00050000 | libc::EPERM as u32));
    let program = libc::sock_fprog {
        len: filter.len() as u16,
        filter: filter.as_mut_ptr(),
    };
    if unsafe { libc::prctl(libc::PR_SET_SECCOMP, 2, &program) } != 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    Ok(())
}
#[cfg(not(target_arch = "x86_64"))]
pub fn restrict() -> Result<()> {
    Err("Native process containment is currently implemented for x86-64 Linux hosts".into())
}
pub fn active() -> bool {
    (unsafe { libc::prctl(libc::PR_GET_SECCOMP) }) == 2
}
pub fn peak_rss_kib() -> u64 {
    let mut usage = std::mem::MaybeUninit::<libc::rusage>::zeroed();
    if unsafe { libc::getrusage(libc::RUSAGE_SELF, usage.as_mut_ptr()) } == 0 {
        unsafe { usage.assume_init() }.ru_maxrss as u64
    } else {
        0
    }
}
