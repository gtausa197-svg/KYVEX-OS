package android.util;
/** Compile-only signatures. The APK must not contain this framework class. */
public class Base64 {
 public static final int DEFAULT=0,NO_PADDING=1,NO_WRAP=2,CRLF=4,URL_SAFE=8,NO_CLOSE=16;
 public static native byte[] encode(byte[] input,int flags);
 public static native byte[] encode(byte[] input,int offset,int length,int flags);
 public static native String encodeToString(byte[] input,int flags);
 public static native String encodeToString(byte[] input,int offset,int length,int flags);
 public static native byte[] decode(byte[] input,int flags);
 public static native byte[] decode(byte[] input,int offset,int length,int flags);
 public static native byte[] decode(String input,int flags);
}
