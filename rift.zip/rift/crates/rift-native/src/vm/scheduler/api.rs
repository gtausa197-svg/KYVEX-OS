use super::*;
fn wide(a: &[u32], i: usize) -> Result<i64> {
    Ok((*a.get(i).ok_or("Long argument")? as u64
        | ((*a.get(i + 1).ok_or("Long argument high word")? as u64) << 32)) as i64)
}
impl Runtime {
    pub(in crate::vm) fn scheduler_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Scheduler signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Scheduler argument count");
        if class == "Ljava/lang/Thread;" {
            self.ensure_main_thread()?;
            match method {
                "sleep(J)V" | "sleep(JI)V" => {
                    let millis = wide(a, 0)?;
                    let nanos = if a.len() > 2 { arg(2)? as i32 } else { 0 };
                    let time = Self::java_wait_nanos(millis, nanos)?;
                    self.check_interrupted()?;
                    return self
                        .suspend(if time == 0 {
                            Wait::Yield
                        } else {
                            Wait::Sleep(Self::deadline(time))
                        })
                        .map(Some);
                }
                "yield()V" => {
                    return if self.can_suspend() {
                        self.suspend(Wait::Yield).map(Some)
                    } else {
                        Ok(Some(0))
                    };
                }
                "interrupted()Z" => {
                    let r = self
                        .scheduler
                        .records
                        .get_mut(&self.current_thread)
                        .unwrap();
                    return Ok(Some(std::mem::replace(&mut r.interrupted, false) as u64));
                }
                "holdsLock(Ljava/lang/Object;)Z" => {
                    let id = arg(0)?;
                    self.object(id)?;
                    return Ok(Some(
                        self.monitors
                            .get(&id)
                            .is_some_and(|m| m.owner == self.current_thread)
                            as u64,
                    ));
                }
                "join()V" | "join(J)V" | "join(JI)V" => {
                    let id = arg(0)?;
                    self.object(id)?;
                    let time = if a.len() > 1 {
                        Self::java_wait_nanos(
                            wide(a, 1)?,
                            if a.len() > 3 { arg(3)? as i32 } else { 0 },
                        )?
                    } else {
                        0
                    };
                    // The monitor-based Java implementation checks interruption only while alive.
                    if !self.scheduler.records.get(&id).is_some_and(Record::alive) {
                        return Ok(Some(0));
                    }
                    self.check_interrupted()?;
                    return self
                        .suspend(Wait::Join {
                            target: id,
                            until: if time == 0 {
                                None
                            } else {
                                Self::deadline(time)
                            },
                        })
                        .map(Some);
                }
                "interrupt()V" => {
                    let id = arg(0)?;
                    self.object(id)?;
                    if let Some(r) = self.scheduler.records.get_mut(&id).filter(|r| r.alive()) {
                        r.interrupted = true;
                    }
                    return Ok(Some(0));
                }
                "isInterrupted()Z" => {
                    let id = arg(0)?;
                    self.object(id)?;
                    return Ok(Some(
                        self.scheduler
                            .records
                            .get(&id)
                            .is_some_and(|r| r.interrupted) as u64,
                    ));
                }
                "getState()Ljava/lang/Thread$State;" => {
                    return self.state_object(arg(0)?).map(|id| Some(id as u64));
                }
                "setUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V" => {
                    let id = arg(0)?;
                    let h = arg(1)?;
                    if h != 0 {
                        self.object(h)?;
                    }
                    self.object_mut(id)?
                        .fields
                        .insert(threads::HANDLER, h as u64);
                    return Ok(Some(0));
                }
                "getUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;" => {
                    return self.thread_handler(arg(0)?).map(|value| Some(value as u64));
                }
                _ => {}
            }
        }
        if class == "Ljava/lang/Object;"
            && matches!(
                method,
                "wait()V" | "wait(J)V" | "wait(JI)V" | "notify()V" | "notifyAll()V"
            )
        {
            let id = arg(0)?;
            self.object(id)?;
            self.ensure_main_thread()?;
            let time = if method.starts_with("wait(") && a.len() > 1 {
                Self::java_wait_nanos(wide(a, 1)?, if a.len() > 3 { arg(3)? as i32 } else { 0 })?
            } else {
                0
            };
            let monitor = self
                .monitors
                .get(&id)
                .copied()
                .filter(|m| m.owner == self.current_thread)
                .ok_or_else(|| {
                    fault(
                        "Ljava/lang/IllegalMonitorStateException;",
                        "Current thread does not own monitor",
                    )
                })?;
            if method.starts_with("wait(") {
                self.check_interrupted()?;
                if !self.can_suspend() {
                    return self.suspend(Wait::Yield).map(Some);
                }
                self.monitors.remove(&id);
                return self
                    .suspend(Wait::Object {
                        object: id,
                        holds: monitor.holds,
                        until: if time == 0 {
                            None
                        } else {
                            Self::deadline(time)
                        },
                        notified: false,
                        interrupted: false,
                    })
                    .map(Some);
            }
            for record in self.scheduler.records.values_mut() {
                if let State::Waiting(Wait::Object {
                    object, notified, ..
                }) = &mut record.state
                    && *object == id
                    && !*notified
                {
                    *notified = true;
                    if method == "notify()V" {
                        break;
                    }
                }
            }
            return Ok(Some(0));
        }
        if class == "Ljava/util/concurrent/locks/LockSupport;" {
            self.ensure_main_thread()?;
            if method == "unpark(Ljava/lang/Thread;)V" {
                let id = arg(0)?;
                if id != 0 {
                    self.object(id)?;
                    if let Some(r) = self.scheduler.records.get_mut(&id).filter(|r| r.alive()) {
                        r.permit = true;
                    }
                }
                return Ok(Some(0));
            }
            if method == "getBlocker(Ljava/lang/Thread;)Ljava/lang/Object;" {
                let id = arg(0)?;
                self.object(id)?;
                return Ok(Some(
                    match self.scheduler.records.get(&id).map(|r| &r.state) {
                        Some(State::Waiting(Wait::Park { blocker, .. })) => *blocker as u64,
                        _ => 0,
                    },
                ));
            }
            let (blocker, at) = if method.contains("Ljava/lang/Object;") {
                let id = arg(0)?;
                if id != 0 {
                    self.object(id)?;
                }
                (id, 1)
            } else {
                (0, 0)
            };
            let until = if method.starts_with("parkNanos(") {
                let time = wide(a, at)?;
                if time <= 0 {
                    return Ok(Some(0));
                }
                Self::deadline(time as u64)
            } else if method.starts_with("parkUntil(") {
                let target = wide(a, at)? as i128;
                let now = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)?
                    .as_millis() as i128;
                if target <= now {
                    return Ok(Some(0));
                }
                Self::deadline(((target - now) * 1_000_000).min(u64::MAX as i128) as u64)
            } else if matches!(method, "park()V" | "park(Ljava/lang/Object;)V") {
                None
            } else {
                return Ok(None);
            };
            let r = self
                .scheduler
                .records
                .get_mut(&self.current_thread)
                .unwrap();
            if r.permit {
                r.permit = false;
                return Ok(Some(0));
            }
            if r.interrupted {
                return Ok(Some(0));
            }
            return self.suspend(Wait::Park { until, blocker }).map(Some);
        }
        Ok(None)
    }
    fn java_wait_nanos(millis: i64, nanos: i32) -> Result<u64> {
        if millis < 0 || !(0..1_000_000).contains(&nanos) {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Negative milliseconds or nanoseconds outside 0..999999",
            ));
        }
        Ok((millis as u64)
            .saturating_mul(1_000_000)
            .saturating_add(nanos as u64))
    }
}
