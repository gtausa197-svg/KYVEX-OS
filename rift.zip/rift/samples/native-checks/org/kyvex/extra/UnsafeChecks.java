package org.kyvex.extra;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.concurrent.CountDownLatch;
import sun.misc.Unsafe;
/** Same legal typed Unsafe operations run on stock Java8 and both guest ABIs. */
public final class UnsafeChecks {
 private static int checks,initializations;
 public static Object retained;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 private static final class Values {private int number=7;volatile long stamp=8;Object ref;boolean flag;byte tiny;short small;char unit;float fraction;double precise;static int shared=11;}
 private static final class Lazy {static int value=touch();private static int touch(){initializations++;return 77;}}
 private static Unsafe acquire()throws Exception{Field singleton=null;for(Field field:Unsafe.class.getDeclaredFields())if(field.getType()==Unsafe.class&&Modifier.isStatic(field.getModifiers()))singleton=field;if(singleton==null)throw new IllegalStateException("No real Unsafe singleton");singleton.setAccessible(true);return (Unsafe)singleton.get(null);}
 private static long offset(Unsafe u,String name)throws Exception{return u.objectFieldOffset(Values.class.getDeclaredField(name));}
 public static int verify() throws Exception {
  checks=0;initializations=0;final Unsafe u=acquire();check(u==acquire(),"Stable real guest singleton");
  try{Unsafe.getUnsafe();throw new IllegalStateException("Application getUnsafe was allowed");}catch(SecurityException expected){checks++;}
  check(u.addressSize()==4||u.addressSize()==8,"Guest address width");
  final Values value=new Values();final long number=offset(u,"number");long stamp=offset(u,"stamp"),ref=offset(u,"ref");
  check(number==offset(u,"number")&&stamp!=number,"Stable distinct field capabilities");
  check(u.getInt(value,number)==7&&u.getLongVolatile(value,stamp)==8,"Read actual private/volatile fields");
  u.putInt(value,number,19);check(value.number==19,"Write visible to ordinary Java");
  value.number=20;check(u.getIntVolatile(value,number)==20,"Ordinary Java write visible to Unsafe");
  check(!u.compareAndSwapInt(value,number,19,99)&&value.number==20,"Failed CAS preserves value");
  check(u.compareAndSwapInt(value,number,20,21)&&value.number==21,"Successful CAS changes actual value");
  u.putLongVolatile(value,stamp,0x1122334455667788L);check(!u.compareAndSwapLong(value,stamp,8,99)&&u.compareAndSwapLong(value,stamp,0x1122334455667788L,-1234567890123L)&&value.stamp==-1234567890123L,"Wide CAS arguments and comparison");
  Object first=new String("same"),equal=new String("same"),replacement=new Object();u.putObjectVolatile(value,ref,first);
  check(!u.compareAndSwapObject(value,ref,equal,replacement)&&value.ref==first,"Reference CAS uses identity, not equals");
  check(u.compareAndSwapObject(value,ref,first,replacement)&&value.ref==replacement,"Reference CAS succeeds on identity");
  check(u.getAndSetObject(value,ref,null)==replacement&&value.ref==null,"Reference exchange returns previous value");
  u.putOrderedInt(value,number,Integer.MAX_VALUE);check(u.getAndAddInt(value,number,1)==Integer.MAX_VALUE&&value.number==Integer.MIN_VALUE,"Atomic int add wraps and returns old value");
  u.putOrderedLong(value,stamp,Long.MAX_VALUE);check(u.getAndAddLong(value,stamp,1)==Long.MAX_VALUE&&value.stamp==Long.MIN_VALUE,"Atomic long add wraps and returns old value");
  check(u.getAndSetInt(value,number,3)==Integer.MIN_VALUE&&value.number==3&&u.getAndSetLong(value,stamp,4)==Long.MIN_VALUE&&value.stamp==4,"Primitive exchanges return old values");
  u.putBooleanVolatile(value,offset(u,"flag"),true);check(value.flag&&u.getBoolean(value,offset(u,"flag")),"Boolean typed storage");
  u.putByte(value,offset(u,"tiny"),(byte)-123);check(value.tiny==-123&&u.getByteVolatile(value,offset(u,"tiny"))==-123,"Signed byte typed storage");
  u.putShortVolatile(value,offset(u,"small"),(short)-30001);check(value.small==-30001&&u.getShort(value,offset(u,"small"))==-30001,"Signed short typed storage");
  u.putChar(value,offset(u,"unit"),'\ud800');check(value.unit=='\ud800'&&u.getCharVolatile(value,offset(u,"unit"))=='\ud800',"Unsigned UTF16 char storage");
  u.putFloatVolatile(value,offset(u,"fraction"),-1.25f);check(value.fraction==-1.25f&&u.getFloat(value,offset(u,"fraction"))==-1.25f,"Float bit transport");
  u.putDouble(value,offset(u,"precise"),-1234.567);check(value.precise==-1234.567&&u.getDoubleVolatile(value,offset(u,"precise"))==-1234.567,"Wide double bit transport");
  int[] ints={1,2,3};long ib=u.arrayBaseOffset(int[].class),is=u.arrayIndexScale(int[].class);u.putIntVolatile(ints,ib+is,9);check(ints[1]==9&&u.getInt(ints,ib+2*is)==3,"Array base/scale address real int elements");
  check(u.compareAndSwapInt(ints,ib,1,4)&&!u.compareAndSwapInt(ints,ib,1,5)&&ints[0]==4,"Array int CAS");
  long[] longs={11,12};long lb=u.arrayBaseOffset(long[].class),ls=u.arrayIndexScale(long[].class);check(u.getAndAddLong(longs,lb+ls,5)==12&&longs[1]==17,"Array long atomic add");
  Object[] refs={first,null};long rb=u.arrayBaseOffset(Object[].class),rs=u.arrayIndexScale(Object[].class);check(u.compareAndSwapObject(refs,rb,first,replacement)&&u.getAndSetObject(refs,rb+rs,first)==null&&refs[0]==replacement&&refs[1]==first,"Reference array CAS and exchange");
  String[] strings={null};long sb=u.arrayBaseOffset(String[].class);u.putOrderedObject(strings,sb,"actual");check(strings[0].equals("actual")&&u.getObjectVolatile(strings,sb)==strings[0],"Typed reference array write");
  byte[] bytes={0,0};long bb=u.arrayBaseOffset(byte[].class),bs=u.arrayIndexScale(byte[].class);u.putByte(bytes,bb+bs,(byte)-7);check(bytes[1]==-7&&u.getByteVolatile(bytes,bb+bs)==-7,"Packed byte array typed access");
  Field shared=Values.class.getDeclaredField("shared");Object base=u.staticFieldBase(shared);long so=u.staticFieldOffset(shared);u.putIntVolatile(base,so,22);check(Values.shared==22&&u.getInt(base,so)==22,"Static base/offset access actual static state");
  Field lazy=Lazy.class.getDeclaredField("value");Object lazyBase=u.staticFieldBase(lazy);long lo=u.staticFieldOffset(lazy);check(initializations==0&&u.getInt(lazyBase,lo)==0&&initializations==0,"Unsafe metadata/static read does not initialize class");
  check(Lazy.value==77&&initializations==1&&u.getIntVolatile(lazyBase,lo)==77,"Ordinary static initialization visible through issued capability");
  try{u.objectFieldOffset(shared);throw new IllegalStateException("Static field accepted as instance");}catch(IllegalArgumentException expected){checks++;}
  try{u.staticFieldOffset(Values.class.getDeclaredField("number"));throw new IllegalStateException("Instance field accepted as static");}catch(IllegalArgumentException expected){checks++;}
  value.number=0;final CountDownLatch gate=new CountDownLatch(1);
  Runnable increment=new Runnable(){public void run(){try{gate.await();}catch(InterruptedException e){throw new IllegalStateException(e);}for(int i=0;i<128;i++)u.getAndAddInt(value,number,1);u.storeFence();}};
  Thread a=new Thread(increment),b=new Thread(increment);a.start();b.start();gate.countDown();a.join();b.join();u.loadFence();u.fullFence();check(u.getIntVolatile(value,number)==256,"Actual guest threads publish atomic increments");
  Object kept=new Object();u.putObject(value,ref,kept);retained=value;System.gc();check(u.getObject(value,ref)==kept&&((Values)retained).ref==kept,"Unsafe writes participate in actual GC ownership");retained=null;
  return checks;
 }
 public static int report(){try{return verify();}catch(Exception e){throw new IllegalStateException(e);}}
 public static void main(String[] args)throws Exception{System.out.println("Unsafe checks: "+verify());}
}
