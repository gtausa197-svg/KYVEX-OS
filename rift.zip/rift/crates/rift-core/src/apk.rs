//! Bounded APK inspection. Nothing from the archive is executed or unpacked.
use crate::Result;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs::File,
    io::{Read, Seek},
    path::Path,
};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", content = "value", rename_all = "snake_case")]
pub enum MetaValue {
    String(String),
    Integer(i32),
    Boolean(bool),
    FloatBits(u32),
    Resource(u32),
    Reference(u32),
    Null,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Provider {
    pub name: String,
    pub authorities: String,
    pub process: String,
    pub enabled: bool,
    pub enabled_resource: Option<u32>,
    pub exported: Option<bool>,
    pub init_order: i32,
    pub direct_boot_aware: bool,
    #[serde(default)]
    pub grant_uri_permissions: bool,
    #[serde(default)]
    pub grant_uri_permissions_resource: Option<u32>,
    pub read_permission: String,
    pub write_permission: String,
    pub meta_data: BTreeMap<String, MetaValue>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Service {
    pub name: String,
    pub process: String,
    pub permission: String,
    pub enabled: bool,
    pub enabled_resource: Option<u32>,
    pub exported: Option<bool>,
    pub direct_boot_aware: bool,
    pub has_intent_filter: bool,
    pub meta_data: BTreeMap<String, MetaValue>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Apk {
    pub package: String,
    pub label: String,
    pub version: String,
    pub min_sdk: u32,
    pub abis: Vec<String>,
    pub dex_files: usize,
    pub dex_methods: u64,
    pub permissions: Vec<String>,
    pub sha256: String,
    pub bytes: u64,
    pub expanded: u64,
    pub native_libraries: usize,
    pub split: bool,
    #[serde(default)]
    pub launcher: String,
    #[serde(default)]
    pub application: String,
    #[serde(default)]
    pub target_sdk: u32,
    #[serde(default)]
    pub version_code: u64,
    #[serde(default)]
    pub application_meta: BTreeMap<String, MetaValue>,
    #[serde(default)]
    pub process: String,
    #[serde(default)]
    pub providers: Vec<Provider>,
    #[serde(default)]
    pub services: Vec<Service>,
}
fn u16at(b: &[u8], p: usize) -> Result<u16> {
    Ok(u16::from_le_bytes(
        b.get(p..p + 2).ok_or("Truncated XML")?.try_into()?,
    ))
}
fn u32at(b: &[u8], p: usize) -> Result<u32> {
    Ok(u32::from_le_bytes(
        b.get(p..p + 4).ok_or("Truncated XML")?.try_into()?,
    ))
}
fn len8(b: &[u8], p: &mut usize) -> Result<usize> {
    let a = *b.get(*p).ok_or("String bounds")? as usize;
    *p += 1;
    Ok(if a & 128 != 0 {
        let c = *b.get(*p).ok_or("String bounds")? as usize;
        *p += 1;
        ((a & 127) << 8) | c
    } else {
        a
    })
}
fn string(b: &[u8], p: usize, utf8: bool) -> Result<String> {
    let mut p = p;
    if utf8 {
        let _ = len8(b, &mut p)?;
        let n = len8(b, &mut p)?;
        Ok(std::str::from_utf8(b.get(p..p + n).ok_or("String bounds")?)?.into())
    } else {
        let mut n = u16at(b, p)? as usize;
        p += 2;
        if n & 32768 != 0 {
            n = ((n & 32767) << 16) | u16at(b, p)? as usize;
            p += 2;
        }
        if n > 1000000 {
            return Err("String limit".into());
        }
        let data = b.get(p..p + n * 2).ok_or("String bounds")?;
        Ok(String::from_utf16(
            &data
                .as_chunks::<2>()
                .0
                .iter()
                .map(|c| u16::from_le_bytes([c[0], c[1]]))
                .collect::<Vec<_>>(),
        )?)
    }
}
pub fn package_valid(s: &str) -> bool {
    s.len() <= 240
        && s.contains('.')
        && s.split('.').all(|p| {
            !p.is_empty()
                && p.as_bytes()[0].is_ascii_alphabetic()
                && p.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'_')
        })
}
#[derive(Debug)]
struct Manifest {
    package: String,
    label: String,
    version: String,
    min_sdk: u32,
    permissions: Vec<String>,
    split: bool,
    launcher: String,
    application: String,
    target_sdk: u32,
    version_code: u64,
    application_meta: BTreeMap<String, MetaValue>,
    process: String,
    providers: Vec<Provider>,
    services: Vec<Service>,
}
fn manifest(b: &[u8]) -> Result<Manifest> {
    if u16at(b, 0)? != 3 || u32at(b, 4)? as usize != b.len() {
        return Err("Binary Android manifest required".into());
    }
    let mut strings = Vec::new();
    let mut string_bytes = 0usize;
    let mut budget = 32 * 1024 * 1024usize;
    let mut p = 8;
    let (mut package, mut label, mut version, mut sdk, mut permissions, mut split) = (
        String::new(),
        String::new(),
        String::new(),
        0,
        Vec::new(),
        false,
    );
    let (mut activity, mut launcher, mut main, mut category) =
        (String::new(), String::new(), false, false);
    let (mut target, mut application, mut target_sdk) = (String::new(), String::new(), 0);
    let (mut version_code, mut version_major) = (0u32, 0u32);
    let mut application_meta = BTreeMap::new();
    let mut application_process = String::new();
    let mut providers = Vec::new();
    let mut provider: Option<Provider> = None;
    let mut services = Vec::new();
    let mut service: Option<Service> = None;
    let mut scope = Vec::<usize>::new();
    while p + 8 <= b.len() {
        let kind = u16at(b, p)?;
        let head = u16at(b, p + 2)? as usize;
        let size = u32at(b, p + 4)? as usize;
        if size < head || size < 8 || p + size > b.len() {
            return Err("Invalid XML chunk".into());
        }
        let chunk = &b[p..p + size];
        if kind == 1 {
            let count = u32at(chunk, 8)? as usize;
            let flags = u32at(chunk, 16)?;
            let start = u32at(chunk, 20)? as usize;
            if head < 28 || count > 100000 || head + count * 4 > size {
                return Err("XML string table limit".into());
            }
            for i in 0..count {
                let value = string(
                    chunk,
                    start
                        .checked_add(u32at(chunk, head + i * 4)? as usize)
                        .ok_or("Overflow")?,
                    flags & 256 != 0,
                )?;
                string_bytes += value.len();
                if string_bytes > 8 * 1024 * 1024 {
                    return Err("XML string allocation budget".into());
                }
                strings.push(value);
            }
        } else if kind == 0x102 {
            let tag_index = u32at(chunk, 20)? as usize;
            let tag = strings
                .get(u32at(chunk, 20)? as usize)
                .ok_or("XML tag bounds")?;
            let start = 16 + u16at(chunk, 24)? as usize;
            let stride = u16at(chunk, 26)? as usize;
            let count = u16at(chunk, 28)? as usize;
            if stride < 20 || start + count * stride > size {
                return Err("XML attribute bounds".into());
            }
            let app_meta = tag == "meta-data"
                && scope
                    .last()
                    .and_then(|i| strings.get(*i))
                    .is_some_and(|s| s == "application");
            let direct_app = scope
                .last()
                .and_then(|i| strings.get(*i))
                .is_some_and(|s| s == "application");
            if tag == "service" && direct_app {
                if service.is_some() || services.len() >= 256 {
                    return Err("Manifest service count/nesting quota".into());
                }
                service = Some(Service {
                    name: String::new(),
                    process: String::new(),
                    permission: String::new(),
                    enabled: true,
                    enabled_resource: None,
                    exported: None,
                    direct_boot_aware: false,
                    has_intent_filter: false,
                    meta_data: BTreeMap::new(),
                });
            }
            if tag == "service" && !direct_app && service.is_some() {
                return Err("Nested manifest service".into());
            }
            let in_service = scope
                .last()
                .and_then(|i| strings.get(*i))
                .is_some_and(|s| s == "service");
            if tag == "intent-filter"
                && in_service
                && let Some(entry) = &mut service
            {
                entry.has_intent_filter = true;
            }
            let service_meta = tag == "meta-data" && in_service && service.is_some();
            if tag == "provider" && direct_app {
                if provider.is_some() || providers.len() >= 256 {
                    return Err("Manifest provider count/nesting quota".into());
                }
                provider = Some(Provider {
                    name: String::new(),
                    authorities: String::new(),
                    process: String::new(),
                    enabled: true,
                    enabled_resource: None,
                    exported: None,
                    init_order: 0,
                    direct_boot_aware: false,
                    grant_uri_permissions: false,
                    grant_uri_permissions_resource: None,
                    read_permission: String::new(),
                    write_permission: String::new(),
                    meta_data: BTreeMap::new(),
                });
            }
            if tag == "provider" && !direct_app && provider.is_some() {
                return Err("Nested manifest provider".into());
            }
            let provider_meta = tag == "meta-data"
                && provider.is_some()
                && scope
                    .last()
                    .and_then(|i| strings.get(*i))
                    .is_some_and(|s| s == "provider");
            let (mut meta_name, mut meta_value, mut meta_resource) = (None, None, None);
            for i in 0..count {
                let a = start + i * stride;
                let key = strings
                    .get(u32at(chunk, a + 4)? as usize)
                    .ok_or("XML attribute name")?;
                let raw = u32at(chunk, a + 8)?;
                let typ = *chunk.get(a + 15).ok_or("XML attribute type")?;
                let val = u32at(chunk, a + 16)?;
                let value = if raw != u32::MAX {
                    strings
                        .get(raw as usize)
                        .ok_or("XML value bounds")?
                        .as_str()
                } else if typ == 3 {
                    strings
                        .get(val as usize)
                        .ok_or("XML value bounds")?
                        .as_str()
                } else {
                    ""
                };
                budget = budget
                    .checked_sub(value.len())
                    .ok_or("XML attribute copy budget")?;
                let text = if raw != u32::MAX || typ == 3 {
                    value.to_string()
                } else {
                    val.to_string()
                };
                let namespace = u32at(chunk, a)?;
                let android_attr = namespace != u32::MAX
                    && strings
                        .get(namespace as usize)
                        .is_some_and(|s| s == "http://schemas.android.com/apk/res/android");
                if (app_meta || provider_meta || service_meta)
                    && namespace != u32::MAX
                    && strings
                        .get(namespace as usize)
                        .is_some_and(|s| s == "http://schemas.android.com/apk/res/android")
                {
                    match key.as_str() {
                        "name" => meta_name = Some(text.clone()),
                        "resource" => meta_resource = Some(MetaValue::Resource(val)),
                        "value" => {
                            meta_value = Some(match typ {
                                0 => MetaValue::Null,
                                1 => MetaValue::Reference(val),
                                3 => MetaValue::String(text.clone()),
                                4 => MetaValue::FloatBits(val),
                                0x12 => MetaValue::Boolean(val != 0),
                                0x10..=0x1f => MetaValue::Integer(val as i32),
                                _ => return Err("Unsupported manifest metadata type".into()),
                            })
                        }
                        _ => {}
                    }
                }
                if tag == "provider" && direct_app && android_attr {
                    let entry = provider.as_mut().ok_or("Provider scope")?;
                    match key.as_str() {
                        "name" => entry.name = text.clone(),
                        "authorities" => entry.authorities = text.clone(),
                        "process" => entry.process = text.clone(),
                        "enabled" if typ == 1 => entry.enabled_resource = Some(val),
                        "enabled" => entry.enabled = val != 0,
                        "exported" => entry.exported = Some(val != 0),
                        "initOrder" => entry.init_order = val as i32,
                        "directBootAware" => entry.direct_boot_aware = val != 0,
                        "grantUriPermissions" if typ == 1 => {
                            entry.grant_uri_permissions_resource = Some(val)
                        }
                        "grantUriPermissions" => entry.grant_uri_permissions = val != 0,
                        "readPermission" => entry.read_permission = text.clone(),
                        "writePermission" => entry.write_permission = text.clone(),
                        _ => {}
                    }
                }
                if tag == "service" && direct_app && android_attr {
                    let entry = service.as_mut().ok_or("Service scope")?;
                    match key.as_str() {
                        "name" => entry.name = text.clone(),
                        "process" => entry.process = text.clone(),
                        "permission" => entry.permission = text.clone(),
                        "enabled" if typ == 1 => entry.enabled_resource = Some(val),
                        "enabled" => entry.enabled = val != 0,
                        "exported" => entry.exported = Some(val != 0),
                        "directBootAware" => entry.direct_boot_aware = val != 0,
                        _ => {}
                    }
                }
                match (tag.as_str(), key.as_str()) {
                    ("manifest", "package") => package = text,
                    ("manifest", "versionName") => version = text,
                    ("manifest", "versionCode") => version_code = val,
                    ("manifest", "versionCodeMajor") => version_major = val,
                    ("manifest", "split") => split = !text.is_empty(),
                    ("application", "label") if typ == 3 || raw != u32::MAX => label = text,
                    ("application", "name") => application = text,
                    ("application", "process") if android_attr => application_process = text,
                    ("uses-sdk", "minSdkVersion") => sdk = val,
                    ("uses-sdk", "targetSdkVersion") => target_sdk = val,
                    ("uses-permission", "name") => permissions.push(text),
                    ("activity" | "activity-alias", "name") => activity = text,
                    ("activity-alias", "targetActivity") => target = text,
                    ("action", "name") if text == "android.intent.action.MAIN" => main = true,
                    ("category", "name") if text == "android.intent.category.LAUNCHER" => {
                        category = true
                    }
                    _ => {}
                }
            }
            if (app_meta || provider_meta || service_meta)
                && let (Some(name), Some(value)) = (meta_name, meta_resource.or(meta_value))
            {
                let metadata = if app_meta {
                    &mut application_meta
                } else if provider_meta {
                    &mut provider
                        .as_mut()
                        .ok_or("Provider metadata scope")?
                        .meta_data
                } else {
                    &mut service.as_mut().ok_or("Service metadata scope")?.meta_data
                };
                if metadata.len() >= 1024 && !metadata.contains_key(&name) {
                    return Err("Application metadata count quota".into());
                }
                metadata.insert(name, value);
            }
            if scope.len() >= 256 {
                return Err("Manifest element depth quota".into());
            }
            scope.push(tag_index);
        } else if kind == 0x103 {
            let tag = strings
                .get(u32at(chunk, 20)? as usize)
                .ok_or("XML end tag bounds")?;
            if scope.pop().and_then(|i| strings.get(i)) != Some(tag) {
                return Err("Manifest element nesting".into());
            }
            if tag == "intent-filter" {
                if main && category && launcher.is_empty() {
                    launcher = if target.is_empty() {
                        activity.clone()
                    } else {
                        target.clone()
                    }
                }
                main = false;
                category = false;
            }
            if tag == "activity" || tag == "activity-alias" {
                activity.clear();
                target.clear();
            }
            if tag == "provider"
                && let Some(entry) = provider.take()
            {
                providers.push(entry);
            }
            if tag == "service"
                && let Some(entry) = service.take()
            {
                services.push(entry);
            }
        }
        p += size;
    }
    if !package_valid(&package) {
        return Err("Invalid APK package identifier".into());
    }
    if !scope.is_empty() {
        return Err("Unclosed manifest element".into());
    }
    if label.is_empty() {
        label = package.rsplit('.').next().unwrap_or(&package).to_string()
    }
    if launcher.starts_with('.') {
        launcher = format!("{package}{launcher}")
    } else if !launcher.is_empty() && !launcher.contains('.') {
        launcher = format!("{package}.{launcher}")
    }
    if !launcher
        .bytes()
        .all(|c| c.is_ascii_alphanumeric() || matches!(c, b'.' | b'_' | b'$'))
    {
        launcher.clear();
    }
    if application.starts_with('.') {
        application = format!("{package}{application}")
    } else if !application.is_empty() && !application.contains('.') {
        application = format!("{package}.{application}")
    }
    for entry in &mut providers {
        if entry.name.starts_with('.') {
            entry.name = format!("{package}{}", entry.name);
        } else if !entry.name.contains('.') {
            entry.name = format!("{package}.{}", entry.name);
        }
        if entry.name.is_empty()
            || entry.authorities.is_empty()
            || entry.name.len() > 1024
            || !entry
                .name
                .bytes()
                .all(|c| c.is_ascii_alphanumeric() || matches!(c, b'.' | b'_' | b'$'))
        {
            return Err("Invalid manifest provider class/authority".into());
        }
    }
    for entry in &mut services {
        if entry.name.starts_with('.') {
            entry.name = format!("{package}{}", entry.name);
        } else if !entry.name.contains('.') {
            entry.name = format!("{package}.{}", entry.name);
        }
        if entry.name.is_empty()
            || entry.name.len() > 1024
            || !entry
                .name
                .bytes()
                .all(|c| c.is_ascii_alphanumeric() || matches!(c, b'.' | b'_' | b'$'))
        {
            return Err("Invalid manifest service class".into());
        }
    }
    Ok(Manifest {
        package,
        label,
        version,
        min_sdk: sdk,
        permissions,
        split,
        launcher,
        application,
        target_sdk,
        version_code: version_code as u64 | ((version_major as u64) << 32),
        application_meta,
        process: application_process,
        providers,
        services,
    })
}
pub fn inspect(path: &Path) -> Result<Apk> {
    let path = path.canonicalize()?;
    let mut file = File::open(&path)?;
    let bytes = file.metadata()?.len();
    if !file.metadata()?.is_file() || !(32..=2 * 1024 * 1024 * 1024).contains(&bytes) {
        return Err("APK must be a regular file, at most 2 GiB".into());
    }
    let mut hash = Sha256::new();
    let mut buf = [0u8; 131072];
    loop {
        let n = file.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hash.update(&buf[..n]);
    }
    file.rewind()?;
    let mut z = zip::ZipArchive::new(crate::archive::CachedReader::new(file)?)?;
    if z.len() > 50000 {
        return Err("APK file-count limit".into());
    }
    let (mut seen, mut abis, mut expanded, mut libraries, mut dex_files, mut dex_methods) =
        (BTreeSet::new(), BTreeSet::new(), 0u64, 0, 0, 0);
    for i in 0..z.len() {
        let mut f = z.by_index(i)?;
        let n = f.name().to_string();
        if n.len() > 1024
            || n.starts_with('/')
            || n.contains('\\')
            || n.split('/').any(|c| c == "..")
            || !seen.insert(n.clone())
            || f.unix_mode().is_some_and(|m| m & 0o170000 == 0o120000)
        {
            return Err("Unsafe or duplicate APK archive entry".into());
        }
        expanded = expanded
            .checked_add(f.size())
            .ok_or("Expanded size overflow")?;
        if expanded > 3 * 1024 * 1024 * 1024 {
            return Err("APK expansion limit: 3 GiB".into());
        }
        if n.starts_with("lib/")
            && n.ends_with(".so")
            && let Some(abi) = n.split('/').nth(1)
        {
            abis.insert(abi.to_string());
            libraries += 1;
        }
        if n.ends_with(".dex") {
            let mut h = [0u8; 112];
            f.read_exact(&mut h)?;
            if &h[..4] != b"dex\n"
                || h[7] != 0
                || u32at(&h, 36)? != 112
                || u32at(&h, 40)? != 0x12345678
                || u32at(&h, 32)? as u64 != f.size()
            {
                return Err("Invalid DEX header".into());
            }
            dex_files += 1;
            dex_methods += u32at(&h, 88)? as u64;
        }
    }
    let mut f = z.by_name("AndroidManifest.xml")?;
    if f.size() > 4 * 1024 * 1024 {
        return Err("APK manifest limit".into());
    }
    let mut b = Vec::new();
    f.read_to_end(&mut b)?;
    let Manifest {
        package,
        label,
        version,
        min_sdk,
        permissions,
        split,
        launcher,
        application,
        target_sdk,
        version_code,
        application_meta,
        process,
        providers,
        services,
    } = manifest(&b)?;
    if split {
        return Err("Split APK requires its complete bundle; import a universal APK".into());
    }
    Ok(Apk {
        package,
        label,
        version,
        min_sdk,
        abis: abis.into_iter().collect(),
        dex_files,
        dex_methods,
        permissions,
        sha256: format!("{:x}", hash.finalize()),
        bytes,
        expanded,
        native_libraries: libraries,
        split,
        launcher,
        application,
        target_sdk,
        version_code,
        application_meta,
        process,
        providers,
        services,
    })
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn hostile_identifiers() {
        for p in ["../x", "org.a;reboot", "org..app", "org.9a", "org.a/b"] {
            assert!(!package_valid(p))
        }
        assert!(package_valid("com.kiloo.subwaysurf"));
    }
    #[test]
    fn manifest_version_code_matches_the_actual_fixture_and_old_records_still_load() {
        let apk = inspect(
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../samples/built/rift-native-demo.apk"),
        )
        .unwrap();
        assert_eq!(apk.version_code, 2);
        assert_eq!(apk.version, "0.2");
        let mut old = serde_json::to_value(&apk).unwrap();
        old.as_object_mut().unwrap().remove("version_code");
        old.as_object_mut().unwrap().remove("application_meta");
        let decoded: Apk = serde_json::from_value(old).unwrap();
        assert_eq!(decoded.version_code, 0);
        assert_eq!(decoded.package, apk.package);
        assert!(decoded.application_meta.is_empty());
    }
    #[test]
    fn application_metadata_is_typed_and_excludes_nested_activity_metadata() {
        let apk = inspect(
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../samples/built/rift-bridge-demo.apk"),
        )
        .unwrap();
        assert_eq!(apk.application_meta.len(), 5);
        assert!(
            matches!(apk.application_meta.get("fixture.text"),Some(MetaValue::String(s)) if s=="metadata")
        );
        assert!(matches!(
            apk.application_meta.get("fixture.float"),
            Some(MetaValue::FloatBits(0x3fc00000))
        ));
        assert!(matches!(
            apk.application_meta.get("fixture.resource"),
            Some(MetaValue::Resource(0x7f010001))
        ));
        assert!(!apk.application_meta.contains_key("activity.only"));
    }
    #[test]
    fn truncated_manifest_is_error() {
        for n in 0..64 {
            assert!(manifest(&vec![0; n]).is_err())
        }
    }
    #[test]
    fn provider_manifest_preserves_lifecycle_controls_and_scoped_metadata() {
        let apk = inspect(
            &std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("../../samples/built/rift-provider-demo.apk"),
        )
        .unwrap();
        assert_eq!(apk.providers.len(), 4);
        assert_eq!(apk.services.len(), 2);
        let service = apk
            .services
            .iter()
            .find(|s| s.name.ends_with("$MetadataService"))
            .unwrap();
        assert_eq!(service.process, ":metadata");
        assert_eq!(service.permission, "org.kyvex.nativehello.SERVICE");
        assert!(matches!(
            service.meta_data.get("service.marker"),
            Some(MetaValue::Integer(7))
        ));
        assert!(!service.meta_data.contains_key("provider.marker"));
        assert_eq!(apk.application, "org.kyvex.extra.ProviderChecks$App");
        let early = apk
            .providers
            .iter()
            .find(|p| p.name.ends_with("$Early"))
            .unwrap();
        assert_eq!(early.init_order, 100);
        assert!(early.direct_boot_aware && early.enabled);
        assert!(early.grant_uri_permissions);
        assert_eq!(early.exported, Some(false));
        assert_eq!(early.authorities, "org.kyvex.nativehello.early");
        assert!(matches!(
            early.meta_data.get("provider.marker"),
            Some(MetaValue::Integer(11))
        ));
        assert!(apk.application_meta.is_empty());
        assert!(
            !apk.providers
                .iter()
                .find(|p| p.name.ends_with("$Disabled"))
                .unwrap()
                .enabled
        );
        assert_eq!(
            apk.providers
                .iter()
                .find(|p| p.name.ends_with("$Remote"))
                .unwrap()
                .process,
            ":aux"
        );
    }
    #[test]
    fn unicode_string_bounds() {
        assert!(string(&[1, 128], 0, true).is_err());
        assert!(string(&[255, 255, 255, 255], 0, false).is_err());
    }
    #[test]
    fn overlapping_string_table_has_allocation_budget() {
        let count = 1000usize;
        let start = 28 + 4 * count;
        let size = start + 32768;
        let mut data = vec![0u8; 8 + size];
        data[0..2].copy_from_slice(&3u16.to_le_bytes());
        data[2..4].copy_from_slice(&8u16.to_le_bytes());
        let total = data.len() as u32;
        data[4..8].copy_from_slice(&total.to_le_bytes());
        data[8..10].copy_from_slice(&1u16.to_le_bytes());
        data[10..12].copy_from_slice(&28u16.to_le_bytes());
        data[12..16].copy_from_slice(&(size as u32).to_le_bytes());
        data[16..20].copy_from_slice(&(count as u32).to_le_bytes());
        data[24..28].copy_from_slice(&256u32.to_le_bytes());
        data[28..32].copy_from_slice(&(start as u32).to_le_bytes());
        data[8 + start..12 + start].copy_from_slice(&[255, 248, 255, 248]);
        data[12 + start..12 + start + 32760].fill(b'x');
        assert!(manifest(&data).unwrap_err().to_string().contains("budget"));
    }
}
