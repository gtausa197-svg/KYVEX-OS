package org.kyvex.extra;
import android.app.Application;
import android.content.Context;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.pm.ProviderInfo;
import android.net.Uri;
import android.database.Cursor;
public final class ProviderChecks {
 private static int stage,earlyCalls,lateCalls;
 private static boolean attached,created;
 private static ProviderInfo earlyInfo;
 private static ContentProvider retained;
 private static android.widget.TextView detail;
 private static int activityEvents,memoryEvents;
 private static void require(boolean ok){if(!ok)throw new IllegalStateException("Provider lifecycle order or metadata mismatch");}
 public static class App extends Application {
  public App(){require(stage==0);stage=1;boolean rejected=false;try{getSystemService("activity");}catch(NullPointerException expected){rejected=true;}require(rejected);}
  protected void attachBaseContext(Context context){require(stage==1);super.attachBaseContext(context);stage=2;attached=true;}
  public void onCreate(){require(stage==4);super.onCreate();stage=5;created=true;Observer observer=new Observer();registerActivityLifecycleCallbacks(observer);registerComponentCallbacks(observer);}
 }
 public static final class Observer implements Application.ActivityLifecycleCallbacks,android.content.ComponentCallbacks2 {
  public void onActivityCreated(android.app.Activity activity,android.os.Bundle state){require(stage==5&&activityEvents==0&&state==null);activityEvents=1;}
  public void onActivityStarted(android.app.Activity activity){require(activityEvents==1&&detail!=null);activityEvents=2;}
  public void onActivityResumed(android.app.Activity activity){require(activityEvents==2);activityEvents=3;detail.setText("Provider lifecycle: verified");}
  public void onActivityPaused(android.app.Activity activity){require(activityEvents==3);activityEvents=4;}
  public void onActivityStopped(android.app.Activity activity){require(activityEvents==4);activityEvents=5;}
  public void onActivityDestroyed(android.app.Activity activity){require(activityEvents==5);activityEvents=6;}
  public void onActivitySaveInstanceState(android.app.Activity activity,android.os.Bundle state){throw new IllegalStateException("No save-state transition was requested");}
  public void onConfigurationChanged(android.content.res.Configuration config){memoryEvents++;}
  public void onLowMemory(){memoryEvents++;}
  public void onTrimMemory(int level){memoryEvents++;}
 }
 public static void watch(android.widget.TextView view){detail=view;}
 public static int verifyClosed(){require(activityEvents==6&&memoryEvents==0);return activityEvents;}
 public static abstract class Base extends ContentProvider {
  public Cursor query(Uri uri,String[] p,String s,String[] a,String sort){return null;}
  public String getType(Uri uri){return null;}
  public Uri insert(Uri uri,ContentValues values){return null;}
  public int delete(Uri uri,String s,String[] a){return 0;}
  public int update(Uri uri,ContentValues v,String s,String[] a){return 0;}
 }
 public static final class Early extends Base {
  public void attachInfo(Context context,ProviderInfo info){require(info.grantUriPermissions);earlyInfo=info;super.attachInfo(context,info);}
  public boolean onCreate(){require(stage==2&&attached&&!created);stage=3;earlyCalls++;retained=this;
   require(getContext().getApplicationContext() instanceof App);
   int id=getContext().getResources().getIdentifier("greeting","string",getContext().getPackageName());
   require("Hello from APK resources \ud83c\udf0d".equals(getContext().getString(id)));
   CompiledXmlChecks.verify(getContext(),earlyInfo);
   return true;}
 }
 public static final class Late extends Base {public void attachInfo(Context context,ProviderInfo info){require(!info.grantUriPermissions);super.attachInfo(context,info);}public boolean onCreate(){require(stage==3&&!created);stage=4;lateCalls++;return true;}}
 public static final class Disabled extends Base {public Disabled(){throw new IllegalStateException("Disabled provider must not be constructed");}public boolean onCreate(){return false;}}
 public static final class Remote extends Base {public Remote(){throw new IllegalStateException("Foreign process provider must not be constructed");}public boolean onCreate(){return false;}}
 public static final class MetadataService extends android.app.Service {public android.os.IBinder onBind(android.content.Intent intent){return null;}}
 public static final class DisabledService extends android.app.Service {public android.os.IBinder onBind(android.content.Intent intent){return null;}}
 private static void verifyServices(Context context)throws android.content.pm.PackageManager.NameNotFoundException {
  android.content.pm.PackageManager pm=context.getPackageManager();
  ProviderInfo resolved=pm.resolveContentProvider("org.kyvex.nativehello.early",128);require(resolved!=null&&resolved.grantUriPermissions&&resolved.metaData.getInt("provider.marker")==11);
  require(pm.resolveContentProvider("org.kyvex.nativehello.early",0).metaData==null&&pm.resolveContentProvider("missing.authority",128)==null);
  require(pm.resolveContentProvider("org.kyvex.nativehello.disabled",0)==null&&!pm.resolveContentProvider("org.kyvex.nativehello.disabled",512).enabled);
  require("org.kyvex.nativehello:aux".equals(pm.resolveContentProvider("org.kyvex.nativehello.remote",0).processName));
  android.content.ComponentName provider=new android.content.ComponentName(context,Early.class);
  ProviderInfo byName=pm.getProviderInfo(provider,128);
  require(resolved.name.equals(byName.name)&&resolved.authority.equals(byName.authority)
          &&byName.metaData.getInt("provider.paths")==resolved.metaData.getInt("provider.paths"));
  require(pm.getProviderInfo(provider,0).metaData==null);
  android.content.ComponentName disabledProvider=new android.content.ComponentName(context,Disabled.class);
  boolean missingProvider=false;
  try{pm.getProviderInfo(disabledProvider,0);}catch(android.content.pm.PackageManager.NameNotFoundException expected){missingProvider=true;}
  require(missingProvider&&!pm.getProviderInfo(disabledProvider,512).enabled);
  missingProvider=false;
  try{pm.getProviderInfo(new android.content.ComponentName(context,"not.declared.Provider"),128);}
  catch(android.content.pm.PackageManager.NameNotFoundException expected){missingProvider=true;}
  require(missingProvider);
  android.content.ComponentName component=new android.content.ComponentName(context,MetadataService.class);
  android.content.pm.ServiceInfo info=pm.getServiceInfo(component,128);
  require("org.kyvex.extra.ProviderChecks$MetadataService".equals(info.name)&&"org.kyvex.nativehello:metadata".equals(info.processName));
  require(info.enabled&&!info.exported&&"org.kyvex.nativehello.SERVICE".equals(info.permission));
  require(info.metaData.getInt("service.marker")==7&&"org.kyvex.extra.RealRegistrar".equals(info.metaData.getString("fixture.registrar")));
  require(!info.metaData.containsKey("provider.marker")&&pm.getServiceInfo(component,0).metaData==null);
  android.content.ComponentName disabled=new android.content.ComponentName(context,DisabledService.class);
  boolean rejected=false;try{pm.getServiceInfo(disabled,128);}catch(android.content.pm.PackageManager.NameNotFoundException expected){rejected=true;}require(rejected&&!pm.getServiceInfo(disabled,512).enabled);
  rejected=false;try{pm.getServiceInfo(new android.content.ComponentName(context,"not.declared.Service"),128);}catch(android.content.pm.PackageManager.NameNotFoundException expected){rejected=true;}require(rejected);
 }
 public static String verify(Context context){
  require(stage==5&&created&&earlyCalls==1&&lateCalls==1);
  require(activityEvents==1&&memoryEvents==0);
  require("org.kyvex.nativehello.early".equals(earlyInfo.authority));
  require("org.kyvex.extra.ProviderChecks$Early".equals(earlyInfo.name));
  require(earlyInfo.initOrder==100&&!earlyInfo.exported&&earlyInfo.enabled&&earlyInfo.directBootAware);
  require("org.kyvex.nativehello.READ".equals(earlyInfo.readPermission));
  require(earlyInfo.metaData.getInt("provider.marker")==11);
  require(earlyInfo.applicationInfo.dataDir.equals(context.getApplicationInfo().dataDir));
  require("org.kyvex.nativehello".equals(earlyInfo.processName));
  require(retained.getContext().getApplicationContext()==context.getApplicationContext());
  try{verifyServices(context);}catch(android.content.pm.PackageManager.NameNotFoundException error){throw new IllegalStateException(error);}
  return "verified";
 }
}
