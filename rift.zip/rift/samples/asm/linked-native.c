/* Independent libraries for testing actual ARM link and initialization order. */
#if defined(LINK_LEAF)
static int constructed;
static int jni_loads;
__attribute__((constructor)) static void initialize(void) { constructed++; }
int leaf_constructed(void) { return constructed; }
int leaf_jni_loads(void) { return jni_loads; }
int marker(void) { return 99; }
int JNI_OnLoad(void *vm, void *reserved) {
    (void)vm;
    (void)reserved;
    jni_loads++;
    return 0x10006;
}
#elif defined(LINK_FIRST) || defined(LINK_SECOND)
extern int leaf_constructed(void);
static int ready;
__attribute__((constructor)) static void initialize(void) { ready = leaf_constructed() == 1; }
#if defined(LINK_FIRST)
int first_ready(void) { return ready; }
#else
int second_ready(void) { return ready; }
int marker(void) { return 7; }
#endif
#elif defined(LINK_UNRESOLVED)
extern int leaf_constructed(void);
extern int absent_strong_import(void);
int unreachable(void) { return leaf_constructed() + absent_strong_import(); }
#elif defined(LINK_BROKEN_JNI)
typedef struct { const void **functions; } Env;
typedef struct { const void **functions; } VM;
typedef struct { const char *name; const char *signature; const void *function; } Method;
static int bad_result(Env *env, void *type) { (void)env; (void)type; return -123; }
int JNI_OnLoad(VM *vm, void *reserved) {
    (void)reserved;
    Env *env = 0;
    int (*get_env)(VM *, Env **, int) = (void *)vm->functions[6];
    if (get_env(vm, &env, 0x10006) != 0 || !env) return -2;
    void *(*find)(Env *, const char *) = (void *)env->functions[6];
    int (*register_native)(Env *, void *, const Method *, int) = (void *)env->functions[215];
    void *type = find(env, "org/kyvex/extra/LinkChecks");
    static const Method method = { "nativeResult", "()I", bad_result };
    if (!type || register_native(env, type, &method, 1) != 0) return -3;
    return 0x1234;
}
#elif defined(LINK_ROOT)
#include <stdarg.h>

extern int leaf_constructed(void);
extern int leaf_jni_loads(void);
extern int first_ready(void);
extern int second_ready(void);
extern int marker(void);
extern int __android_log_write(int priority, const char *tag, const char *text);
extern int __android_log_print(int priority, const char *tag, const char *format, ...);
extern unsigned long adler32(unsigned long sum, const unsigned char *buffer, unsigned int length);
static int ready;
static int constructed;
__attribute__((constructor)) static void initialize(void) {
    constructed++;
    ready = first_ready() && second_ready() && leaf_constructed() == 1 && marker() == 7;
}
int Java_org_kyvex_extra_LinkChecks_nativeResult(void *env, void *type) {
    (void)env;
    (void)type;
    return ready && constructed == 1 ? 71 + leaf_jni_loads() : -1;
}
#ifdef __arm__
extern void __aeabi_memset4(void *dest, __SIZE_TYPE__ size, int byte);
extern void __aeabi_memcpy4(void *dest, const void *source, __SIZE_TYPE__ size);
extern void __aeabi_memmove(void *dest, const void *source, __SIZE_TYPE__ size);
extern void __aeabi_memclr4(void *dest, __SIZE_TYPE__ size);
#endif
int Java_org_kyvex_extra_LinkChecks_nativeHelpers(void *env, void *type) {
    (void)env;
    (void)type;
    unsigned long seed = adler32(0, 0, 0);
    unsigned long sum = adler32(seed, (const unsigned char *)"Wiki", 4);
    if (seed != 1 || adler32(sum, (const unsigned char *)"pedia", 5) != 0x11e60398UL) return -1;
    if (__android_log_write(4, "RiftLink", "ELF dependency initialized") != 1) return -2;
    if (__android_log_print(4, "RiftLink", "value=%lld hex=%08X word=%s %%",
                            -12345678901234LL, 0xcafeU, "ARM") != 1) return -3;
    if (__android_log_write(3, "RiftLink", "filtered native message") != -1) return -4;
#ifdef __arm__
    _Alignas(8) unsigned char first[8];
    _Alignas(8) unsigned char second[8];
    __aeabi_memset4(first, 8, 0x5a);
    __aeabi_memcpy4(second, first, 8);
    __aeabi_memmove(second + 1, second, 6);
    __aeabi_memclr4(second + 4, 4);
    if (second[0] != 0x5a || second[3] != 0x5a || second[4] != 0 || second[7] != 0) return -5;
#endif
    return 17;
}

extern void *malloc(__SIZE_TYPE__ size);
extern void *calloc(__SIZE_TYPE__ count, __SIZE_TYPE__ size);
extern void *realloc(void *ptr, __SIZE_TYPE__ size);
extern void free(void *ptr);
extern void *memalign(__SIZE_TYPE__ alignment, __SIZE_TYPE__ size);
extern __SIZE_TYPE__ malloc_usable_size(const void *ptr);
extern int *__errno(void);

int Java_org_kyvex_extra_LinkChecks_nativeHeap(void *env, void *type) {
    (void)env;
    (void)type;
    unsigned char *small = malloc(17);
    unsigned char *blocker = malloc(19);
    if (!small || !blocker || ((__UINTPTR_TYPE__)small & 15) || malloc_usable_size(small) < 17) return -1;
    small[0] = 23;
    small[16] = 41;
    blocker[0] = 77;
    unsigned char *grown = realloc(small, 4000);
    if (!grown || grown[0] != 23 || grown[16] != 41 || blocker[0] != 77) return -2;
    volatile __SIZE_TYPE__ too_large = (__SIZE_TYPE__)-1;
    if (realloc(grown, too_large) || *__errno() != 12 || grown[16] != 41) return -3;
    if (calloc(too_large, 2) || *__errno() != 12) return -4;
    unsigned char *zeroes = calloc(23, 7);
    if (!zeroes) return -5;
    for (int i = 0; i < 161; i++) if (zeroes[i] != 0) return -6;
    unsigned char *aligned = memalign(4096, 31);
    if (!aligned || ((__UINTPTR_TYPE__)aligned & 4095)) return -7;
    if (memalign(3, 31) || *__errno() != 22) return -8;
    if (realloc(grown, 0)) return -9;
    free(blocker);
    free(zeroes);
    free(aligned);
    free(0);
    void *from_null = realloc(0, 64);
    if (!from_null) return -10;
    free(from_null);
    *__errno() = 0;
    return 11;
}

int Java_org_kyvex_extra_LinkChecks_nativeErrno(void *env, void *type, int next) {
    (void)env;
    (void)type;
    int *errno_slot = __errno();
    int old = *errno_slot;
    *errno_slot = next;
    return old;
}

extern long strtol(const char *, char **, int);
extern long long strtoll(const char *, char **, int);
extern unsigned long strtoul(const char *, char **, int);
extern unsigned long long strtoull(const char *, char **, int);
extern long long strtoll_l(const char *, char **, int, const void *);
extern unsigned long long strtoull_l(const char *, char **, int, const void *);
extern __INTMAX_TYPE__ strtoimax(const char *, char **, int);
extern __UINTMAX_TYPE__ strtoumax(const char *, char **, int);

int Java_org_kyvex_extra_LinkChecks_nativeInteger(void *env, void *type) {
    (void)env;
    (void)type;
    char *end = 0;
    int *error = __errno();
    *error = 73;
    const char hex[] = " \v-0x100000002g";
    if (strtoll(hex, &end, 0) != -4294967298LL || end != hex + 14 || *error != 73) return -1;
    if (strtol("0778", &end, 0) != 63 || *end != '8') return -2;
    const char prefix[] = "0X";
    if (strtol(prefix, &end, 16) || end != prefix + 1) return -3;
    if (strtol("+Z!", &end, 36) != 35 || *end != '!') return -4;
    const char empty[] = " +";
    if (strtoll(empty, &end, 10) || end != empty || *error != 73) return -5;
    if (strtol(empty, &end, 1) || end != empty || *error != 22) return -6;
    *error = 0;
    if (strtoll("9223372036854775808!", &end, 10) != __LONG_LONG_MAX__ || *end != '!' || *error != 34) return -7;
    *error = 0;
    if (strtoimax("-9223372036854775808!", &end, 10) != -__INTMAX_MAX__ - 1 || *end != '!' || *error) return -8;
    if (strtoimax("-9223372036854775809", 0, 10) != -__INTMAX_MAX__ - 1 || *error != 34) return -9;
    *error = 0;
    if (strtoull("-1", 0, 10) != (unsigned long long)-1 || *error) return -10;
    if (strtoumax("-184467440737095516150000!", &end, 10) != (__UINTMAX_TYPE__)-1 || *end != '!' || *error != 34) return -11;
    *error = 0;
    unsigned long word = strtoul("4294967296!", &end, 10);
    if (*end != '!' || (sizeof(word) == 4 ? word != (unsigned long)-1 || *error != 34
                                         : word != 4294967296ULL || *error)) return -12;
    *error = 0;
    long negative = strtol("-2147483649!", &end, 10);
    if (*end != '!' || (sizeof(negative) == 4 ? negative != -__LONG_MAX__ - 1 || *error != 34
                                             : negative != -2147483649LL || *error)) return -13;
    *error = 0;
    if (strtoll_l(hex, &end, 0, hex) != -4294967298LL || *end != 'g' || *error) return -14;
    if (strtoull_l("-1z", &end, 10, hex) != (unsigned long long)-1 || *end != 'z' || *error) return -15;
    return 15;
}

typedef __SIZE_TYPE__ Size;
typedef struct {
#ifdef __LP64__
    char opaque[152];
#else
    char opaque[84];
#endif
} __attribute__((aligned(sizeof(void *)))) GuestFile;
extern GuestFile __sF[3];
extern GuestFile *stdin, *stdout, *stderr;
extern int fileno(GuestFile *);
extern int ferror(GuestFile *);
extern int feof(GuestFile *);
extern void clearerr(GuestFile *);
extern int fgetc(GuestFile *);
extern int fputc(int, GuestFile *);
extern int fputs(const char *, GuestFile *);
extern int fflush(GuestFile *);
extern Size fread(void *, Size, Size, GuestFile *);
extern Size fwrite(const void *, Size, Size, GuestFile *);
extern int fprintf(GuestFile *, const char *, ...);
extern int vfprintf(GuestFile *, const char *, va_list);
extern int snprintf(char *, Size, const char *, ...);
extern int __vsprintf_chk(char *, int, Size, const char *, va_list);
extern int __vsnprintf_chk(char *, Size, int, Size, const char *, va_list);

static int same(const char *left, const char *right) {
    while (*left && *left == *right) { left++; right++; }
    return *left == *right;
}

static int variadic_report(GuestFile *file, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int result = vfprintf(file, format, args);
    va_end(args);
    return result;
}

static int checked_format(char *dest, Size cap, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int result = __vsprintf_chk(dest, 0, cap, format, args);
    va_end(args);
    return result;
}

static int checked_bounded(char *dest, Size n, Size cap, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int result = __vsnprintf_chk(dest, n, 0, cap, format, args);
    va_end(args);
    return result;
}

int Java_org_kyvex_extra_LinkChecks_nativeStdio(void *env, void *type) {
    (void)env;
    (void)type;
    int *error = __errno();
    if (stdin != &__sF[0] || stdout != &__sF[1] || stderr != &__sF[2]
            || fileno(stdin) != 0 || fileno(stdout) != 1 || fileno(stderr) != 2) return -1;
    if (feof(stdin) || fgetc(stdin) != -1 || !feof(stdin) || ferror(stdin)) return -2;
    clearerr(stdin);
    char byte = 'X';
    if (feof(stdin) || fread(&byte, 1, 1, stdin) || byte != 'X' || !feof(stdin)) return -3;
    if (fputc('X', stdin) != -1 || *error != 9 || !ferror(stdin) || !feof(stdin)) return -4;
    clearerr(stdin);
    if (fwrite("io", 1, 2, stdout) != 2 || fputs("-v34", stdout) < 0
            || fputc(0x10a, stdout) != '\n' || fflush(stdout) != 0) return -5;
    if (fprintf(&__sF[2], "direct=%lld %s %u\n", -4294967297LL, "ok", 17u)
            != sizeof("direct=-4294967297 ok 17\n") - 1) return -6;
    if (variadic_report(stderr, "saved:%u/%lld/%s/%u/%u/%u/%u/%u/%u\n",
                        11u, -4294967298LL, "ARM", 3u, 4u, 5u, 6u, 7u, 8u)
            != sizeof("saved:11/-4294967298/ARM/3/4/5/6/7/8\n") - 1) return -7;
    char buffer[64];
    static const char text[3] = { 'A', 'R', 'M' };
    if (snprintf(buffer, sizeof(buffer), "%+d/%#08x/%.*s/%zu", 7, 0x2au, 3, text, (Size)12)
            != sizeof("+7/0x00002a/ARM/12") - 1 || !same(buffer, "+7/0x00002a/ARM/12")) return -8;
    buffer[4] = 'Z';
    if (snprintf(buffer, 4, "%s", "longer") != 6 || !same(buffer, "lon")
            || buffer[4] != 'Z' || snprintf(0, 0, "%s", "longer") != 6) return -9;
    if (checked_format(buffer, sizeof(buffer), "bound=%lld/%d", -4294967297LL, -9)
            != sizeof("bound=-4294967297/-9") - 1 || !same(buffer, "bound=-4294967297/-9")) return -10;
    if (checked_bounded(buffer, 6, sizeof(buffer), "%-*s/%04u", 6, "A", 9u) != 11
            || !same(buffer, "A    ")) return -11;
    int marker = 77;
    if (fprintf(stderr, "blocked=%n", &marker) != -1 || marker != 77 || *error != 22 || !ferror(stderr)) return -12;
    clearerr(stderr);
    volatile Size overflow = (Size)-1;
    if (fwrite(&byte, overflow, 2, stderr) || *error != 75 || !ferror(stderr)) return -13;
    clearerr(stderr);
    if (fwrite(&byte, 1, 65537, stderr) || *error != 27 || !ferror(stderr)
            || fputs("close-v34", stderr) < 0 || fflush(0)) return -14;
    clearerr(stderr);
    *error = 0;
    return 14;
}

extern int sscanf(const char *, const char *, ...);
extern int vsscanf(const char *, const char *, va_list);

static int scan_saved(const char *input, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int count = vsscanf(input, format, args);
    va_end(args);
    return count;
}

int Java_org_kyvex_extra_LinkChecks_nativeScan(void *env, void *type) {
    (void)env;
    (void)type;
    int number = 99, hexadecimal = 99, consumed = -1;
    if (sscanf(" \t-15/0x20", "%d/%i%n", &number, &hexadecimal, &consumed) != 2
            || number != -15 || hexadecimal != 32 || consumed != 10) return -1;
    long long wide = 0;
    unsigned short octal = 0;
    if (sscanf(" -9223372036854775808 +077", "%lld%ho", &wide, &octal) != 2
            || wide != -9223372036854775807LL - 1 || octal != 63) return -2;
    Size size = 0;
    void *pointer = 0;
    signed char small = 0;
    if (sscanf("123 0x1234 -42", "%zu %p %hhd", &size, &pointer, &small) != 3
            || size != 123 || (__UINTPTR_TYPE__)pointer != 0x1234 || small != -42) return -3;
    char characters[4] = {'?', '?', '?', '?'};
    if (sscanf("a", "%3c", characters) != 1 || characters[0] != 'a'
            || characters[1] != '?' || characters[3] != '?') return -4;
    char first[16], second[16];
    if (sscanf("arch:rift", "%4[a-z]%*c%3s", first, second) != 2
            || !same(first, "arch") || !same(second, "rif")) return -5;
    if (sscanf("D drive:99", "%15[^:]:%d", first, &number) != 2
            || !same(first, "D drive") || number != 99) return -6;
    float single = 0.0f;
    double real = 0.0;
    if (sscanf("-2.5/0x1.2p+3", "%f/%la", &single, &real) != 2
            || single != -2.5f || real != 9.0) return -7;
    double infinity = 0.0, nan = 0.0;
    if (sscanf("infinity nan", "%lf %lf", &infinity, &nan) != 2
            || !(infinity > 1e300) || nan == nan) return -8;
    number = 77;
    hexadecimal = 88;
    if (sscanf("", "%d", &number) != -1 || sscanf("x", "%d", &number) != 0 || number != 77
            || sscanf("7:x", "%d:%d", &number, &hexadecimal) != 1
            || number != 7 || hexadecimal != 88) return -9;
    unsigned left = 0, right = 0;
    if (sscanf("12%", "%1u%1u%%", &left, &right) != 2 || left != 1 || right != 2) return -10;
    int fields[9] = {0};
    if (scan_saved("1 2 3 4 5 6 7 8 9", "%d %d %d %d %d %d %d %d %d",
                   fields, fields + 1, fields + 2, fields + 3, fields + 4,
                   fields + 5, fields + 6, fields + 7, fields + 8) != 9) return -11;
    for (int i = 0; i < 9; i++) if (fields[i] != i + 1) return -11;
    unsigned long long limit = 0;
    *__errno() = 0;
    if (sscanf("18446744073709551616", "%llu", &limit) != 1
            || limit != (unsigned long long)-1 || *__errno() != 34) return -12;
    consumed = -1;
    if (sscanf("", "%n", &consumed) != 0 || consumed != 0
            || sscanf("7", "%*d%d", &number) != -1) return -13;
    *__errno() = 0;
    return 13;
}

extern int asprintf(char **, const char *, ...);
extern int vasprintf(char **, const char *, va_list);

static int format_saved(char **output, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int length = vasprintf(output, format, args);
    va_end(args);
    return length;
}

int Java_org_kyvex_extra_LinkChecks_nativeAllocFormat(void *env, void *type) {
    (void)env;
    (void)type;
    char *output = 0;
    if (asprintf(&output, "%s=%lld", "signed", -4294967297LL) != 18
            || !output || !same(output, "signed=-4294967297") || malloc_usable_size(output) < 19) return -1;
    free(output);
    if (asprintf(&output, "%s", "") != 0 || !output || output[0]) return -2;
    free(output);
    if (format_saved(&output, "%d/%d/%d/%d/%d/%d/%d/%d", 1,2,3,4,5,6,7,8) != 15
            || !output || !same(output, "1/2/3/4/5/6/7/8")) return -3;
    free(output);
    int marker = 41;
    output = (char *)1;
    if (asprintf(&output, "unsafe %n", &marker) != -1 || output || marker != 41 || *__errno() != 22) return -4;
    *__errno() = 0;
    return 4;
}
#endif
