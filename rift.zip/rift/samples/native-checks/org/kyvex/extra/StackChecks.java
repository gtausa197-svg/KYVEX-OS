package org.kyvex.extra;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
/** Test actual construction/fault origins; do not depend on optional source/debug metadata. */
public final class StackChecks {
 private static int checks;
 public static Throwable retained;
 private static void check(boolean value,String why){if(!value)throw new IllegalStateException(why);checks++;}
 private static boolean has(StackTraceElement[] frames,String method){for(StackTraceElement frame:frames)if(frame!=null&&frame.getClassName().equals(StackChecks.class.getName())&&frame.getMethodName().equals(method))return true;return false;}
 private static RuntimeException build(){return new RuntimeException("origin");}
 private static Throwable buildRetained(){return new IllegalStateException("retained");}
 private static void rethrow(RuntimeException value){throw value;}
 private static void refreshHere(Throwable value){value.fillInStackTrace();}
 private static void faultDeep(){Object value=null;value.getClass();}
 private static void faultOuter(){faultDeep();}
 private static void libraryFault(){"abc".charAt(99);}
 private static void gcHere(){System.gc();int sum=0;for(int i=0;i<700;i++)sum+=i;if(sum!=244650)throw new IllegalStateException("Loop not executed");}
 public static class Frozen extends RuntimeException {Frozen(){super("frozen",null,false,false);}}
 public static class VirtualFill extends RuntimeException {
  static int calls;static String seen;
  VirtualFill(){super("assigned-after-fill");}
  public Throwable fillInStackTrace(){calls++;seen=getMessage();return this;}
 }
 private static void workerWait(CountDownLatch ready,CountDownLatch gate){ready.countDown();try{gate.await();}catch(InterruptedException e){throw new IllegalStateException(e);}}
 private static void verifyThreads()throws InterruptedException{
  final Thread main=Thread.currentThread();final CountDownLatch ready=new CountDownLatch(1),gate=new CountDownLatch(1);final AtomicInteger peer=new AtomicInteger();
  Thread worker=new Thread(new Runnable(){public void run(){peer.set(has(main.getStackTrace(),"verifyThreads")?1:-1);workerWait(ready,gate);}},"trace-worker");
  worker.start();ready.await();check(peer.get()==1,"Paused main thread exposes its actual Java stack");
  StackTraceElement[] first=worker.getStackTrace();check(has(first,"workerWait"),"Paused worker stack has actual waiting method");first[0]=null;
  check(worker.getStackTrace()[0]!=null,"Thread snapshots are independent arrays");
  Map<Thread,StackTraceElement[]> all=Thread.getAllStackTraces();check(all.containsKey(main)&&all.containsKey(worker),"All live guest threads included");
  check(has(all.get(worker),"workerWait")&&has(all.get(main),"verifyThreads"),"Map snapshots contain actual stacks");
  all.clear();check(worker.isAlive(),"Snapshot map cannot alter scheduler ownership");gate.countDown();worker.join();
  check(worker.getStackTrace().length==0&&!Thread.getAllStackTraces().containsKey(worker),"Terminated thread has no executing frames");
 }
 public static int verify()throws Exception{
  checks=0;
  char[] chars={'a','\ud800','z'};String copied=new String(chars),slice=new String(chars,1,1);chars[0]='x';chars[1]='b';
  check(new String().length()==0&&copied.charAt(0)=='a'&&slice.charAt(0)==0xd800&&new String(new StringBuilder("xy")).equals("xy")&&new String(new StringBuffer("buf")).equals("buf"),"String constructors copy UTF16 char/builder inputs");
  try{new String(chars,-1,1);throw new IllegalStateException("Invalid char range accepted");}catch(StringIndexOutOfBoundsException expected){checks++;}
  StackTraceElement frame=new StackTraceElement("demo.Type","run","Type.java",7);
  check(frame.getClassName().equals("demo.Type")&&frame.getMethodName().equals("run"),"Element method and declaring class");
  check(frame.getFileName().equals("Type.java")&&frame.getLineNumber()==7&&!frame.isNativeMethod(),"Element supplied source location");
  check(frame.toString().equals("demo.Type.run(Type.java:7)")&&String.valueOf(frame).equals(frame.toString())&&new StringBuilder().append(frame).toString().equals(frame.toString()),"Element text with source line and Object dispatch");
  StackTraceElement copy=new StackTraceElement(new String("demo.Type"),new String("run"),new String("Type.java"),7);
  check(frame.equals(copy)&&frame.hashCode()==copy.hashCode(),"Element equality and hash use values");
  check(!frame.equals(null)&&!frame.equals("x")&&!frame.equals(new StackTraceElement("demo.Type","run",null,7)),"Element inequality/null/source differences");
  Set<StackTraceElement> set=new HashSet<StackTraceElement>();set.add(frame);set.add(copy);check(set.size()==1,"Collection equality agrees with element.equals");
  check(new StackTraceElement("T","m",null,-1).toString().equals("T.m(Unknown Source)"),"Unknown location remains unknown");
  check(new StackTraceElement("T","m","File.java",-1).toString().equals("T.m(File.java)"),"File without line");
  String unicodeThrowable=String.valueOf(new RuntimeException("\ud800"));
  check(new StackTraceElement("\ud800","m",null,-1).toString().charAt(0)==0xd800&&unicodeThrowable.charAt(unicodeThrowable.length()-1)==0xd800,"Element/Throwable text preserves unpaired UTF16 units");
  StackTraceElement nativeFrame=new StackTraceElement("T","m","native.c",-2);check(nativeFrame.isNativeMethod()&&nativeFrame.toString().equals("T.m(Native Method)"),"Native source marker");
  try{new StackTraceElement(null,"m",null,0);throw new IllegalStateException("Null declaring class accepted");}catch(NullPointerException expected){checks++;}
  try{new StackTraceElement("T",null,null,0);throw new IllegalStateException("Null method accepted");}catch(NullPointerException expected){checks++;}
  RuntimeException created=build();StackTraceElement[] original=created.getStackTrace();check(original.length>0&&original[0].getMethodName().equals("build")&&has(original,"verify"),"Constructor records actual creation stack");
  try{rethrow(created);}catch(RuntimeException actual){check(actual==created&&actual.getStackTrace()[0].equals(original[0]),"Rethrow preserves original construction snapshot");}
  created.setStackTrace(new StackTraceElement[]{frame});StackTraceElement[] supplied={copy};created.setStackTrace(supplied);supplied[0]=nativeFrame;
  check(created.getStackTrace()[0].equals(frame),"setStackTrace copies caller array");
  StackTraceElement[] returned=created.getStackTrace();returned[0]=nativeFrame;check(created.getStackTrace()[0].equals(frame),"getStackTrace returns copy");
  try{created.setStackTrace(null);throw new IllegalStateException("Null trace accepted");}catch(NullPointerException expected){checks++;}
  try{created.setStackTrace(new StackTraceElement[]{null});throw new IllegalStateException("Null trace entry accepted");}catch(NullPointerException expected){checks++;}
  check(created.getStackTrace()[0].equals(frame),"Failed setStackTrace leaves prior value intact");
  refreshHere(created);check(created.getStackTrace()[0].getMethodName().equals("refreshHere"),"fillInStackTrace records current stack");
  try{faultOuter();throw new IllegalStateException("Null receiver succeeded");}catch(NullPointerException e){StackTraceElement[] trace=e.getStackTrace();check(has(trace,"faultDeep")&&has(trace,"faultOuter"),"VM fault pinned before call stack unwinds");}
  try{libraryFault();throw new IllegalStateException("Invalid string index succeeded");}catch(IndexOutOfBoundsException e){check(has(e.getStackTrace(),"libraryFault"),"Library fault retains original caller");}
  Throwable suppressed=new IllegalArgumentException("suppressed");created.addSuppressed(suppressed);Throwable[] exceptions=created.getSuppressed();
  check(exceptions.length==1&&exceptions[0]==suppressed,"Suppressed exception stored");exceptions[0]=null;check(created.getSuppressed()[0]==suppressed,"Suppressed getter returns copy");
  try{created.addSuppressed(created);throw new IllegalStateException("Self suppression accepted");}catch(IllegalArgumentException expected){checks++;}
  try{created.addSuppressed(null);throw new IllegalStateException("Null suppression accepted");}catch(NullPointerException expected){checks++;}
  Frozen frozen=new Frozen();frozen.setStackTrace(new StackTraceElement[]{frame});frozen.fillInStackTrace();frozen.addSuppressed(suppressed);
  check(frozen.getStackTrace().length==0&&frozen.getSuppressed().length==0,"Explicit nonwritable/disabled suppression flags honored");
  try{frozen.setStackTrace(null);throw new IllegalStateException("Disabled trace skipped validation");}catch(NullPointerException expected){checks++;}
  VirtualFill virtual=new VirtualFill();check(VirtualFill.calls==1&&VirtualFill.seen==null&&virtual.getStackTrace().length==0,"Constructor really calls virtual fill before message assignment");
  check(virtual.getMessage().equals("assigned-after-fill"),"Constructor message assigned after callback");
  retained=buildRetained();gcHere();check(has(retained.getStackTrace(),"buildRetained"),"Snapshot elements/strings stay alive through collection");
  verifyThreads();return checks;
 }
 private static native void nativeFault();
 public static int verifyNative(){try{nativeFault();throw new IllegalStateException("Native ThrowNew succeeded");}catch(IllegalStateException e){StackTraceElement[] trace=e.getStackTrace();if(!e.getMessage().equals("native-stack")||trace.length==0||!trace[0].getClassName().equals(StackChecks.class.getName())||!trace[0].getMethodName().equals("nativeFault")||!trace[0].isNativeMethod()||trace[0].getLineNumber()!=-2)throw new IllegalStateException("Native fault snapshot incorrect");return 1;}}
 public static int report(){try{return verify();}catch(Exception e){throw new IllegalStateException(e);}}
 public static void main(String[] args)throws Exception{System.out.println("Stack checks: "+verify());}
}
