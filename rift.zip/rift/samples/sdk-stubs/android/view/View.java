package android.view;
import android.content.Context;
public class View {
    public View(Context context) {}
    public void setBackgroundColor(int color) {}
    public void setPadding(int left,int top,int right,int bottom) {}
    public void setId(int id) {}
    public int getId() {return 0;}
    public void setOnClickListener(OnClickListener listener) {}
    public interface OnClickListener {void onClick(View view);}
}
