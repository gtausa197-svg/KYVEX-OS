//! Normalized touch scheduler shared by the test scene and Android adapter.
use crate::Result;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Control {
    pub id: String,
    pub kind: String,
    pub key: String,
    pub x: f64,
    pub y: f64,
    #[serde(default = "end")]
    pub end_x: f64,
    #[serde(default = "end")]
    pub end_y: f64,
    #[serde(default = "radius")]
    pub radius: f64,
    #[serde(default = "duration")]
    pub duration_ms: u64,
}
fn end() -> f64 {
    0.5
}
fn radius() -> f64 {
    0.1
}
fn duration() -> u64 {
    160
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Profile {
    pub schema_version: u32,
    pub package: String,
    pub name: String,
    pub orientation: String,
    #[serde(default = "automatic_abi")]
    pub abi: String,
    #[serde(default = "native_backend")]
    pub backend: String,
    #[serde(default = "light_memory")]
    pub native_memory: String,
    pub controls: Vec<Control>,
}
fn automatic_abi() -> String {
    "auto".into()
}
fn native_backend() -> String {
    "native".into()
}
fn light_memory() -> String {
    "light".into()
}
impl Profile {
    pub fn validate(&self) -> Result<()> {
        if self.schema_version != 1
            || !super::apk::package_valid(&self.package)
            || self.controls.len() > 64
            || self.name.len() > 100
            || !matches!(self.orientation.as_str(), "portrait" | "landscape")
            || !matches!(self.backend.as_str(), "native")
            || !matches!(self.native_memory.as_str(), "light" | "balanced" | "large")
            || !matches!(self.abi.as_str(), "auto" | "arm64-v8a" | "armeabi-v7a")
        {
            return Err("Invalid profile schema".into());
        }
        let mut ids = BTreeSet::new();
        let mut keys = BTreeSet::new();
        for c in &self.controls {
            if c.id.is_empty()
                || c.id.len() > 64
                || !ids.insert(&c.id)
                || c.key.is_empty()
                || c.key.len() > 32
                || !keys.insert(&c.key)
                || !matches!(
                    c.kind.as_str(),
                    "tap" | "hold" | "swipe" | "joystick" | "aim"
                )
                || ![c.x, c.y, c.end_x, c.end_y]
                    .iter()
                    .all(|v| v.is_finite() && (0.0..=1.0).contains(v))
                || !(0.01..=0.4).contains(&c.radius)
                || !(40..=2000).contains(&c.duration_ms)
            {
                return Err("Invalid or duplicate input binding".into());
            }
        }
        Ok(())
    }
    pub fn default_for(package: &str) -> Self {
        let swipe = |id: &str, key: &str, x: f64, y: f64| Control {
            id: id.into(),
            kind: "swipe".into(),
            key: key.into(),
            x: 0.5,
            y: 0.55,
            end_x: x,
            end_y: y,
            radius: 0.1,
            duration_ms: 140,
        };
        let controls = if package == "com.kiloo.subwaysurf" {
            vec![
                swipe("left", "Left", 0.15, 0.55),
                swipe("right", "Right", 0.85, 0.55),
                swipe("jump", "Up", 0.5, 0.2),
                swipe("roll", "Down", 0.5, 0.9),
                Control {
                    id: "hoverboard".into(),
                    kind: "tap".into(),
                    key: "Space".into(),
                    x: 0.5,
                    y: 0.65,
                    end_x: 0.5,
                    end_y: 0.5,
                    radius: 0.1,
                    duration_ms: 80,
                },
            ]
        } else {
            vec![
                Control {
                    id: "movement".into(),
                    kind: "joystick".into(),
                    key: "WASD".into(),
                    x: 0.2,
                    y: 0.75,
                    end_x: 0.5,
                    end_y: 0.5,
                    radius: 0.1,
                    duration_ms: 160,
                },
                Control {
                    id: "action".into(),
                    kind: "hold".into(),
                    key: "Space".into(),
                    x: 0.82,
                    y: 0.75,
                    end_x: 0.5,
                    end_y: 0.5,
                    radius: 0.1,
                    duration_ms: 160,
                },
                Control {
                    id: "camera".into(),
                    kind: "aim".into(),
                    key: "RightMouseButton".into(),
                    x: 0.65,
                    y: 0.4,
                    end_x: 0.5,
                    end_y: 0.5,
                    radius: 0.12,
                    duration_ms: 160,
                },
            ]
        };
        Self {
            schema_version: 1,
            package: package.into(),
            name: "Keyboard & touch".into(),
            orientation: if package == "com.kiloo.subwaysurf" {
                "portrait"
            } else {
                "landscape"
            }
            .into(),
            abi: automatic_abi(),
            backend: native_backend(),
            native_memory: light_memory(),
            controls,
        }
    }
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Touch {
    pub action: String,
    pub pointer: u64,
    pub x: f64,
    pub y: f64,
}
#[derive(Clone)]
struct Active {
    id: u64,
    c: Control,
    start: u64,
    x: f64,
    y: f64,
    finite: bool,
}
pub struct Engine {
    pub profile: Profile,
    active: BTreeMap<String, Active>,
    keys: BTreeSet<String>,
    next: u64,
    pub now: u64,
    pub last_heartbeat: u64,
    pub trace: Vec<Touch>,
}
impl Engine {
    pub fn new(profile: Profile) -> Self {
        Self {
            profile,
            active: BTreeMap::new(),
            keys: BTreeSet::new(),
            next: 1000,
            now: 0,
            last_heartbeat: 0,
            trace: Vec::new(),
        }
    }
    fn record(&mut self, t: Touch, out: &mut Vec<Touch>) {
        self.trace.push(t.clone());
        if self.trace.len() > 80 {
            self.trace.remove(0);
        }
        out.push(t);
    }
    pub fn release(&mut self) -> Vec<Touch> {
        let mut out = Vec::new();
        for a in std::mem::take(&mut self.active).into_values() {
            self.record(
                Touch {
                    action: "up".into(),
                    pointer: a.id,
                    x: a.x,
                    y: a.y,
                },
                &mut out,
            )
        }
        self.keys.clear();
        out
    }
    pub fn event(&mut self, key: &str, down: bool) -> Vec<Touch> {
        self.last_heartbeat = self.now;
        if down && !self.keys.insert(key.into()) {
            return vec![];
        }
        if !down {
            self.keys.remove(key);
        }
        let mut out = Vec::new();
        for c in self.profile.controls.clone() {
            let joystick = c.kind == "joystick" && ["W", "A", "S", "D"].contains(&key);
            if c.key != key && !joystick {
                continue;
            }
            let (pressed, x, y) = if joystick {
                let dx = self.keys.contains("D") as i32 - self.keys.contains("A") as i32;
                let dy = self.keys.contains("S") as i32 - self.keys.contains("W") as i32;
                let norm = ((dx * dx + dy * dy) as f64).sqrt().max(1.0);
                (
                    dx != 0 || dy != 0,
                    (c.x + dx as f64 * c.radius / norm).clamp(0.0, 1.0),
                    (c.y + dy as f64 * c.radius / norm).clamp(0.0, 1.0),
                )
            } else {
                (down, c.x, c.y)
            };
            if pressed {
                if let Some(a) = self.active.get_mut(&c.id) {
                    a.x = x;
                    a.y = y;
                    let t = Touch {
                        action: "move".into(),
                        pointer: a.id,
                        x,
                        y,
                    };
                    self.record(t, &mut out)
                } else {
                    let id = self.next;
                    self.next += 1;
                    self.active.insert(
                        c.id.clone(),
                        Active {
                            id,
                            c: c.clone(),
                            start: self.now,
                            x,
                            y,
                            finite: matches!(c.kind.as_str(), "tap" | "swipe"),
                        },
                    );
                    self.record(
                        Touch {
                            action: "down".into(),
                            pointer: id,
                            x,
                            y,
                        },
                        &mut out,
                    )
                }
            } else if self.active.get(&c.id).is_some_and(|a| !a.finite) {
                let a = self.active.remove(&c.id).unwrap();
                self.record(
                    Touch {
                        action: "up".into(),
                        pointer: a.id,
                        x: a.x,
                        y: a.y,
                    },
                    &mut out,
                )
            }
        }
        out
    }
    pub fn aim(&mut self, dx: f64, dy: f64) -> Vec<Touch> {
        let mut out = Vec::new();
        if !dx.is_finite() || !dy.is_finite() {
            return out;
        }
        let a = self.active.values_mut().find(|a| a.c.kind == "aim");
        if let Some(a) = a {
            a.x = (a.x + dx.clamp(-0.1, 0.1)).clamp(0.01, 0.99);
            a.y = (a.y + dy.clamp(-0.1, 0.1)).clamp(0.01, 0.99);
            let t = Touch {
                action: "move".into(),
                pointer: a.id,
                x: a.x,
                y: a.y,
            };
            self.record(t, &mut out)
        }
        out
    }
    pub fn tick(&mut self, ms: u64) -> Vec<Touch> {
        self.now = ms;
        let mut out = Vec::new();
        let mut done = Vec::new();
        for (key, a) in &mut self.active {
            if !a.finite {
                continue;
            }
            let age = ms.saturating_sub(a.start);
            let progress = (age as f64 / a.c.duration_ms as f64).min(1.0);
            if a.c.kind == "swipe" {
                a.x = a.c.x + (a.c.end_x - a.c.x) * progress;
                a.y = a.c.y + (a.c.end_y - a.c.y) * progress;
                out.push(Touch {
                    action: "move".into(),
                    pointer: a.id,
                    x: a.x,
                    y: a.y,
                })
            }
            if progress >= 1.0 {
                out.push(Touch {
                    action: "up".into(),
                    pointer: a.id,
                    x: a.x,
                    y: a.y,
                });
                done.push(key.clone())
            }
        }
        for d in done {
            self.active.remove(&d);
        }
        self.trace.extend(out.iter().cloned());
        if self.trace.len() > 80 {
            self.trace.drain(..self.trace.len() - 80);
        }
        if ms.saturating_sub(self.last_heartbeat) > 1800 {
            out.extend(self.release());
        }
        out
    }
    pub fn contacts(&self) -> Vec<Touch> {
        self.active
            .values()
            .map(|a| Touch {
                action: "move".into(),
                pointer: a.id,
                x: a.x,
                y: a.y,
            })
            .collect()
    }
    pub fn pressed(&self) -> Vec<String> {
        self.keys.iter().cloned().collect()
    }
}
pub fn packet(t: &Touch, width: u16, height: u16) -> [u8; 32] {
    let mut b = [0u8; 32];
    b[0] = 2;
    b[1] = match t.action.as_str() {
        "down" => 0,
        "up" => 1,
        _ => 2,
    };
    b[2..10].copy_from_slice(&t.pointer.to_be_bytes());
    b[10..14].copy_from_slice(
        &((t.x.clamp(0.0, 1.0) * (width - 1) as f64).round() as u32).to_be_bytes(),
    );
    b[14..18].copy_from_slice(
        &((t.y.clamp(0.0, 1.0) * (height - 1) as f64).round() as u32).to_be_bytes(),
    );
    b[18..20].copy_from_slice(&width.to_be_bytes());
    b[20..22].copy_from_slice(&height.to_be_bytes());
    b[22..24].copy_from_slice(&(if t.action == "up" { 0u16 } else { u16::MAX }).to_be_bytes());
    b
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn multitouch_and_release() {
        let mut e = Engine::new(Profile::default_for("org.kyvex.test"));
        let a = e.event("W", true);
        let b = e.event("Space", true);
        assert_eq!(e.contacts().len(), 2);
        assert_ne!(a[0].pointer, b[0].pointer);
        assert!(e.event("W", true).is_empty());
        assert_eq!(e.release().len(), 2);
        assert!(e.contacts().is_empty())
    }
    #[test]
    fn diagonal_joystick_and_opposites() {
        let mut e = Engine::new(Profile::default_for("org.kyvex.test"));
        e.event("W", true);
        e.event("D", true);
        let t = e.contacts()[0].clone();
        assert!((t.x - 0.2 - 0.1 / 2f64.sqrt()).abs() < 1e-8);
        e.event("S", true);
        assert!((e.contacts()[0].y - 0.75).abs() < 1e-8)
    }
    #[test]
    fn swipe_finishes_after_key_up() {
        let mut e = Engine::new(Profile::default_for("com.kiloo.subwaysurf"));
        e.event("Up", true);
        e.event("Up", false);
        let v = e.tick(150);
        assert_eq!(v.last().unwrap().action, "up");
        assert_eq!(v.last().unwrap().y, 0.2);
        assert!(e.contacts().is_empty());
    }
    #[test]
    fn heartbeat_watchdog() {
        let mut e = Engine::new(Profile::default_for("org.kyvex.test"));
        e.event("Space", true);
        assert_eq!(e.tick(1900).len(), 1);
        assert!(e.contacts().is_empty())
    }
    #[test]
    fn schema_and_bounds() {
        let mut p = Profile::default_for("org.kyvex.test");
        p.controls[0].x = 2.0;
        assert!(p.validate().is_err());
        p.controls[0].x = 0.2;
        p.controls.push(p.controls[0].clone());
        assert!(p.validate().is_err())
    }
    #[test]
    fn protocol_layout() {
        let b = packet(
            &Touch {
                action: "down".into(),
                pointer: 7,
                x: 0.5,
                y: 1.0,
            },
            720,
            1280,
        );
        assert_eq!(b.len(), 32);
        assert_eq!(u32::from_be_bytes(b[14..18].try_into().unwrap()), 1279);
        assert_eq!(u16::from_be_bytes(b[22..24].try_into().unwrap()), 65535)
    }
    #[test]
    fn old_profiles_default_to_auto_and_abi_is_allowlisted() {
        let mut value = serde_json::to_value(Profile::default_for("org.kyvex.test")).unwrap();
        value.as_object_mut().unwrap().remove("abi");
        value.as_object_mut().unwrap().remove("backend");
        value.as_object_mut().unwrap().remove("native_memory");
        let mut profile: Profile = serde_json::from_value(value).unwrap();
        assert_eq!(profile.abi, "auto");
        assert_eq!(profile.backend, "native");
        assert_eq!(profile.native_memory, "light");
        profile.abi = "armeabi-v7a".into();
        assert!(profile.validate().is_ok());
        profile.abi = "--arbitrary-argument".into();
        assert!(profile.validate().is_err());
        profile.abi = "auto".into();
        profile.backend = "--arbitrary-argument".into();
        assert!(profile.validate().is_err());
        profile.backend = "native".into();
        profile.native_memory = "unlimited".into();
        assert!(profile.validate().is_err());
    }
}
