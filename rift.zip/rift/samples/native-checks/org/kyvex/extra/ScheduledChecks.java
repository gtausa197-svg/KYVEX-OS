package org.kyvex.extra;

import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** The same checks run on stock Java 8 and in the real Native APK. */
public final class ScheduledChecks {
    private static int checks;
    private static final long LIMIT = 3;

    private static void check(boolean ok, String message) {
        if (!ok) throw new IllegalStateException(message);
        checks++;
    }

    private static final class Pool extends ScheduledThreadPoolExecutor {
        volatile boolean sawWorker;
        volatile Throwable hookFailure;
        int decorated;

        Pool() {
            super(1, new ThreadFactory() {
                public Thread newThread(Runnable task) {
                    return new Thread(task, "rift-scheduled-test");
                }
            });
        }
        protected <V> RunnableScheduledFuture<V> decorateTask(
                Callable<V> command, RunnableScheduledFuture<V> task) {
            decorated++;
            return super.decorateTask(command, task);
        }
        protected void beforeExecute(Thread thread, Runnable task) {
            sawWorker = "rift-scheduled-test".equals(thread.getName())
                    && task instanceof RunnableScheduledFuture;
        }
        protected void afterExecute(Runnable task, Throwable error) {
            hookFailure = error;
        }
    }

    public static int verify() {
        checks = 0;
        try {
            exercise();
            shutdownPolicies();
            return checks;
        } catch (Exception error) {
            throw new IllegalStateException(error);
        }
    }

    private static void exercise() throws Exception {
        boolean rejected = false;
        try { new ScheduledThreadPoolExecutor(-1); }
        catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "Reject a negative core size");
        rejected = false;
        try { new ScheduledThreadPoolExecutor(1, (ThreadFactory) null); }
        catch (NullPointerException expected) { rejected = true; }
        check(rejected, "Reject a null ThreadFactory");

        final Object token = new Object();
        final IllegalArgumentException failure = new IllegalArgumentException("real task failure");
        final Runnable idle = new Runnable() { public void run() {} };
        Pool pool = new Pool();
        try {
            check(pool.getCorePoolSize() == 1 && pool.getMaximumPoolSize() == Integer.MAX_VALUE,
                    "Scheduled pool has the correct core and maximum size");
            check(pool.getExecuteExistingDelayedTasksAfterShutdownPolicy()
                    && !pool.getContinueExistingPeriodicTasksAfterShutdownPolicy()
                    && !pool.getRemoveOnCancelPolicy(), "Default shutdown and cancellation policies");
            check(pool.prestartCoreThread(), "Start a worker before any task arrives");
            final ScheduledFuture<?> late = pool.schedule(idle, 1, TimeUnit.DAYS);
            check(pool.getQueue().peek() == late && pool.getQueue().poll() == null,
                    "An unexpired task can be inspected but cannot be polled");
            check(late.getDelay(TimeUnit.HOURS) > 0 && !late.isDone(), "Actual remaining delay");
            try {
                late.get(10, TimeUnit.MILLISECONDS);
                throw new IllegalStateException("get should time out");
            } catch (TimeoutException expected) {
                check(!late.isDone(), "A timed get leaves the task pending");
            }

            long scheduledAt = System.nanoTime();
            ScheduledFuture<Object> early = pool.schedule(new Callable<Object>() {
                public Object call() throws Exception {
                    Thread.sleep(12);
                    return token;
                }
            }, 60, TimeUnit.MILLISECONDS);
            check(early.compareTo(late) < 0 && late.compareTo(early) > 0,
                    "A new earlier task takes precedence over a distant deadline");
            check(early.get(LIMIT, TimeUnit.SECONDS) == token, "Return the actual Callable result");
            check(System.nanoTime() - scheduledAt >= TimeUnit.MILLISECONDS.toNanos(60),
                    "Do not execute before the deadline");
            check(early.isDone() && !early.isCancelled() && !early.cancel(true),
                    "A successful result is terminal");
            check(pool.decorated == 1 && pool.sawWorker, "Real decoration, ThreadFactory and hook");
            check(pool.submit(idle, token).get(LIMIT, TimeUnit.SECONDS) == token,
                    "submit(Runnable, result) returns the supplied reference");
            check(pool.schedule(idle, -1, TimeUnit.SECONDS).get(LIMIT, TimeUnit.SECONDS) == null,
                    "A negative delay makes a Runnable immediately eligible");

            Future<?> failed = pool.submit(new Runnable() {
                public void run() { throw failure; }
            });
            try {
                failed.get(LIMIT, TimeUnit.SECONDS);
                throw new IllegalStateException("Task failure must reach the Future");
            } catch (ExecutionException expected) {
                check(expected.getCause() == failure, "Retain the original task exception");
            }
            check(pool.submit(idle).get(LIMIT, TimeUnit.SECONDS) == null
                    && pool.getLargestPoolSize() == 1 && pool.hookFailure == null,
                    "A failed future leaves its worker reusable and the hook error is null");

            final CountDownLatch waiting = new CountDownLatch(1);
            final AtomicInteger interrupted = new AtomicInteger();
            Thread waiter = new Thread(new Runnable() {
                public void run() {
                    waiting.countDown();
                    try { late.get(); }
                    catch (InterruptedException expected) {
                        if (!Thread.currentThread().isInterrupted()) interrupted.set(1);
                    }
                    catch (ExecutionException unexpected) {
                        throw new IllegalStateException(unexpected);
                    }
                }
            });
            waiter.start();
            check(waiting.await(LIMIT, TimeUnit.SECONDS), "The Future waiter actually started");
            waiter.interrupt();
            waiter.join(TimeUnit.SECONDS.toMillis(LIMIT));
            check(!waiter.isAlive() && interrupted.get() == 1, "Future.get is interruptible");
            check(late.cancel(false) && late.isDone() && late.isCancelled() && !late.cancel(true),
                    "A cancellation succeeds exactly once");
            try { late.get(); throw new IllegalStateException("Cancelled get should fail"); }
            catch (CancellationException expected) { checks++; }
            check(pool.getQueue().contains(late), "Default policy retains cancelled queue entries");
            pool.purge();
            check(!pool.getQueue().contains(late), "Purge removes a cancelled queue entry");
            pool.setRemoveOnCancelPolicy(true);
            ScheduledFuture<?> removed = pool.schedule(idle, 1, TimeUnit.DAYS);
            check(removed.cancel(false) && !pool.getQueue().contains(removed),
                    "Remove-on-cancel changes the actual queue");

            final CountDownLatch active = new CountDownLatch(1);
            final CountDownLatch stopped = new CountDownLatch(1);
            ScheduledFuture<?> running = pool.schedule(new Runnable() {
                public void run() {
                    active.countDown();
                    try { Thread.sleep(10000); }
                    catch (InterruptedException expected) { stopped.countDown(); }
                }
            }, 0, TimeUnit.NANOSECONDS);
            check(active.await(LIMIT, TimeUnit.SECONDS), "Scheduled task entered its real callback");
            check(running.cancel(true) && running.isCancelled(), "Cancel a running task");
            check(stopped.await(LIMIT, TimeUnit.SECONDS), "Cancellation interrupts the guest worker");

            final AtomicInteger runs = new AtomicInteger();
            ScheduledFuture<?> periodic = pool.scheduleAtFixedRate(new Runnable() {
                public void run() {
                    if (runs.incrementAndGet() == 3) throw failure;
                }
            }, 0, 15, TimeUnit.MILLISECONDS);
            check(((RunnableScheduledFuture<?>) periodic).isPeriodic(), "Recognize fixed-rate tasks");
            try { periodic.get(LIMIT, TimeUnit.SECONDS); throw new IllegalStateException("Periodic failure"); }
            catch (ExecutionException expected) {
                check(expected.getCause() == failure && runs.get() == 3,
                        "Fixed-rate repeats and stops on the actual third-run failure");
            }
            final CountDownLatch repeats = new CountDownLatch(2);
            ScheduledFuture<?> fixedDelay = pool.scheduleWithFixedDelay(new Runnable() {
                public void run() { repeats.countDown(); }
            }, 1, 15, TimeUnit.MILLISECONDS);
            check(repeats.await(LIMIT, TimeUnit.SECONDS), "Fixed-delay runs more than once");
            check(!fixedDelay.isDone() && fixedDelay.cancel(false), "Fixed-delay remains cancellable");
            rejected = false;
            try { pool.scheduleWithFixedDelay(idle, 0, 0, TimeUnit.MILLISECONDS); }
            catch (IllegalArgumentException expected) { rejected = true; }
            check(rejected, "A nonpositive period is invalid");
        } finally {
            pool.shutdownNow();
            check(pool.awaitTermination(LIMIT, TimeUnit.SECONDS), "Worker terminates");
        }
    }

    private static void shutdownPolicies() throws Exception {
        final Runnable action = new Runnable() { public void run() {} };
        ScheduledThreadPoolExecutor drain = new ScheduledThreadPoolExecutor(1);
        try {
            ScheduledFuture<?> delayed = drain.schedule(action, 40, TimeUnit.MILLISECONDS);
            ScheduledFuture<?> periodic = drain.scheduleAtFixedRate(action, 1, 1, TimeUnit.DAYS);
            drain.shutdown();
            check(drain.isShutdown() && periodic.isCancelled(), "Graceful shutdown removes periodic work");
            check(delayed.get(LIMIT, TimeUnit.SECONDS) == null && !delayed.isCancelled(),
                    "Accepted delayed work still runs after graceful shutdown");
            check(drain.awaitTermination(LIMIT, TimeUnit.SECONDS) && drain.isTerminated(),
                    "Termination follows the last delayed task");
            boolean rejected = false;
            try { drain.execute(action); } catch (RejectedExecutionException expected) { rejected = true; }
            check(rejected, "Default rejection after shutdown");
        } finally { drain.shutdownNow(); }

        ScheduledThreadPoolExecutor keep = new ScheduledThreadPoolExecutor(0);
        try {
            keep.setContinueExistingPeriodicTasksAfterShutdownPolicy(true);
            keep.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
            ScheduledFuture<?> periodic = keep.scheduleAtFixedRate(action, 1, 1, TimeUnit.DAYS);
            ScheduledFuture<?> delayed = keep.schedule(action, 1, TimeUnit.DAYS);
            keep.shutdown();
            check(!periodic.isCancelled() && delayed.isCancelled() && !keep.isTerminated(),
                    "Shutdown applies independently configured policies");
            keep.setContinueExistingPeriodicTasksAfterShutdownPolicy(false);
            check(periodic.isCancelled() && keep.awaitTermination(LIMIT, TimeUnit.SECONDS),
                    "Changing a shutdown policy prunes the existing queue");
        } finally { keep.shutdownNow(); }

        ScheduledThreadPoolExecutor stop = new ScheduledThreadPoolExecutor(1);
        try {
            ScheduledFuture<?> delayed = stop.schedule(action, 1, TimeUnit.DAYS);
            List<Runnable> tasks = stop.shutdownNow();
            check(tasks.size() == 1 && tasks.get(0) == delayed && !delayed.isDone(),
                    "shutdownNow returns the real pending future even before its deadline");
            tasks.get(0).run();
            check(delayed.isCancelled() && stop.awaitTermination(LIMIT, TimeUnit.SECONDS),
                    "A drained task cannot run after immediate shutdown");
        } finally { stop.shutdownNow(); }

        final Runnable[] seen = new Runnable[1];
        ScheduledThreadPoolExecutor custom = new ScheduledThreadPoolExecutor(1,
                new RejectedExecutionHandler() {
                    public void rejectedExecution(Runnable task, ThreadPoolExecutor owner) {
                        if (owner.isShutdown()) seen[0] = task;
                    }
                });
        custom.shutdown();
        ScheduledFuture<?> rejected = custom.schedule(action, 0, TimeUnit.MILLISECONDS);
        check(seen[0] == rejected && !rejected.isDone(), "Actual rejection callback gets the future");
        rejected.cancel(false);

        ScheduledExecutorService wrapped = Executors.newSingleThreadScheduledExecutor();
        try {
            check(!(wrapped instanceof ScheduledThreadPoolExecutor), "Single-thread factory hides pool configuration");
            check(wrapped.schedule(action, 0, TimeUnit.MILLISECONDS).get(LIMIT, TimeUnit.SECONDS) == null,
                    "Wrapped ScheduledExecutorService executes the real task");
        } finally { wrapped.shutdownNow(); }
    }

    public static void main(String[] args) {
        System.out.println("Scheduled checks: " + verify());
    }
}
