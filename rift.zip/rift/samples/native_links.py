"""Build isolated dependency fixtures without shipping the link-only platform objects."""
from pathlib import Path
import subprocess


def build(target: str, root: Path, asm: Path) -> list[Path]:
    root.mkdir()
    platform = root / 'platform'
    platform.mkdir()
    flags = ['clang', '--target=' + target, '-O2', '-fno-builtin', '-fPIC', '-nostdlib', '-shared',
             '-fuse-ld=lld', '-Wl,--hash-style=sysv', '-Wl,--pack-dyn-relocs=android+relr',
             '-Wl,-z,max-page-size=4096', '-Wl,--no-as-needed']

    def compile_library(path, source, define, *links):
        subprocess.run([*flags, '-D' + define, '-Wl,-soname,' + path.name, str(asm / source),
                        '-L' + str(root), '-L' + str(platform), *links, '-o', str(path)], check=True)

    for library, define in [('log', 'LOG'), ('z', 'Z'), ('android', 'ANDROID')]:
        compile_library(platform / f'lib{library}.so', 'platform-link-only.c', 'LINK_' + define)
    images = []
    for name, define, links in [
        ('leaf', 'LEAF', []),
        ('first', 'FIRST', ['-llink-leaf']),
        ('second', 'SECOND', ['-llink-leaf']),
        ('unresolved', 'UNRESOLVED', ['-llink-leaf']),
        ('broken-jni', 'BROKEN_JNI', []),
        ('root', 'ROOT', ['-llink-first', '-llink-second', '-llog', '-lz', '-landroid']),
    ]:
        path = root / f'liblink-{name}.so'
        compile_library(path, 'linked-native.c', 'LINK_' + define, *links)
        images.append(path)
    for name, source in [
        ('native-strings', 'native-strings.c'),
        ('native-threads', 'pthread-checks.c'),
        ('native-locale', 'native-locale.c'),
    ]:
        path = root / f'liblink-{name}.so'
        compile_library(path, source, 'LINK_CHECKS')
        images.append(path)
    return images
