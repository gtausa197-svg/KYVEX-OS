package android.content.res;
/** Compile-only signatures, never included in the APK. */
public class Resources {
 public AssetManager getAssets(){return null;}
 public XmlResourceParser getXml(int id){return null;}
 public java.io.InputStream openRawResource(int id){return null;}
 public static class NotFoundException extends RuntimeException {}
 public String getString(int id){return null;}
 public CharSequence getText(int id){return null;}
 public CharSequence getText(int id,CharSequence fallback){return null;}
 public int getIdentifier(String name,String kind,String pkg){return 0;}
 public String getResourceName(int id){return null;}
 public String getResourcePackageName(int id){return null;}
 public String getResourceTypeName(int id){return null;}
 public String getResourceEntryName(int id){return null;}
 public boolean getBoolean(int id){return false;}
 public int getInteger(int id){return 0;}
 public int getColor(int id){return 0;}
 public float getDimension(int id){return 0;}
 public int getDimensionPixelOffset(int id){return 0;}
 public int getDimensionPixelSize(int id){return 0;}
 public String[] getStringArray(int id){return null;}
 public CharSequence[] getTextArray(int id){return null;}
 public int[] getIntArray(int id){return null;}
 public void getValue(int id,android.util.TypedValue target,boolean resolve){}
 public Configuration getConfiguration(){return null;}
 public android.util.DisplayMetrics getDisplayMetrics(){return null;}
}
