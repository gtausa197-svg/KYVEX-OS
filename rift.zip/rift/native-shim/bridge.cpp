#include "bridge.h"
#include "dynarmic/interface/A32/a32.h"
#include "dynarmic/interface/A32/coprocessor.h"
#include "dynarmic/interface/A64/a64.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <string>

namespace {
struct Cpu;
struct Common {
  Cpu &cpu;
  explicit Common(Cpu &c) : cpu(c) {}
  template <class T> T read(uint64_t address, uint32_t access = 1);
  template <class T> void write(uint64_t address, T value);
  void stop(uint32_t reason, uint32_t svc = 0);
  void ticks(uint64_t n);
  uint64_t remaining() const;
};
// Android ARM32 reads its read-only thread pointer through CP15 TPIDRURO.
// Every other unimplemented coprocessor operation halts the guest through
// our callback; Dynarmic's missing-coprocessor emitter otherwise asserts.
class GuestCoprocessor final : public Dynarmic::A32::Coprocessor {
  using Reg = Dynarmic::A32::CoprocReg;
  Common &env;
  uint32_t *thread_pointer;
  Callback reject() {
    return Callback{[](void *arg, uint32_t, uint32_t) -> uint64_t {
                      static_cast<Common *>(arg)->stop(4);
                      return 0;
                    }, &env};
  }
public:
  GuestCoprocessor(Common &e, uint32_t *pointer) : env(e), thread_pointer(pointer) {}
  std::optional<Callback> CompileInternalOperation(bool, unsigned, Reg, Reg, Reg, unsigned) override { return reject(); }
  CallbackOrAccessOneWord CompileSendOneWord(bool, unsigned, Reg, Reg, unsigned) override { return reject(); }
  CallbackOrAccessTwoWords CompileSendTwoWords(bool, unsigned, Reg) override { return reject(); }
  CallbackOrAccessOneWord CompileGetOneWord(bool two, unsigned opc1, Reg n, Reg m, unsigned opc2) override {
    if (thread_pointer && !two && opc1 == 0 && n == Reg::C13 && m == Reg::C0 && opc2 == 3)
      return thread_pointer;
    return reject();
  }
  CallbackOrAccessTwoWords CompileGetTwoWords(bool, unsigned, Reg) override { return reject(); }
  std::optional<Callback> CompileLoadWords(bool, bool, Reg, std::optional<uint8_t>) override { return reject(); }
  std::optional<Callback> CompileStoreWords(bool, bool, Reg, std::optional<uint8_t>) override { return reject(); }
};
struct Env32 final : Dynarmic::A32::UserCallbacks, Common {
  explicit Env32(Cpu &c) : Common(c) {}
  std::optional<uint32_t> MemoryReadCode(uint32_t a) override;
  uint8_t MemoryRead8(uint32_t a) override { return read<uint8_t>(a); }
  uint16_t MemoryRead16(uint32_t a) override { return read<uint16_t>(a); }
  uint32_t MemoryRead32(uint32_t a) override { return read<uint32_t>(a); }
  uint64_t MemoryRead64(uint32_t a) override { return read<uint64_t>(a); }
  void MemoryWrite8(uint32_t a, uint8_t v) override { write(a, v); }
  void MemoryWrite16(uint32_t a, uint16_t v) override { write(a, v); }
  void MemoryWrite32(uint32_t a, uint32_t v) override { write(a, v); }
  void MemoryWrite64(uint32_t a, uint64_t v) override { write(a, v); }
  bool MemoryWriteExclusive8(uint32_t a, uint8_t v, uint8_t e) override {
    if (MemoryRead8(a) != e)
      return false;
    MemoryWrite8(a, v);
    return true;
  }
  bool MemoryWriteExclusive16(uint32_t a, uint16_t v, uint16_t e) override {
    if (MemoryRead16(a) != e)
      return false;
    MemoryWrite16(a, v);
    return true;
  }
  bool MemoryWriteExclusive32(uint32_t a, uint32_t v, uint32_t e) override {
    if (MemoryRead32(a) != e)
      return false;
    MemoryWrite32(a, v);
    return true;
  }
  bool MemoryWriteExclusive64(uint32_t a, uint64_t v, uint64_t e) override {
    if (MemoryRead64(a) != e)
      return false;
    MemoryWrite64(a, v);
    return true;
  }
  void InterpreterFallback(uint32_t, size_t) override { stop(4); }
  void CallSVC(uint32_t s) override { stop(2, s); }
  void ExceptionRaised(uint32_t, Dynarmic::A32::Exception) override { stop(4); }
  void AddTicks(uint64_t n) override { ticks(n); }
  uint64_t GetTicksRemaining() override { return remaining(); }
};
struct Env64 final : Dynarmic::A64::UserCallbacks, Common {
  explicit Env64(Cpu &c) : Common(c) {}
  std::optional<uint32_t> MemoryReadCode(uint64_t a) override;
  uint8_t MemoryRead8(uint64_t a) override { return read<uint8_t>(a); }
  uint16_t MemoryRead16(uint64_t a) override { return read<uint16_t>(a); }
  uint32_t MemoryRead32(uint64_t a) override { return read<uint32_t>(a); }
  uint64_t MemoryRead64(uint64_t a) override { return read<uint64_t>(a); }
  Dynarmic::A64::Vector MemoryRead128(uint64_t a) override {
    return read<Dynarmic::A64::Vector>(a);
  }
  void MemoryWrite8(uint64_t a, uint8_t v) override { write(a, v); }
  void MemoryWrite16(uint64_t a, uint16_t v) override { write(a, v); }
  void MemoryWrite32(uint64_t a, uint32_t v) override { write(a, v); }
  void MemoryWrite64(uint64_t a, uint64_t v) override { write(a, v); }
  void MemoryWrite128(uint64_t a, Dynarmic::A64::Vector v) override {
    write(a, v);
  }
  bool MemoryWriteExclusive8(uint64_t a, uint8_t v, uint8_t e) override {
    if (MemoryRead8(a) != e)
      return false;
    MemoryWrite8(a, v);
    return true;
  }
  bool MemoryWriteExclusive16(uint64_t a, uint16_t v, uint16_t e) override {
    if (MemoryRead16(a) != e)
      return false;
    MemoryWrite16(a, v);
    return true;
  }
  bool MemoryWriteExclusive32(uint64_t a, uint32_t v, uint32_t e) override {
    if (MemoryRead32(a) != e)
      return false;
    MemoryWrite32(a, v);
    return true;
  }
  bool MemoryWriteExclusive64(uint64_t a, uint64_t v, uint64_t e) override {
    if (MemoryRead64(a) != e)
      return false;
    MemoryWrite64(a, v);
    return true;
  }
  bool MemoryWriteExclusive128(uint64_t a, Dynarmic::A64::Vector v,
                               Dynarmic::A64::Vector e) override {
    if (MemoryRead128(a) != e)
      return false;
    MemoryWrite128(a, v);
    return true;
  }
  void InterpreterFallback(uint64_t, size_t) override { stop(4); }
  void CallSVC(uint32_t s) override { stop(2, s); }
  void ExceptionRaised(uint64_t, Dynarmic::A64::Exception) override { stop(4); }
  void AddTicks(uint64_t n) override { ticks(n); }
  uint64_t GetTicksRemaining() override { return remaining(); }
  uint64_t GetCNTPCT() override {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
               std::chrono::steady_clock::now().time_since_epoch())
        .count();
  }
};
struct Cpu {
  uint32_t arch, reason = 0, svc = 0;
  void *context;
  kv_read rd;
  kv_write wr;
  uint64_t left = 0, used = 0;
  uint64_t thread_pointer = 0;
  uint32_t thread_pointer32 = 0;
  std::unique_ptr<Env32> env32;
  std::unique_ptr<Env64> env64;
  std::unique_ptr<Dynarmic::A32::Jit> a32;
  std::unique_ptr<Dynarmic::A64::Jit> a64;
  Cpu(uint32_t a, void *p, kv_read r, kv_write w, size_t cache)
      : arch(a), context(p), rd(r), wr(w) {
    if (a == 32) {
      env32 = std::make_unique<Env32>(*this);
      Dynarmic::A32::UserConfig c;
      c.callbacks = env32.get();
      c.code_cache_size = cache;
      c.check_halt_on_memory_access = true;
      c.enable_cycle_counting = true;
      for (size_t i = 0; i < c.coprocessors.size(); ++i)
        c.coprocessors[i] = std::make_shared<GuestCoprocessor>(*env32, i == 15 ? &thread_pointer32 : nullptr);
      a32 = std::make_unique<Dynarmic::A32::Jit>(c);
    } else if (a == 64) {
      env64 = std::make_unique<Env64>(*this);
      Dynarmic::A64::UserConfig c;
      c.callbacks = env64.get();
      c.code_cache_size = cache;
      c.check_halt_on_memory_access = true;
      c.enable_cycle_counting = true;
      c.cntfrq_el0 = 1000000000;
      c.tpidr_el0 = &thread_pointer;
      a64 = std::make_unique<Dynarmic::A64::Jit>(c);
    } else
      throw std::invalid_argument("ARM32 or ARM64 is required");
  }
  void halt() {
    if (a32)
      a32->HaltExecution();
    if (a64)
      a64->HaltExecution();
  }
};
template <class T> T Common::read(uint64_t a, uint32_t access) {
  T value{};
  if (cpu.rd(cpu.context, a, reinterpret_cast<uint8_t *>(&value), sizeof(T),
             access) != 0)
    stop(3);
  return value;
}
template <class T> void Common::write(uint64_t a, T value) {
  if (cpu.wr(cpu.context, a, reinterpret_cast<const uint8_t *>(&value),
             sizeof(T)) != 0)
    stop(3);
}
void Common::stop(uint32_t r, uint32_t s) {
  if (!cpu.reason) {
    cpu.reason = r;
    cpu.svc = s;
  }
  cpu.halt();
}
void Common::ticks(uint64_t n) {
  cpu.used += n;
  cpu.left = n >= cpu.left ? 0 : cpu.left - n;
}
uint64_t Common::remaining() const { return cpu.left; }
std::optional<uint32_t> Env32::MemoryReadCode(uint32_t a) {
  auto v = read<uint32_t>(a, 4);
  return cpu.reason == 3 ? std::nullopt : std::optional<uint32_t>(v);
}
std::optional<uint32_t> Env64::MemoryReadCode(uint64_t a) {
  auto v = read<uint32_t>(a, 4);
  return cpu.reason == 3 ? std::nullopt : std::optional<uint32_t>(v);
}
void error(char *p, size_t n, const char *message) {
  if (p && n) {
    std::strncpy(p, message, n - 1);
    p[n - 1] = 0;
  }
}
} // namespace
extern "C" uint32_t kv_dynarmic_abi() { return 1; }
static_assert(sizeof(kv_state) == 808);
static_assert(offsetof(kv_state, ticks) == 800);
extern "C" size_t kv_dynarmic_state_size() { return sizeof(kv_state); }
extern "C" void *kv_cpu_new(uint32_t arch, void *context, kv_read rd,
                            kv_write wr, size_t cache, char *err, size_t n) {
  try {
    if (!rd || !wr || cache < 2 * 1024 * 1024 || cache > 32 * 1024 * 1024)
      throw std::invalid_argument("Invalid callbacks or JIT cache limit");
    return new Cpu(arch, context, rd, wr, cache);
  } catch (const std::exception &e) {
    error(err, n, e.what());
    return nullptr;
  } catch (...) {
    error(err, n, "Dynarmic construction failed");
    return nullptr;
  }
}
extern "C" int kv_cpu_run(void *ptr, kv_state *state, uint64_t budget,
                          uint32_t single_step, char *err, size_t n) {
  try {
    if (!ptr || !state || !budget || budget > 10000000) {
      throw std::invalid_argument("Invalid CPU run request");
    }
    auto &c = *static_cast<Cpu *>(ptr);
    c.reason = 0;
    c.svc = 0;
    c.left = budget;
    c.used = 0;
    if (c.a64) {
      auto &j = *c.a64;
      for (size_t i = 0; i < 31; i++)
        j.SetRegister(i, state->regs[i]);
      j.SetSP(state->regs[31]);
      j.SetPC(state->pc);
      j.SetPstate(state->flags);
      j.SetFpcr(state->fp_control);
      j.SetFpsr(state->fp_status);
      for (size_t i = 0; i < 32; i++)
        j.SetVector(i, {state->vectors[i * 2], state->vectors[i * 2 + 1]});
      j.ClearHalt();
      if (single_step)
        j.Step();
      else
        j.Run();
      for (size_t i = 0; i < 31; i++)
        state->regs[i] = j.GetRegister(i);
      state->regs[31] = j.GetSP();
      state->pc = j.GetPC();
      state->flags = j.GetPstate();
      state->fp_control = j.GetFpcr();
      state->fp_status = j.GetFpsr();
      for (size_t i = 0; i < 32; i++) {
        auto v = j.GetVector(i);
        state->vectors[i * 2] = v[0];
        state->vectors[i * 2 + 1] = v[1];
      }
    } else {
      auto &j = *c.a32;
      for (size_t i = 0; i < 16; i++)
        j.Regs()[i] = uint32_t(state->regs[i]);
      j.Regs()[15] = uint32_t(state->pc);
      j.SetCpsr(state->flags);
      j.SetFpscr(state->fp_control);
      for (size_t i = 0; i < 64; i++)
        j.ExtRegs()[i] = uint32_t(state->vectors[i]);
      j.ClearHalt();
      if (single_step)
        j.Step();
      else
        j.Run();
      for (size_t i = 0; i < 16; i++)
        state->regs[i] = j.Regs()[i];
      state->pc = j.Regs()[15];
      state->flags = j.Cpsr();
      state->fp_control = j.Fpscr();
      for (size_t i = 0; i < 64; i++)
        state->vectors[i] = j.ExtRegs()[i];
    }
    state->reason = c.reason ? c.reason : 1;
    state->svc = c.svc;
    state->ticks = c.used;
    return 0;
  } catch (const std::exception &e) {
    error(err, n, e.what());
    return -1;
  } catch (...) {
    error(err, n, "Dynarmic execution failed");
    return -1;
  }
}
extern "C" void kv_cpu_free(void *ptr) { delete static_cast<Cpu *>(ptr); }
extern "C" void kv_cpu_set_thread_pointer(void *ptr, uint64_t address) {
  if (ptr) {
    auto &cpu = *static_cast<Cpu *>(ptr);
    if (cpu.thread_pointer != address) {
      if (cpu.a32)
        cpu.a32->ClearExclusiveState();
      if (cpu.a64)
        cpu.a64->ClearExclusiveState();
    }
    cpu.thread_pointer = address;
    cpu.thread_pointer32 = static_cast<uint32_t>(address);
  }
}
extern "C" void kv_cpu_clear_cache(void *ptr) {
  if (!ptr)
    return;
  auto &c = *static_cast<Cpu *>(ptr);
  if (c.a32)
    c.a32->ClearCache();
  if (c.a64)
    c.a64->ClearCache();
}
