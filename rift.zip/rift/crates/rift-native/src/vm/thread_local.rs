//! Active guest ThreadLocal map; the scheduler owns each suspended thread's map.
use super::*;
const SUPPLIER: usize = usize::MAX - 74;
impl Runtime {
    pub(super) fn thread_local_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("ThreadLocal signature")?;
        if !self.subclass(class, "Ljava/lang/ThreadLocal;")? {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("ThreadLocal argument count");
        if method == "withInitial(Ljava/util/function/Supplier;)Ljava/lang/ThreadLocal;" {
            let supplier = arg(0)?;
            self.object(supplier)?;
            let id = self.instantiate("Ljava/lang/ThreadLocal;")?;
            self.object_mut(id)?
                .fields
                .insert(SUPPLIER, supplier as u64);
            return Ok(Some(id as u64));
        }
        let id = arg(0)?;
        if !self.subclass(&self.object(id)?.class, "Ljava/lang/ThreadLocal;")? {
            return Err("ThreadLocal receiver".into());
        }
        // Values belong to the running thread, keys are weak. Like Android's
        // ThreadLocalMap, stale keys are expunged on subsequent map operations.
        self.thread_local_values
            .retain(|key, _| self.heap.contains_key(key));
        match method {
            "<init>()V" => return Ok(Some(0)),
            "initialValue()Ljava/lang/Object;" => return Ok(Some(0)),
            "childValue(Ljava/lang/Object;)Ljava/lang/Object;"
                if self.subclass(class, "Ljava/lang/InheritableThreadLocal;")? =>
            {
                return Ok(Some(arg(1)? as u64));
            }
            "remove()V" => {
                self.thread_local_values.remove(&id);
                return Ok(Some(0));
            }
            "set(Ljava/lang/Object;)V" => {
                let value = arg(1)?;
                if value != 0 {
                    self.object(value)?;
                }
                self.set_thread_local_value(id, value)?;
                return Ok(Some(0));
            }
            "get()Ljava/lang/Object;" => {
                if let Some(value) = self.thread_local_values.get(&id) {
                    return Ok(Some(*value as u64));
                }
                let actual = self.object(id)?.class.clone();
                let supplier = self.object(id)?.fields.get(&SUPPLIER).copied().unwrap_or(0) as u32;
                let value = if supplier != 0 {
                    let supplier_class = self.object(supplier)?.class.clone();
                    let index = self
                        .dex
                        .find(&supplier_class, "get", "()Ljava/lang/Object;")
                        .ok_or("Supplier.get implementation absent")?;
                    self.invoke(index, &[supplier], true)? as u32
                } else if let Some(index) =
                    self.dex
                        .find(&actual, "initialValue", "()Ljava/lang/Object;")
                    && self.dex.bodies.contains_key(&index)
                {
                    self.invoke(index, &[id], true)? as u32
                } else {
                    0
                };
                if value != 0 {
                    self.object(value)?;
                }
                self.set_thread_local_value(id, value)?;
                return Ok(Some(value as u64));
            }
            _ => {}
        }
        Ok(None)
    }
    fn set_thread_local_value(&mut self, key: u32, value: u32) -> Result<()> {
        if !self.thread_local_values.contains_key(&key)
            && self.heap_bytes().saturating_add(48) > self.heap_limit
        {
            return Err("ThreadLocal memory quota".into());
        }
        if self.thread_local_values.len() >= 4096 && !self.thread_local_values.contains_key(&key) {
            return Err("ThreadLocal entry quota".into());
        }
        self.thread_local_values.insert(key, value);
        Ok(())
    }
}
