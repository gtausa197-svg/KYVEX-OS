//! Bounded Bionic allocations in guest pages, with no host pointers exposed.
use super::*;
use crate::memory::PAGE;

const BASE: u64 = elf::ADDRESS_LIMIT;
const LIMIT: u64 = 0x3f000000;
const ALIGNMENT: u64 = 16;
const MAX_BLOCKS: usize = 65536;
const ERRNO_OFFSET: u64 = 128;

fn align(value: u64, alignment: u64) -> Option<u64> {
    value
        .checked_add(alignment - 1)
        .map(|rounded| rounded & !(alignment - 1))
}

pub(super) fn overlaps(address: u64, bytes: u64) -> bool {
    bytes != 0 && address < LIMIT && address.checked_add(bytes).is_none_or(|end| end > BASE)
}

pub(super) struct Heap {
    frontier: u64,
    free: BTreeMap<u64, u64>,
    live: BTreeMap<u64, u64>,
}

impl Default for Heap {
    fn default() -> Self {
        Self {
            frontier: BASE,
            free: BTreeMap::new(),
            live: BTreeMap::new(),
        }
    }
}

impl Heap {
    fn allocate(&mut self, memory: &mut Memory, size: u64, alignment: u64) -> Option<u64> {
        if self.live.len() >= MAX_BLOCKS {
            return None;
        }
        let size = align(size.max(1), ALIGNMENT)?;
        let alignment = alignment.max(ALIGNMENT);
        if let Some((begin, start, end, limit)) = self.free.iter().find_map(|(&begin, &limit)| {
            let start = align(begin, alignment)?;
            let end = start.checked_add(size)?;
            (end <= limit).then_some((begin, start, end, limit))
        }) {
            self.free.remove(&begin);
            if start > begin {
                self.free.insert(begin, start);
            }
            if end < limit {
                self.free.insert(end, limit);
            }
            self.live.insert(start, end);
            return Some(start);
        }

        let start = align(self.frontier, alignment)?;
        let end = start.checked_add(size).filter(|end| *end <= LIMIT)?;
        self.extend(memory, end)?;
        if start > self.frontier {
            // Keep alignment padding available to smaller allocations.
            self.free.insert(self.frontier, start);
        }
        self.frontier = end;
        self.live.insert(start, end);
        Some(start)
    }

    fn extend(&self, memory: &mut Memory, end: u64) -> Option<()> {
        let old_end = align(self.frontier, PAGE)?;
        let new_end = align(end, PAGE)?;
        if new_end > old_end {
            memory
                .map(old_end, (new_end - old_end) as usize, READ | WRITE)
                .ok()?;
        }
        Some(())
    }

    fn release(&mut self, memory: &mut Memory, mut start: u64, mut end: u64) -> Result<()> {
        if let Some((&begin, &limit)) = self.free.range(..start).next_back()
            && limit == start
        {
            self.free.remove(&begin);
            start = begin;
        }
        if let Some(limit) = self.free.remove(&end) {
            end = limit;
        }
        if end == self.frontier {
            let old_end = align(end, PAGE).ok_or("Guest heap page overflow")?;
            let new_end = align(start, PAGE).ok_or("Guest heap page overflow")?;
            if new_end < old_end {
                memory.unmap(new_end, (old_end - new_end) as usize)?;
            }
            self.frontier = start;
        } else {
            self.free.insert(start, end);
        }
        Ok(())
    }

    fn deallocate(&mut self, memory: &mut Memory, address: u64) -> Result<()> {
        if address == 0 {
            return Ok(());
        }
        let end = self
            .live
            .remove(&address)
            .ok_or("Invalid guest free pointer")?;
        self.release(memory, address, end)
    }

    fn resize(&mut self, memory: &mut Memory, address: u64, size: u64) -> Result<Option<u64>> {
        if address == 0 {
            return Ok(self.allocate(memory, size, ALIGNMENT));
        }
        if size == 0 {
            self.deallocate(memory, address)?;
            return Ok(Some(0));
        }
        let old_end = *self
            .live
            .get(&address)
            .ok_or("Invalid guest realloc pointer")?;
        let Some(new_end) = align(size, ALIGNMENT).and_then(|bytes| address.checked_add(bytes))
        else {
            return Ok(None);
        };
        if new_end <= old_end {
            if new_end != old_end {
                self.release(memory, new_end, old_end)?;
                self.live.insert(address, new_end);
            }
            return Ok(Some(address));
        }
        if let Some(limit) = self
            .free
            .get(&old_end)
            .copied()
            .filter(|limit| *limit >= new_end)
        {
            self.free.remove(&old_end);
            if limit > new_end {
                self.free.insert(new_end, limit);
            }
            self.live.insert(address, new_end);
            return Ok(Some(address));
        }
        if old_end == self.frontier && new_end <= LIMIT && self.extend(memory, new_end).is_some() {
            self.frontier = new_end;
            self.live.insert(address, new_end);
            return Ok(Some(address));
        }
        let Some(replacement) = self.allocate(memory, size, ALIGNMENT) else {
            return Ok(None);
        };
        let copied = (|| -> Result<()> {
            let mut buffer = [0; PAGE as usize];
            let size = (old_end - address) as usize;
            for offset in (0..size).step_by(buffer.len()) {
                let count = (size - offset).min(buffer.len());
                memory.read(address + offset as u64, &mut buffer[..count], READ)?;
                memory.write(replacement + offset as u64, &buffer[..count])?;
            }
            Ok(())
        })();
        if let Err(error) = copied {
            self.deallocate(memory, replacement)?;
            return Err(error);
        }
        self.deallocate(memory, address)?;
        Ok(Some(replacement))
    }
}

impl Machine {
    fn guest_errno(&self) -> u64 {
        let tls = if self.current_tid == crate::identity::MAIN_TID {
            TLS
        } else {
            self.jni_env + PAGE
        };
        tls + ERRNO_OFFSET
    }

    pub(super) fn set_guest_errno(&mut self, errno: i32) -> Result<()> {
        let address = self.guest_errno();
        self.cpu.memory_mut().write(address, &errno.to_le_bytes())
    }

    fn allocation_failure(&mut self, errno: i32) -> Result<u64> {
        self.set_guest_errno(errno)?;
        Ok(0)
    }

    pub(super) fn heap_call(&mut self, function: &str, a: &[u64; 32]) -> Result<u64> {
        let result = match function {
            "__errno" => return Ok(self.guest_errno()),
            "malloc" => self.heap.allocate(self.cpu.memory_mut(), a[0], ALIGNMENT),
            "memalign" => {
                if !a[0].is_power_of_two() {
                    return self.allocation_failure(libc::EINVAL);
                }
                self.heap.allocate(self.cpu.memory_mut(), a[1], a[0])
            }
            "calloc" => {
                let Some(size) = a[0].checked_mul(a[1]) else {
                    return self.allocation_failure(libc::ENOMEM);
                };
                let memory = self.cpu.memory_mut();
                let allocated = self.heap.allocate(memory, size, ALIGNMENT);
                if let Some(address) = allocated {
                    memory.fill(address, size as usize, 0)?;
                }
                allocated
            }
            "realloc" => self.heap.resize(self.cpu.memory_mut(), a[0], a[1])?,
            "free" => {
                self.heap.deallocate(self.cpu.memory_mut(), a[0])?;
                return Ok(0);
            }
            "malloc_usable_size" => {
                return Ok(self.heap.live.get(&a[0]).map_or(0, |end| end - a[0]));
            }
            _ => return Err("Unknown guest heap call".into()),
        };
        match result {
            Some(address) => Ok(address),
            None => self.allocation_failure(libc::ENOMEM),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reuses_holes_keeps_alignment_and_releases_empty_pages() {
        let mut memory = Memory::new(8 * PAGE as usize);
        let mut heap = Heap::default();
        let first = heap.allocate(&mut memory, 7, ALIGNMENT).unwrap();
        let aligned = heap.allocate(&mut memory, 11, PAGE).unwrap();
        assert_eq!(aligned % PAGE, 0);
        let adjacent = heap.allocate(&mut memory, 63, ALIGNMENT).unwrap();
        assert_eq!(adjacent, first + 16);
        heap.deallocate(&mut memory, first).unwrap();
        heap.deallocate(&mut memory, adjacent).unwrap();
        let next = heap.allocate(&mut memory, 64, ALIGNMENT).unwrap();
        assert_eq!(next, first);
        heap.deallocate(&mut memory, aligned).unwrap();
        heap.deallocate(&mut memory, next).unwrap();
        assert_eq!(memory.mapped(), 0);
        assert!(heap.free.is_empty());
        assert!(heap.deallocate(&mut memory, next).is_err());
    }

    #[test]
    fn growth_preserves_contents_and_failed_growth_keeps_original_allocation() {
        let mut memory = Memory::new(3 * PAGE as usize);
        let mut heap = Heap::default();
        let old = heap.allocate(&mut memory, 36, ALIGNMENT).unwrap();
        let blocker = heap.allocate(&mut memory, 48, ALIGNMENT).unwrap();
        memory.write(old, &[0xa5; 36]).unwrap();
        assert_eq!(heap.resize(&mut memory, old, u64::MAX).unwrap(), None);
        assert_eq!(memory.bytes(old, 36).unwrap(), [0xa5; 36]);
        let next = heap.resize(&mut memory, old, 200).unwrap().unwrap();
        assert_ne!(next, old);
        assert_eq!(memory.bytes(next, 36).unwrap(), [0xa5; 36]);
        assert!(heap.deallocate(&mut memory, old).is_err());
        assert_eq!(heap.resize(&mut memory, next, 1).unwrap(), Some(next));
        assert_eq!(heap.resize(&mut memory, next, 0).unwrap(), Some(0));
        heap.deallocate(&mut memory, blocker).unwrap();
        assert_eq!(memory.mapped(), 0);
    }
}
