package org.kyvex.extra;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public final class StorageChecks {
    private static int checks;

    private static void check(boolean ok, String label) {
        if (!ok) throw new IllegalStateException(label);
        checks++;
    }

    private static int read(Context context) throws IOException {
        FileInputStream stream = context.openFileInput("same.bin");
        try {
            return stream.read();
        } finally {
            stream.close();
        }
    }

    private static void write(Context context, int value) throws IOException {
        FileOutputStream stream = context.openFileOutput("same.bin", 0);
        try {
            stream.write(value);
        } finally {
            stream.close();
        }
    }

    private static final class Helper extends SQLiteOpenHelper {
        private final int marker;
        Helper(Context context, int marker) {
            super(context, "same.db", null, 1);
            this.marker = marker;
        }

        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE test(marker INTEGER)");
            db.execSQL("INSERT INTO test VALUES(?)", new Object[]{marker});
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            throw new IllegalStateException("Unexpected database upgrade");
        }

        int read() {
            Cursor cursor = getReadableDatabase().rawQuery("SELECT marker FROM test", null);
            try {
                if (!cursor.moveToFirst()) throw new IllegalStateException("Missing database marker");
                return cursor.getInt(0);
            } finally {
                cursor.close();
            }
        }
    }

    public static String verify(Context context) {
        checks = 0;
        Context device = context.createDeviceProtectedStorageContext();
        Context second = device.createDeviceProtectedStorageContext();
        Context ordinary = device.createCredentialProtectedStorageContext();
        Context wrapper = new ContextWrapper(device);
        check(device != context && second != device && ordinary != context, "Fresh storage contexts");
        check(device.isDeviceProtectedStorage() && wrapper.isDeviceProtectedStorage(), "Device flag follows wrapper base");
        check(!context.isDeviceProtectedStorage() && ordinary.isCredentialProtectedStorage(), "Ordinary storage flag");
        check(context.getPackageName().equals(device.getPackageName()), "Package identity retained");
        check(context.getApplicationContext() == device.getApplicationContext(), "Application identity retained");
        check(device.getDataDir().getPath().startsWith("/data/user_de/0/"), "Device storage root");
        check(context.getDataDir().equals(ordinary.getDataDir()), "Ordinary storage root retained");
        check(wrapper.getFilesDir().equals(second.getFilesDir()), "Same device files across contexts");
        check(!context.getCacheDir().equals(device.getCacheDir()), "Separate cache paths");
        check(context.getExternalCacheDir().equals(device.getExternalCacheDir()), "Same emulated external volume");
        try {
            write(device, 71);
            check(!context.getFileStreamPath("same.bin").exists(), "No ordinary copy of device file");
            write(context, 19);
            check(read(wrapper) == 71 && read(ordinary) == 19, "Same name and distinct file contents");
            check(device.deleteFile("same.bin") && read(context) == 19, "Device deletion leaves ordinary file");
        } catch (IOException error) {
            throw new IllegalStateException("Private file operation failed", error);
        }
        check(!context.getDatabasePath("same.db").equals(device.getDatabasePath("same.db")), "Separate database paths");
        Helper ordinaryDb = new Helper(context, 11);
        Helper deviceDb = new Helper(device, 23);
        try {
            check(ordinaryDb.read() == 11 && deviceDb.read() == 23, "Separate databases open concurrently");
            check(deviceDb.getWritableDatabase().getPath().equals(wrapper.getDatabasePath("same.db").getPath()), "SQLite helper uses device root");
        } finally {
            ordinaryDb.close();
            deviceDb.close();
        }

        SharedPreferences normalPrefs = context.getSharedPreferences("same", 0);
        SharedPreferences devicePrefs = device.getSharedPreferences("same", 0);
        check(devicePrefs != normalPrefs, "Separate preference handles");
        check(wrapper.getSharedPreferences("same", 0) == devicePrefs, "Same device preferences through wrapper");
        int ordinaryLaunch = normalPrefs.getInt("launch", 0);
        int deviceLaunch = devicePrefs.getInt("launch", 0);
        check(ordinaryLaunch * 3 == deviceLaunch, "Both namespaces reloaded independently");
        check(normalPrefs.edit().putInt("launch", ordinaryLaunch + 1).commit(), "Ordinary journal commit");
        check(devicePrefs.edit().putInt("launch", deviceLaunch + 3).commit(), "Device journal commit");
        System.gc();
        check(ordinary.getSharedPreferences("same", 0).getInt("launch", 0) == ordinaryLaunch + 1, "Ordinary value retained after collection");
        check(second.getSharedPreferences("same", 0).getInt("launch", 0) == deviceLaunch + 3, "Device value retained after collection");
        return checks + " / launch " + (ordinaryLaunch + 1);
    }
}
