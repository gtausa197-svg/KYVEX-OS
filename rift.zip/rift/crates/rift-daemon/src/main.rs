mod native;
use rift_core::{
    Result,
    apk::{self, Apk},
    dex,
    input::{Engine, Profile, Touch},
};
use rusqlite::{Connection, params};
use serde_json::{Value, json};
use std::{
    fs::{self, File, OpenOptions},
    io::{BufRead, BufReader, Read, Write},
    os::{
        fd::AsRawFd,
        unix::{
            fs::{MetadataExt, PermissionsExt},
            net::{UnixListener, UnixStream},
        },
    },
    path::{Path, PathBuf},
    sync::{
        Arc, Mutex,
        atomic::{AtomicU64, AtomicUsize, Ordering},
    },
    thread,
    time::{Duration, Instant},
};
static NEXT: AtomicU64 = AtomicU64::new(1);
struct State {
    input: Engine,
    error: String,
    manual: std::collections::BTreeMap<u64, Touch>,
    owner: String,
}
struct Service {
    home: PathBuf,
    state: Mutex<State>,
    native: Mutex<Option<native::Session>>,
    started: Instant,
}
impl Service {
    fn db(&self) -> Result<Connection> {
        let c = Connection::open(self.home.join("library.sqlite"))?;
        c.busy_timeout(Duration::from_secs(5))?;
        c.execute_batch("PRAGMA journal_mode=WAL;CREATE TABLE IF NOT EXISTS apps(package TEXT PRIMARY KEY,metadata TEXT NOT NULL);CREATE TABLE IF NOT EXISTS profiles(package TEXT PRIMARY KEY,data TEXT NOT NULL);")?;
        Ok(c)
    }
    fn get(&self, package: &str) -> Result<Apk> {
        if !apk::package_valid(package) {
            return Err("Invalid package".into());
        }
        let text: String = self.db()?.query_row(
            "SELECT metadata FROM apps WHERE package=?1",
            [package],
            |r| r.get(0),
        )?;
        Ok(serde_json::from_str(&text)?)
    }
    fn profile(&self, p: &str) -> Result<Profile> {
        if !apk::package_valid(p) {
            return Err("Invalid package".into());
        }
        let text = self
            .db()?
            .query_row("SELECT data FROM profiles WHERE package=?1", [p], |r| {
                r.get::<_, String>(0)
            });
        Ok(match text {
            Ok(t) => {
                let mut value: Value = serde_json::from_str(&t)?;
                if value["backend"] == "compatibility" || value.get("backend").is_none() {
                    value["backend"] = json!("native");
                    if matches!(value["abi"].as_str(), Some("x86" | "x86_64")) {
                        value["abi"] = json!("auto");
                    }
                }
                let profile: Profile = serde_json::from_value(value)?;
                profile.validate()?;
                self.db()?.execute(
                    "UPDATE profiles SET data=?2 WHERE package=?1",
                    params![p, serde_json::to_string(&profile)?],
                )?;
                profile
            }
            Err(rusqlite::Error::QueryReturnedNoRows) => Profile::default_for(p),
            Err(e) => return Err(e.into()),
        })
    }
    fn release(state: &mut State) -> Vec<Touch> {
        let mut e = state.input.release();
        for mut t in std::mem::take(&mut state.manual).into_values() {
            t.action = "up".into();
            e.push(t);
        }
        e
    }
    fn request(&self, r: &Value) -> Result<Value> {
        let method = r["method"].as_str().ok_or("Method required")?;
        let p = &r["params"];
        let package = p["package"].as_str().unwrap_or("org.kyvex.test");
        let owner = r["client_id"].as_str().unwrap_or("cli");
        if owner.len() > 80 {
            return Err("Client identifier limit".into());
        }
        if matches!(
            method,
            "input" | "aim" | "touch" | "heartbeat" | "release" | "disconnect"
        ) {
            let s = self.state.lock().unwrap();
            if !s.owner.is_empty() && s.owner != owner {
                return Err("Another Rift client owns this input session; open a new session to take control".into());
            }
        }
        match method {
            "status" => {
                // This flag labels temporary Live data in Studio. Installation
                // authorization uses the separate, stricter OS Live probe.
                let live = Path::new("/run/archiso/bootmnt/arch/x86_64/airootfs.sfs").is_file()
                    && fs::read_to_string("/proc/self/mountinfo").is_ok_and(|mounts| {
                        mounts.contains(" - overlay airootfs ")
                            && mounts.contains("lowerdir=/run/archiso/airootfs")
                    });
                let (connected, error) = {
                    let s = self.state.lock().unwrap();
                    (false, s.error.clone())
                };
                Ok(
                    json!({"engine":"KYVEX Rift 0.3.0","protocol":1,"backend":"native","native":"Rust DEX/JNI/UI runtime with Dynarmic ARM32/ARM64. Experimental; unsupported APIs are reported. No Android container backend.","native_session":self.native.lock().unwrap().as_mut().map(|s|s.status()),"input_connected":connected,"input_error":error,"runtime":{"backend":"native","live":live,"requires_android_image":false,"full_android_framework":false},"data":self.home,"uptime_seconds":self.started.elapsed().as_secs()}),
                )
            }
            "list" => {
                let c = self.db()?;
                let mut q = c.prepare("SELECT metadata FROM apps ORDER BY package")?;
                let records = q.query_map([], |r| r.get::<_, String>(0))?;
                let mut apps = Vec::new();
                for v in records {
                    apps.push(serde_json::from_str::<Value>(&v?)?)
                }
                Ok(json!(apps))
            }
            "inspect" => Ok(serde_json::to_value(apk::inspect(Path::new(
                p["path"].as_str().ok_or("Choose an APK")?,
            ))?)?),
            "native-demo" | "native-advanced" => {
                let path = if method == "native-advanced" {
                    "/usr/share/kyvex/rift/samples/rift-native-advanced.apk"
                } else {
                    "/usr/share/kyvex/rift/samples/rift-native-demo.apk"
                };
                let app = self.request(
                    &json!({"method":"import","client_id":owner,"params":{"path":path}}),
                )?;
                let package = app["package"].as_str().ok_or("Demo package metadata")?;
                let mut profile = Profile::default_for(package);
                profile.backend = "native".into();
                self.request(&json!({"method":"save-profile","client_id":owner,"params":profile}))?;
                self.request(
                    &json!({"method":"launch","client_id":owner,"params":{"package":package}}),
                )
            }
            "import" => {
                let path = Path::new(p["path"].as_str().ok_or("Choose an APK")?).canonicalize()?;
                let mut f = File::open(path)?;
                if !f.metadata()?.is_file() || f.metadata()?.len() > 2 * 1024 * 1024 * 1024 {
                    return Err("APK exceeds import size limit".into());
                }
                let temp = self.home.join("packages").join(format!(
                    "import-{}-{}.tmp",
                    std::process::id(),
                    NEXT.fetch_add(1, Ordering::Relaxed)
                ));
                let result = (|| -> Result<Apk> {
                    let mut dest = OpenOptions::new()
                        .write(true)
                        .create_new(true)
                        .open(&temp)?;
                    fs::set_permissions(&temp, fs::Permissions::from_mode(0o600))?;
                    let n = std::io::copy(
                        &mut std::io::Read::by_ref(&mut f).take(2 * 1024 * 1024 * 1024 + 1),
                        &mut dest,
                    )?;
                    if n > 2 * 1024 * 1024 * 1024 {
                        return Err("APK import limit".into());
                    }
                    dest.sync_all()?;
                    drop(dest);
                    let info = apk::inspect(&temp)?;
                    let target = self
                        .home
                        .join("packages")
                        .join(format!("{}.apk", info.sha256));
                    fs::rename(&temp, &target)?;
                    self.db()?.execute("INSERT INTO apps(package,metadata) VALUES(?1,?2) ON CONFLICT(package) DO UPDATE SET metadata=excluded.metadata",params![info.package,serde_json::to_string(&info)?])?;
                    Ok(info)
                })();
                let _ = fs::remove_file(&temp);
                Ok(serde_json::to_value(result?)?)
            }
            "remove" => {
                let app = self.get(package)?;
                {
                    let mut active = self.native.lock().unwrap();
                    if active.as_ref().is_some_and(|s| s.package == package) {
                        active.take();
                    }
                }
                self.db()?
                    .execute("DELETE FROM apps WHERE package=?1", [package])?;
                let used: i64 = self.db()?.query_row(
                    "SELECT count(*) FROM apps WHERE metadata LIKE ?1",
                    [format!("%{}%", app.sha256)],
                    |r| r.get(0),
                )?;
                if used == 0 {
                    fs::remove_file(
                        self.home
                            .join("packages")
                            .join(format!("{}.apk", app.sha256)),
                    )?;
                }
                Ok(json!({"removed":package,"profile_retained":true}))
            }
            "launch" => {
                let app = self.get(package)?;
                let path = self
                    .home
                    .join("packages")
                    .join(format!("{}.apk", app.sha256));
                if app.launcher.is_empty() {
                    return Err("This APK has no launcher activity".into());
                }
                let profile = self.profile(package)?;
                profile.validate()?;
                if profile.abi != "auto" && !app.abis.is_empty() && !app.abis.contains(&profile.abi)
                {
                    return Err("This APK does not contain the selected architecture; choose Auto in Game Controls".into());
                }
                let mut active = self.native.lock().unwrap();
                active.take();
                let (session, value) = native::Session::start(
                    &path,
                    &profile.abi,
                    &profile.native_memory,
                    owner,
                    package,
                    NEXT.fetch_add(1, Ordering::Relaxed),
                )?;
                *active = Some(session);
                Ok(value)
            }
            "native-event" | "native-tick" => {
                let id = p["session"].as_u64().ok_or("Native session required")?;
                let request = if method == "native-event" {
                    let widget = u32::try_from(p["widget"].as_u64().ok_or("Widget required")?)?;
                    json!({"method":"click","id":widget})
                } else {
                    json!({"method":"tick"})
                };
                let mut active = self.native.lock().unwrap();
                let session = active.as_mut().ok_or("Native application is not running")?;
                session.authorized(owner, id)?;
                let result = session.request(request);
                if result.is_err() {
                    active.take();
                }
                result
            }
            "native-close" => {
                let id = p["session"].as_u64().ok_or("Native session required")?;
                let mut active = self.native.lock().unwrap();
                if let Some(s) = active.as_ref() {
                    s.authorized(owner, id)?;
                }
                active.take();
                Ok(json!({"closed":true}))
            }
            "stop-app" => {
                self.get(package)?;
                {
                    let mut active = self.native.lock().unwrap();
                    if active.as_ref().is_some_and(|s| s.package == package) {
                        active.take();
                        return Ok(json!({"stopped":package,"backend":"native"}));
                    }
                }
                Ok(json!({"stopped":package,"backend":"native"}))
            }
            "profile" => Ok(serde_json::to_value(self.profile(package)?)?),
            "save-profile" => {
                let profile: Profile = serde_json::from_value(p.clone())?;
                profile.validate()?;
                self.db()?.execute("INSERT INTO profiles(package,data)VALUES(?1,?2) ON CONFLICT(package)DO UPDATE SET data=excluded.data",params![profile.package,serde_json::to_string(&profile)?])?;
                Ok(json!({"saved":true}))
            }
            "session" => {
                let profile = self.profile(package)?;
                profile.validate()?;
                if p["android"].as_bool().unwrap_or(false) {
                    return Err("External Android input backend was removed. Native currently supports UI button events; use Test scene for mapping experiments.".into());
                }
                let mut s = self.state.lock().unwrap();
                Self::release(&mut s);
                s.owner = owner.into();
                s.input = Engine::new(profile);
                s.input.now = self.started.elapsed().as_millis() as u64;
                s.input.last_heartbeat = s.input.now;
                s.error.clear();
                Ok(json!({"connected":false,"display":null}))
            }
            "disconnect" => {
                let mut s = self.state.lock().unwrap();
                Self::release(&mut s);
                Ok(json!({"released":true}))
            }
            "input" => {
                let key = p["key"].as_str().ok_or("Key required")?;
                if key.len() > 32 {
                    return Err("Key length".into());
                }
                let down = p["down"].as_bool().ok_or("Key state required")?;
                let mut s = self.state.lock().unwrap();
                let e = s.input.event(key, down);

                Ok(json!(e))
            }
            "aim" => {
                let dx = p["dx"].as_f64().ok_or("Delta required")?;
                let dy = p["dy"].as_f64().ok_or("Delta required")?;
                let mut s = self.state.lock().unwrap();
                let e = s.input.aim(dx, dy);

                Ok(json!(e))
            }
            "touch" => {
                let t: Touch = serde_json::from_value(p.clone())?;
                if !(90..=99).contains(&t.pointer)
                    || !matches!(t.action.as_str(), "down" | "move" | "up")
                    || ![t.x, t.y]
                        .iter()
                        .all(|v| v.is_finite() && (0.0..=1.0).contains(v))
                {
                    return Err("Invalid touch".into());
                }
                let mut s = self.state.lock().unwrap();
                if t.action == "up" {
                    s.manual.remove(&t.pointer);
                } else {
                    s.manual.insert(t.pointer, t.clone());
                }
                s.input.last_heartbeat = self.started.elapsed().as_millis() as u64;
                Ok(json!({"sent":true}))
            }
            "heartbeat" => {
                let mut s = self.state.lock().unwrap();
                s.input.last_heartbeat = self.started.elapsed().as_millis() as u64;
                let mut contacts = s.input.contacts();
                contacts.extend(s.manual.values().cloned());
                Ok(
                    json!({"contacts":contacts,"trace":s.input.trace,"connected":false,"error":s.error}),
                )
            }
            "release" => {
                let mut s = self.state.lock().unwrap();
                let e = Self::release(&mut s);

                Ok(json!(e))
            }
            "native-test" => Ok(
                json!({"result":dex::self_test()?,"runtime":"Rift experimental DEX register interpreter","supported":"integer constants, move, arithmetic, goto, return; bounded instruction budget","android_apk_supported":false}),
            ),
            "input-state" => {
                let s = self.state.lock().unwrap();
                Ok(
                    json!({"contacts":s.input.contacts(),"trace":s.input.trace,"pressed":s.input.pressed(),"profile":s.input.profile,"connected":false,"error":s.error}),
                )
            }
            _ => Err("Unknown Rift API method".into()),
        }
    }
}
fn socket_path() -> Result<PathBuf> {
    let uid = unsafe { libc::getuid() };
    let p = PathBuf::from(format!("/run/user/{uid}"));
    let m = p.metadata()?;
    if m.uid() != uid || m.permissions().mode() & 0o077 != 0 {
        return Err("User runtime directory must be private".into());
    }
    Ok(p.join("kyvex-rift.sock"))
}
fn same_user(s: &UnixStream) -> bool {
    unsafe {
        let mut c: libc::ucred = std::mem::zeroed();
        let mut n = std::mem::size_of::<libc::ucred>() as libc::socklen_t;
        libc::getsockopt(
            s.as_raw_fd(),
            libc::SOL_SOCKET,
            libc::SO_PEERCRED,
            &mut c as *mut _ as *mut _,
            &mut n,
        ) == 0
            && c.uid == libc::getuid()
    }
}
fn main() -> Result<()> {
    if unsafe { libc::geteuid() } == 0 {
        return Err("Rift runs as your desktop user, never root".into());
    }
    unsafe { libc::umask(0o077) };
    let args: Vec<String> = std::env::args().skip(1).collect();
    let socket = socket_path()?;
    if args.first().is_some_and(|s| s == "--request") {
        let request = args.get(1).ok_or("JSON request required")?;
        let mut s = UnixStream::connect(socket)?;
        s.write_all(request.as_bytes())?;
        s.write_all(b"\n")?;
        let mut out = String::new();
        BufReader::new(s).read_line(&mut out)?;
        print!("{out}");
        return Ok(());
    }
    if socket.exists() {
        if UnixStream::connect(&socket).is_ok() {
            return Ok(());
        }
        fs::remove_file(&socket)?;
    }
    let listener = UnixListener::bind(&socket)?;
    fs::set_permissions(&socket, fs::Permissions::from_mode(0o600))?;
    let base = std::env::var_os("XDG_DATA_HOME")
        .map(PathBuf::from)
        .unwrap_or(
            PathBuf::from(std::env::var_os("HOME").ok_or("HOME required")?).join(".local/share"),
        );
    let home = base.join("kyvex/rift");
    fs::create_dir_all(home.join("packages"))?;
    fs::create_dir_all(home.join("logs"))?;
    let service = Arc::new(Service {
        home,
        native: Mutex::new(None),
        state: Mutex::new(State {
            input: Engine::new(Profile::default_for("org.kyvex.test")),
            error: String::new(),
            manual: Default::default(),
            owner: String::new(),
        }),
        started: Instant::now(),
    });
    service.db()?;
    let tick = Arc::clone(&service);
    thread::spawn(move || {
        loop {
            thread::sleep(Duration::from_millis(16));
            let mut s = tick.state.lock().unwrap();
            let ms = tick.started.elapsed().as_millis() as u64;
            s.input.tick(ms);
            if ms.saturating_sub(s.input.last_heartbeat) > 1800 {
                Service::release(&mut s);
            }
        }
    });
    let inflight = Arc::new(AtomicUsize::new(0));
    for connection in listener.incoming() {
        let Ok(mut socket) = connection else { continue };
        if !same_user(&socket) {
            continue;
        }
        if inflight.fetch_add(1, Ordering::SeqCst) >= 16 {
            inflight.fetch_sub(1, Ordering::SeqCst);
            continue;
        }
        let service = Arc::clone(&service);
        let pending = Arc::clone(&inflight);
        thread::spawn(move || {
            let _ = socket.set_read_timeout(Some(Duration::from_secs(3)));
            let result = (|| -> Result<Value> {
                let mut b = Vec::new();
                let n = BufReader::new(socket.try_clone()?)
                    .take(262145)
                    .read_until(b'\n', &mut b)?;
                if n > 262144 || b.last() != Some(&b'\n') {
                    return Err("IPC request size or framing error".into());
                }
                let request: Value = serde_json::from_slice(&b)?;
                if request["version"].as_u64() != Some(1) {
                    return Err("Unsupported Rift protocol version".into());
                }
                service.request(&request)
            })();
            let response = match result {
                Ok(data) => json!({"ok":true,"version":1,"data":data}),
                Err(e) => json!({"ok":false,"version":1,"error":e.to_string()}),
            };
            let _ = socket.set_write_timeout(Some(Duration::from_secs(2)));
            let _ = writeln!(socket, "{response}");
            pending.fetch_sub(1, Ordering::SeqCst);
        });
    }
    Ok(())
}
