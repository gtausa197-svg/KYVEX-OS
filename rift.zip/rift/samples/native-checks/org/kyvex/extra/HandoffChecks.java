package org.kyvex.extra;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.function.Predicate;
import java.util.function.Supplier;

/** Real Java 8 code shared by the reference process and both Native ABIs. */
public final class HandoffChecks {
    private static int checks;
    private static final long LIMIT = 3;
    private static final TimeUnit SECONDS = TimeUnit.SECONDS;
    private static final TimeUnit MILLIS = TimeUnit.MILLISECONDS;

    private static void check(boolean ok, String message) {
        if (!ok) throw new IllegalStateException(message);
        checks++;
    }

    private static void waitFor(Thread thread, Thread.State state) throws InterruptedException {
        long deadline = System.nanoTime() + SECONDS.toNanos(LIMIT);
        while (thread.isAlive() && thread.getState() != state && System.nanoTime() < deadline) {
            Thread.sleep(1);
        }
        if (thread.getState() != state) throw new IllegalStateException("Unexpected thread state");
    }

    private static void join(Thread thread) throws InterruptedException {
        thread.join(SECONDS.toMillis(LIMIT));
        if (thread.isAlive()) throw new IllegalStateException("Thread failed to finish");
    }

    static final class Receiver extends Thread {
        final SynchronousQueue<Object> queue;
        Object value;
        boolean interrupted;

        Receiver(SynchronousQueue<Object> queue) {
            this.queue = queue;
            setDaemon(true);
        }
        public void run() {
            try { value = queue.take(); }
            catch (InterruptedException expected) { interrupted = !isInterrupted(); }
        }
    }

    private static final class Sender extends Thread {
        final SynchronousQueue<Object> queue;
        final Object value;
        boolean sent;

        Sender(SynchronousQueue<Object> queue, Object value) {
            this.queue = queue;
            this.value = value;
            setDaemon(true);
        }
        public void run() {
            try { queue.put(value); sent = true; }
            catch (InterruptedException unexpected) { throw new IllegalStateException(unexpected); }
        }
    }

    private static void queue() throws InterruptedException {
        SynchronousQueue<Object> queue = new SynchronousQueue<Object>(true);
        Object a = new Object();
        Object b = new Object();
        check(queue.size() == 0 && queue.isEmpty() && queue.remainingCapacity() == 0,
                "SynchronousQueue stores no elements");
        check(!queue.offer(a) && queue.poll() == null && queue.peek() == null,
                "Nonblocking operations fail without a partner");
        Object[] target = new Object[]{a, b};
        check(queue.toArray().length == 0 && queue.toArray(target) == target
                && target[0] == null && target[1] == b && !queue.iterator().hasNext(),
                "Empty collection views and typed array terminator");
        boolean rejected = false;
        try { queue.offer(null); } catch (NullPointerException expected) { rejected = true; }
        check(rejected, "Null handoffs are rejected");
        rejected = false;
        try { queue.add(a); } catch (IllegalStateException expected) { rejected = true; }
        check(rejected, "add reports the absence of capacity");

        long start = System.nanoTime();
        check(!queue.offer(a, 12, MILLIS) && System.nanoTime() - start >= MILLIS.toNanos(12),
                "Timed offer expires without transferring its value");
        start = System.nanoTime();
        check(queue.poll(12, MILLIS) == null && System.nanoTime() - start >= MILLIS.toNanos(12),
                "Timed poll expires without fabricating a value");
        check(!queue.offer(a, -1, MILLIS) && queue.poll(0, SECONDS) == null,
                "Nonpositive timeout is immediate");

        Receiver first = new Receiver(queue);
        Receiver second = new Receiver(queue);
        first.start();
        waitFor(first, Thread.State.WAITING);
        second.start();
        waitFor(second, Thread.State.WAITING);
        check(queue.offer(a) && queue.offer(b), "Each offer matches a different waiting receiver");
        join(first);
        join(second);
        check(first.value == a && second.value == b, "Fair waiters receive their original values in order");

        Sender sender = new Sender(queue, a);
        sender.start();
        waitFor(sender, Thread.State.WAITING);
        check(queue.isEmpty() && queue.peek() == null && !queue.contains(a),
                "A blocked producer does not fill the collection");
        check(queue.poll(LIMIT, SECONDS) == a, "Poll claims a blocked producer's object");
        join(sender);
        check(sender.sent, "The producer resumes after a match");

        Sender drainA = new Sender(queue, a);
        Sender drainB = new Sender(queue, b);
        drainA.start();
        waitFor(drainA, Thread.State.WAITING);
        drainB.start();
        waitFor(drainB, Thread.State.WAITING);
        ArrayList<Object> drained = new ArrayList<Object>();
        check(queue.drainTo(drained, 1) == 1 && drained.size() == 1 && drained.get(0) == a,
                "Bounded drain transfers only the first waiting sender");
        check(queue.take() == b, "Remaining sender is still waiting");
        join(drainA);
        join(drainB);

        Receiver interrupted = new Receiver(queue);
        interrupted.start();
        waitFor(interrupted, Thread.State.WAITING);
        interrupted.interrupt();
        join(interrupted);
        check(interrupted.interrupted && interrupted.value == null && !queue.offer(a),
                "Interrupt clears the flag and withdraws the unmatched receiver");
    }

    private static final class Factory implements ThreadFactory {
        final Thread[] made = new Thread[3];
        int count;
        public Thread newThread(Runnable target) {
            Thread thread = new Thread(target, "rift-cache-worker");
            made[count++] = thread;
            return thread;
        }
    }

    private static void cachedPool() throws InterruptedException {
        boolean rejected = false;
        try { Executors.newCachedThreadPool((ThreadFactory) null); }
        catch (NullPointerException expected) { rejected = true; }
        check(rejected, "Cached factory rejects null ThreadFactory");
        ThreadPoolExecutor defaults = (ThreadPoolExecutor) Executors.newCachedThreadPool();
        check(defaults.getCorePoolSize() == 0 && defaults.getMaximumPoolSize() == Integer.MAX_VALUE
                && defaults.getKeepAliveTime(SECONDS) == 60
                && defaults.getQueue() instanceof SynchronousQueue,
                "Cached factory starts with the standard zero-capacity configuration");
        defaults.shutdown();
        check(defaults.isTerminated(), "An unused pool terminates");

        Factory factory = new Factory();
        ThreadPoolExecutor pool = (ThreadPoolExecutor) Executors.newCachedThreadPool(factory);
        final CountDownLatch entered = new CountDownLatch(2);
        final CountDownLatch release = new CountDownLatch(1);
        final Runnable busy = new Runnable() {
            public void run() {
                entered.countDown();
                try { release.await(); }
                catch (InterruptedException expected) { throw new IllegalStateException(expected); }
            }
        };
        try {
            pool.execute(busy);
            pool.execute(busy);
            check(entered.await(LIMIT, SECONDS) && factory.count == 2 && pool.getPoolSize() == 2
                    && pool.getQueue().isEmpty(), "Busy workers trigger new workers instead of a backlog");
            release.countDown();
            waitFor(factory.made[0], Thread.State.TIMED_WAITING);
            waitFor(factory.made[1], Thread.State.TIMED_WAITING);
            final CountDownLatch ran = new CountDownLatch(2);
            Runnable task = new Runnable() {
                public void run() { ran.countDown(); }
            };
            pool.execute(task);
            check(pool.getQueue().offer(task), "The exposed queue hands work directly to an idle worker");
            check(ran.await(LIMIT, SECONDS) && factory.count == 2 && pool.getLargestPoolSize() == 2,
                    "The two existing workers execute both handoffs");
            waitFor(factory.made[0], Thread.State.TIMED_WAITING);
            waitFor(factory.made[1], Thread.State.TIMED_WAITING);
            pool.setKeepAliveTime(20, MILLIS);
            join(factory.made[0]);
            join(factory.made[1]);
            check(pool.getPoolSize() == 0 && pool.getCompletedTaskCount() == 4,
                    "Idle workers expire after real completed work");
        } finally {
            release.countDown();
            pool.shutdownNow();
            check(pool.awaitTermination(LIMIT, SECONDS), "Cached pool terminates");
        }
        rejected = false;
        try { pool.execute(busy); } catch (RejectedExecutionException expected) { rejected = true; }
        check(rejected, "Shutdown pool rejects new work");
    }

    private static void primitiveAndNullChecks() {
        long wide = 0x12345678abcdef12L;
        check(Math.abs(-wide) == wide && Math.abs(Long.MIN_VALUE) == Long.MIN_VALUE,
                "Long abs preserves both words and Java overflow");
        check(StrictMath.min(-wide, wide) == -wide && Math.max(-wide, wide) == wide,
                "Signed long comparisons preserve the wide result");
        check(1.0 / Math.abs(-0.0) == Double.POSITIVE_INFINITY
                && Math.abs(Float.NEGATIVE_INFINITY) == Float.POSITIVE_INFINITY
                && Math.abs(-Double.MIN_VALUE) == Double.MIN_VALUE, "IEEE absolute values");
        double nan = StrictMath.abs(Double.NaN);
        check(nan != nan && Math.abs(Integer.MIN_VALUE) == Integer.MIN_VALUE, "NaN and integer overflow");

        final Object value = new Object();
        final String detail = "required detail";
        final int[] calls = new int[1];
        Supplier<String> supplier = new Supplier<String>() {
            public String get() { calls[0]++; return detail; }
        };
        check(Objects.requireNonNull(value) == value && Objects.requireNonNull(value, supplier) == value
                && calls[0] == 0, "Identity is preserved without invoking a supplier");
        try { Objects.requireNonNull(null); throw new IllegalStateException("Expected null check"); }
        catch (NullPointerException expected) { check(expected.getMessage() == null, "No detail is invented"); }
        try { Objects.requireNonNull(null, detail); throw new IllegalStateException("Expected null check"); }
        catch (NullPointerException expected) { check(expected.getMessage() == detail, "Original detail String"); }
        try { Objects.requireNonNull(null, supplier); throw new IllegalStateException("Expected null check"); }
        catch (NullPointerException expected) {
            check(expected.getMessage() == detail && calls[0] == 1, "Actual lazy supplier detail");
        }
    }

    private static void removeIf() {
        final Object a = new Object();
        final Object b = new Object();
        final Object c = new Object();
        final ArrayList<Object> list = new ArrayList<Object>();
        list.add(a);
        list.add(b);
        list.add(null);
        Iterator<Object> old = list.iterator();
        final int[] visits = new int[1];
        check(list.removeIf(new Predicate<Object>() {
            public boolean test(Object value) {
                visits[0]++;
                if (value == a) list.set(1, c);
                return value == c || value == null;
            }
        }) && visits[0] == 3 && list.size() == 1 && list.get(0) == a,
                "Predicate sees current values and preserves surviving order");
        try { old.next(); throw new IllegalStateException("Iterator should fail fast"); }
        catch (ConcurrentModificationException expected) { checks++; }
        final IllegalStateException failure = new IllegalStateException("predicate failure");
        list.add(b);
        try {
            list.removeIf(new Predicate<Object>() {
                public boolean test(Object value) { if (value == b) throw failure; return true; }
            });
            throw new IllegalStateException("Predicate exception did not propagate");
        } catch (IllegalStateException expected) {
            check(expected == failure && list.size() == 2 && list.get(0) == a && list.get(1) == b,
                    "Predicate failure does not commit earlier removals");
        }
        try {
            list.removeIf(new Predicate<Object>() {
                public boolean test(Object value) { list.add(c); return true; }
            });
            throw new IllegalStateException("Mutation should fail fast");
        } catch (ConcurrentModificationException expected) {
            check(list.size() == 3 && list.get(2) == c, "Structural callback mutation survives without compaction");
        }
        Iterator<Object> retained = list.iterator();
        check(!list.removeIf(new Predicate<Object>() {
            public boolean test(Object value) { return false; }
        }) && retained.next() == a, "An unchanged list preserves the live iterator");
        list.clear();
        try { list.removeIf(null); throw new IllegalStateException("Expected null predicate"); }
        catch (NullPointerException expected) { checks++; }
    }

    private static final class ClockDate extends Date {
        final Object marker;
        ClockDate(long stored, Object marker) { super(stored); this.marker = marker; }
        public long getTime() { return 42; }
    }

    private static void dates() {
        Date low = new Date(Long.MIN_VALUE);
        Date high = new Date(Long.MAX_VALUE);
        check(low.getTime() == Long.MIN_VALUE && high.getTime() == Long.MAX_VALUE,
                "Dates retain signed epoch milliseconds");
        check(low.before(high) && high.after(low) && high.compareTo(low) > 0 && low.compareTo(high) < 0,
                "Chronological comparisons across the signed range");
        check(!low.equals(high) && !low.equals(null) && !low.equals("date"), "Date equality requires a date");
        Date copy = (Date) low.clone();
        check(copy != low && copy.equals(low) && copy.hashCode() == low.hashCode(), "A clone has equal time and independent identity");
        copy.setTime(-0x12345678abcdef12L);
        long millis = copy.getTime();
        check(millis == -0x12345678abcdef12L && copy.hashCode() == ((int) millis ^ (int) (millis >>> 32))
                && low.getTime() == Long.MIN_VALUE, "Date update and exact wide hash");
        Object marker = new Object();
        ClockDate overridden = new ClockDate(-50, marker);
        check(overridden.equals(new Date(42)) && overridden.hashCode() == 42,
                "Date equals and hashCode use the virtual getTime");
        check(overridden.before(new Date(0)) && overridden.compareTo(new Date(0)) < 0,
                "Ordering uses the stored time");
        ClockDate subclassCopy = (ClockDate) overridden.clone();
        check(subclassCopy != overridden && subclassCopy.marker == marker && subclassCopy.before(new Date(0)),
                "Clone preserves the runtime class, time and fields");
        long before = System.currentTimeMillis();
        long now = new Date().getTime();
        check(now >= before && now <= System.currentTimeMillis(), "The no-argument constructor uses the guest wall clock");
    }

    public static int verify() {
        checks = 0;
        try {
            queue();
            cachedPool();
            primitiveAndNullChecks();
            removeIf();
            dates();
            return checks;
        } catch (InterruptedException error) {
            throw new IllegalStateException(error);
        }
    }
    public static void main(String[] args) {
        System.out.println("Handoff checks: " + verify());
    }
}
