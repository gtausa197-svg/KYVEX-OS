//! Incremental cursor over Android's compiled XML chunks.
use super::*;
use crate::resources::{Pool, Value, chunk, u16le, u32le};
use std::ops::Range;

const NONE: u32 = u32::MAX;
const MAX_DEPTH: usize = 128;
const MAX_NAMESPACES: usize = 128;
const MAX_ATTRIBUTES: usize = 256;
const MAX_EVENT_BYTES: usize = 65536;
const MAX_NODES: usize = 32768;
const BUFFER_FACTOR: usize = 3;
const EVENT_RESERVE: usize = MAX_EVENT_BYTES * 2;

pub(super) fn input_limit(budget: usize) -> usize {
    (budget.saturating_sub(EVENT_RESERVE) / BUFFER_FACTOR).min(1024 * 1024)
}

#[derive(Clone, Copy)]
pub(super) struct AttributeInfo {
    pub value: Value,
    pub resource: u32,
    pub has_raw_string: bool,
}

#[derive(Clone, Copy, Default)]
pub(super) struct AttributeIndices {
    pub id: Option<usize>,
    pub class: Option<usize>,
    pub style: Option<usize>,
}

#[derive(Clone, Copy, Eq, Ord, PartialEq, PartialOrd)]
struct Name {
    namespace: u32,
    local: u32,
}
impl Name {
    fn parse(bytes: &[u8]) -> Result<Self> {
        Ok(Self {
            namespace: u32le(bytes, 0)?,
            local: u32le(bytes, 4)?,
        })
    }
}

#[derive(PartialEq, Eq)]
struct NamespaceDecl {
    depth: usize,
    prefix: u32,
    uri: u32,
}

pub(super) struct Binary {
    bytes: Vec<u8>,
    strings: Pool,
    resource_ids: Range<usize>,
    offset: usize,
    elements: Vec<Name>,
    namespaces: Vec<NamespaceDecl>,
    nodes: usize,
    saw_root: bool,
}

impl Binary {
    pub fn new(bytes: Vec<u8>) -> Result<Self> {
        let (kind, head, root) = chunk(&bytes, 0)?;
        if kind != 3 || root.len() != bytes.len() {
            return Err("Compiled XML document header".into());
        }
        let strings = Pool::parse(root, head)?;
        let (_, _, string_chunk) = chunk(root, head)?;
        let mut offset = head + string_chunk.len();
        let mut resource_ids = 0..0;
        if offset < root.len() {
            let (kind, head, part) = chunk(root, offset)?;
            if kind == 0x0180 {
                let count = (part.len() - head) / 4;
                if head != 8 || count > strings.count() {
                    return Err("Compiled XML resource map bounds".into());
                }
                resource_ids = offset + head..offset + part.len();
                offset += part.len();
            }
        }
        Ok(Self {
            bytes,
            strings,
            resource_ids,
            offset,
            elements: Vec::new(),
            namespaces: Vec::new(),
            nodes: 0,
            saw_root: false,
        })
    }

    pub fn reserved_bytes(&self) -> usize {
        self.bytes.capacity() * BUFFER_FACTOR + EVENT_RESERVE
    }

    fn string(&self, id: u32, budget: &mut usize) -> Result<String> {
        let units = self
            .strings
            .bounded_units(&self.bytes, id, (*budget / 2).min(16384))?;
        let text = String::from_utf16(&units)?;
        xml_chars(&text)?;
        *budget = budget
            .checked_sub(text.len())
            .ok_or("Compiled XML event text budget")?;
        Ok(text)
    }

    fn local_name(&self, id: u32, budget: &mut usize) -> Result<String> {
        let name = self.string(id, budget)?;
        if name.contains(':') || !valid_name(&name) {
            return Err("Invalid compiled XML local name".into());
        }
        Ok(name)
    }

    fn namespace(&self, id: u32, budget: &mut usize) -> Result<String> {
        if id == NONE {
            return Ok(String::new());
        }
        self.string(id, budget)
    }

    fn name_resource(&self, string_id: u32) -> Result<u32> {
        let relative = string_id as usize * 4;
        let map = &self.bytes[self.resource_ids.clone()];
        if relative < map.len() {
            u32le(map, relative)
        } else {
            Ok(0)
        }
    }

    fn start(&self, ext: &[u8], line: usize) -> Result<XmlEvent> {
        let name = Name::parse(ext)?;
        let start = u16le(ext, 8)? as usize;
        let stride = u16le(ext, 10)? as usize;
        let count = u16le(ext, 12)? as usize;
        if start < 20 || stride < 20 || count > MAX_ATTRIBUTES || start + stride * count > ext.len()
        {
            return Err("Compiled XML attributes bounds".into());
        }
        let index = |at| -> Result<Option<usize>> {
            let one_based = u16le(ext, at)? as usize;
            if one_based > count {
                return Err("Compiled XML special attribute index".into());
            }
            Ok(one_based.checked_sub(1))
        };
        let indices = AttributeIndices {
            id: index(14)?,
            class: index(16)?,
            style: index(18)?,
        };
        let mut budget = MAX_EVENT_BYTES;
        let mut event = XmlEvent {
            kind: 2,
            depth: self.elements.len() + 1,
            line,
            name: Some(self.local_name(name.local, &mut budget)?),
            namespace: Some(self.namespace(name.namespace, &mut budget)?),
            compiled_indices: Some(indices),
            ..XmlEvent::default()
        };
        let mut names = BTreeSet::new();
        for i in 0..count {
            let at = start + i * stride;
            let bytes = &ext[at..at + stride];
            let name = Name::parse(bytes)?;
            if !names.insert(name) {
                return Err("Duplicate compiled XML attribute".into());
            }
            let raw = u32le(bytes, 8)?;
            let value = Value::parse(bytes, 12)?;
            let string_index = if raw != NONE {
                raw
            } else if value.kind == 3 {
                value.data
            } else {
                NONE
            };
            event.attributes.push(Attribute {
                name: self.local_name(name.local, &mut budget)?,
                namespace: self.namespace(name.namespace, &mut budget)?,
                value: if string_index == NONE {
                    String::new()
                } else {
                    self.string(string_index, &mut budget)?
                },
                compiled: Some(AttributeInfo {
                    value,
                    resource: self.name_resource(name.local)?,
                    has_raw_string: raw != NONE,
                }),
                ..Attribute::default()
            });
        }
        Ok(event)
    }

    pub fn advance(&mut self) -> Result<XmlEvent> {
        while self.offset < self.bytes.len() {
            self.nodes += 1;
            if self.nodes > MAX_NODES {
                return Err("Compiled XML node budget".into());
            }
            let (kind, head, node) = chunk(&self.bytes, self.offset)?;
            if head < 16 {
                return Err("Compiled XML node header".into());
            }
            self.offset += node.len();
            let line = u32le(node, 8)? as usize;
            let ext = &node[head..];
            let depth = self.elements.len();
            match kind {
                0x0100 | 0x0101 => {
                    let decl = NamespaceDecl {
                        depth: depth + 1,
                        prefix: u32le(ext, 0)?,
                        uri: u32le(ext, 4)?,
                    };
                    if kind == 0x0100 {
                        if self.namespaces.len() >= MAX_NAMESPACES || (depth == 0 && self.saw_root)
                        {
                            return Err("Compiled XML namespace bounds".into());
                        }
                        let mut budget = MAX_EVENT_BYTES;
                        if decl.prefix != NONE {
                            self.string(decl.prefix, &mut budget)?;
                        }
                        self.string(decl.uri, &mut budget)?;
                        self.namespaces.push(decl);
                    } else if self.namespaces.pop() != Some(decl) {
                        return Err("Unmatched compiled XML namespace".into());
                    }
                }
                0x0102 => {
                    if depth >= MAX_DEPTH || depth == 0 && self.saw_root {
                        return Err("Compiled XML element depth/root".into());
                    }
                    let event = self.start(ext, line)?;
                    self.elements.push(Name::parse(ext)?);
                    self.saw_root = true;
                    return Ok(event);
                }
                0x0103 => {
                    let name = Name::parse(ext)?;
                    if self.elements.pop() != Some(name) {
                        return Err("Mismatched compiled XML end tag".into());
                    }
                    let mut budget = MAX_EVENT_BYTES;
                    return Ok(XmlEvent {
                        kind: 3,
                        depth,
                        line,
                        name: Some(self.local_name(name.local, &mut budget)?),
                        namespace: Some(self.namespace(name.namespace, &mut budget)?),
                        ..XmlEvent::default()
                    });
                }
                0x0104 => {
                    if depth == 0 {
                        return Err("Compiled XML text outside an element".into());
                    }
                    let mut budget = MAX_EVENT_BYTES;
                    let text = self.string(u32le(ext, 0)?, &mut budget)?;
                    // AAPT2 leaves the unused typed part of text nodes all zero.
                    if ext.get(4..12).ok_or("Compiled XML text node bounds")? != [0; 8] {
                        Value::parse(ext, 4)?;
                    }
                    return Ok(XmlEvent {
                        kind: 4,
                        depth,
                        line,
                        text: Some(text),
                        ..XmlEvent::default()
                    });
                }
                _ => return Err(format!("Unknown compiled XML node 0x{kind:04x}").into()),
            }
        }
        if !self.saw_root || !self.elements.is_empty() || !self.namespaces.is_empty() {
            return Err("Incomplete compiled XML document".into());
        }
        Ok(XmlEvent {
            kind: 1,
            ..XmlEvent::default()
        })
    }
}
