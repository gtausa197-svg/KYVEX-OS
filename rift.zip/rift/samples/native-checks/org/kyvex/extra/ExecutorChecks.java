package org.kyvex.extra;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Standard executor contracts, run unchanged on Java8 and real Native workers. */
public final class ExecutorChecks {
 private static int checks;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 private static void await(CountDownLatch latch) throws InterruptedException {check(latch.await(3,TimeUnit.SECONDS),"Task must actually execute before deadline");}
 private static void finish(ExecutorService pool) throws InterruptedException {pool.shutdown();check(pool.awaitTermination(3,TimeUnit.SECONDS),"Actual pool termination");}
 private static final class Mark implements Runnable {
  final AtomicInteger count;Mark(AtomicInteger count){this.count=count;}
  public void run(){count.incrementAndGet();}
 }
 public static final class Factory implements ThreadFactory {
  final ThreadFactory base=Executors.defaultThreadFactory();
  final ArrayList<Thread> threads=new ArrayList<Thread>();
  final AtomicInteger wrappers=new AtomicInteger();
  final CountDownLatch error=new CountDownLatch(1);
  final AtomicReference<Throwable> failure=new AtomicReference<Throwable>();
  public Thread newThread(final Runnable work){
   System.gc();
   Thread thread=base.newThread(new Runnable(){public void run(){wrappers.incrementAndGet();work.run();}});
   thread.setName("fixture-pool-"+(threads.size()+1));thread.setDaemon(true);
   thread.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){public void uncaughtException(Thread thread,Throwable thrown){failure.set(thrown);error.countDown();}});
   threads.add(thread);return thread;
  }
 }
 public static final class Pool extends ThreadPoolExecutor {
  final AtomicInteger before=new AtomicInteger(),after=new AtomicInteger(),errors=new AtomicInteger(),ended=new AtomicInteger();
  public Pool(int size,int maximum,long keep,TimeUnit unit,LinkedBlockingQueue<Runnable> queue,ThreadFactory factory){super(size,maximum,keep,unit,queue,factory);}
  protected void beforeExecute(Thread thread,Runnable task){super.beforeExecute(thread,task);before.incrementAndGet();}
  protected void afterExecute(Runnable task,Throwable failure){super.afterExecute(task,failure);after.incrementAndGet();if(failure!=null)errors.incrementAndGet();}
  protected void terminated(){ended.incrementAndGet();super.terminated();}
 }
 public static int verify(){try{return run();}catch(InterruptedException error){throw new IllegalStateException(error);}}
 private static int run() throws InterruptedException {
  checks=0;
  final AtomicInteger marks=new AtomicInteger();
  ThreadFactory defaults=Executors.defaultThreadFactory();
  Thread a=defaults.newThread(new Mark(marks)),b=defaults.newThread(new Mark(marks));
  check(a!=b&&!a.isDaemon()&&a.getPriority()==Thread.NORM_PRIORITY&&a.getThreadGroup()==Thread.currentThread().getThreadGroup(),"Default factory creates real configured threads");
  check(a.getName().startsWith("pool-")&&a.getName().endsWith("-thread-1")&&b.getName().endsWith("-thread-2"),"Default factory thread sequence");
  a.start();b.start();a.join();b.join();check(marks.get()==2,"Default factory targets really ran");
  LinkedBlockingQueue<Runnable> bounded=new LinkedBlockingQueue<Runnable>(1);
  Runnable firstMark=new Mark(marks),secondMark=new Mark(marks);
  check(bounded.remainingCapacity()==1&&bounded.offer(firstMark)&&bounded.remainingCapacity()==0,"Actual bounded queue capacity");
  check(!bounded.offer(secondMark)&&bounded.peek()==firstMark,"Full offer preserves queued task");
  boolean rejected=false;try{bounded.add(secondMark);}catch(IllegalStateException expected){rejected=true;}check(rejected&&bounded.poll()==firstMark,"Full add fails without replacing data");
  rejected=false;try{bounded.offer(null);}catch(NullPointerException expected){rejected=true;}check(rejected,"Blocking queue rejects null");
  rejected=false;try{new LinkedBlockingQueue<Runnable>(0);}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"Zero queue capacity rejected");
  rejected=false;try{bounded.addAll(Arrays.asList(firstMark,secondMark));}catch(IllegalStateException expected){rejected=true;}check(rejected&&bounded.size()==1&&bounded.poll()==firstMark,"Bulk insertion retains the first accepted task when capacity is reached");
  final Factory factory=new Factory();final LinkedBlockingQueue<Runnable> queue=new LinkedBlockingQueue<Runnable>(1);
  final Pool pool=new Pool(1,1,1,TimeUnit.SECONDS,queue,factory);
  final CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1),done=new CountDownLatch(1);
  final ThreadLocal<String> local=new ThreadLocal<String>();
  final AtomicReference<Thread> actual=new AtomicReference<Thread>();final AtomicInteger results=new AtomicInteger();
  pool.execute(new Runnable(){public void run(){actual.set(Thread.currentThread());local.set("retained");entered.countDown();try{release.await();results.incrementAndGet();}catch(InterruptedException error){throw new IllegalStateException(error);}}});
  await(entered);
  check(pool.getPoolSize()==1&&pool.getActiveCount()==1&&pool.getQueue()==queue&&queue.isEmpty(),"First task owns an actual worker rather than occupying queue");
  Runnable second=new Runnable(){public void run(){try{if(Thread.currentThread()==actual.get()&&"retained".equals(local.get()))results.addAndGet(10);System.gc();}finally{done.countDown();}}};
  pool.execute(second);check(queue.size()==1&&queue.peek()==second&&pool.getTaskCount()==2&&pool.getCompletedTaskCount()==0,"Busy worker queues next task and reports real counts");
  rejected=false;try{pool.execute(new Mark(marks));}catch(RejectedExecutionException expected){rejected=true;}check(rejected&&queue.peek()==second,"Saturated pool invokes AbortPolicy");
  release.countDown();await(done);finish(pool);factory.threads.get(0).join();
  check(results.get()==11&&factory.threads.size()==1&&factory.wrappers.get()==1,"Worker reused through actual custom ThreadFactory wrapper and ThreadLocal state");
  check(pool.before.get()==2&&pool.after.get()==2&&pool.errors.get()==0&&pool.ended.get()==1,"Actual before/after/terminated hooks");
  check(pool.getCompletedTaskCount()==2&&pool.getTaskCount()==2&&pool.getLargestPoolSize()==1&&pool.getPoolSize()==0,"Completed and terminated pool statistics");
  check(pool.isShutdown()&&pool.isTerminated()&&!pool.isTerminating(),"Terminated state");
  rejected=false;try{pool.execute(new Mark(marks));}catch(RejectedExecutionException expected){rejected=true;}check(rejected,"Shutdown rejects further tasks");
  rejected=false;try{pool.execute(null);}catch(NullPointerException expected){rejected=true;}check(rejected,"Null task rejected before shutdown policy");
  final Factory replacements=new Factory();final Pool failed=new Pool(1,1,1,TimeUnit.SECONDS,new LinkedBlockingQueue<Runnable>(),replacements);
  check(failed.prestartCoreThread()&&!failed.prestartCoreThread(),"Real core prestart");
  final ThreadLocal<String> discarded=new ThreadLocal<String>();
  failed.execute(new Runnable(){public void run(){discarded.set("old");throw new IllegalStateException("planned-task-error");}});
  await(replacements.error);
  final CountDownLatch recovered=new CountDownLatch(1);final AtomicBoolean fresh=new AtomicBoolean();
  failed.execute(new Runnable(){public void run(){fresh.set(discarded.get()==null);recovered.countDown();}});
  await(recovered);finish(failed);
  check(replacements.threads.size()==2&&fresh.get()&&replacements.failure.get() instanceof IllegalStateException,"Failed worker replaced with fresh ordinary ThreadLocal state");
  check("planned-task-error".equals(replacements.failure.get().getMessage())&&failed.errors.get()==1&&failed.getCompletedTaskCount()==2,"Actual task Throwable, hook and completed count");
  Factory timeFactory=new Factory();Pool timed=new Pool(1,1,1,TimeUnit.SECONDS,new LinkedBlockingQueue<Runnable>(),timeFactory);
  check(timed.prestartAllCoreThreads()==1&&timed.prestartAllCoreThreads()==0,"All-core prestart uses actual existing worker count");
  long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);while(timeFactory.threads.get(0).getState()!=Thread.State.WAITING&&System.nanoTime()<deadline)Thread.yield();
  check(timeFactory.threads.get(0).getState()==Thread.State.WAITING,"Core worker really waits before changing timeout policy");
  timed.setKeepAliveTime(20,TimeUnit.MILLISECONDS);timed.allowCoreThreadTimeOut(true);check(timed.getKeepAliveTime(TimeUnit.MILLISECONDS)==20,"Live keepalive configuration");
  timeFactory.threads.get(0).join(2000);
  check(!timeFactory.threads.get(0).isAlive()&&timed.getPoolSize()==0&&!timed.isShutdown(),"Idle core actually retires after keepalive");
  final CountDownLatch restarted=new CountDownLatch(1);timed.execute(new Runnable(){public void run(){restarted.countDown();}});await(restarted);finish(timed);
  check(timeFactory.threads.size()==2&&timed.getCompletedTaskCount()==1,"Timed-out pool starts a new worker when work returns");
  Factory stopFactory=new Factory();Pool stopped=new Pool(1,1,1,TimeUnit.SECONDS,new LinkedBlockingQueue<Runnable>(2),stopFactory);
  final CountDownLatch waiting=new CountDownLatch(1);final AtomicBoolean interrupted=new AtomicBoolean();
  stopped.execute(new Runnable(){public void run(){waiting.countDown();try{new CountDownLatch(1).await();}catch(InterruptedException expected){interrupted.set(true);}}});await(waiting);
  final AtomicInteger pendingRuns=new AtomicInteger();Runnable pending1=new Mark(pendingRuns),pending2=new Mark(pendingRuns);stopped.execute(pending1);stopped.execute(pending2);
  List<Runnable> pending=stopped.shutdownNow();check(pending.size()==2&&pending.get(0)==pending1&&pending.get(1)==pending2,"shutdownNow returns actual pending tasks in queue order");
  check(stopped.awaitTermination(3,TimeUnit.SECONDS)&&interrupted.get()&&pendingRuns.get()==0,"shutdownNow interrupts the active wait and does not execute pending tasks");
  final AtomicInteger refusedRuns=new AtomicInteger();ThreadFactory refuses=new ThreadFactory(){public Thread newThread(Runnable work){return null;}};
  Pool refused=new Pool(1,1,1,TimeUnit.SECONDS,new LinkedBlockingQueue<Runnable>(1),refuses);Runnable refusedTask=new Mark(refusedRuns);refused.execute(refusedTask);
  check(refused.getPoolSize()==0&&refused.getQueue().peek()==refusedTask&&refusedRuns.get()==0,"Null ThreadFactory result leaves the real task queued");
  check(refused.shutdownNow().get(0)==refusedTask&&refused.isTerminated(),"Never-started pool returns queued task and terminates");
  Factory singleFactory=new Factory();ExecutorService single=Executors.newSingleThreadExecutor(singleFactory);final CountDownLatch delegated=new CountDownLatch(1);single.execute(new Runnable(){public void run(){delegated.countDown();}});await(delegated);finish(single);
  check(singleFactory.threads.size()==1,"Delegated executor executes actual task");
  Factory resizingFactory=new Factory();Pool resizing=new Pool(1,2,1,TimeUnit.SECONDS,new LinkedBlockingQueue<Runnable>(2),resizingFactory);
  final CountDownLatch busy=new CountDownLatch(1),unblock=new CountDownLatch(1),parallel=new CountDownLatch(1);
  resizing.execute(new Runnable(){public void run(){busy.countDown();try{unblock.await();}catch(InterruptedException error){throw new IllegalStateException(error);}}});await(busy);
  resizing.execute(new Runnable(){public void run(){parallel.countDown();}});resizing.setCorePoolSize(2);await(parallel);
  check(resizingFactory.threads.size()==2&&resizing.getCorePoolSize()==2,"Increasing core size actually starts queued work while the first worker is blocked");
  unblock.countDown();finish(resizing);check(resizing.getCompletedTaskCount()==2,"Resized pool completes both real tasks");
  return checks;
 }
 public static void main(String[] args){System.out.println("Executor checks: "+verify());}
}
