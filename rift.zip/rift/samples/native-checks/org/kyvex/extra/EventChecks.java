package org.kyvex.extra;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.TextView;

/** Real Java callbacks. The queued Message fields are read by actual DEX iget. */
public final class EventChecks {
    private static TextView view;
    private static StringBuilder order=new StringBuilder();
    private static int ticks;
    private static int dispatches,handled;
    private static final class ChildHandler extends Handler {
        @Override public void dispatchMessage(Message message){dispatches++;super.dispatchMessage(message);}
        @Override public void handleMessage(Message message){if(message.what!=123||Thread.currentThread()!=Looper.getMainLooper().getThread())throw new IllegalStateException("Handler subclass dispatch or thread identity");handled++;}
    }
    public static void watch(TextView text){view=text;}
    private static void update(){view.setText("Events: "+order.toString()+" / ticks "+ticks);}
    public static void schedule() {
        final Handler handler=new Handler(Looper.getMainLooper(),new Handler.Callback(){
            @Override public boolean handleMessage(Message message){
                if(message.what!=7||message.arg1!=9||message.arg2!=11||!"payload".equals(message.obj))throw new IllegalStateException("Message fields or cancellation");
                order.append('M');update();return true;
            }
        });
        handler.post(new Runnable(){public void run(){order.append('A');update();}});
        Runnable canceled=new Runnable(){public void run(){throw new IllegalStateException("Canceled callback ran");}};
        handler.post(canceled);
        handler.post(new Runnable(){public void run(){order.append('B');update();}});
        handler.removeCallbacks(canceled);
        Message message=handler.obtainMessage(7,0,0,"payload");message.arg1=9;message.arg2=11;
        handler.sendMessage(message);
        boolean rejected=false;try{handler.sendMessage(message);}catch(IllegalStateException expected){rejected=true;}
        if(!rejected)throw new IllegalStateException("Message was queued twice");
        handler.sendEmptyMessage(99);handler.removeMessages(99);
        new ChildHandler().sendEmptyMessage(123);
        handler.postAtFrontOfQueue(new Runnable(){public void run(){order.append('F');update();}});
        handler.postDelayed(new Runnable(){public void run(){if(dispatches!=1||handled!=1)throw new IllegalStateException("Handler override was not dispatched");ticks++;order.append('T');update();}},500);
    }
}
