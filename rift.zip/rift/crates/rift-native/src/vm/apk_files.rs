//! APK-backed read-only streams and native-library paths, never host paths.
use super::*;
use crate::vfs;
impl Runtime {
    pub(super) fn native_library_dir(&self) -> String {
        format!(
            "/data/app/{}/lib/{}",
            self.package_name,
            if self.machine.arch == 64 {
                "arm64-v8a"
            } else {
                "armeabi-v7a"
            }
        )
    }
    pub(super) fn mount_native_libraries(&mut self) -> Result<()> {
        let mut cmdline = self.guest_process_name().into_bytes();
        cmdline.push(0);
        for directory in ["/proc/self", "/proc/1"] {
            self.files.mount_directory(&vfs::units(directory))?;
            self.files
                .mount_memory(vfs::units(&format!("{directory}/cmdline")), cmdline.clone())?;
        }
        let directory = self.native_library_dir();
        self.files.mount_directory(&vfs::units(&directory))?;
        for (name, member, size) in self.libraries.library_members()? {
            self.files
                .mount_archive(vfs::units(&format!("{directory}/{name}")), member, size)?;
        }
        Ok(())
    }
    fn asset_manager(&mut self) -> Result<u32> {
        if self.asset_manager == 0 {
            self.asset_manager =
                self.allocate("Landroid/content/res/AssetManager;", Payload::Instance)?;
        }
        Ok(self.asset_manager)
    }
    fn apk_input_stream(&mut self, member: String) -> Result<u32> {
        let length = self
            .libraries
            .member_size(&member)
            .map_err(|e| fault("Ljava/io/FileNotFoundException;", &e.to_string()))?;
        if length > 192 * 1024 * 1024 {
            return Err(fault(
                "Ljava/io/IOException;",
                "APK member exceeds stream quota (192 MiB)",
            ));
        }
        let inode = self.files.open_archive(member, length)?;
        match self.allocate(
            "Landroid/content/res/AssetManager$AssetInputStream;",
            Payload::FileStream(Some(filesystem::Stream {
                inode,
                position: 0,
                output: false,
                append: false,
                closed: false,
                io: None,
            })),
        ) {
            Ok(id) => Ok(id),
            Err(error) => {
                self.files.close(inode);
                Err(error)
            }
        }
    }
    pub(super) fn apk_file_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("APK file signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("APK file argument count");
        if method == "getAssets()Landroid/content/res/AssetManager;" {
            let id = arg(0)?;
            self.object(id)?;
            if id == self.resources
                || self.subclass(&self.object(id)?.class, "Landroid/content/Context;")?
            {
                return Ok(Some(self.asset_manager()? as u64));
            }
        }
        if class == "Landroid/content/res/AssetManager;" {
            if arg(0)? != self.asset_manager || self.asset_manager == 0 {
                return Err("Unknown APK AssetManager".into());
            }
            if matches!(
                method,
                "open(Ljava/lang/String;)Ljava/io/InputStream;"
                    | "open(Ljava/lang/String;I)Ljava/io/InputStream;"
            ) {
                let name = self.text(arg(1)?)?;
                if name.is_empty()
                    || name.len() > 4096
                    || name.starts_with('/')
                    || name.contains('\0')
                    || name.split('/').any(|p| p == ".." || p == ".")
                {
                    return Err(fault(
                        "Ljava/io/FileNotFoundException;",
                        "Invalid relative APK asset path",
                    ));
                }
                if a.len() == 3 && arg(2)? > 3 {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Invalid asset access mode",
                    ));
                }
                return Ok(Some(self.apk_input_stream(format!("assets/{name}"))? as u64));
            }
        }
        if class == "Landroid/content/res/Resources;"
            && method == "openRawResource(I)Ljava/io/InputStream;"
        {
            if arg(0)? != self.resources || self.resources == 0 {
                return Err("Unknown APK Resources".into());
            }
            let (_, value) = self.resource_value(arg(1)?)?;
            if value.kind != 3 {
                return Err(fault(
                    "Landroid/content/res/Resources$NotFoundException;",
                    "Raw resource is not an APK member",
                ));
            }
            let path = String::from_utf16(
                &self
                    .resource_table
                    .as_ref()
                    .ok_or("Resource table")?
                    .string(value.data)?,
            )?;
            if !path.starts_with("res/") || path.split('/').any(|p| p == "..") {
                return Err(fault(
                    "Landroid/content/res/Resources$NotFoundException;",
                    "Raw resource path is outside res/",
                ));
            }
            return Ok(Some(self.apk_input_stream(path)? as u64));
        }
        if sig == "Ljava/lang/System;->load(Ljava/lang/String;)V" {
            let path = self.units(arg(0)?)?;
            if path.first() != Some(&47) {
                return Err(fault(
                    "Ljava/lang/UnsatisfiedLinkError;",
                    "System.load requires an absolute guest library path",
                ));
            }
            let path = vfs::canonical(&path, &self.files.cwd)?;
            let root = format!("{}/", self.native_library_dir());
            let path = String::from_utf16(&path)?;
            let filename = path
                .strip_prefix(&root)
                .filter(|s| !s.contains('/'))
                .ok_or_else(|| {
                    fault(
                        "Ljava/lang/UnsatisfiedLinkError;",
                        "Only APK-backed native library paths are supported",
                    )
                })?;
            self.load_library_file(filename)
                .map_err(|e| fault("Ljava/lang/UnsatisfiedLinkError;", &e.to_string()))?;
            return Ok(Some(0));
        }
        Ok(None)
    }
}
