use rift_native::dexfile::Dex;
use std::io::Read;
fn main() {
    let path = std::env::args().nth(1).unwrap();
    let mut zip = zip::ZipArchive::new(std::fs::File::open(path).unwrap()).unwrap();
    let mut b = Vec::new();
    zip.by_name("classes.dex")
        .unwrap()
        .read_to_end(&mut b)
        .unwrap();
    let d = Dex::parse(&b).unwrap();
    for (idx, body) in &d.bodies {
        println!(
            "{} flags={:x} regs={} ins={}: {:04x?}",
            d.signature(*idx),
            body.access,
            body.registers,
            body.incoming,
            body.code
        );
    }
}
