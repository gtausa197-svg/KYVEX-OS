package android.view.animation;
public class DecelerateInterpolator extends BaseInterpolator {
    public DecelerateInterpolator() {}
    public DecelerateInterpolator(float amount) {}
    public float getInterpolation(float input) { return 0; }
}
