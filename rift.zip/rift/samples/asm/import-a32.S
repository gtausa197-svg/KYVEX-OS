.syntax unified
.arm
.text
.global _start
_start:
    adr r0, .Lmessage
    bl strlen
    mov r7, #1
    svc #0
.Lmessage: .asciz "012345678901234567890123456789012345678901"
.data
.word .Lmessage
