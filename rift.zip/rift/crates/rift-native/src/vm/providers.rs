//! Execute manifest providers before Application.onCreate, in initOrder order.
use super::*;
const CONTEXT: usize = usize::MAX - 80;
const INFO: usize = usize::MAX - 81;
fn process(package: &str, name: &str) -> String {
    if name.is_empty() {
        package.into()
    } else if name.starts_with(':') {
        format!("{package}{name}")
    } else {
        name.into()
    }
}
impl Runtime {
    pub(super) fn guest_process_name(&self) -> String {
        self.metadata
            .as_ref()
            .map(|m| process(&m.package, &m.process))
            .unwrap_or_else(|| self.package_name.clone())
    }
    pub(super) fn start_providers(&mut self, context: u32) -> Result<()> {
        let Some(metadata) = &self.metadata else {
            return Ok(());
        };
        let mut providers = metadata.providers.clone();
        providers.sort_by_key(|p| std::cmp::Reverse(p.init_order));
        let current_process = self.guest_process_name();
        for provider in providers {
            if !provider.enabled {
                continue;
            }
            if let Some(id) = provider.enabled_resource {
                self.apk_resources()?;
                let (_, value) = self.resource_value(id)?;
                if !(0x10..=0x1f).contains(&value.kind) {
                    return Err("Provider enabled resource is not boolean".into());
                }
                if value.data == 0 {
                    continue;
                }
            }
            if !provider.process.is_empty()
                && process(&self.package_name, &provider.process) != current_process
            {
                continue;
            }
            let class = format!("L{};", provider.name.replace('.', "/"));
            self.ensure_class(&class)?;
            let ty = self
                .dex
                .type_id(&class)
                .filter(|ty| self.dex.classes.contains_key(ty))
                .ok_or("Manifest provider class is absent from APK")?;
            self.initialize(ty)?;
            let object = self.instantiate(&class)?;
            if !self.subclass(&class, "Landroid/content/ContentProvider;")? {
                return Err("Manifest class is not ContentProvider".into());
            }
            self.providers.push(object);
            let init = self
                .dex
                .find(&class, "<init>", "()V")
                .ok_or("Provider requires no-argument constructor")?;
            self.invoke(init, &[object], false)?;
            let info = self.new_provider_info(&provider, true)?;
            let signature = "(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V";
            if let Some(index) = self.dex.find(&class, "attachInfo", signature)
                && self.dex.bodies.contains_key(&index)
            {
                self.invoke(index, &[object, context, info], true)?;
            } else {
                self.hle(
                    &format!("Landroid/content/ContentProvider;->attachInfo{signature}"),
                    &[object, context, info],
                )?;
            }
        }
        Ok(())
    }
    pub(super) fn provider_enabled(&mut self, p: &rift_core::apk::Provider) -> Result<bool> {
        if !p.enabled {
            return Ok(false);
        }
        if let Some(resource) = p.enabled_resource {
            self.apk_resources()?;
            let (_, value) = self.resource_value(resource)?;
            if !(0x10..=0x1f).contains(&value.kind) {
                return Err("Provider enabled resource is not boolean".into());
            }
            return Ok(value.data != 0);
        }
        Ok(true)
    }
    pub(super) fn new_provider_info(
        &mut self,
        p: &rift_core::apk::Provider,
        include_metadata: bool,
    ) -> Result<u32> {
        let package = self.string(&self.package_name.clone())?;
        let name = self.string(&p.name)?;
        let authority = self.string(&p.authorities)?;
        let process_name = if p.process.is_empty() {
            self.guest_process_name()
        } else {
            process(&self.package_name, &p.process)
        };
        let process_name = self.string(&process_name)?;
        let read = if p.read_permission.is_empty() {
            0
        } else {
            self.string(&p.read_permission)?
        };
        let write = if p.write_permission.is_empty() {
            0
        } else {
            self.string(&p.write_permission)?
        };
        let application = self.new_application_info(include_metadata)?;
        let meta = if !include_metadata || p.meta_data.is_empty() {
            0
        } else {
            self.metadata_bundle(p.meta_data.clone())?
        };
        let target = self.metadata.as_ref().map_or(1, |m| m.target_sdk);
        let enabled = self.provider_enabled(p)?;
        let grant = if let Some(resource) = p.grant_uri_permissions_resource {
            self.apk_resources()?;
            let (_, value) = self.resource_value(resource)?;
            if !(0x10..=0x1f).contains(&value.kind) {
                return Err("Provider grantUriPermissions resource is not boolean".into());
            }
            value.data != 0
        } else {
            p.grant_uri_permissions
        };
        self.allocate(
            "Landroid/content/pm/ProviderInfo;",
            Payload::Record(BTreeMap::from([
                ("packageName".into(), package as u64),
                ("name".into(), name as u64),
                ("authority".into(), authority as u64),
                ("processName".into(), process_name as u64),
                ("applicationInfo".into(), application as u64),
                ("metaData".into(), meta as u64),
                ("enabled".into(), enabled as u64),
                ("exported".into(), p.exported.unwrap_or(target < 17) as u64),
                ("directBootAware".into(), p.direct_boot_aware as u64),
                ("grantUriPermissions".into(), grant as u64),
                ("initOrder".into(), p.init_order as u32 as u64),
                ("readPermission".into(), read as u64),
                ("writePermission".into(), write as u64),
            ])),
        )
    }
    pub(super) fn provider_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Provider signature")?;
        if !self.subclass(class, "Landroid/content/ContentProvider;")? {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Provider argument count");
        let id = arg(0)?;
        self.object(id)?;
        match method {
            "<init>()V" => return Ok(Some(0)),
            "getContext()Landroid/content/Context;" => {
                return Ok(Some(
                    self.object(id)?.fields.get(&CONTEXT).copied().unwrap_or(0),
                ));
            }
            "attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V" => {
                if self.object(id)?.fields.contains_key(&CONTEXT) {
                    return Ok(Some(0));
                }
                let context = arg(1)?;
                if !self.subclass(&self.object(context)?.class, "Landroid/content/Context;")? {
                    return Err("Provider context type".into());
                }
                let info = arg(2)?;
                if info != 0
                    && !self.subclass(
                        &self.object(info)?.class,
                        "Landroid/content/pm/ProviderInfo;",
                    )?
                {
                    return Err("ProviderInfo type".into());
                }
                self.object_mut(id)?.fields.insert(CONTEXT, context as u64);
                self.object_mut(id)?.fields.insert(INFO, info as u64);
                let actual = self.object(id)?.class.clone();
                let create = self
                    .dex
                    .find(&actual, "onCreate", "()Z")
                    .ok_or("Provider.onCreate implementation absent")?;
                self.invoke(create, &[id], true)?;
                return Ok(Some(0));
            }
            _ => {}
        }
        Ok(None)
    }
}
