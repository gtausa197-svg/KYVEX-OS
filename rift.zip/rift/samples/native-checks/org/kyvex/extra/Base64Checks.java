package org.kyvex.extra;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
/** Identical assertions execute against Android API28 and our real DEX API. */
public final class Base64Checks {
 private static int checks;
 private static void check(boolean value,String why){if(!value)throw new IllegalStateException(why);checks++;}
 private static byte[] ascii(String value){return value.getBytes(StandardCharsets.US_ASCII);}
 private static boolean same(byte[] value,int...expected){if(value.length!=expected.length)return false;for(int i=0;i<value.length;i++)if((value[i]&255)!=expected[i])return false;return true;}
 public static int verify(){checks=0;
  String[] input={"","f","fo","foo","foob","fooba","foobar"};
  String[] encoded={"","Zg==","Zm8=","Zm9v","Zm9vYg==","Zm9vYmE=","Zm9vYmFy"};
  for(int i=0;i<input.length;i++)check(encoded[i].equals(Base64.encodeToString(ascii(input[i]),Base64.NO_WRAP)),"RFC encoding vector");
  check("".equals(Base64.encodeToString(new byte[0],Base64.DEFAULT)),"Empty input has no line ending");
  check("Zg==\n".equals(Base64.encodeToString(ascii("f"),Base64.DEFAULT)),"Default final newline");
  check("Zg".equals(Base64.encodeToString(ascii("f"),Base64.NO_WRAP|Base64.NO_PADDING)),"Padding omitted");
  check("Zm8\n".equals(Base64.encodeToString(ascii("fo"),Base64.NO_PADDING)),"Unpadded default retains newline");
  byte[] raw={(byte)251,(byte)255};
  check("+/8=".equals(Base64.encodeToString(raw,Base64.NO_WRAP))&&"-_8=".equals(Base64.encodeToString(raw,Base64.NO_WRAP|Base64.URL_SAFE)),"Alphabet selection");
  check("-_8".equals(Base64.encodeToString(raw,Base64.NO_WRAP|Base64.URL_SAFE|Base64.NO_PADDING)),"Firebase URL-safe unpadded mode");
  check(same(Base64.encode(ascii("f"),Base64.NO_WRAP),90,103,61,61),"Byte array encoding");
  byte[] slice=ascii("xxfooyy");
  check("Zm9v".equals(Base64.encodeToString(slice,2,3,Base64.NO_WRAP)),"String encoding slice");
  check(same(Base64.encode(slice,2,1,Base64.NO_WRAP|Base64.NO_PADDING),90,103),"Byte encoding slice");
  String wrapped=Base64.encodeToString(new byte[58],Base64.DEFAULT);
  check(wrapped.length()==82&&wrapped.charAt(76)=='\n'&&wrapped.charAt(81)=='\n',"76-character wrapping and final line ending");
  wrapped=Base64.encodeToString(new byte[58],Base64.CRLF);
  check(wrapped.length()==84&&wrapped.charAt(76)=='\r'&&wrapped.charAt(77)=='\n'&&wrapped.charAt(82)=='\r'&&wrapped.charAt(83)=='\n',"CRLF wrapping");
  check(Base64.encodeToString(new byte[58],Base64.NO_WRAP|Base64.CRLF).length()==80,"No-wrap overrides CRLF");
  check("Zg==\n".equals(Base64.encodeToString(ascii("f"),Base64.NO_CLOSE)),"No-close flag does not alter standalone encoding");
  check(same(Base64.decode("Zg==",Base64.DEFAULT),102)&&same(Base64.decode("Zm8=",Base64.DEFAULT),102,111),"Padded decoding");
  check(same(Base64.decode("Zg",Base64.DEFAULT),102)&&same(Base64.decode("Zm8",Base64.DEFAULT),102,111),"Optional omitted padding");
  check(same(Base64.decode(" Z!m@9v\r\n",Base64.DEFAULT),102,111,111),"Android ignored non-alphabet bytes");
  check(same(Base64.decode("-_8=",Base64.URL_SAFE),251,255),"URL alphabet decoding");
  check(same(Base64.decode(ascii("xxZm9vyy"),2,4,Base64.DEFAULT),102,111,111),"Byte decoder slice");
  check(same(Base64.decode(ascii("AA= \t="),Base64.DEFAULT),0),"Whitespace between required padding");
  check(same(Base64.decode(new byte[]{65,65,(byte)255,61,61},Base64.DEFAULT),0),"Decoder ignores non-ASCII junk like Android");
  check(same(Base64.decode("AB==",Base64.DEFAULT),0),"Unused tail bits follow Android decoding");
  check(same(Base64.decode("!!!",Base64.DEFAULT))&&same(Base64.decode("",Base64.DEFAULT)),"Empty and entirely ignored inputs");
  for(String bad:new String[]{"A","A===","AA=","AA===","AA==A","AAA=="}){boolean rejected=false;try{Base64.decode(bad,Base64.DEFAULT);}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"Malformed padding rejected");}
  boolean rejected=false;try{Base64.encodeToString(null,Base64.DEFAULT);}catch(NullPointerException expected){rejected=true;}check(rejected,"Null encode input rejected");
  rejected=false;try{Base64.decode((String)null,Base64.DEFAULT);}catch(NullPointerException expected){rejected=true;}check(rejected,"Null decoder String rejected");
  byte[] first=Base64.decode("AQID",Base64.DEFAULT);first[0]=9;check(same(Base64.decode("AQID",Base64.DEFAULT),1,2,3),"Decoder returns fresh result arrays");
  check(same(raw,251,255)&&"xxfooyy".equals(new String(slice,StandardCharsets.US_ASCII)),"Input arrays preserved");
  String key="KYVEX\u0000\u043a\ud83d\ude00";String round=Base64.encodeToString(key.getBytes(StandardCharsets.UTF_8),11);
  check(key.equals(new String(Base64.decode(round,Base64.URL_SAFE),StandardCharsets.UTF_8)),"Actual UTF8 persistence-key data round trip");
  return checks;
 }
 public static void main(String[] args){System.out.println("Base64 checks: "+verify());}
}
