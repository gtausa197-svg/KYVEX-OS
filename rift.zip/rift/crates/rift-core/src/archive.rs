//! Small seek-aware read cache for immutable APK archives.
//! Seeking inside a cached header range does not issue another host filesystem IO.
use std::io::{self, ErrorKind, Read, Seek, SeekFrom};
pub struct CachedReader<R> {
    inner: R,
    buffer: Vec<u8>,
    start: u64,
    filled: usize,
    position: u64,
    length: u64,
}
impl<R: Read + Seek> CachedReader<R> {
    pub fn new(inner: R) -> io::Result<Self> {
        Self::with_capacity(64 * 1024, inner)
    }
    pub fn with_capacity(capacity: usize, mut inner: R) -> io::Result<Self> {
        if !(1..=1024 * 1024).contains(&capacity) {
            return Err(io::Error::new(
                ErrorKind::InvalidInput,
                "Archive read cache capacity",
            ));
        }
        let position = inner.stream_position()?;
        let length = inner.seek(SeekFrom::End(0))?;
        Ok(Self {
            inner,
            buffer: vec![0; capacity],
            start: 0,
            filled: 0,
            position,
            length,
        })
    }
    pub fn into_inner(self) -> R {
        self.inner
    }
    fn advance(&mut self, count: usize) -> io::Result<()> {
        self.position = self
            .position
            .checked_add(count as u64)
            .ok_or_else(|| io::Error::new(ErrorKind::InvalidData, "Archive cursor overflow"))?;
        Ok(())
    }
}
impl<R: Read + Seek> Read for CachedReader<R> {
    fn read(&mut self, out: &mut [u8]) -> io::Result<usize> {
        if out.is_empty() {
            return Ok(0);
        }
        if let Some(relative) = self.position.checked_sub(self.start)
            && relative < self.filled as u64
        {
            let at = relative as usize;
            let count = out.len().min(self.filled - at);
            out[..count].copy_from_slice(&self.buffer[at..at + count]);
            self.advance(count)?;
            return Ok(count);
        }
        self.inner.seek(SeekFrom::Start(self.position))?;
        if out.len() >= self.buffer.len() {
            let count = self.inner.read(out)?;
            self.advance(count)?;
            return Ok(count);
        }
        self.start = self.position;
        self.filled = 0;
        self.filled = self.inner.read(&mut self.buffer)?;
        let count = out.len().min(self.filled);
        out[..count].copy_from_slice(&self.buffer[..count]);
        self.advance(count)?;
        Ok(count)
    }
}
impl<R: Read + Seek> Seek for CachedReader<R> {
    fn seek(&mut self, from: SeekFrom) -> io::Result<u64> {
        let position = match from {
            SeekFrom::Start(position) => position,
            SeekFrom::Current(delta) => {
                self.position.checked_add_signed(delta).ok_or_else(|| {
                    io::Error::new(
                        ErrorKind::InvalidInput,
                        "Archive seek before start or overflow",
                    )
                })?
            }
            SeekFrom::End(delta) => self.inner.seek(SeekFrom::End(delta))?,
        };
        // In-file seeks are cheap. Out-of-file positions still pass through the
        // underlying validation: File and Cursor have different maximum offsets.
        if position > self.length {
            match from {
                SeekFrom::Start(_) => {
                    self.inner.seek(SeekFrom::Start(position))?;
                }
                SeekFrom::Current(delta) => {
                    self.inner.seek(SeekFrom::Start(self.position))?;
                    self.inner.seek(SeekFrom::Current(delta))?;
                }
                SeekFrom::End(_) => {}
            }
        }
        self.position = position;
        Ok(self.position)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;
    #[test]
    fn cached_reads_match_plain_cursor_for_random_seeks_eof_and_large_reads() {
        let data: Vec<u8> = (0u32..180000)
            .map(|i| (i.wrapping_mul(73) ^ (i >> 8)) as u8)
            .collect();
        for capacity in [1, 17, 4096, 65536] {
            let mut plain = Cursor::new(data.clone());
            let mut cached =
                CachedReader::with_capacity(capacity, Cursor::new(data.clone())).unwrap();
            let mut seed = 0x735dac0016bc49efu64;
            for iteration in 0..3000 {
                seed = seed
                    .wrapping_mul(6364136223846793005)
                    .wrapping_add(1442695040888963407);
                let from = match iteration % 4 {
                    0 => SeekFrom::Start(seed % 190000),
                    1 => SeekFrom::Current((seed % 20001) as i64 - 10000),
                    2 => SeekFrom::End((seed % 400001) as i64 - 200000),
                    _ => SeekFrom::Current(0),
                };
                let a = plain.seek(from);
                let b = cached.seek(from);
                assert_eq!(
                    a.as_ref().ok(),
                    b.as_ref().ok(),
                    "capacity {capacity}, seek {from:?}"
                );
                assert_eq!(
                    a.as_ref().err().map(io::Error::kind),
                    b.as_ref().err().map(io::Error::kind)
                );
                let length = (seed % 8193) as usize;
                let mut expected = vec![0; length];
                let n = plain.read(&mut expected).unwrap();
                expected.truncate(n);
                // Read may return a shorter cached prefix; read_exact preserves
                // the logical stream while allowing the same EOF as plain read.
                let mut actual = vec![0; n];
                cached.read_exact(&mut actual).unwrap();
                assert_eq!(actual, expected);
                assert_eq!(plain.position(), cached.stream_position().unwrap());
            }
            cached.seek(SeekFrom::Start(u64::MAX)).unwrap();
            assert_eq!(cached.read(&mut [0; 8]).unwrap(), 0);
            assert!(cached.seek(SeekFrom::Current(1)).is_err());
            cached.seek(SeekFrom::Start(0)).unwrap();
            assert!(cached.seek(SeekFrom::Current(i64::MIN)).is_err());
            assert_eq!(cached.read(&mut []).unwrap(), 0);
        }
        assert!(CachedReader::with_capacity(0, Cursor::new(Vec::<u8>::new())).is_err());
    }
    struct Counted {
        bytes: Cursor<Vec<u8>>,
        reads: usize,
        seeks: usize,
    }
    impl Read for Counted {
        fn read(&mut self, b: &mut [u8]) -> io::Result<usize> {
            self.reads += 1;
            self.bytes.read(b)
        }
    }
    impl Seek for Counted {
        fn seek(&mut self, p: SeekFrom) -> io::Result<u64> {
            self.seeks += 1;
            self.bytes.seek(p)
        }
    }
    #[test]
    fn nearby_archive_headers_reuse_one_read_instead_of_hundreds_of_file_roundtrips() {
        let source = Counted {
            bytes: Cursor::new(vec![0x5a; 65536]),
            reads: 0,
            seeks: 0,
        };
        let mut reader = CachedReader::new(source).unwrap();
        for index in 0..500 {
            reader.seek(SeekFrom::Start(index * 16)).unwrap();
            let mut header = [0; 8];
            reader.read_exact(&mut header).unwrap();
            assert_eq!(header, [0x5a; 8]);
        }
        let source = reader.into_inner();
        assert_eq!(source.reads, 1);
        assert!(source.seeks <= 3, "{} underlying seeks", source.seeks);
    }
    #[test]
    fn real_file_eof_and_invalid_large_seeks_preserve_file_validation() {
        let path = std::env::temp_dir().join(format!(
            "rift-cache-file-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let file = std::fs::OpenOptions::new()
            .read(true)
            .write(true)
            .create_new(true)
            .open(&path)
            .unwrap();
        file.set_len(1280).unwrap();
        let mut plain = std::fs::File::open(&path).unwrap();
        let mut cached = CachedReader::new(file).unwrap();
        for from in [
            SeekFrom::Start(0),
            SeekFrom::Start(1279),
            SeekFrom::Start(1280),
            SeekFrom::Start(1400),
            SeekFrom::Start(u64::MAX),
            SeekFrom::Current(i64::MAX),
            SeekFrom::End(-1281),
            SeekFrom::End(-1),
            SeekFrom::End(0),
        ] {
            let a = plain.seek(from);
            let b = cached.seek(from);
            assert_eq!(a.as_ref().ok(), b.as_ref().ok(), "{from:?}");
            assert_eq!(a.is_err(), b.is_err(), "{from:?}");
            let mut expected = [0; 8];
            let n = plain.read(&mut expected).unwrap();
            let mut actual = vec![0; n];
            cached.read_exact(&mut actual).unwrap();
            assert_eq!(&actual, &expected[..n]);
            assert_eq!(
                plain.stream_position().unwrap(),
                cached.stream_position().unwrap()
            );
        }
        drop(cached);
        drop(plain);
        std::fs::remove_file(path).unwrap();
    }
}
