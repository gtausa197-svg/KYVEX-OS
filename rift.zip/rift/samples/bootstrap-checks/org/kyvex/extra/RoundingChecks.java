package org.kyvex.extra;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;

public final class RoundingChecks {
    private static int checks;

    private static void check(boolean condition, String name) {
        if (!condition) throw new IllegalStateException(name);
        checks++;
    }

    public static int verify() {
        checks = 0;
        RoundingMode[] modes = RoundingMode.values();
        check(modes.length == 8 && modes[7] == RoundingMode.UNNECESSARY, "Declared mode order");
        for (int i = 0; i < modes.length; i++) {
            check(modes[i] == RoundingMode.valueOf(i) && modes[i].ordinal() == i, "Legacy rounding index");
        }
        modes[7] = RoundingMode.UP;
        check(RoundingMode.values()[7] == RoundingMode.UNNECESSARY
                && RoundingMode.valueOf("UNNECESSARY") == Enum.valueOf(RoundingMode.class, "UNNECESSARY"),
                "Independent values arrays and canonical enums");
        boolean invalid = false;
        try { RoundingMode.valueOf(-1); }
        catch (IllegalArgumentException expected) { invalid = true; }
        check(invalid, "Invalid legacy index");

        NumberFormat format = new DecimalFormat("0");
        check(format.getRoundingMode() == RoundingMode.HALF_EVEN
                && "2".equals(format.format(2.5)) && "4".equals(format.format(3.5)), "Default ties to even");
        format.setRoundingMode(RoundingMode.UP);
        check("-3".equals(format.format(-2.25)), "Round away from zero");
        format.setRoundingMode(RoundingMode.DOWN);
        check("-2".equals(format.format(-2.25)), "Round toward zero");
        format.setRoundingMode(RoundingMode.CEILING);
        check("-2".equals(format.format(-2.25)) && "3".equals(format.format(2.25)), "Round toward positive infinity");
        format.setRoundingMode(RoundingMode.FLOOR);
        check("-3".equals(format.format(-2.25)) && "2".equals(format.format(2.25)), "Round toward negative infinity");
        format.setRoundingMode(RoundingMode.HALF_UP);
        check("3".equals(format.format(2.5)), "Tie away from zero");
        format.setRoundingMode(RoundingMode.HALF_DOWN);
        check("2".equals(format.format(2.5)), "Tie toward zero");
        format.setRoundingMode(RoundingMode.UNNECESSARY);
        boolean inexact = false;
        try { format.format(2.5); }
        catch (ArithmeticException expected) { inexact = true; }
        check(inexact && "2".equals(format.format(2L))
                && format.getRoundingMode() == RoundingMode.UNNECESSARY, "Inexact formatting raises ArithmeticException");
        return checks;
    }

    public static void main(String[] args) {
        System.out.println("Rounding checks: " + verify());
    }
}
