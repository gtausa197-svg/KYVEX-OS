package org.kyvex.extra;

import android.content.ContentResolver;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Point;
import android.provider.Settings;
import android.util.Pair;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;

public final class PairSettingsChecks {
    private static int checks;

    private static void check(boolean condition, String name) {
        if (!condition) throw new IllegalStateException(name);
        checks++;
    }

    private static final class Right {}

    private static final class Left {
        public boolean equals(Object other) { return other == null || other instanceof Right; }
        public int hashCode() { return 33; }
        public String toString() { return "left"; }
    }

    private static final class NullText {
        public String toString() { return null; }
    }

    private static final class Derived extends Pair<String, Integer> {
        final String first = "shadow";
        Derived(String first, int second) { super(first, second); }
    }

    private static final class ResolverOverride extends ContextWrapper {
        private final ContentResolver resolver;
        ResolverOverride(Context base, ContentResolver resolver) {
            super(base);
            this.resolver = resolver;
        }
        public ContentResolver getContentResolver() { return resolver; }
    }

    public static int verify(Context context) {
        checks = 0;
        String name = new String(new char[]{'x', '\u00e9'});
        Integer number = Integer.valueOf(-7);
        Pair<String, Integer> pair = new Pair<>(name, number);
        Pair<String, Integer> same = Pair.create("x\u00e9", -7);
        check(pair.first == name && pair.second == number, "Pair fields preserve references");
        check(pair.equals(same) && same.equals(pair) && !pair.equals(name) && !pair.equals(null), "Pair equality");
        check(pair.hashCode() == (name.hashCode() ^ number.hashCode()), "Pair hash XOR");
        check("Pair{x\u00e9 -7}".equals(pair.toString()) && "Pair{null null}".equals(Pair.create(null, null).toString()),
                "Pair text");

        Left left = new Left();
        Pair<Left, Object> leftPair = Pair.create(left, null);
        Pair<Right, Object> rightPair = Pair.create(new Right(), null);
        check(rightPair.equals(leftPair) && !leftPair.equals(rightPair), "Pair uses other members as equals receivers");
        check(Pair.create(null, null).equals(leftPair), "Pair forwards a null argument to a guest override");
        check(leftPair.hashCode() == 33 && "Pair{left null}".equals(leftPair.toString()), "Pair guest hash and text");
        check("Pair{null null}".equals(Pair.create(new NullText(), null).toString()), "Null from guest toString");
        check(Pair.create(pair, null).equals(Pair.create(same, null))
                && Pair.create(pair, null).hashCode() == pair.hashCode()
                && "Pair{Pair{x\u00e9 -7} null}".equals(Pair.create(pair, null).toString()), "Nested Pair");
        check(Pair.create("\ud800", null).toString().charAt(5) == '\ud800', "UTF-16 code units");
        Derived derived = new Derived(name, -7);
        Pair<String, Integer> base = derived;
        check(base.first == name && "shadow".equals(derived.first) && derived.second == number, "Inherited and hidden fields");
        Object object = derived;
        check(object.equals(pair) && object.hashCode() == pair.hashCode() && object.toString().equals(pair.toString()), "Virtual Pair methods");
        HashMap<Pair<String, Integer>, String> map = new HashMap<>();
        map.put(pair, "stored");
        check("stored".equals(map.get(same)), "Pair works as a map key");
        try {
            Field field = Pair.class.getDeclaredField("first");
            check(field.getType() == Object.class && Modifier.isPublic(field.getModifiers())
                    && Modifier.isFinal(field.getModifiers()) && field.get(derived) == name
                    && Pair.class.getDeclaredFields().length == 2, "Public final field metadata");
            try {
                field.set(pair, "changed");
                throw new IllegalStateException("Pair field changed");
            } catch (IllegalAccessException expected) {
                check(pair.first == name, "Final Pair field");
            }
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Pair field reflection", e);
        }
        Point point = new Point(4, -5);
        Pair<Point, Object> pointPair = Pair.create(point, null);
        check(pointPair.equals(Pair.create(new Point(4, -5), null))
                && pointPair.hashCode() == point.hashCode()
                && "Pair{Point(4, -5) null}".equals(pointPair.toString()), "Native Point members");

        ContentResolver resolver = context.getContentResolver();
        check(resolver != null && resolver == context.getContentResolver(), "Stable context resolver");
        check(new ContextWrapper(context).getContentResolver() == resolver, "Wrapper delegates to base resolver");
        Context device = context.createDeviceProtectedStorageContext();
        ContentResolver deviceResolver = device.getContentResolver();
        check(deviceResolver != null && deviceResolver != resolver && deviceResolver == device.getContentResolver(),
                "Distinct underlying context resolver");
        check(new ContextWrapper(new ResolverOverride(context, deviceResolver)).getContentResolver() == deviceResolver,
                "Wrapper honors a guest base override");
        try {
            new ContextWrapper(null).getContentResolver();
            throw new IllegalStateException("Unattached context");
        } catch (NullPointerException expected) {
            check(true, "Unattached ContextWrapper");
        }

        check(Settings.Secure.getString(resolver, "advertising_id") == null, "No Fire OS advertising identity");
        try {
            Settings.Secure.getInt(resolver, "limit_ad_tracking");
            throw new IllegalStateException("Invented ad tracking setting");
        } catch (Settings.SettingNotFoundException expected) {
            check("limit_ad_tracking".equals(expected.getMessage()), "Typed missing setting");
        }
        try {
            check(Settings.Secure.getInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED) == 0
                    && Settings.Secure.getInt(resolver, "limit_ad_tracking", -37) == -37, "Guest accessibility and int fallback");
            check("1.0".equals(Settings.System.getString(resolver, Settings.System.FONT_SCALE))
                    && Settings.System.getFloat(resolver, Settings.System.FONT_SCALE)
                        == context.getResources().getConfiguration().fontScale
                    && Settings.System.getInt(resolver, Settings.System.FONT_SCALE, -9) == -9, "Display profile and malformed int");
        } catch (Settings.SettingNotFoundException e) {
            throw new IllegalStateException("Virtual device setting missing", e);
        }
        check(Settings.Global.getString(resolver, Settings.System.FONT_SCALE) == null
                && Settings.Global.getLong(resolver, "absent", -0x123456789abcL) == -0x123456789abcL
                && Settings.Global.getFloat(resolver, "absent", -3.25f) == -3.25f, "Table isolation and wide defaults");
        try {
            Settings.Secure.getString(null, "advertising_id");
            throw new IllegalStateException("Invalid resolver was accepted");
        } catch (NullPointerException expected) {
            check(true, "Null resolver");
        }
        return checks;
    }
}
