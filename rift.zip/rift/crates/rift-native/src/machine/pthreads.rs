//! Cooperative Bionic threads share the guest address space and Dynarmic CPU.
use super::{JAVA_VM, Machine, NativeStep, READ, RETURN, Result, State, Trap, WRITE};
use std::collections::BTreeMap;

mod mutex;
mod once;

pub(super) const QUANTUM: u64 = 4096;
const WAIT_SLICES: usize = 128;
const FIRST_TID: u32 = 0x4000_0000;
const STACK_BASE: u64 = 0x7300_0000;
const STACK_SIZE: usize = 512 * 1024;
const STACK_SLOT: u64 = 1024 * 1024;
const STACK_GUARD: u64 = 4096;
const MAX_THREADS: usize = 32;

#[derive(Clone, Copy)]
pub(super) enum Wait {
    Join { target: u32, destination: u64 },
    Mutex(u64),
    Once(u64),
}

struct Runnable {
    state: State,
    wait: Option<Wait>,
}

struct Thread {
    stack: u64,
    detached: bool,
    joiner: Option<u32>,
    runnable: Option<Runnable>,
    result: Option<u64>,
}

pub(super) struct Pthreads {
    threads: BTreeMap<u32, Thread>,
    next_tid: u32,
    last_scheduled: u32,
    mutexes: BTreeMap<u64, mutex::HeldMutex>,
    initializers: BTreeMap<u32, Vec<once::Initializer>>,
}

impl Default for Pthreads {
    fn default() -> Self {
        Self {
            threads: BTreeMap::new(),
            next_tid: FIRST_TID,
            last_scheduled: 0,
            mutexes: BTreeMap::new(),
            initializers: BTreeMap::new(),
        }
    }
}

pub(super) fn overlaps(address: u64, size: u64) -> bool {
    let end = address.saturating_add(size);
    (address < STACK_BASE + STACK_SLOT * MAX_THREADS as u64 && end > STACK_BASE)
        || (address < super::THREAD_CONTEXT_END && end > super::JNI_ENV)
        || (address < super::STACK_TOP && end > super::STACK_TOP - 65536)
}

impl Pthreads {
    fn ready(&self, wait: Wait) -> bool {
        match wait {
            Wait::Join { target, .. } => self
                .threads
                .get(&target)
                .is_none_or(|thread| thread.result.is_some()),
            Wait::Mutex(address) => !self.mutexes.contains_key(&address),
            Wait::Once(address) => self.once_owner(address).is_none(),
        }
    }

    fn next_ready(&self) -> Option<u32> {
        use std::ops::Bound::{Excluded, Unbounded};
        self.threads
            .range((Excluded(self.last_scheduled), Unbounded))
            .chain(self.threads.range(..=self.last_scheduled))
            .find(|(_, thread)| {
                thread
                    .runnable
                    .as_ref()
                    .is_some_and(|run| run.wait.is_none_or(|wait| self.ready(wait)))
            })
            .map(|(&tid, _)| tid)
    }

    fn blocked_by(&self, wait: Wait) -> Option<u32> {
        match wait {
            Wait::Join { target, .. } => Some(target),
            Wait::Mutex(address) => self.mutexes.get(&address).map(|mutex| mutex.owner),
            Wait::Once(address) => self.once_owner(address),
        }
    }

    fn would_deadlock(&self, tid: u32, mut wait: Wait) -> bool {
        for _ in 0..=self.threads.len() {
            let Some(owner) = self.blocked_by(wait) else {
                return false;
            };
            if owner == tid {
                return true;
            }
            let Some(next_wait) = self
                .threads
                .get(&owner)
                .and_then(|thread| thread.runnable.as_ref())
                .and_then(|run| run.wait)
            else {
                return false;
            };
            wait = next_wait;
        }
        true
    }
}

impl Machine {
    fn pthread_pointer(&mut self, address: u64, value: u64) -> Result<()> {
        let width = if self.arch == 64 { 8 } else { 4 };
        self.cpu
            .memory_mut()
            .write(address, &value.to_le_bytes()[..width])
    }

    fn start_pthread(&mut self, output: u64, attr: u64, start: u64, argument: u64) -> Result<i32> {
        if attr != 0 {
            return Ok(libc::ENOTSUP);
        }
        let address = if self.arch == 32 { start & !1 } else { start };
        let alignment = if self.arch == 32 && start & 1 != 0 {
            2
        } else {
            4
        };
        if !address.is_multiple_of(alignment)
            || self
                .cpu
                .memory()
                .read(address, &mut [0; 1], super::EXEC)
                .is_err()
        {
            return Ok(libc::EINVAL);
        }
        if self.pthreads.threads.len() >= MAX_THREADS || self.pthreads.next_tid >= i32::MAX as u32 {
            return Ok(libc::EAGAIN);
        }
        let stack = (0..MAX_THREADS as u64)
            .map(|slot| STACK_BASE + slot * STACK_SLOT + STACK_GUARD)
            .find(|base| {
                self.pthreads
                    .threads
                    .values()
                    .all(|thread| thread.stack != *base)
            })
            .ok_or("Guest pthread stack quota")?;
        if self
            .cpu
            .memory_mut()
            .map(stack, STACK_SIZE, READ | WRITE)
            .is_err()
        {
            return Ok(libc::EAGAIN);
        }
        let tid = self.pthreads.next_tid;
        if self.thread_context(tid).is_err() {
            self.cpu.memory_mut().unmap(stack, STACK_SIZE)?;
            return Ok(libc::EAGAIN);
        }
        if self.pthread_pointer(output, u64::from(tid)).is_err() {
            self.release_thread(tid)?;
            self.cpu.memory_mut().unmap(stack, STACK_SIZE)?;
            return Ok(libc::EFAULT);
        }
        let mut state = State {
            pc: address,
            ..State::default()
        };
        state.regs[0] = argument;
        if self.arch == 64 {
            state.regs[31] = stack + STACK_SIZE as u64;
            state.regs[30] = RETURN;
        } else {
            state.flags = if start & 1 != 0 { 0x30 } else { 0x10 };
            state.regs[13] = stack + STACK_SIZE as u64;
            state.regs[14] = RETURN;
        }
        self.pthreads.threads.insert(
            tid,
            Thread {
                stack,
                detached: false,
                joiner: None,
                runnable: Some(Runnable { state, wait: None }),
                result: None,
            },
        );
        self.pthreads.next_tid += 1;
        Ok(0)
    }

    fn join_pthread(&mut self, handle: u64, destination: u64) -> std::result::Result<Wait, i32> {
        let target = u32::try_from(handle).map_err(|_| libc::ESRCH)?;
        let tid = self.current_tid;
        if target == tid {
            return Err(libc::EDEADLK);
        }
        let thread = self.pthreads.threads.get_mut(&target).ok_or(libc::ESRCH)?;
        if thread.detached || thread.joiner.is_some() {
            return Err(libc::EINVAL);
        }
        let wait = Wait::Join {
            target,
            destination,
        };
        if self.pthreads.would_deadlock(tid, wait) {
            return Err(libc::EDEADLK);
        }
        self.pthreads.threads.get_mut(&target).unwrap().joiner = Some(tid);
        Ok(wait)
    }

    fn detach_pthread(&mut self, handle: u64) -> i32 {
        let Ok(target) = u32::try_from(handle) else {
            return libc::ESRCH;
        };
        let Some(thread) = self.pthreads.threads.get_mut(&target) else {
            return libc::ESRCH;
        };
        if thread.detached || thread.joiner.is_some() {
            return libc::EINVAL;
        }
        if thread.result.is_some() {
            self.pthreads.threads.remove(&target);
        } else {
            thread.detached = true;
        }
        0
    }

    pub(super) fn pthread_call(
        &mut self,
        function: &str,
        state: &mut State,
    ) -> Result<Option<NativeStep>> {
        let [a, b, c, d, ..] = state.regs;
        let result = match function {
            "pthread_create" => {
                let error = self.start_pthread(a, b, c, d)?;
                if error == 0 {
                    state.regs[0] = 0;
                    return Ok(Some(NativeStep::Yield));
                }
                error as u64
            }
            "pthread_self" => u64::from(self.current_tid),
            "pthread_equal" => u64::from(a == b),
            "pthread_join" => match self.join_pthread(a, b) {
                Ok(wait) => return Ok(Some(NativeStep::Wait(wait))),
                Err(error) => error as u64,
            },
            "pthread_detach" => self.detach_pthread(a) as u64,
            "pthread_exit" => return Ok(Some(NativeStep::ThreadExit(a))),
            "pthread_once" => return Ok(Some(self.start_pthread_once(state))),
            "sched_yield" => {
                state.regs[0] = 0;
                return Ok(Some(NativeStep::Yield));
            }
            _ => return Ok(self.pthread_mutex_call(function, state)),
        };
        state.regs[0] = result;
        Ok(Some(NativeStep::Resume))
    }

    pub(super) fn has_native_workers(&self) -> bool {
        self.pthreads.next_ready().is_some()
    }

    pub(crate) fn pump_native_threads(&mut self, slices: usize) -> Result<()> {
        for _ in 0..slices {
            if !self.run_one_pthread()? {
                break;
            }
        }
        Ok(())
    }

    pub(super) fn drive_native_wait(&mut self, wait: Wait) -> Result<u64> {
        for _ in 0..WAIT_SLICES {
            if self.pthreads.ready(wait) {
                return Ok(self.complete_native_wait(wait));
            }
            match self.run_one_pthread() {
                Ok(true) => {}
                Ok(false) => {
                    self.cancel_native_wait(wait);
                    return Ok(libc::EDEADLK as u64);
                }
                Err(error) => {
                    self.cancel_native_wait(wait);
                    return Err(error);
                }
            }
        }
        if self.pthreads.ready(wait) {
            return Ok(self.complete_native_wait(wait));
        }
        self.cancel_native_wait(wait);
        Err("Guest pthread wait instruction budget exhausted".into())
    }

    fn complete_native_wait(&mut self, wait: Wait) -> u64 {
        match wait {
            Wait::Join {
                target,
                destination,
            } => {
                let Some(result) = self.pthreads.threads.get(&target).and_then(|t| t.result) else {
                    return libc::ESRCH as u64;
                };
                if destination != 0 && self.pthread_pointer(destination, result).is_err() {
                    self.cancel_native_wait(wait);
                    return libc::EFAULT as u64;
                }
                self.pthreads.threads.remove(&target);
                0
            }
            Wait::Mutex(address) => self.take_mutex(address, true).err().unwrap_or(0) as u64,
            Wait::Once(address) => self.completed_pthread_once(address),
        }
    }

    fn cancel_native_wait(&mut self, wait: Wait) {
        if let Wait::Join { target, .. } = wait
            && let Some(thread) = self.pthreads.threads.get_mut(&target)
        {
            thread.joiner = None;
        }
    }

    fn run_one_pthread(&mut self) -> Result<bool> {
        let Some(tid) = self.pthreads.next_ready() else {
            return Ok(false);
        };
        let caller = self.current_tid;
        self.activate_thread(tid)?;
        self.pthreads.last_scheduled = tid;
        let mut run = self
            .pthreads
            .threads
            .get_mut(&tid)
            .unwrap()
            .runnable
            .take()
            .unwrap();
        if let Some(wait) = run.wait.take() {
            run.state.regs[0] = self.complete_native_wait(wait);
        }
        let result = self.native_slice(&mut run.state, QUANTUM);
        self.activate_thread(caller)?;
        match result {
            Ok((_, NativeStep::Quantum | NativeStep::Yield)) => {
                self.pthreads.threads.get_mut(&tid).unwrap().runnable = Some(run);
            }
            Ok((_, NativeStep::Wait(wait))) => {
                run.wait = Some(wait);
                self.pthreads.threads.get_mut(&tid).unwrap().runnable = Some(run);
            }
            Ok((_, NativeStep::ThreadExit(value) | NativeStep::Trap(Trap::Returned(value)))) => {
                self.finish_pthread(tid, value)?;
            }
            Ok((_, NativeStep::Trap(Trap::Vm(6)))) if run.state.regs[0] == JAVA_VM => {
                // A POSIX-created worker has no Java environment before attachment.
                run.state.regs[0] = if self.pthread_pointer(run.state.regs[1], 0).is_ok() {
                    (-2i32) as u32 as u64
                } else {
                    (-1i32) as u32 as u64
                };
                self.pthreads.threads.get_mut(&tid).unwrap().runnable = Some(run);
            }
            Ok((_, NativeStep::Trap(trap))) => {
                self.discard_pthread(tid)?;
                return Err(format!("Unsupported guest pthread transition {trap:?}").into());
            }
            Err(error) => {
                self.discard_pthread(tid)?;
                return Err(format!("Guest pthread {tid}: {error}").into());
            }
            Ok((_, NativeStep::Resume)) => unreachable!("native_slice handles Resume"),
        }
        Ok(true)
    }

    fn release_pthread_memory(&mut self, tid: u32, stack: u64) -> Result<()> {
        self.release_thread(tid)?;
        self.cpu.memory_mut().unmap(stack, STACK_SIZE)
    }

    fn finish_pthread(&mut self, tid: u32, result: u64) -> Result<()> {
        let stack = self.pthreads.threads[&tid].stack;
        self.release_pthread_memory(tid, stack)?;
        let thread = self.pthreads.threads.get_mut(&tid).unwrap();
        if thread.detached {
            self.pthreads.threads.remove(&tid);
        } else {
            thread.stack = 0;
            thread.result = Some(result);
        }
        Ok(())
    }

    fn discard_pthread(&mut self, tid: u32) -> Result<()> {
        let thread = self.pthreads.threads.remove(&tid).unwrap();
        self.release_pthread_memory(tid, thread.stack)
    }
}
