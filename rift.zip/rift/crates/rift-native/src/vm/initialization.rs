//! Owned class-initialization transactions. Waiting never suspends a Rust frame.
use super::*;
#[derive(Clone)]
pub(super) enum State {
    Running { thread: u32, execution: u64 },
    Complete,
    Failed(Failure),
}
#[derive(Clone)]
pub(super) enum Failure {
    Java(u32),
    Capability(String),
}
#[derive(Debug)]
pub(super) struct Request(pub usize);
impl std::fmt::Display for Request {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Initialize guest class {}", self.0)
    }
}
impl std::error::Error for Request {}
pub(super) enum Check {
    Ready,
    Begin,
    Wait,
}
#[derive(PartialEq)]
pub(super) enum Stage {
    Acquire,
    Dependencies,
    Clinit,
    Complete,
}
pub(super) struct Task {
    pub ty: usize,
    pub stage: Stage,
    pub dependencies: std::collections::VecDeque<usize>,
}
impl Task {
    pub fn new(ty: usize) -> Self {
        Self {
            ty,
            stage: Stage::Acquire,
            dependencies: std::collections::VecDeque::new(),
        }
    }
}
impl Runtime {
    pub(super) fn initialization_bytes(&self) -> usize {
        self.initialization_states
            .values()
            .map(|state| {
                64 + match state {
                    State::Failed(Failure::Capability(message)) => message.len(),
                    _ => 0,
                }
            })
            .sum()
    }
    pub(super) fn check_initialization(&mut self, ty: usize) -> Result<Check> {
        let name = self
            .dex
            .types
            .get(ty)
            .map(|_| self.dex.ty(ty).to_owned())
            .ok_or("DEX initialization type")?;
        self.ensure_class(&name)?;
        self.ensure_main_thread()?;
        match self.initialization_states.get(&ty).cloned() {
            Some(State::Complete) => Ok(Check::Ready),
            Some(State::Running { thread, .. }) => Ok(if thread == self.current_thread {
                Check::Ready
            } else {
                Check::Wait
            }),
            Some(State::Failed(failure)) => Err(self.class_failure_error(ty, failure)?),
            None => Ok(Check::Begin),
        }
    }
    fn class_failure_error(
        &mut self,
        ty: usize,
        failure: Failure,
    ) -> Result<Box<dyn std::error::Error + Send + Sync>> {
        let name = self.dex.ty(ty).to_owned();
        match failure {
            Failure::Capability(message) => {
                Ok(format!("Class initialization previously failed for {name}: {message}").into())
            }
            Failure::Java(cause) => {
                let error = fault(
                    "Ljava/lang/NoClassDefFoundError;",
                    &format!("Could not initialize class {name}"),
                );
                let object = self.materialize_fault(
                    error
                        .downcast_ref::<JavaFault>()
                        .ok_or("Class failure fault type")?,
                )?;
                self.object_mut(object)?
                    .fields
                    .insert(throwable::CAUSE, cause as u64);
                Ok(Box::new(JavaFault {
                    class: "Ljava/lang/NoClassDefFoundError;".into(),
                    object,
                    message: format!("Could not initialize class {name}"),
                }))
            }
        }
    }
    pub(super) fn initialize(&mut self, ty: usize) -> Result<()> {
        if matches!(self.check_initialization(ty)?, Check::Ready) {
            return Ok(());
        }
        if self.defer_initialization {
            return Err(Box::new(Request(ty)));
        }
        let mut execution = self.begin_initialization(ty)?;
        let outcome = self.drive_guest_execution(&mut execution);
        if outcome.is_err() {
            self.cancel_execution(&mut execution)?;
        }
        outcome.map(|_| ())
    }
    pub(super) fn claim_initialization(
        &mut self,
        ty: usize,
        execution: u64,
    ) -> Result<std::collections::VecDeque<usize>> {
        self.initialization_states.insert(
            ty,
            State::Running {
                thread: self.current_thread,
                execution,
            },
        );
        let Some(class) = self.dex.classes.get(&ty).cloned() else {
            return Ok(std::collections::VecDeque::new());
        };
        // Preparation precedes superclass execution. Never reset recursive writes.
        for (field, value) in class.static_values {
            let value =
                match value {
                    StaticValue::Bits(value) => value,
                    StaticValue::String(index) => {
                        let units =
                            self.dex.utf16.get(&index).cloned().unwrap_or_else(|| {
                                self.dex.strings[index].encode_utf16().collect()
                            });
                        self.literal(units)? as u64
                    }
                };
            self.statics.insert(field, value);
        }
        let mut dependencies = std::collections::VecDeque::new();
        if class.access & 0x200 == 0 {
            if let Some(parent) = class.parent {
                dependencies.push_back(parent);
            }
            let mut seen = BTreeSet::new();
            for interface in class.interfaces {
                self.default_initialization_interfaces(interface, &mut seen, &mut dependencies, 0)?;
            }
        }
        Ok(dependencies)
    }
    fn default_initialization_interfaces(
        &mut self,
        ty: usize,
        seen: &mut BTreeSet<usize>,
        out: &mut std::collections::VecDeque<usize>,
        depth: usize,
    ) -> Result<()> {
        if depth >= 64 || seen.len() >= 1024 {
            return Err("Class initialization interface hierarchy quota".into());
        }
        if !seen.insert(ty) {
            return Ok(());
        }
        let name = self.dex.ty(ty).to_owned();
        self.ensure_class(&name)?;
        let Some(class) = self.dex.classes.get(&ty).cloned() else {
            return Ok(());
        };
        for parent in class.interfaces {
            self.default_initialization_interfaces(parent, seen, out, depth + 1)?;
        }
        if class.methods.iter().any(|method| {
            self.dex
                .bodies
                .get(method)
                .is_some_and(|body| body.access & (8 | 0x400 | 2) == 0)
                && !matches!(
                    self.dex.strings[self.dex.methods[*method].name].as_str(),
                    "<init>" | "<clinit>"
                )
        }) {
            out.push_back(ty);
        }
        Ok(())
    }
    pub(super) fn fail_initialization(
        &mut self,
        ty: usize,
        execution: u64,
        wrap: bool,
        mut error: Box<dyn std::error::Error + Send + Sync>,
    ) -> Result<Box<dyn std::error::Error + Send + Sync>> {
        if !matches!(self.initialization_states.get(&ty),Some(State::Running{execution:owner,..})if *owner==execution)
        {
            return Ok(error);
        }
        if self.startup_trace.is_some() {
            let class = self.dex.ty(ty).to_owned();
            self.trace_initialization_failure(&class, &error.to_string());
        }
        let failure = if let Some(exception) = error.downcast_ref::<JavaFault>() {
            let cause = self.materialize_fault(exception)?;
            if wrap && !self.subclass(&exception.class, "Ljava/lang/Error;")? {
                let object =
                    self.allocate("Ljava/lang/ExceptionInInitializerError;", Payload::Instance)?;
                self.object_mut(object)?
                    .fields
                    .insert(throwable::CAUSE, cause as u64);
                self.capture_throwable_stack(object)?;
                error = Box::new(JavaFault {
                    class: "Ljava/lang/ExceptionInInitializerError;".into(),
                    object,
                    message: format!("Class initialization failed: {}", self.dex.ty(ty)),
                });
                Failure::Java(object)
            } else {
                Failure::Java(cause)
            }
        } else {
            Failure::Capability(error.to_string())
        };
        self.initialization_states
            .insert(ty, State::Failed(failure));
        Ok(error)
    }
    pub(super) fn abandon_initialization(&mut self, execution: u64) {
        for state in self.initialization_states.values_mut() {
            if matches!(state,State::Running{execution:owner,..}if *owner==execution) {
                *state = State::Failed(Failure::Capability(
                    "Class initialization execution was cancelled".into(),
                ));
            }
        }
    }
    pub(super) fn initialization_pending(&self, ty: usize) -> bool {
        matches!(
            self.initialization_states.get(&ty),
            Some(State::Running { .. })
        )
    }
    pub(super) fn initialization_roots(&self) -> Vec<u32> {
        self.initialization_states
            .values()
            .filter_map(|state| {
                if let State::Failed(Failure::Java(id)) = state {
                    Some(*id)
                } else {
                    None
                }
            })
            .collect()
    }
}
