//! Explicit Java register/PC state; a slice never leaves borrowed guest objects suspended.
use super::*;
#[derive(Default, Debug)]
pub(super) struct Cursor {
    pub pc: usize,
    pub result: u64,
    pub pending_exception: u32,
    call_pc: Option<usize>,
    returned: bool,
}
pub(super) struct Call {
    pub index: usize,
    pub args: Vec<u32>,
    pub virtual_call: bool,
}
pub(super) enum Slice {
    Return(u64),
    Invoke(Call),
    Yield,
    Blocked(scheduler::Wait),
    Initialize(usize),
}
impl Runtime {
    pub(super) fn resume_interpreter_instruction(
        &mut self,
        body: &Body,
        cursor: &mut Cursor,
        error: Box<dyn std::error::Error + Send + Sync>,
    ) -> Result<()> {
        if cursor.call_pc.is_some() || cursor.returned {
            return Err("Cannot deliver instruction fault to an invocation/returned frame".into());
        }
        (cursor.pc, cursor.pending_exception) =
            self.catch_interpreter_error(body, cursor.pc, error)?;
        Ok(())
    }
    pub(super) fn resume_interpreter_call(
        &mut self,
        body: &Body,
        cursor: &mut Cursor,
        outcome: Result<u64>,
    ) -> Result<()> {
        let pc = cursor
            .call_pc
            .take()
            .ok_or("Frame has no outstanding call")?;
        match outcome {
            Ok(value) => cursor.result = value,
            Err(error) => {
                (cursor.pc, cursor.pending_exception) =
                    self.catch_interpreter_error(body, pc, error)?;
            }
        }
        Ok(())
    }
    fn catch_interpreter_error(
        &mut self,
        body: &Body,
        pc: usize,
        error: Box<dyn std::error::Error + Send + Sync>,
    ) -> Result<(usize, u32)> {
        let error = self.pin_fault(error);
        let Some(exception) = error.downcast_ref::<JavaFault>() else {
            return Err(error);
        };
        let mut handler = None;
        for block in &body.tries {
            if pc < block.start || pc >= block.end {
                continue;
            }
            for (ty, target) in &block.handlers {
                if ty.is_none() || self.subclass(&exception.class, self.dex.ty(ty.unwrap()))? {
                    handler = Some(*target);
                    break;
                }
            }
            if handler.is_some() {
                break;
            }
        }
        let Some(target) = handler else {
            return Err(error);
        };
        let pending_exception = self.materialize_fault(exception)?;
        Ok((target, pending_exception))
    }
    pub(super) fn interpret_slice(
        &mut self,
        body: &Body,
        r: &mut [u32],
        cursor: &mut Cursor,
        mut quantum: usize,
    ) -> Result<Slice> {
        if cursor.returned || cursor.call_pc.is_some() {
            return Err("Cannot resume a returned frame or unresolved call".into());
        }
        let c = &body.code;
        let refs = &body.refs;
        let mut pc = cursor.pc;
        let mut result = cursor.result;
        let mut pending_exception = cursor.pending_exception;
        loop {
            if quantum == 0 {
                *cursor = Cursor {
                    pc,
                    result,
                    pending_exception,
                    call_pc: None,
                    returned: false,
                };
                return Ok(Slice::Yield);
            }
            quantum -= 1;
            if self.fuel == 0 {
                return Err("DEX instruction budget exhausted".into());
            }
            self.fuel -= 1;
            self.instructions += 1;
            let w = word(c, pc)?;
            let op = w as u8;
            let aa = (w >> 8) as usize;
            let a = aa & 15;
            let b = aa >> 4;
            let mut next = pc + 1;
            let mut call = None;
            let outcome = (|| -> Result<Option<u64>> {
                match op {
                    0x00 => {
                        if w != 0 {
                            return Err("Executed a DEX payload as an instruction".into());
                        }
                    }
                    0x01 | 0x07 => set(r, a, get(r, b)?)?,
                    0x02 | 0x08 => {
                        set(r, aa, get(r, word(c, pc + 1)? as usize)?)?;
                        next += 1
                    }
                    0x03 | 0x09 => {
                        set(
                            r,
                            word(c, pc + 1)? as usize,
                            get(r, word(c, pc + 2)? as usize)?,
                        )?;
                        next += 2
                    }
                    0x04 => setwide(r, a, wide(r, b)?)?,
                    0x05 => {
                        setwide(r, aa, wide(r, word(c, pc + 1)? as usize)?)?;
                        next += 1
                    }
                    0x06 => {
                        setwide(
                            r,
                            word(c, pc + 1)? as usize,
                            wide(r, word(c, pc + 2)? as usize)?,
                        )?;
                        next += 2
                    }
                    0x0a | 0x0c => set(r, aa, result as u32)?,
                    0x0b => setwide(r, aa, result)?,
                    0x0d => {
                        if pending_exception == 0 {
                            return Err("move-exception outside a handler".into());
                        }
                        set(r, aa, pending_exception)?;
                        pending_exception = 0;
                    }
                    0x0e => return Ok(Some(0)),
                    0x0f | 0x11 => return Ok(Some(get(r, aa)? as u64)),
                    0x10 => return Ok(Some(wide(r, aa)?)),
                    0x12 => set(r, a, ((b as i32) << 28 >> 28) as u32)?,
                    0x13 => {
                        set(r, aa, word(c, pc + 1)? as i16 as i32 as u32)?;
                        next += 1
                    }
                    0x14 => {
                        set(r, aa, dword(c, pc + 1)?)?;
                        next += 2
                    }
                    0x15 => {
                        set(r, aa, (word(c, pc + 1)? as u32) << 16)?;
                        next += 1
                    }
                    0x16 => {
                        setwide(r, aa, word(c, pc + 1)? as i16 as i64 as u64)?;
                        next += 1
                    }
                    0x17 => {
                        setwide(r, aa, dword(c, pc + 1)? as i32 as i64 as u64)?;
                        next += 2
                    }
                    0x18 => {
                        let v = dword(c, pc + 1)? as u64 | ((dword(c, pc + 3)? as u64) << 32);
                        setwide(r, aa, v)?;
                        next += 4
                    }
                    0x19 => {
                        setwide(r, aa, (word(c, pc + 1)? as u64) << 48)?;
                        next += 1
                    }
                    0x1a | 0x1b => {
                        let idx = if op == 0x1a {
                            word(c, pc + 1)? as usize
                        } else {
                            dword(c, pc + 1)? as usize
                        };
                        let idx = Refs::index(&refs.strings, idx)?;
                        let s = self.dex.strings.get(idx).ok_or("DEX string index")?;
                        let units = self
                            .dex
                            .utf16
                            .get(&idx)
                            .cloned()
                            .unwrap_or_else(|| s.encode_utf16().collect());
                        set(r, aa, self.literal(units)?)?;
                        next += if op == 0x1a { 1 } else { 2 }
                    }
                    0x1c => {
                        let ty = Refs::index(&refs.types, word(c, pc + 1)? as usize)?;
                        let class = self
                            .dex
                            .types
                            .get(ty)
                            .map(|_| self.dex.ty(ty).to_owned())
                            .ok_or("DEX class index")?;
                        let obj = self.class_object(&class)?;
                        set(r, aa, obj)?;
                        next += 1
                    }
                    0x1d | 0x1e => {
                        let id = get(r, aa)?;
                        if op == 0x1d {
                            self.enter_monitor(id)?;
                        } else {
                            self.exit_monitor(id)?;
                        }
                    }
                    0x1f | 0x20 => {
                        let ty = Refs::index(&refs.types, word(c, pc + 1)? as usize)?;
                        let class = self
                            .dex
                            .types
                            .get(ty)
                            .map(|_| self.dex.ty(ty).to_owned())
                            .ok_or("DEX cast type")?;
                        self.ensure_class(&class)?;
                        let id = get(r, if op == 0x1f { aa } else { b })?;
                        let valid = id != 0 && self.subclass(&self.object(id)?.class, &class)?;
                        if op == 0x1f {
                            if id != 0 && !valid {
                                return Err(fault("Ljava/lang/ClassCastException;", &class));
                            }
                        } else {
                            set(r, a, valid as u32)?;
                        }
                        next += 1;
                    }
                    0x21 => {
                        let id = get(r, b)?;
                        let n = match &self.object(id)?.payload {
                            Payload::Array(v) => v.len(),
                            _ => return Err("Expected Java array".into()),
                        };
                        set(r, a, n as u32)?
                    }
                    0x22 => {
                        let ty = Refs::index(&refs.types, word(c, pc + 1)? as usize)?;
                        if ty >= self.dex.types.len() {
                            return Err("DEX type index".into());
                        }
                        self.initialize(ty)?;
                        let class = self.dex.ty(ty).to_owned();
                        let obj = self.instantiate(&class)?;
                        set(r, aa, obj)?;
                        next += 1
                    }
                    0x23 => {
                        let n = get(r, b)? as usize;
                        if n > MAX_ARRAY_ELEMENTS {
                            return Err("Java array quota".into());
                        }
                        let ty = Refs::index(&refs.types, word(c, pc + 1)? as usize)?;
                        let class = self
                            .dex
                            .types
                            .get(ty)
                            .map(|_| self.dex.ty(ty).to_owned())
                            .ok_or("DEX array type index")?;
                        if !class.starts_with('[') {
                            return Err("Invalid array type".into());
                        }
                        let obj = self.allocate(&class, Payload::Array(vec![0; n]))?;
                        set(r, a, obj)?;
                        next += 1
                    }
                    0x24 | 0x25 => {
                        let ty = Refs::index(&refs.types, word(c, pc + 1)? as usize)?;
                        let class = self
                            .dex
                            .types
                            .get(ty)
                            .map(|_| self.dex.ty(ty).to_owned())
                            .ok_or("DEX filled-array type")?;
                        if !class.starts_with('[') || matches!(class.as_str(), "[J" | "[D") {
                            return Err("Invalid filled-new-array component".into());
                        }
                        let mut values = Vec::new();
                        if op == 0x24 {
                            if b > 5 {
                                return Err("DEX filled-array registers".into());
                            }
                            let v = word(c, pc + 2)?;
                            for i in [v & 15, (v >> 4) & 15, (v >> 8) & 15, v >> 12, a as u16]
                                .iter()
                                .take(b)
                            {
                                values.push(get(r, *i as usize)? as u64);
                            }
                        } else {
                            let first = word(c, pc + 2)? as usize;
                            for i in first..first + aa {
                                values.push(get(r, i)? as u64);
                            }
                        }
                        result = self.allocate(&class, Payload::Array(values))? as u64;
                        next += 2;
                    }
                    0x26 => {
                        let at = branch(c, pc, dword(c, pc + 1)? as i32)?;
                        if !at.is_multiple_of(2) || word(c, at)? != 0x0300 {
                            return Err("DEX fill-array payload alignment/tag".into());
                        }
                        let width = word(c, at + 1)? as usize;
                        let count = dword(c, at + 2)? as usize;
                        if !matches!(width, 1 | 2 | 4 | 8) || count > 16384 {
                            return Err("DEX array payload budget".into());
                        }
                        let mut values = Vec::with_capacity(count);
                        for i in 0..count {
                            let mut value = 0;
                            for j in 0..width {
                                let byte = i * width + j;
                                value |= (((word(c, at + 4 + byte / 2)? >> (8 * (byte % 2))) & 255)
                                    as u64)
                                    << (j * 8);
                            }
                            values.push(value);
                        }
                        let object = self.object_mut(get(r, aa)?)?;
                        if object.class
                            != match width {
                                1 => "[B",
                                2 => {
                                    if object.class == "[C" {
                                        "[C"
                                    } else {
                                        "[S"
                                    }
                                }
                                4 => {
                                    if object.class == "[F" {
                                        "[F"
                                    } else {
                                        "[I"
                                    }
                                }
                                8 => {
                                    if object.class == "[D" {
                                        "[D"
                                    } else {
                                        "[J"
                                    }
                                }
                                _ => unreachable!(),
                            }
                        {
                            return Err("DEX array payload element width mismatch".into());
                        }
                        let Payload::Array(array) = &mut object.payload else {
                            return Err("Expected primitive array".into());
                        };
                        if count > array.len() {
                            return Err(fault(
                                "Ljava/lang/ArrayIndexOutOfBoundsException;",
                                "fill-array-data length",
                            ));
                        }
                        array[..count].copy_from_slice(&values);
                        next += 2;
                    }
                    0x27 => {
                        let id = get(r, aa)?;
                        let class = self.object(id)?.class.clone();
                        if !self.subclass(&class, "Ljava/lang/Throwable;")? {
                            return Err("DEX throw requires Throwable".into());
                        }
                        return Err(Box::new(JavaFault {
                            class,
                            object: id,
                            message: self
                                .object(id)?
                                .fields
                                .get(&usize::MAX)
                                .and_then(|v| self.text(*v as u32).ok())
                                .unwrap_or_else(|| "explicit throw".into()),
                        }));
                    }
                    0x28 => next = branch(c, pc, (aa as u8 as i8) as i32)?,
                    0x29 => next = branch(c, pc, word(c, pc + 1)? as i16 as i32)?,
                    0x2a => next = branch(c, pc, dword(c, pc + 1)? as i32)?,
                    0x2b | 0x2c => {
                        let payload = branch(c, pc, dword(c, pc + 1)? as i32)?;
                        if !payload.is_multiple_of(2)
                            || word(c, payload)? != if op == 0x2b { 0x0100 } else { 0x0200 }
                        {
                            return Err("DEX switch payload alignment/tag".into());
                        }
                        let count = word(c, payload + 1)? as usize;
                        if count > 16384 {
                            return Err("DEX switch table quota".into());
                        }
                        let key = get(r, aa)? as i32;
                        let mut chosen = None;
                        for i in 0..count {
                            let candidate = if op == 0x2b {
                                (dword(c, payload + 2)? as i32)
                                    .checked_add(i as i32)
                                    .ok_or("DEX packed-switch key overflow")?
                            } else {
                                dword(c, payload + 2 + i * 2)? as i32
                            };
                            let target = dword(
                                c,
                                if op == 0x2b {
                                    payload + 4 + i * 2
                                } else {
                                    payload + 2 + count * 2 + i * 2
                                },
                            )? as i32;
                            if candidate == key {
                                chosen = Some(target);
                            }
                        }
                        next = if let Some(offset) = chosen {
                            branch(c, pc, offset)?
                        } else {
                            pc + 3
                        };
                    }
                    0x2d..=0x31 => {
                        let spec = word(c, pc + 1)?;
                        let left = (spec & 255) as usize;
                        let right = (spec >> 8) as usize;
                        let value = if op == 0x31 {
                            (wide(r, left)? as i64).cmp(&(wide(r, right)? as i64)) as i32
                        } else {
                            let (x, y) = if op <= 0x2e {
                                (
                                    f32::from_bits(get(r, left)?) as f64,
                                    f32::from_bits(get(r, right)?) as f64,
                                )
                            } else {
                                (
                                    f64::from_bits(wide(r, left)?),
                                    f64::from_bits(wide(r, right)?),
                                )
                            };
                            if x.is_nan() || y.is_nan() {
                                if matches!(op, 0x2d | 0x2f) { -1 } else { 1 }
                            } else {
                                x.partial_cmp(&y).unwrap() as i32
                            }
                        };
                        set(r, aa, value as u32)?;
                        next += 1;
                    }
                    0x32..=0x3d => {
                        let (left, right) = if op <= 0x37 {
                            (get(r, a)? as i32, get(r, b)? as i32)
                        } else {
                            (get(r, aa)? as i32, 0)
                        };
                        let kind = if op <= 0x37 { op - 0x32 } else { op - 0x38 };
                        let yes = match kind {
                            0 => left == right,
                            1 => left != right,
                            2 => left < right,
                            3 => left >= right,
                            4 => left > right,
                            5 => left <= right,
                            _ => unreachable!(),
                        };
                        next = if yes {
                            branch(c, pc, word(c, pc + 1)? as i16 as i32)?
                        } else {
                            pc + 2
                        }
                    }
                    0x44..=0x51 => {
                        let spec = word(c, pc + 1)?;
                        let array = get(r, (spec & 255) as usize)?;
                        let idx = get(r, (spec >> 8) as usize)? as usize;
                        let kind = if op <= 0x4a { op - 0x44 } else { op - 0x4b };
                        if op <= 0x4a {
                            let value = match &self.object(array)?.payload {
                                Payload::Array(v) => *v.get(idx).ok_or_else(|| {
                                    fault(
                                        "Ljava/lang/ArrayIndexOutOfBoundsException;",
                                        "array read",
                                    )
                                })?,
                                _ => return Err("Expected Java array".into()),
                            };
                            if kind == 1 {
                                setwide(r, aa, value)?
                            } else {
                                set(r, aa, narrow(kind, value) as u32)?
                            }
                        } else {
                            let value = if kind == 1 {
                                wide(r, aa)?
                            } else {
                                narrow(kind, get(r, aa)? as u64)
                            };
                            match &mut self.object_mut(array)?.payload {
                                Payload::Array(v) => {
                                    *v.get_mut(idx).ok_or_else(|| {
                                        fault(
                                            "Ljava/lang/ArrayIndexOutOfBoundsException;",
                                            "array write",
                                        )
                                    })? = value
                                }
                                _ => return Err("Expected Java array".into()),
                            }
                        }
                        next += 1
                    }
                    0x52..=0x6d => {
                        let field = Refs::index(&refs.fields, word(c, pc + 1)? as usize)?;
                        let field = self.resolve_field(field)?;
                        let f = self.dex.fields.get(field).ok_or("DEX field index")?.clone();
                        let class = self.dex.ty(f.class).to_owned();
                        self.ensure_class(&class)?;
                        let kind = (op - 0x52) % 7;
                        let static_field = op >= 0x60;
                        let writing = matches!(op,0x59..=0x5f|0x67..=0x6d);
                        let reg = if static_field { aa } else { a };
                        let native_instance = !static_field
                            && (events::instance_field(
                                &class,
                                &self.dex.strings[f.name],
                                self.dex.ty(f.ty),
                            ) || framework::instance_field(
                                &class,
                                &self.dex.strings[f.name],
                                self.dex.ty(f.ty),
                            ));
                        if !self.dex.classes.contains_key(&f.class) && !native_instance {
                            if !static_field || writing {
                                return Err(format!(
                                    "Unsupported writable/instance framework field {class}->{}",
                                    self.dex.strings[f.name]
                                )
                                .into());
                            }
                            let value = self.platform_static(field)?;
                            if kind == 1 {
                                setwide(r, reg, value)?;
                            } else {
                                set(r, reg, narrow(kind, value) as u32)?;
                            }
                            next += 1;
                            return Ok(None);
                        }
                        if static_field {
                            self.initialize(f.class)?;
                        }
                        if writing {
                            let v = if kind == 1 {
                                wide(r, reg)?
                            } else {
                                narrow(kind, get(r, reg)? as u64)
                            };
                            if static_field {
                                self.statics.insert(field, v);
                            } else {
                                let id = get(r, b)?;
                                self.store_field(id, field, v)?;
                            }
                        } else {
                            let v = if static_field {
                                *self.statics.get(&field).unwrap_or(&0)
                            } else {
                                self.load_field(get(r, b)?, field)?
                            };
                            if kind == 1 {
                                setwide(r, reg, v)?
                            } else {
                                set(r, reg, narrow(kind, v) as u32)?
                            }
                        }
                        next += 1
                    }
                    0x6e..=0x72 | 0x74..=0x78 => {
                        let index = Refs::index(&refs.methods, word(c, pc + 1)? as usize)?;
                        let mut args = Vec::new();
                        if op <= 0x72 {
                            let count = b;
                            if count > 5 {
                                return Err("DEX invoke register count".into());
                            }
                            let spec = word(c, pc + 2)?;
                            let indices = [
                                spec & 15,
                                (spec >> 4) & 15,
                                (spec >> 8) & 15,
                                spec >> 12,
                                a as u16,
                            ];
                            for i in indices.iter().take(count) {
                                args.push(get(r, *i as usize)?);
                            }
                        } else {
                            let first = word(c, pc + 2)? as usize;
                            if aa > 255 {
                                return Err("DEX invoke argument quota".into());
                            }
                            for i in first..first + aa {
                                args.push(get(r, i)?);
                            }
                        }
                        call = Some(Call {
                            index,
                            args,
                            virtual_call: matches!(op, 0x6e | 0x72 | 0x74 | 0x78),
                        });
                        next += 2
                    }
                    0x7b..=0x8f => {
                        let input = if matches!(op,0x7d|0x7e|0x80|0x84..=0x86|0x8a..=0x8c) {
                            wide(r, b)?
                        } else {
                            get(r, b)? as u64
                        };
                        let v = unary(op, input)?;
                        if matches!(
                            op,
                            0x7d | 0x7e | 0x80 | 0x81 | 0x83 | 0x86 | 0x88 | 0x89 | 0x8b
                        ) {
                            setwide(r, a, v)?
                        } else {
                            set(r, a, v as u32)?
                        }
                    }
                    0x90..=0xcf => {
                        let normalized = if op >= 0xb0 { op - 0x20 } else { op };
                        let output_wide = matches!(normalized,0x9b..=0xa5|0xab..=0xaf);
                        let (dest, left, right) = if op >= 0xb0 {
                            (a, a, b)
                        } else {
                            let spec = word(c, pc + 1)?;
                            next += 1;
                            (aa, (spec & 255) as usize, (spec >> 8) as usize)
                        };
                        let lhs = if output_wide {
                            wide(r, left)?
                        } else {
                            get(r, left)? as u64
                        };
                        let rhs = if output_wide && !matches!(normalized, 0xa3..=0xa5) {
                            wide(r, right)?
                        } else {
                            get(r, right)? as u64
                        };
                        let value = numeric(normalized, lhs, rhs)?;
                        if output_wide {
                            setwide(r, dest, value)?
                        } else {
                            set(r, dest, value as u32)?
                        }
                    }
                    0xd0..=0xe2 => {
                        let spec = word(c, pc + 1)?;
                        let (dest, left, right, kind) = if op <= 0xd7 {
                            (a, get(r, b)?, spec as i16 as i32 as u32, op - 0xd0)
                        } else {
                            (
                                aa,
                                get(r, (spec & 255) as usize)?,
                                (spec >> 8) as u8 as i8 as i32 as u32,
                                op - 0xd8,
                            )
                        };
                        let value = if kind == 1 {
                            right.wrapping_sub(left)
                        } else {
                            arithmetic(kind, left, right)?
                        };
                        set(r, dest, value)?;
                        next += 1
                    }
                    _ => {
                        return Err(
                            format!("Unsupported DEX opcode 0x{op:02x} at code unit {pc}").into(),
                        );
                    }
                }
                Ok(None)
            })();
            match outcome {
                Ok(Some(value)) => {
                    *cursor = Cursor {
                        pc,
                        result: value,
                        pending_exception: 0,
                        call_pc: None,
                        returned: true,
                    };
                    return Ok(Slice::Return(value));
                }
                Ok(None) => {}
                Err(error) => {
                    if let Some(request) = error.downcast_ref::<initialization::Request>() {
                        *cursor = Cursor {
                            pc,
                            result,
                            pending_exception,
                            call_pc: None,
                            returned: false,
                        };
                        return Ok(Slice::Initialize(request.0));
                    }
                    if let Some(signal) = error.downcast_ref::<scheduler::Signal>() {
                        *cursor = Cursor {
                            pc,
                            result,
                            pending_exception,
                            call_pc: None,
                            returned: false,
                        };
                        return Ok(Slice::Blocked(signal.0.clone()));
                    }
                    (next, pending_exception) = self.catch_interpreter_error(body, pc, error)?;
                }
            }
            if next >= c.len() {
                return Err("DEX execution left the method without a return".into());
            }
            if let Some(call) = call {
                *cursor = Cursor {
                    pc: next,
                    result,
                    pending_exception,
                    call_pc: Some(pc),
                    returned: false,
                };
                return Ok(Slice::Invoke(call));
            }
            pc = next;
        }
    }
}
