//! Android SQLite helper/database lifecycle over the real isolated SQL engine.
use super::*;
use crate::database::{Cell, Database};
mod cursor;
#[derive(Clone)]
pub(super) struct Helper {
    context: u32,
    name: u32,
    factory: u32,
    handler: u32,
    version: i32,
    pub db: u32,
    opening: bool,
}
impl Helper {
    pub(super) fn roots(&self) -> [u32; 5] {
        [self.context, self.name, self.factory, self.handler, self.db]
    }
}
struct Transaction {
    success: bool,
    child_failed: bool,
}
pub(super) struct Open {
    pub engine: Database,
    pub inode: Option<u32>,
    path: Option<Vec<u16>>,
    factory: u32,
    transactions: Vec<Transaction>,
    owner: u32,
}
impl Open {
    pub(super) fn bytes(&self) -> usize {
        self.engine.reserved_bytes()
            + self.path.as_ref().map_or(0, |p| p.capacity() * 2)
            + self.transactions.capacity() * std::mem::size_of::<Transaction>()
            + 64
    }
}
pub(super) struct Cursor {
    pub rows: crate::database::Rows,
    position: i32,
    closed: bool,
}
pub(super) fn inherits(class: &str, base: &str) -> bool {
    class == "Lorg/kyvex/rift/SqliteCursor;"
        && matches!(
            base,
            "Landroid/database/Cursor;" | "Ljava/io/Closeable;" | "Ljava/lang/AutoCloseable;"
        )
        || class == "Landroid/database/sqlite/SQLiteOpenHelper;"
            && base == "Ljava/lang/AutoCloseable;"
        || class == "Landroid/database/sqlite/SQLiteClosable;"
            && matches!(base, "Ljava/lang/AutoCloseable;" | "Ljava/io/Closeable;")
}
fn sql_error(
    error: Box<dyn std::error::Error + Send + Sync>,
) -> Box<dyn std::error::Error + Send + Sync> {
    let class = if let Some(rusqlite::Error::SqliteFailure(failure, _)) =
        error.downcast_ref::<rusqlite::Error>()
    {
        match failure.code {
            rusqlite::ErrorCode::ConstraintViolation => {
                "Landroid/database/sqlite/SQLiteConstraintException;"
            }
            rusqlite::ErrorCode::DatabaseBusy | rusqlite::ErrorCode::DatabaseLocked => {
                "Landroid/database/sqlite/SQLiteDatabaseLockedException;"
            }
            rusqlite::ErrorCode::DiskFull => "Landroid/database/sqlite/SQLiteFullException;",
            rusqlite::ErrorCode::DatabaseCorrupt | rusqlite::ErrorCode::NotADatabase => {
                "Landroid/database/sqlite/SQLiteDatabaseCorruptException;"
            }
            _ => "Landroid/database/sqlite/SQLiteException;",
        }
    } else {
        "Landroid/database/sqlite/SQLiteException;"
    };
    fault(class, &error.to_string())
}
fn object_method(method: &str) -> bool {
    matches!(
        method,
        "getClass()Ljava/lang/Class;"
            | "equals(Ljava/lang/Object;)Z"
            | "hashCode()I"
            | "toString()Ljava/lang/String;"
            | "wait()V"
            | "wait(J)V"
            | "wait(JI)V"
            | "notify()V"
            | "notifyAll()V"
    )
}
impl Runtime {
    fn sql_open(&self, id: u32) -> Result<&Open> {
        let Payload::SqliteDatabase(Some(db)) = &self.object(id)?.payload else {
            return Err(fault(
                "Ljava/lang/IllegalStateException;",
                "Database is closed",
            ));
        };
        if db.owner != 0 && db.owner != self.current_thread {
            return Err(fault(
                "Landroid/database/sqlite/SQLiteDatabaseLockedException;",
                "Another guest thread owns the transaction",
            ));
        }
        Ok(db)
    }
    fn sql_open_mut(&mut self, id: u32) -> Result<&mut Open> {
        self.sql_open(id)?;
        let Payload::SqliteDatabase(Some(db)) = &mut self.object_mut(id)?.payload else {
            unreachable!()
        };
        Ok(db)
    }
    fn sync_sqlite(&mut self, id: u32) -> Result<()> {
        let db = self.sql_open(id)?;
        if !db.engine.autocommit() {
            return Ok(());
        }
        if let Some(inode) = db.inode {
            let image = db.engine.image().map_err(sql_error)?;
            self.files
                .replace_reserved_inode(inode, &image)
                .map_err(|e| {
                    fault(
                        "Landroid/database/sqlite/SQLiteDiskIOException;",
                        &e.to_string(),
                    )
                })?;
        }
        Ok(())
    }
    fn abort_sqlite(&mut self, id: u32) -> Result<()> {
        let Payload::SqliteDatabase(slot) = &mut self.object_mut(id)?.payload else {
            return Err("Expected SQLite database".into());
        };
        if let Some(db) = slot.take()
            && let Some(inode) = db.inode
        {
            self.files.release_inode_reservation(inode);
            self.files.close(inode);
        }
        Ok(())
    }
    fn sqlite_path(&mut self, context: u32, name: u32) -> Result<Option<Vec<u16>>> {
        if name == 0 {
            return Ok(None);
        }
        let name = self.units(name)?;
        let device = self.context_device_storage(context)?;
        let storage_error = |e: crate::vfs::Error| {
            fault(
                "Landroid/database/sqlite/SQLiteCantOpenDatabaseException;",
                &e.to_string(),
            )
        };
        let root = self.files.app_data(device).map_err(storage_error)?;
        let directory = crate::vfs::join(&root, &crate::vfs::units("databases"));
        let path = if name.first() == Some(&47) {
            name
        } else {
            crate::vfs::join(&directory, &name)
        };
        let path = crate::vfs::canonical(&path, &root).map_err(storage_error)?;
        if !path.starts_with(&root) || path.get(root.len()) != Some(&47) {
            return Err(fault(
                "Landroid/database/sqlite/SQLiteCantOpenDatabaseException;",
                "Database path is outside this context's storage root",
            ));
        }
        self.files.mkdirs(&directory).map_err(storage_error)?;
        Ok(Some(path))
    }
    fn create_sqlite(&mut self, helper: &Helper) -> Result<u32> {
        if helper.context == 0 && helper.name != 0 {
            return Err(fault(
                "Ljava/lang/NullPointerException;",
                "A named database needs a Context",
            ));
        }
        if helper.handler != 0 {
            return Err("Custom SQLite DatabaseErrorHandler is not implemented".into());
        }
        let count = self
            .heap
            .values()
            .filter(|o| matches!(o.payload, Payload::SqliteDatabase(Some(_))))
            .count();
        if count >= 8 {
            return Err("Open SQLite database quota".into());
        }
        let limit = (self.heap_limit / 8).clamp(65536, 4 * 1024 * 1024);
        let path = self.sqlite_path(helper.context, helper.name)?;
        if path.is_some()
            && self
                .heap
                .values()
                .any(|o| matches!(&o.payload,Payload::SqliteDatabase(Some(db)) if db.path==path))
        {
            return Err(
                "Concurrent helpers for one named SQLite database are not implemented".into(),
            );
        }
        let inode = if let Some(path) = &path {
            Some(self.files.open(path, true, true).map_err(|e| {
                fault(
                    "Landroid/database/sqlite/SQLiteCantOpenDatabaseException;",
                    &e.to_string(),
                )
            })?)
        } else {
            None
        };
        let result = (|| {
            let image = if let Some(inode) = inode {
                let length = self.files.length(inode)?;
                if length > limit {
                    return Err("SQLite image memory quota".into());
                }
                let image = self.files.read(inode, 0, length)?;
                self.files.reserve_inode(inode, limit)?;
                (!image.is_empty()).then_some(image)
            } else {
                None
            };
            let engine = Database::new(image.as_deref(), limit).map_err(sql_error)?;
            if self
                .heap_bytes()
                .saturating_add(engine.reserved_bytes() + 128)
                > self.heap_limit
            {
                return Err("SQLite guest heap quota".into());
            }
            self.allocate(
                "Landroid/database/sqlite/SQLiteDatabase;",
                Payload::SqliteDatabase(Some(Box::new(Open {
                    engine,
                    inode,
                    path,
                    factory: helper.factory,
                    transactions: Vec::new(),
                    owner: 0,
                }))),
            )
        })();
        if result.is_err()
            && let Some(inode) = inode
        {
            self.files.release_inode_reservation(inode);
            self.files.close(inode);
        }
        result
    }
    fn get_sqlite_database(&mut self, id: u32) -> Result<u64> {
        let Payload::SqliteHelper(Some(helper)) = &self.object(id)?.payload else {
            return Err("Uninitialized SQLiteOpenHelper".into());
        };
        if helper.opening {
            return Err(fault(
                "Ljava/lang/IllegalStateException;",
                "Recursive SQLite database initialization",
            ));
        }
        if helper.db != 0
            && matches!(
                self.object(helper.db)?.payload,
                Payload::SqliteDatabase(Some(_))
            )
        {
            return Ok(helper.db as u64);
        }
        let helper = helper.clone();
        let mut roots = self.scoped_library_roots(&[id])?;
        let Payload::SqliteHelper(Some(state)) = &mut self.object_mut(id)?.payload else {
            unreachable!()
        };
        state.opening = true;
        let mut opened = 0;
        let result = (|| {
            opened = self.create_sqlite(&helper)?;
            roots.keep(opened)?;
            self.collection_dispatch(
                id,
                "Landroid/database/sqlite/SQLiteOpenHelper;",
                "onConfigure(Landroid/database/sqlite/SQLiteDatabase;)V",
                &[opened],
            )?;
            let version = self
                .sql_open(opened)?
                .engine
                .query("PRAGMA user_version", &[], 1024)
                .map_err(sql_error)?;
            let Cell::Integer(old) = version.values[0][0] else {
                return Err("SQLite version type".into());
            };
            if old != helper.version as i64 {
                self.sqlite_begin(opened, true)?;
                let upgrade: Result<()> = (|| {
                    if old == 0 {
                        self.collection_dispatch(
                            id,
                            "Landroid/database/sqlite/SQLiteOpenHelper;",
                            "onCreate(Landroid/database/sqlite/SQLiteDatabase;)V",
                            &[opened],
                        )?;
                    } else {
                        let method = if old > helper.version as i64 {
                            "onDowngrade"
                        } else {
                            "onUpgrade"
                        };
                        self.collection_dispatch(
                            id,
                            "Landroid/database/sqlite/SQLiteOpenHelper;",
                            &format!("{method}(Landroid/database/sqlite/SQLiteDatabase;II)V"),
                            &[opened, old as u32, helper.version as u32],
                        )?;
                    }
                    self.sql_open(opened)?
                        .engine
                        .exec(&format!("PRAGMA user_version={}", helper.version), &[])
                        .map_err(sql_error)?;
                    self.sqlite_success(opened)?;
                    Ok(())
                })();
                let ended = self.sqlite_end(opened);
                upgrade?;
                ended?;
            }
            self.collection_dispatch(
                id,
                "Landroid/database/sqlite/SQLiteOpenHelper;",
                "onOpen(Landroid/database/sqlite/SQLiteDatabase;)V",
                &[opened],
            )?;
            self.sync_sqlite(opened)?;
            Ok(opened as u64)
        })();
        let Payload::SqliteHelper(Some(state)) = &mut self.object_mut(id)?.payload else {
            return Err("SQLite helper state lost".into());
        };
        state.opening = false;
        if result.is_ok() {
            state.db = opened;
        } else if opened != 0 {
            self.abort_sqlite(opened)?;
        }
        result
    }
    fn sqlite_begin(&mut self, id: u32, exclusive: bool) -> Result<()> {
        self.ensure_main_thread()?;
        let current = self.current_thread;
        let db = self.sql_open_mut(id)?;
        if db.transactions.is_empty() {
            if !db.engine.autocommit() {
                return Err(fault(
                    "Ljava/lang/IllegalStateException;",
                    "Transaction already started through SQL",
                ));
            }
            db.engine
                .exec(
                    if exclusive {
                        "BEGIN EXCLUSIVE"
                    } else {
                        "BEGIN IMMEDIATE"
                    },
                    &[],
                )
                .map_err(sql_error)?;
            db.owner = current;
        }
        if db.transactions.len() >= 32 {
            return Err("SQLite transaction nesting quota".into());
        }
        if db.transactions.last().is_some_and(|t| t.success) {
            return Err(fault(
                "Ljava/lang/IllegalStateException;",
                "Parent transaction already marked successful",
            ));
        }
        db.transactions.push(Transaction {
            success: false,
            child_failed: false,
        });
        Ok(())
    }
    fn sqlite_success(&mut self, id: u32) -> Result<()> {
        let state = self
            .sql_open_mut(id)?
            .transactions
            .last_mut()
            .ok_or_else(|| fault("Ljava/lang/IllegalStateException;", "No SQLite transaction"))?;
        if state.success {
            return Err(fault(
                "Ljava/lang/IllegalStateException;",
                "Transaction already successful",
            ));
        }
        state.success = true;
        Ok(())
    }
    fn sqlite_end(&mut self, id: u32) -> Result<()> {
        let db = self.sql_open_mut(id)?;
        let state = db
            .transactions
            .pop()
            .ok_or_else(|| fault("Ljava/lang/IllegalStateException;", "No SQLite transaction"))?;
        let success = state.success && !state.child_failed;
        if let Some(parent) = db.transactions.last_mut() {
            if !success {
                parent.child_failed = true;
            }
            return Ok(());
        }
        let result = db
            .engine
            .exec(if success { "COMMIT" } else { "ROLLBACK" }, &[])
            .map_err(sql_error);
        let cleanup = if result.is_err() && !db.engine.autocommit() {
            db.engine.exec("ROLLBACK", &[]).map_err(sql_error)
        } else {
            Ok(0)
        };
        db.owner = 0;
        if let Err(error) = cleanup {
            self.abort_sqlite(id)?;
            return Err(error);
        }
        result?;
        self.sync_sqlite(id)
    }
    fn sqlite_args(&self, array: u32, strings: bool) -> Result<Vec<Cell>> {
        if array == 0 {
            return Ok(Vec::new());
        }
        let Payload::Array(values) = &self.object(array)?.payload else {
            return Err("SQLite bindings need Object[]".into());
        };
        if values.len() > 999 {
            return Err("SQLite binding quota".into());
        }
        values
            .iter()
            .map(|v| {
                if *v == 0 {
                    return Ok(Cell::Null);
                }
                let object = self.object(u32::try_from(*v)?)?;
                Ok(match &object.payload {
                    Payload::String(units) => Cell::Text(charsets::Encoding::Utf8.encode(units)),
                    Payload::Boxed { kind, bits } if !strings => match kind {
                        'F' => Cell::Real(f32::from_bits(*bits as u32) as f64),
                        'D' => Cell::Real(f64::from_bits(*bits)),
                        'J' => Cell::Integer(*bits as i64),
                        _ => Cell::Integer(*bits as u32 as i32 as i64),
                    },
                    Payload::Array(bytes) if !strings && object.class == "[B" => {
                        Cell::Blob(bytes.iter().map(|v| *v as u8).collect())
                    }
                    _ => return Err("Unsupported SQLite binding type".into()),
                })
            })
            .collect()
    }
    pub(super) fn sqlite_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        if let Some(result) = self.sqlite_cursor_api(sig, a)? {
            return Ok(Some(result));
        }
        let (class, method) = sig.split_once("->").ok_or("SQLite signature")?;
        if object_method(method) {
            return Ok(None);
        }
        if method == "getDatabasePath(Ljava/lang/String;)Ljava/io/File;" {
            let context = *a.first().ok_or("Database Context")?;
            if self.subclass(&self.object(context)?.class, "Landroid/content/Context;")? {
                let path = self
                    .sqlite_path(context, *a.get(1).ok_or("Database name")?)?
                    .ok_or_else(|| {
                        fault("Ljava/lang/NullPointerException;", "Database path name")
                    })?;
                return Ok(Some(
                    self.allocate("Ljava/io/File;", Payload::File(path))? as u64
                ));
            }
        }
        if !matches!(
            class,
            "Landroid/database/sqlite/SQLiteOpenHelper;"
                | "Landroid/database/sqlite/SQLiteDatabase;"
                | "Landroid/database/sqlite/SQLiteClosable;"
                | "Ljava/lang/AutoCloseable;"
                | "Ljava/io/Closeable;"
        ) {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("SQLite argument count");
        let id = arg(0)?;
        if class == "Landroid/database/sqlite/SQLiteOpenHelper;"
            && matches!(
                method,
                "<init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)V"
                    | "<init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;ILandroid/database/DatabaseErrorHandler;)V"
            )
        {
            let version = arg(4)? as i32;
            if version < 1 {
                return Err(fault(
                    "Ljava/lang/IllegalArgumentException;",
                    "SQLite version must be at least one",
                ));
            }
            let context = arg(1)?;
            let name = arg(2)?;
            let factory = arg(3)?;
            let handler = if a.len() == 6 { arg(5)? } else { 0 };
            for object in [context, name, factory, handler]
                .into_iter()
                .filter(|id| *id != 0)
            {
                self.object(object)?;
            }
            if name != 0 {
                self.units(name)?;
            }
            self.object_mut(id)?.payload = Payload::SqliteHelper(Some(Helper {
                context,
                name,
                factory,
                handler,
                version,
                db: 0,
                opening: false,
            }));
            return Ok(Some(0));
        }
        if let Payload::SqliteHelper(Some(helper)) = &self.object(id)?.payload {
            return Ok(Some(match method {
                "getDatabaseName()Ljava/lang/String;" => helper.name as u64,
                "getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;"
                | "getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;" => {
                    self.get_sqlite_database(id)?
                }
                "onConfigure(Landroid/database/sqlite/SQLiteDatabase;)V"
                | "onOpen(Landroid/database/sqlite/SQLiteDatabase;)V" => 0,
                "onCreate(Landroid/database/sqlite/SQLiteDatabase;)V"
                | "onUpgrade(Landroid/database/sqlite/SQLiteDatabase;II)V" => {
                    return Err(fault(
                        "Ljava/lang/AbstractMethodError;",
                        "SQLite helper callback absent",
                    ));
                }
                "onDowngrade(Landroid/database/sqlite/SQLiteDatabase;II)V" => {
                    return Err(fault(
                        "Landroid/database/sqlite/SQLiteException;",
                        "Database downgrade callback absent",
                    ));
                }
                "close()V" => {
                    if helper.opening {
                        return Err(fault(
                            "Ljava/lang/IllegalStateException;",
                            "Database initialization in progress",
                        ));
                    }
                    let db = helper.db;
                    if db != 0 {
                        self.sqlite_api(
                            "Landroid/database/sqlite/SQLiteDatabase;->close()V",
                            &[db],
                        )?;
                    }
                    0
                }
                _ => return Ok(None),
            }));
        }
        if !matches!(self.object(id)?.payload, Payload::SqliteDatabase(_)) {
            return Ok(None);
        }
        if method == "isOpen()Z" {
            return Ok(Some(
                matches!(self.object(id)?.payload, Payload::SqliteDatabase(Some(_))) as u64,
            ));
        }
        if method == "close()V" {
            if matches!(self.object(id)?.payload, Payload::SqliteDatabase(Some(_))) {
                if !self.sql_open(id)?.transactions.is_empty() {
                    return Err(fault(
                        "Ljava/lang/IllegalStateException;",
                        "Cannot close an active SQLite transaction",
                    ));
                }
                self.sync_sqlite(id)?;
                self.abort_sqlite(id)?;
            }
            return Ok(Some(0));
        }
        self.sql_open(id)?;
        let result = match method {
            "isReadOnly()Z" | "isWriteAheadLoggingEnabled()Z" => 0,
            "getPath()Ljava/lang/String;" => {
                let path = self
                    .sql_open(id)?
                    .path
                    .clone()
                    .unwrap_or_else(|| crate::vfs::units(":memory:"));
                self.string_units(path)? as u64
            }
            "getVersion()I" => {
                let rows = self
                    .sql_open(id)?
                    .engine
                    .query("PRAGMA user_version", &[], 1024)
                    .map_err(sql_error)?;
                let Cell::Integer(version) = rows.values[0][0] else {
                    return Err("SQLite version type".into());
                };
                version as u32 as u64
            }
            "setVersion(I)V" => {
                self.sql_open(id)?
                    .engine
                    .exec(&format!("PRAGMA user_version={}", arg(1)? as i32), &[])
                    .map_err(sql_error)?;
                self.sync_sqlite(id)?;
                0
            }
            "setForeignKeyConstraintsEnabled(Z)V" => {
                if !self.sql_open(id)?.engine.autocommit() {
                    return Err(fault(
                        "Ljava/lang/IllegalStateException;",
                        "Foreign key changes inside a transaction",
                    ));
                }
                self.sql_open(id)?
                    .engine
                    .exec(
                        &format!("PRAGMA foreign_keys={}", u32::from(arg(1)? != 0)),
                        &[],
                    )
                    .map_err(sql_error)?;
                0
            }
            "execSQL(Ljava/lang/String;)V" | "execSQL(Ljava/lang/String;[Ljava/lang/Object;)V" => {
                let sql = self.text(arg(1)?)?;
                let values = if a.len() == 3 {
                    self.sqlite_args(arg(2)?, false)?
                } else {
                    Vec::new()
                };
                self.sql_open(id)?
                    .engine
                    .exec(&sql, &values)
                    .map_err(sql_error)?;
                self.sync_sqlite(id)?;
                0
            }
            "rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;" => {
                let sql = self.text(arg(1)?)?;
                let values = self.sqlite_args(arg(2)?, true)?;
                let db = self.sql_open(id)?;
                if db.factory != 0 {
                    return Err("Custom SQLite cursor factories are not implemented".into());
                }
                let rows = db
                    .engine
                    .query(&sql, &values, (self.heap_limit / 4).min(4 * 1024 * 1024))
                    .map_err(sql_error)?;
                let writable = rows.writable;
                if self.heap_bytes().saturating_add(rows.bytes()) > self.heap_limit {
                    return Err("SQLite cursor guest heap quota".into());
                }
                if writable {
                    self.sync_sqlite(id)?;
                }
                self.allocate(
                    "Lorg/kyvex/rift/SqliteCursor;",
                    Payload::SqliteCursor(Cursor {
                        rows,
                        position: -1,
                        closed: false,
                    }),
                )? as u64
            }
            "beginTransaction()V" => {
                self.sqlite_begin(id, true)?;
                0
            }
            "beginTransactionNonExclusive()V" => {
                self.sqlite_begin(id, false)?;
                0
            }
            "setTransactionSuccessful()V" => {
                self.sqlite_success(id)?;
                0
            }
            "endTransaction()V" => {
                self.sqlite_end(id)?;
                0
            }
            "inTransaction()Z" => (!self.sql_open(id)?.engine.autocommit()) as u64,
            _ => return Ok(None),
        };
        Ok(Some(result))
    }
}
