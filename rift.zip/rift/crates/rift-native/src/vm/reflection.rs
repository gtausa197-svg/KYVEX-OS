//! Declared field metadata and access to actual DEX/native object state.
use super::*;
#[derive(Clone)]
pub(super) struct Field {
    pub owner: String,
    pub name: String,
    pub descriptor: String,
    pub access: u32,
    pub index: Option<usize>,
    pub accessible: bool,
}
fn native_field(class: &str, name: &str) -> Option<(&'static str, u32)> {
    if class == guest_unsafe::CLASS && name == "theUnsafe" {
        return Some((guest_unsafe::CLASS, 26));
    }
    resources_api::declared_field(class, name)
        .or_else(|| services::declared_field(class, name))
        .or_else(|| framework::declared_field(class, name))
        .or_else(|| {
            Some(match (class, name) {
                ("Ljava/util/Collections$SynchronizedCollection;", "c") => {
                    ("Ljava/util/Collection;", 16)
                }
                (
                    "Ljava/util/Collections$SynchronizedCollection;"
                    | "Ljava/util/Collections$SynchronizedMap;",
                    "mutex",
                ) => ("Ljava/lang/Object;", 16),
                ("Ljava/util/Collections$SynchronizedList;", "list") => ("Ljava/util/List;", 16),
                ("Ljava/util/Collections$SynchronizedMap;", "m") => ("Ljava/util/Map;", 18),
                ("Landroid/os/Message;", "what" | "arg1" | "arg2" | "sendingUid") => ("I", 1),
                ("Landroid/os/Message;", "obj") => ("Ljava/lang/Object;", 1),
                ("Landroid/os/Message;", "replyTo") => ("Landroid/os/Messenger;", 1),
                _ => return None,
            })
        })
}
pub(super) fn widen(bits: u64, from: char, to: char) -> Option<u64> {
    if from == to {
        return Some(bits);
    }
    let valid = match from {
        'B' => "SIJFD",
        'S' | 'C' => "IJFD",
        'I' => "JFD",
        'J' => "FD",
        'F' => "D",
        _ => "",
    };
    if !valid.contains(to) {
        return None;
    }
    let integer = match from {
        'B' => bits as i8 as i64,
        'S' => bits as i16 as i64,
        'C' => bits as u16 as i64,
        'I' => bits as i32 as i64,
        'J' => bits as i64,
        _ => 0,
    };
    Some(match to {
        'S' => integer as i16 as u16 as u64,
        'I' => integer as i32 as u32 as u64,
        'J' => integer as u64,
        'F' => (integer as f32).to_bits() as u64,
        'D' => {
            if from == 'F' {
                (f32::from_bits(bits as u32) as f64).to_bits()
            } else {
                (integer as f64).to_bits()
            }
        }
        _ => return None,
    })
}
impl Runtime {
    fn declared_fields(&mut self, owner: &str) -> Result<Vec<Field>> {
        self.ensure_class(owner)?;
        if owner == guest_unsafe::CLASS {
            return Ok(vec![self.declared_field(owner, "theUnsafe")?]);
        }
        if owner == pair::PAIR {
            return Ok(vec![
                self.declared_field(owner, "first")?,
                self.declared_field(owner, "second")?,
            ]);
        }
        if let Some(class) = self
            .dex
            .type_id(owner)
            .and_then(|ty| self.dex.classes.get(&ty))
        {
            if class.fields.len() > 4096 {
                return Err("Declared field metadata quota (4096)".into());
            }
            return class
                .fields
                .iter()
                .enumerate()
                .map(|(position, index)| {
                    let field = &self.dex.fields[*index];
                    Ok(Field {
                        owner: owner.into(),
                        name: self.dex.strings[field.name].clone(),
                        descriptor: self.dex.ty(field.ty).into(),
                        access: *class
                            .field_access
                            .get(position)
                            .ok_or("Field access metadata")?,
                        index: Some(*index),
                        accessible: false,
                    })
                })
                .collect();
        }
        if owner.starts_with('[')
            || (owner.len() == 1 && "ZBCSIJFDV".contains(owner))
            || owner == "Ljava/lang/Object;"
        {
            return Ok(Vec::new());
        }
        // A Class literal is not evidence that a native class's complete field
        // layout is implemented. Never substitute an empty or invented layout.
        Err(format!("Bulk native field metadata is not implemented for {owner}").into())
    }
    fn reflected_fields_array(&mut self, owner: &str, public: bool) -> Result<u32> {
        let mut fields = Vec::new();
        let mut todo = vec![(owner.to_owned(), 0)];
        let mut seen = BTreeSet::new();
        while let Some((next, depth)) = todo.pop() {
            if !seen.insert(next.clone()) {
                continue;
            }
            if depth >= 64 {
                return Err("Public field hierarchy quota (64)".into());
            }
            for field in self.declared_fields(&next)? {
                if !public || field.access & 1 != 0 {
                    fields.push(field);
                }
                if fields.len() > 4096 {
                    return Err("Reflected field array quota (4096)".into());
                }
            }
            if public
                && let Some(class) = self
                    .dex
                    .type_id(&next)
                    .and_then(|ty| self.dex.classes.get(&ty))
            {
                todo.extend(
                    class
                        .interfaces
                        .iter()
                        .map(|ty| (self.dex.ty(*ty).to_owned(), depth + 1)),
                );
                if let Some(parent) = class.parent {
                    todo.push((self.dex.ty(parent).to_owned(), depth + 1));
                }
            }
        }
        let mut values = Vec::with_capacity(fields.len());
        for field in fields {
            values.push(
                self.allocate("Ljava/lang/reflect/Field;", Payload::ReflectedField(field))? as u64,
            );
        }
        self.allocate("[Ljava/lang/reflect/Field;", Payload::Array(values))
    }
    pub(super) fn declared_field(&mut self, owner: &str, name: &str) -> Result<Field> {
        self.ensure_class(owner)?;
        if let Some(class) = self
            .dex
            .type_id(owner)
            .and_then(|ty| self.dex.classes.get(&ty))
        {
            for (position, index) in class.fields.iter().enumerate() {
                let field = &self.dex.fields[*index];
                if self.dex.strings[field.name] == name {
                    return Ok(Field {
                        owner: owner.into(),
                        name: name.into(),
                        descriptor: self.dex.ty(field.ty).into(),
                        access: *class
                            .field_access
                            .get(position)
                            .ok_or("Field access metadata")?,
                        index: Some(*index),
                        accessible: false,
                    });
                }
            }
        } else if let Some((descriptor, access)) = native_field(owner, name) {
            return Ok(Field {
                owner: owner.into(),
                name: name.into(),
                descriptor: descriptor.into(),
                access,
                index: None,
                accessible: false,
            });
        }
        Err(fault("Ljava/lang/NoSuchFieldException;", name))
    }
    fn field_receiver(&mut self, field: &Field, object: u32) -> Result<()> {
        if field.access & 1 == 0 && !field.accessible {
            return Err(fault(
                "Ljava/lang/IllegalAccessException;",
                "Field is not accessible",
            ));
        }
        if field.access & 8 != 0 {
            if field.owner != guest_unsafe::CLASS {
                let ty = self.dex.type_id(&field.owner).ok_or("Static field owner")?;
                self.initialize(ty)?;
            }
        } else if !self.subclass(&self.object(object)?.class, &field.owner)? {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Object is not an instance of the declaring class",
            ));
        }
        Ok(())
    }
    fn reflected_read(&mut self, field: &Field, object: u32) -> Result<u64> {
        self.field_receiver(field, object)?;
        if field.owner == guest_unsafe::CLASS && field.name == "theUnsafe" {
            return self.guest_unsafe_singleton().map(|id| id as u64);
        }
        if let Some(index) = field.index {
            return if field.access & 8 != 0 {
                Ok(*self.statics.get(&index).unwrap_or(&0))
            } else {
                self.load_field(object, index)
            };
        }
        if let Some(slot) = pair::field_slot(&field.owner, &field.name) {
            return Ok(self.object(object)?.fields.get(&slot).copied().unwrap_or(0));
        }
        match &self.object(object)?.payload {
            Payload::Record(values) => Ok(*values.get(&field.name).unwrap_or(&0)),
            Payload::CollectionWrapper { target, mutex, .. } => Ok(if field.name == "mutex" {
                if *mutex == 0 {
                    object as u64
                } else {
                    *mutex as u64
                }
            } else {
                *target as u64
            }),
            _ => Err("Native reflected field storage is not implemented".into()),
        }
    }
    fn reflected_write(&mut self, field: &Field, object: u32, value: u64) -> Result<()> {
        self.field_receiver(field, object)?;
        if field.access & 16 != 0
            && (field.access & 8 != 0 || !field.accessible || field.index.is_none())
        {
            return Err(fault(
                "Ljava/lang/IllegalAccessException;",
                "This final field cannot be changed",
            ));
        }
        if let Some(index) = field.index {
            if field.access & 8 != 0 {
                self.statics.insert(index, value);
                Ok(())
            } else {
                self.store_field(object, index, value)
            }
        } else {
            let Payload::Record(values) = &mut self.object_mut(object)?.payload else {
                return Err("Native reflected field storage is not writable".into());
            };
            values.insert(field.name.clone(), value);
            Ok(())
        }
    }
    pub(super) fn reflection_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Reflection signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Reflection argument count");
        if class == "Ljava/lang/reflect/Modifier;" {
            let mask = match method {
                "isPublic(I)Z" => 1,
                "isPrivate(I)Z" => 2,
                "isProtected(I)Z" => 4,
                "isStatic(I)Z" => 8,
                "isFinal(I)Z" => 16,
                "isSynchronized(I)Z" => 32,
                "isVolatile(I)Z" => 64,
                "isTransient(I)Z" => 128,
                "isNative(I)Z" => 256,
                "isInterface(I)Z" => 512,
                "isAbstract(I)Z" => 1024,
                "isStrict(I)Z" => 2048,
                _ => return Ok(None),
            };
            return Ok(Some((arg(0)? & mask != 0) as u64));
        }
        if class == "Ljava/lang/Class;"
            && matches!(
                method,
                "getDeclaredFields()[Ljava/lang/reflect/Field;"
                    | "getFields()[Ljava/lang/reflect/Field;"
            )
        {
            let Payload::Class(owner) = &self.object(arg(0)?)?.payload else {
                return Err("Expected Class object".into());
            };
            let owner = owner.clone();
            return self
                .reflected_fields_array(&owner, method.starts_with("getFields("))
                .map(|array| Some(array as u64));
        }
        if class == "Ljava/lang/Class;"
            && method == "getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;"
        {
            let Payload::Class(owner) = &self.object(arg(0)?)?.payload else {
                return Err("Expected Class object".into());
            };
            let owner = owner.clone();
            let name = self.text(arg(1)?)?;
            let field = self.declared_field(&owner, &name)?;
            return Ok(Some(
                self.allocate("Ljava/lang/reflect/Field;", Payload::ReflectedField(field))? as u64,
            ));
        }
        if !matches!(
            class,
            "Ljava/lang/reflect/Field;" | "Ljava/lang/reflect/AccessibleObject;"
        ) {
            return Ok(None);
        }
        let id = arg(0)?;
        let Payload::ReflectedField(field) = &self.object(id)?.payload else {
            return Err("Expected reflected Field".into());
        };
        let mut field = field.clone();
        let value = match method {
            "getName()Ljava/lang/String;" => self.string(&field.name)? as u64,
            "getType()Ljava/lang/Class;" => self.class_object(&field.descriptor)? as u64,
            "getDeclaringClass()Ljava/lang/Class;" => self.class_object(&field.owner)? as u64,
            "getModifiers()I" => field.access as u64,
            "equals(Ljava/lang/Object;)Z" => {
                let other = arg(1)?;
                if other == 0 {
                    0
                } else if let Payload::ReflectedField(other) = &self.object(other)?.payload {
                    (field.owner == other.owner
                        && field.name == other.name
                        && field.descriptor == other.descriptor) as u64
                } else {
                    0
                }
            }
            "hashCode()I" => {
                let hash = |value: &str| {
                    value
                        .encode_utf16()
                        .fold(0u32, |h, c| h.wrapping_mul(31).wrapping_add(c as u32))
                };
                let owner = field
                    .owner
                    .strip_prefix('L')
                    .and_then(|s| s.strip_suffix(';'))
                    .unwrap_or(&field.owner)
                    .replace('/', ".");
                (hash(&owner) ^ hash(&field.name)) as u64
            }
            "isSynthetic()Z" => (field.access & 0x1000 != 0) as u64,
            "isEnumConstant()Z" => (field.access & 0x4000 != 0) as u64,
            "isAccessible()Z" => field.accessible as u64,
            "setAccessible(Z)V" => {
                field.accessible = arg(1)? != 0;
                self.object_mut(id)?.payload = Payload::ReflectedField(field);
                0
            }
            "get(Ljava/lang/Object;)Ljava/lang/Object;" => {
                let bits = self.reflected_read(&field, arg(1)?)?;
                if field.descriptor.len() == 1 {
                    self.box_value(
                        field.descriptor.chars().next().ok_or("Field descriptor")?,
                        bits,
                    )? as u64
                } else {
                    bits
                }
            }
            "getInt(Ljava/lang/Object;)I"
            | "getLong(Ljava/lang/Object;)J"
            | "getBoolean(Ljava/lang/Object;)Z" => {
                let bits = self.reflected_read(&field, arg(1)?)?;
                let from = field.descriptor.chars().next().ok_or("Field descriptor")?;
                let to = if method.starts_with("getInt") {
                    'I'
                } else if method.starts_with("getLong") {
                    'J'
                } else {
                    'Z'
                };
                widen(bits, from, to).ok_or_else(|| {
                    fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Field cannot be converted to the requested primitive type",
                    )
                })?
            }
            "set(Ljava/lang/Object;Ljava/lang/Object;)V" => {
                let value = arg(2)?;
                let bits = if field.descriptor.starts_with(['L', '[']) {
                    if value != 0
                        && !self.subclass(&self.object(value)?.class, &field.descriptor)?
                    {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Wrong field value type",
                        ));
                    }
                    value as u64
                } else {
                    if value == 0 {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Null cannot be assigned to a primitive field",
                        ));
                    }
                    let Payload::Boxed { kind, bits } = self.object(value)?.payload else {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Primitive field requires a boxed value",
                        ));
                    };
                    widen(
                        bits,
                        kind,
                        field.descriptor.chars().next().ok_or("Field descriptor")?,
                    )
                    .ok_or_else(|| {
                        fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Wrong primitive field type",
                        )
                    })?
                };
                self.reflected_write(&field, arg(1)?, bits)?;
                0
            }
            "setInt(Ljava/lang/Object;I)V" => {
                let to = field.descriptor.chars().next().ok_or("Field descriptor")?;
                let bits = widen(arg(2)? as u64, 'I', to).ok_or_else(|| {
                    fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Int cannot be assigned to this field",
                    )
                })?;
                self.reflected_write(&field, arg(1)?, bits)?;
                0
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}
