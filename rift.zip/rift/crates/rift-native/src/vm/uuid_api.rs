//! UUID values and a v4 factory backed by the operating system's random source.
use super::*;
pub(super) fn display(m: u64, l: u64) -> String {
    format!(
        "{:08x}-{:04x}-{:04x}-{:04x}-{:012x}",
        m >> 32,
        (m >> 16) & 65535,
        m & 65535,
        l >> 48,
        l & 0xffffffffffff
    )
}
fn parse(text: &str) -> Option<(u64, u64)> {
    if text.len() > 36 {
        return None;
    }
    let parts: Vec<_> = text.split('-').collect();
    if parts.len() != 5 {
        return None;
    }
    let mut n = [0u64; 5];
    for (i, (part, width)) in parts.iter().zip([8, 4, 4, 4, 12]).enumerate() {
        if part.is_empty() || part.len() > width || !part.bytes().all(|v| v.is_ascii_hexdigit()) {
            return None;
        }
        n[i] = u64::from_str_radix(part, 16).ok()?;
    }
    Some(((n[0] << 32) | (n[1] << 16) | n[2], (n[3] << 48) | n[4]))
}
impl Runtime {
    pub(super) fn uuid_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("UUID signature")?;
        if class != "Ljava/util/UUID;" {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("UUID argument count");
        let wide = |i: usize| -> Result<u64> { Ok(arg(i)? as u64 | ((arg(i + 1)? as u64) << 32)) };
        if method == "randomUUID()Ljava/util/UUID;" {
            let mut bytes = [0u8; 16];
            let mut count = 0;
            while count < 16 {
                let n =
                    unsafe { libc::getrandom(bytes[count..].as_mut_ptr().cast(), 16 - count, 0) };
                if n < 0 {
                    let e = std::io::Error::last_os_error();
                    if e.kind() == std::io::ErrorKind::Interrupted {
                        continue;
                    }
                    return Err(e.into());
                }
                if n == 0 {
                    return Err("Random source returned no data".into());
                }
                count += n as usize;
            }
            bytes[6] = (bytes[6] & 15) | 0x40;
            bytes[8] = (bytes[8] & 63) | 0x80;
            let most = u64::from_be_bytes(bytes[..8].try_into()?);
            let least = u64::from_be_bytes(bytes[8..].try_into()?);
            return Ok(Some(
                self.allocate(class, Payload::Uuid(most, least))? as u64
            ));
        }
        if method == "fromString(Ljava/lang/String;)Ljava/util/UUID;" {
            let text = self.text(arg(0)?)?;
            let (m, l) = parse(&text).ok_or_else(|| {
                fault(
                    "Ljava/lang/IllegalArgumentException;",
                    "Invalid UUID string",
                )
            })?;
            return Ok(Some(self.allocate(class, Payload::Uuid(m, l))? as u64));
        }
        let id = arg(0)?;
        if method == "<init>(JJ)V" {
            self.object_mut(id)?.payload = Payload::Uuid(wide(1)?, wide(3)?);
            return Ok(Some(0));
        }
        let Payload::Uuid(m, l) = self.object(id)?.payload else {
            return Err("UUID payload".into());
        };
        Ok(Some(match method {
            "getMostSignificantBits()J" => m,
            "getLeastSignificantBits()J" => l,
            "toString()Ljava/lang/String;" => self.string(&display(m, l))? as u64,
            "version()I" => (m >> 12) & 15,
            "variant()I" => {
                if l >> 63 == 0 {
                    0
                } else if l >> 62 == 2 {
                    2
                } else if l >> 61 == 6 {
                    6
                } else {
                    7
                }
            }
            "equals(Ljava/lang/Object;)Z" => self
                .heap
                .get(&arg(1)?)
                .is_some_and(|o| matches!(o.payload,Payload::Uuid(x,y) if x==m&&y==l))
                as u64,
            "hashCode()I" => {
                let bits = m ^ l;
                ((bits >> 32) as u32 ^ bits as u32) as u64
            }
            "compareTo(Ljava/util/UUID;)I" | "compareTo(Ljava/lang/Object;)I" => {
                let Payload::Uuid(x, y) = self.object(arg(1)?)?.payload else {
                    return Err(fault("Ljava/lang/ClassCastException;", "Expected UUID"));
                };
                (m as i64)
                    .cmp(&(x as i64))
                    .then((l as i64).cmp(&(y as i64))) as i32 as u32 as u64
            }
            "timestamp()J" | "clockSequence()I" | "node()J" => {
                if ((m >> 12) & 15) != 1 {
                    return Err(fault(
                        "Ljava/lang/UnsupportedOperationException;",
                        "UUID is not time based",
                    ));
                }
                match method {
                    "timestamp()J" => {
                        ((m & 0xfff) << 48) | (((m >> 16) & 0xffff) << 32) | (m >> 32)
                    }
                    "clockSequence()I" => (l >> 48) & 0x3fff,
                    _ => l & 0xffffffffffff,
                }
            }
            _ => return Ok(None),
        }))
    }
}
