import java.util.*;
public final class NumberParseVectors {
 static String units(String text){StringBuilder s=new StringBuilder();for(int i=0;i<text.length();i++)s.append(String.format("%04x",(int)text.charAt(i)));return s.toString();}
 public static void main(String[] args){
  System.out.print("{\"digit_ranges\":[");boolean comma=false;int start=-1,previous=-1,first=0;
  for(int c=0;c<=65536;c++){
   int value=c==65536?-1:Character.digit((char)c,36);
   if(start>=0&&(value<0||value!=previous+1)){if(comma)System.out.print(",");comma=true;System.out.print("["+start+","+(c-1)+","+first+"]");start=-1;}
   if(value>=0&&start<0){start=c;first=value;}previous=value;
  }
  ArrayList<String> inputs=new ArrayList<String>(Arrays.asList(null,"","+","-","0","+0","-0","127","128","-128","-129","32767","32768","-32768","-32769","2147483647","2147483648","-2147483648","-2147483649","9223372036854775807","9223372036854775808","-9223372036854775808","-9223372036854775809","01110000","0xff","ff","7f","FFFFFFFF","\u0661\u0662\u0667","\uff17\uff26","\u0967\u0968"," ","\u0000","+\u0e51\u0e52","\ud835\udfcf","\ud800"));
  Random random=new Random(0x5041525345L);for(int i=0;i<80;i++)inputs.add(Long.toString(i<40?random.nextInt(65536)-32768:random.nextLong(),2+i%35));
  System.out.print("],\"cases\":[");comma=false;
  for(int width:new int[]{8,16,32,64})for(int radix:new int[]{-1,1,2,8,10,16,36,37})for(String input:inputs){
   String result;try{long value;switch(width){case 8:value=Byte.parseByte(input,radix);break;case 16:value=Short.parseShort(input,radix);break;case 32:value=Integer.parseInt(input,radix);break;default:value=Long.parseLong(input,radix);break;}result="\"value\":"+value;}catch(NumberFormatException expected){result="\"error\":true";}
   if(comma)System.out.print(",");comma=true;
   System.out.print("{\"width\":"+width+",\"radix\":"+radix+",\"input\":"+(input==null?"null":"\""+units(input)+"\"")+","+result+"}");
  }
  System.out.println("]}");
 }
}
