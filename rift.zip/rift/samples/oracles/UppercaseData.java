import java.util.Locale;
/** Sparse full-uppercase facts from the pinned stock Java8 English locale. */
public final class UppercaseData {
 static String hex(String s){StringBuilder out=new StringBuilder();for(int i=0;i<s.length();i++){String h=Integer.toHexString(s.charAt(i));for(int n=h.length();n<4;n++)out.append('0');out.append(h);}return out.toString();}
 public static void main(String[] ignored){
  System.out.print("{\"locale\":\"en-US\",\"mappings\":[");boolean comma=false;
  for(int cp=0;cp<=0x10ffff;cp++){
   if(cp>=0xd800&&cp<=0xdfff)continue;
   String source=new String(Character.toChars(cp)),upper=source.toUpperCase(Locale.US);
   if(!source.equals(upper)){if(comma)System.out.print(',');comma=true;System.out.print("["+cp+",\""+hex(upper)+"\"]");}
  }
  System.out.println("]}");
 }
}
