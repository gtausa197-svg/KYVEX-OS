package android.graphics;

/** Compile-time API signatures. This class is excluded from the fixture APK. */
public class Paint {
    public Paint() {}
    public Paint(int flags) {}
    public Paint(Paint source) {}
    public native void setTextSize(float size);
    public native float getTextSize();
    public native void setAntiAlias(boolean value);
    public native boolean isAntiAlias();
    public native void reset();
    public native boolean hasGlyph(String text);
}
