package org.kyvex.extra;
import android.content.Context;
import java.io.*;
public final class ReaderChecks {
 private static int checks;
 private static void check(boolean ok,String reason){if(!ok)throw new IllegalStateException(reason);checks++;}
 public static int verify(Context context){try{
  StringReader text=new StringReader("A\ud83d\ude00Z");check(text.read()==65&&text.read()==0xd83d&&text.read()==0xde00,"Reader returns UTF16 units");
  text.mark(8);check(text.read()==90&&text.read()==-1,"StringReader EOF");text.reset();check(text.read()==90&&text.skip(-1)==0&&text.ready(),"StringReader mark reset and EOF skip");
  StringReader beginning=new StringReader("xy");beginning.read();beginning.reset();check(beginning.read()==120&&beginning.skip(-1)==-1&&beginning.read()==120,"StringReader default reset and negative skip");
  BufferedReader lines=new BufferedReader(new StringReader("one\r\ntwo\n\nthree\rfour"));check("one".equals(lines.readLine())&&"two".equals(lines.readLine())&&"".equals(lines.readLine())&&"three".equals(lines.readLine())&&"four".equals(lines.readLine())&&lines.readLine()==null,"CR LF CRLF and final unterminated line");
  char[] chars=new char[4];StringReader bulk=new StringReader("cat");check(bulk.read(chars,1,3)==3&&chars[1]=='c'&&chars[3]=='t',"Reader char array offset");
  check(bulk.read(chars)==-1&&bulk.read(new char[0])==0,"zero-length read at EOF");boolean rejected=false;try{bulk.read(chars,-1,1);}catch(IndexOutOfBoundsException expected){rejected=true;}check(rejected,"Reader array range validation");
  byte[] data=new byte[8197];for(int i=0;i<8191;i++)data[i]=65;data[8191]=(byte)0xf0;data[8192]=(byte)0x9f;data[8193]=(byte)0x98;data[8194]=(byte)0x80;data[8195]=13;data[8196]=10;
  FileOutputStream out=context.openFileOutput("reader-utf8",0);out.write(data);out.close();FileInputStream input=context.openFileInput("reader-utf8");InputStreamReader decoded=new InputStreamReader(input,"UTF-8");BufferedReader buffered=new BufferedReader(decoded,3);
  String line=buffered.readLine();check(line.length()==8193&&line.charAt(8191)==0xd83d&&line.charAt(8192)==0xde00&&"UTF8".equals(decoded.getEncoding()),"UTF8 code point crosses byte buffer boundary");
  check(!buffered.ready()&&buffered.readLine()==null,"ready skips pending LF without inventing another line");buffered.close();boolean byteClosed=false,charClosed=false;try{input.read();}catch(IOException expected){byteClosed=true;}try{buffered.readLine();}catch(IOException expected){charClosed=true;}check(byteClosed&&charClosed&&decoded.getEncoding()==null,"reader close propagates and encoding clears");
  BufferedReader process=new BufferedReader(new FileReader("/proc/self/cmdline"));check(context.getPackageName().equals(process.readLine().trim()),"process name comes from virtual proc file");process.close();
  process=new BufferedReader(new FileReader("/proc/1/cmdline"));check(context.getPackageName().equals(process.readLine().trim())&&!new File("/proc/self/cmdline").canWrite(),"guest PID alias and read-only metadata");process.close();
  out=context.openFileOutput("reader-malformed",0);out.write(new byte[]{(byte)0xed,(byte)0xa0,(byte)0x80,65,(byte)0xe2,(byte)0x82});out.close();buffered=new BufferedReader(new FileReader(context.getFileStreamPath("reader-malformed")));line=buffered.readLine();check(line.length()==3&&line.charAt(0)==0xfffd&&line.charAt(1)==65&&line.charAt(2)==0xfffd,"Java malformed UTF8 replacement and final partial sequence");buffered.close();
  byte[] everyByte=new byte[256];for(int i=0;i<256;i++)everyByte[i]=(byte)i;out=context.openFileOutput("reader-legacy",0);out.write(everyByte);out.close();
  InputStreamReader legacy=new InputStreamReader(context.openFileInput("reader-legacy"),"iso-8859-1");boolean matches=true;for(int i=0;i<256;i++)matches=matches&&legacy.read()==i;check(matches&&legacy.read()==-1&&"ISO8859_1".equals(legacy.getEncoding()),"ISO-8859-1 maps all 256 bytes including control characters");legacy.close();
  legacy=new InputStreamReader(context.openFileInput("reader-legacy"),"US-ASCII");matches=true;for(int i=0;i<256;i++)matches=matches&&legacy.read()==(i<128?i:0xfffd);check(matches&&legacy.read()==-1&&"ASCII".equals(legacy.getEncoding()),"ASCII replaces each invalid high byte like Java");legacy.close();
  rejected=false;input=context.openFileInput("reader-legacy");try{new InputStreamReader(input,(String)null);}catch(NullPointerException expected){rejected=true;}check(rejected,"null charset throws Java exception");input.close();
  return checks;
 }catch(IOException error){throw new IllegalStateException(error);}}
}
