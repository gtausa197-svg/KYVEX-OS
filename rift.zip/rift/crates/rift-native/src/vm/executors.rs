//! Actual reusable guest executor workers. The tiny own DEX loop keeps task.run
//! on owned interpreter frames, so task waits never borrow a suspended Rust stack.
use super::*;
use std::time::Instant;
pub(super) mod scheduled;
const WORKER: &str = "Lorg/kyvex/rift/internal/PoolWorker;";
const ACCESS: &str = "Lorg/kyvex/rift/internal/PoolAccess;";
const FACTORY: &str = "Ljava/util/concurrent/Executors$DefaultThreadFactory;";
pub(super) const SERVICE: &str = "Ljava/util/concurrent/ExecutorService;";
pub(super) const DELEGATED: &str = "Ljava/util/concurrent/Executors$DelegatedExecutorService;";
pub(super) const FINALIZABLE_DELEGATED: &str =
    "Ljava/util/concurrent/Executors$FinalizableDelegatedExecutorService;";
const SUPPORT: &[u8] = include_bytes!("../../support/pool-worker.dex");

fn service_method(name: &str, descriptor: &str) -> bool {
    matches!(
        (name, descriptor),
        ("execute", "(Ljava/lang/Runnable;)V")
            | ("shutdown", "()V")
            | ("shutdownNow", "()Ljava/util/List;")
            | ("isShutdown" | "isTerminated", "()Z")
            | ("awaitTermination", "(JLjava/util/concurrent/TimeUnit;)Z")
            | (
                "submit",
                "(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;"
            )
            | (
                "submit",
                "(Ljava/lang/Runnable;Ljava/lang/Object;)Ljava/util/concurrent/Future;"
            )
            | (
                "submit",
                "(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;"
            )
            | ("invokeAll", "(Ljava/util/Collection;)Ljava/util/List;")
            | (
                "invokeAll",
                "(Ljava/util/Collection;JLjava/util/concurrent/TimeUnit;)Ljava/util/List;"
            )
            | ("invokeAny", "(Ljava/util/Collection;)Ljava/lang/Object;")
            | (
                "invokeAny",
                "(Ljava/util/Collection;JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;"
            )
    )
}

fn scheduled_method(name: &str, descriptor: &str) -> bool {
    matches!(
        (name, descriptor),
        (
            "schedule",
            "(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;"
        ) | (
            "schedule",
            "(Ljava/util/concurrent/Callable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;"
        ) | (
            "scheduleAtFixedRate" | "scheduleWithFixedDelay",
            "(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;"
        )
    )
}

fn idle_deadline(
    pool: &concurrency::Executor,
    idle: Instant,
    due: Option<Instant>,
) -> Option<Instant> {
    // Keep one worker available for accepted delayed work, even when core is zero.
    let timed = (pool.timeout || pool.workers.len() > pool.core as usize)
        && (due.is_none() || pool.workers.len() > 1);
    if timed {
        idle.checked_add(std::time::Duration::from_nanos(pool.keep_alive as u64))
    } else {
        None
    }
}

#[derive(Default)]
pub(super) struct State {
    loaded: bool,
    next_factory: u64,
    next_scheduled: u64,
}
#[cfg(test)]
mod artifact_tests {
    use super::*;
    use sha2::{Digest, Sha256};
    #[test]
    fn own_pool_loop_is_bound_to_sources_and_contains_no_compile_only_bridge() {
        let pin: serde_json::Value =
            serde_json::from_str(include_str!("../../support/pool-worker.json")).unwrap();
        let hash = |bytes: &[u8]| format!("{:x}", Sha256::digest(bytes));
        assert_eq!(hash(SUPPORT), pin["dex_sha256"]);
        assert_eq!(
            hash(include_bytes!(
                "../../support/java/org/kyvex/rift/internal/PoolWorker.java"
            )),
            pin["sources"]["java/org/kyvex/rift/internal/PoolWorker.java"]
        );
        assert_eq!(
            hash(include_bytes!(
                "../../support/compile-only/org/kyvex/rift/internal/PoolAccess.java"
            )),
            pin["sources"]["compile-only/org/kyvex/rift/internal/PoolAccess.java"]
        );
        let tool: serde_json::Value = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../samples/TOOLCHAIN.json"
        )))
        .unwrap();
        assert_eq!(pin["r8"], tool);
        let dex = Dex::parse(SUPPORT).unwrap();
        assert_eq!(
            hash(include_bytes!(
                "../../support/java/org/kyvex/rift/internal/ScheduledTask.java"
            )),
            pin["sources"]["java/org/kyvex/rift/internal/ScheduledTask.java"]
        );
        assert_eq!(dex.classes.len(), 2);
        assert!(dex.has_class(WORKER) && dex.has_class(scheduled::TASK) && !dex.has_class(ACCESS));
        assert!(
            dex.classes
                .values()
                .flat_map(|class| &class.methods)
                .all(|method| dex.bodies.contains_key(method))
        );
    }
}
#[derive(Clone)]
pub(super) struct Worker {
    pub pool: u32,
    pub thread: u32,
    pub first: u32,
    pub active: u32,
    idle: Option<Instant>,
    exited: bool,
}
#[derive(Clone)]
pub(super) struct Factory {
    pub group: u32,
    pool: u64,
    next: u64,
}
impl Runtime {
    pub(super) fn executor_receiver(
        &self,
        object: &Object,
        name: &str,
        descriptor: &str,
    ) -> Result<Option<u32>> {
        let Payload::ExecutorWrapper(mut target) = object.payload else {
            return Ok(None);
        };
        if !(service_method(name, descriptor)
            || object.class == scheduled::WRAPPER && scheduled_method(name, descriptor))
        {
            return Ok(None);
        }
        for _ in 0..128 {
            if let Payload::ExecutorWrapper(next) = self.object(target)?.payload {
                target = next;
            } else {
                return Ok(Some(target));
            }
        }
        Err("Executor delegation depth limit".into())
    }

    pub(super) fn executor_default_factory(&mut self) -> Result<u32> {
        let current = self.ensure_main_thread()?;
        let group = self.thread_group(current)?;
        self.executors.next_factory = self
            .executors
            .next_factory
            .checked_add(1)
            .ok_or("Executor factory sequence exhausted")?;
        self.allocate(
            FACTORY,
            Payload::ThreadFactory(Factory {
                group,
                pool: self.executors.next_factory,
                next: 1,
            }),
        )
    }
    fn ensure_pool_support(&mut self) -> Result<()> {
        if self.executors.loaded {
            return Ok(());
        }
        if self
            .dex
            .classes
            .keys()
            .any(|ty| self.dex.ty(*ty).starts_with("Lorg/kyvex/rift/internal/"))
        {
            return Err("APK defines reserved Native support namespace".into());
        }
        self.dex.append(Dex::parse(SUPPORT)?)?;
        self.executors.loaded = true;
        Ok(())
    }
    fn pool(&self, id: u32) -> Result<&concurrency::Executor> {
        match &self.object(id)?.payload {
            Payload::Executor(pool) => Ok(pool),
            _ => Err("Expected initialized guest executor pool".into()),
        }
    }
    fn pool_mut(&mut self, id: u32) -> Result<&mut concurrency::Executor> {
        match &mut self.object_mut(id)?.payload {
            Payload::Executor(pool) => Ok(pool),
            _ => Err("Expected initialized guest executor pool".into()),
        }
    }
    fn pool_worker(&self, id: u32) -> Result<&Worker> {
        match &self.object(id)?.payload {
            Payload::PoolWorker(worker) => Ok(worker),
            _ => Err("Expected private Native executor worker".into()),
        }
    }
    fn pool_worker_mut(&mut self, id: u32) -> Result<&mut Worker> {
        match &mut self.object_mut(id)?.payload {
            Payload::PoolWorker(worker) => Ok(worker),
            _ => Err("Expected private Native executor worker".into()),
        }
    }
    fn pool_queue_len(&self, id: u32) -> Result<usize> {
        let queue = self.object(self.pool(id)?.queue)?;
        if let Payload::ScheduledQueue(queue) = &queue.payload {
            return Ok(queue.len());
        }
        if matches!(queue.payload, Payload::HandoffQueue(Some(_))) {
            return Ok(0);
        }
        if !matches!(
            queue.class.as_str(),
            "Ljava/util/concurrent/LinkedBlockingQueue;"
                | "Ljava/util/concurrent/LinkedBlockingDeque;"
        ) {
            return Err("Executable pools require a supported native work queue".into());
        }
        match &queue.payload {
            Payload::List(values) => Ok(values.len()),
            _ => Err("Executable pool queue state".into()),
        }
    }
    fn pool_poll(&mut self, id: u32, include_delayed: bool) -> Result<u32> {
        let queue = self.pool(id)?.queue;
        if let Payload::ScheduledQueue(queue) = &mut self.object_mut(queue)?.payload {
            return Ok(queue.poll(include_delayed));
        }
        if matches!(self.object(queue)?.payload, Payload::HandoffQueue(Some(_))) {
            return Ok(self.transfer_now(queue, 0)?.unwrap_or(0) as u32);
        }
        Ok(self
            .collections_api("Ljava/util/Queue;->poll()Ljava/lang/Object;", &[queue])?
            .ok_or("Pool queue poll")? as u32)
    }
    pub(super) fn pool_accepts_handoff(&self, id: u32, queue: u32) -> Result<bool> {
        let worker = self.pool_worker(id)?;
        let pool = self.pool(worker.pool)?;
        Ok(pool.queue == queue
            && !pool.shutdown
            && !pool.stopping
            && pool.workers.len() <= pool.maximum as usize
            && worker.idle.is_some()
            && worker.first == 0
            && worker.active == 0
            && !worker.exited)
    }
    pub(super) fn assign_pool_handoff(&mut self, id: u32, task: u32) -> Result<()> {
        self.pool_worker_mut(id)?.first = task;
        Ok(())
    }
    fn create_pool_worker(&mut self, id: u32, first: u32) -> Result<bool> {
        let pool = self.pool(id)?;
        if pool.stopping
            || pool.workers.len() >= pool.maximum as usize
            || pool.shutdown && (first != 0 || self.pool_queue_len(id)? == 0)
        {
            return Ok(false);
        }
        self.ensure_pool_support()?;
        let mut roots = self.scoped_library_roots(&[id, first])?;
        let worker = self.allocate(
            WORKER,
            Payload::PoolWorker(Worker {
                pool: id,
                thread: 0,
                first,
                active: 0,
                idle: None,
                exited: false,
            }),
        )?;
        roots.keep(worker)?;
        let factory = self.pool(id)?.factory;
        let thread = self.collection_dispatch(
            factory,
            "Ljava/util/concurrent/ThreadFactory;",
            "newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;",
            &[worker],
        )? as u32;
        if thread == 0 {
            return Ok(false);
        }
        roots.keep(thread)?;
        if !self.subclass(&self.object(thread)?.class, "Ljava/lang/Thread;")? {
            return Err("ThreadFactory returned a non-Thread".into());
        }
        if !self
            .scheduler
            .records
            .get(&thread)
            .is_some_and(|record| matches!(record.state, scheduler::State::New))
        {
            return Err(fault(
                "Ljava/lang/IllegalThreadStateException;",
                "ThreadFactory must return an unstarted Thread",
            ));
        }
        let pool = self.pool(id)?;
        if pool.stopping
            || pool.workers.len() >= pool.maximum as usize
            || pool.shutdown && (first != 0 || self.pool_queue_len(id)? == 0)
        {
            return Ok(false);
        }
        self.pool_worker_mut(worker)?.thread = thread;
        let pool = self.pool_mut(id)?;
        pool.workers.push(worker);
        pool.largest = pool.largest.max(pool.workers.len());
        // Pool creation is an atomic library operation. Ordinary Thread.start
        // keeps its public yielding behavior; these workers run at the next slice.
        let allowed = self.suspension_allowed;
        self.suspension_allowed = false;
        let started = self.start_guest_thread(thread);
        self.suspension_allowed = allowed;
        if let Err(error) = started {
            self.pool_mut(id)?.workers.retain(|value| *value != worker);
            self.pool_worker_mut(worker)?.thread = 0;
            return Err(error);
        }
        Ok(true)
    }
    fn reject_pool_task(&mut self, id: u32, task: u32) -> Result<u64> {
        let handler = self.pool(id)?.handler;
        self.collection_dispatch(
            handler,
            "Ljava/util/concurrent/RejectedExecutionHandler;",
            "rejectedExecution(Ljava/lang/Runnable;Ljava/util/concurrent/ThreadPoolExecutor;)V",
            &[task, id],
        )
    }
    fn execute_pool_task(&mut self, id: u32, task: u32) -> Result<u64> {
        self.object(task)?;
        if !self.subclass(&self.object(task)?.class, "Ljava/lang/Runnable;")? {
            return Err("Executor task does not implement Runnable".into());
        }
        let _roots = self.scoped_library_roots(&[id, task])?;
        self.pool_queue_len(id)?;
        if self.pool(id)?.shutdown {
            return self.reject_pool_task(id, task);
        }
        if self.pool(id)?.workers.len() < (self.pool(id)?.core as usize)
            && self.create_pool_worker(id, task)?
        {
            return Ok(0);
        }
        let queue = self.pool(id)?.queue;
        let offered = if matches!(self.object(queue)?.payload, Payload::HandoffQueue(Some(_))) {
            self.transfer_now(queue, task)?.is_some()
        } else {
            self.collections_api(
                "Ljava/util/Queue;->offer(Ljava/lang/Object;)Z",
                &[queue, task],
            )?
            .ok_or("Pool queue offer")?
                != 0
        };
        if offered {
            if self.pool(id)?.workers.is_empty() {
                self.create_pool_worker(id, 0)?;
            }
            return Ok(0);
        }
        if self.create_pool_worker(id, task)? {
            return Ok(0);
        }
        self.reject_pool_task(id, task)
    }
    fn current_pool_worker(&self, id: u32) -> Result<Worker> {
        let worker = self.pool_worker(id)?;
        if worker.exited
            || worker.thread == 0
            || worker.thread != self.current_thread
            || !self.pool(worker.pool)?.workers.contains(&id)
        {
            return Err("Private executor bridge called outside its owning guest worker".into());
        }
        Ok(worker.clone())
    }
    fn next_pool_task(&mut self, id: u32) -> Result<u64> {
        let worker = self.current_pool_worker(id)?;
        if worker.active != 0 {
            return Err("Executor worker already owns an active task".into());
        }
        let pool = self.pool(worker.pool)?;
        if !pool.stopping {
            self.scheduler
                .records
                .get_mut(&self.current_thread)
                .ok_or("Pool guest Thread")?
                .interrupted = false;
        }
        let pool = self.pool(worker.pool)?;
        if worker.first != 0 {
            let state = self.pool_worker_mut(id)?;
            state.first = 0;
            state.active = worker.first;
            state.idle = None;
            return Ok(worker.first as u64);
        }
        if pool.stopping
            || pool.shutdown && self.pool_queue_len(worker.pool)? == 0
            || pool.workers.len() > pool.maximum as usize
        {
            return Ok(0);
        }
        let task = self.pool_poll(worker.pool, false)?;
        if task != 0 {
            let state = self.pool_worker_mut(id)?;
            state.active = task;
            state.idle = None;
            return Ok(task as u64);
        }
        let pool = self.pool(worker.pool)?;
        let due = self.scheduled_deadline(pool.queue)?;
        let idle = *self
            .pool_worker_mut(id)?
            .idle
            .get_or_insert_with(Instant::now);
        let until = idle_deadline(self.pool(worker.pool)?, idle, due);
        if until.is_some_and(|time| time <= Instant::now()) {
            return Ok(0);
        }
        let wake = until.into_iter().chain(due).min();
        self.suspend(scheduler::Wait::Executor {
            worker: id,
            until: wake,
        })
    }
    pub(super) fn pool_worker_ready(&self, id: u32, until: Option<Instant>) -> Result<bool> {
        let worker = self.pool_worker(id)?;
        let pool = self.pool(worker.pool)?;
        let Some(idle) = worker.idle else {
            return Ok(true);
        };
        let queued = self.pool_queue_len(worker.pool)?;
        let due = self.scheduled_deadline(pool.queue)?;
        let wake = idle_deadline(pool, idle, due).into_iter().chain(due).min();
        Ok(worker.first != 0
            || pool.stopping
            || pool.shutdown && queued == 0
            || pool.workers.len() > pool.maximum as usize
            || due.is_none() && queued > 0
            || wake != until
            || until.is_some_and(|time| time <= Instant::now()))
    }
    fn reset_pool_idle_waits(&mut self, id: u32) -> Result<()> {
        let workers = self.pool(id)?.workers.clone();
        for worker in workers {
            let state = self.pool_worker_mut(worker)?;
            if state.active == 0 {
                state.idle = None;
            }
        }
        Ok(())
    }
    pub(super) fn pool_terminated(&self, id: u32) -> Result<bool> {
        Ok(self.pool(id)?.terminated)
    }
    fn try_terminate_pool(&mut self, id: u32) -> Result<()> {
        let pool = self.pool(id)?;
        if !pool.shutdown
            || !pool.workers.is_empty()
            || !pool.stopping && self.pool_queue_len(id)? != 0
            || pool.terminating
            || pool.terminated
        {
            return Ok(());
        }
        self.pool_mut(id)?.terminating = true;
        let result = if let Some(method) = self.callback_method(id, "terminated", "()V")? {
            self.invoke(method, &[id], true).map(|_| ())
        } else {
            Ok(())
        };
        let pool = self.pool_mut(id)?;
        pool.terminating = false;
        pool.terminated = true;
        result
    }
    fn exit_pool_worker(&mut self, id: u32, abrupt: bool) -> Result<u64> {
        let worker = self.current_pool_worker(id)?;
        self.pool_worker_mut(id)?.exited = true;
        self.pool_mut(worker.pool)?
            .workers
            .retain(|value| *value != id);
        self.try_terminate_pool(worker.pool)?;
        let pool = self.pool(worker.pool)?;
        let minimum = if pool.timeout { 0 } else { pool.core as usize };
        if !pool.stopping
            && (!pool.shutdown || self.pool_queue_len(worker.pool)? > 0)
            && (abrupt
                || pool.workers.len() < minimum
                || pool.workers.is_empty() && self.pool_queue_len(worker.pool)? > 0)
        {
            self.create_pool_worker(worker.pool, 0)?;
        }
        Ok(0)
    }
    fn pool_bridge(&mut self, method: &str, a: &[u32]) -> Result<u64> {
        let arg = |index: usize| a.get(index).copied().ok_or("Pool bridge argument count");
        let id = arg(0)?;
        let worker = self.current_pool_worker(id)?;
        match method {
            "next(Lorg/kyvex/rift/internal/PoolWorker;)Ljava/lang/Runnable;" => {
                self.next_pool_task(id)
            }
            "before(Lorg/kyvex/rift/internal/PoolWorker;Ljava/lang/Runnable;)V"
            | "after(Lorg/kyvex/rift/internal/PoolWorker;Ljava/lang/Runnable;Ljava/lang/Throwable;)V" =>
            {
                let task = arg(1)?;
                if task == 0 || worker.active != task {
                    return Err("Pool hook task ownership".into());
                }
                let (name, descriptor, args) = if method.starts_with("before(") {
                    (
                        "beforeExecute",
                        "(Ljava/lang/Thread;Ljava/lang/Runnable;)V",
                        vec![worker.pool, worker.thread, task],
                    )
                } else {
                    let error = arg(2)?;
                    if error != 0
                        && !self.subclass(&self.object(error)?.class, "Ljava/lang/Throwable;")?
                    {
                        return Err("Pool hook Throwable type".into());
                    }
                    (
                        "afterExecute",
                        "(Ljava/lang/Runnable;Ljava/lang/Throwable;)V",
                        vec![worker.pool, task, error],
                    )
                };
                if let Some(index) = self.callback_method(worker.pool, name, descriptor)? {
                    self.invoke(index, &args, true)?;
                }
                Ok(0)
            }
            "done(Lorg/kyvex/rift/internal/PoolWorker;)V" => {
                if worker.active == 0 {
                    return Err("Pool task completion without an active task".into());
                }
                self.pool_worker_mut(id)?.active = 0;
                let pool = self.pool_mut(worker.pool)?;
                pool.completed = pool
                    .completed
                    .checked_add(1)
                    .ok_or("Pool completion count exhausted")?;
                Ok(0)
            }
            "exit(Lorg/kyvex/rift/internal/PoolWorker;Z)V" => {
                self.exit_pool_worker(id, arg(1)? != 0)
            }
            _ => Err("Unknown private pool bridge method".into()),
        }
    }
    pub(super) fn executors_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Executor signature")?;
        if let Some(value) = self.scheduled_api(class, method, a)? {
            return Ok(Some(value));
        }
        if class == ACCESS {
            return self.pool_bridge(method, a).map(Some);
        }
        let arg = |index: usize| a.get(index).copied().ok_or("Executor argument count");
        let facade = match sig {
            "Ljava/util/concurrent/Executors;->unconfigurableExecutorService(Ljava/util/concurrent/ExecutorService;)Ljava/util/concurrent/ExecutorService;" => {
                Some((SERVICE, DELEGATED))
            }
            "Ljava/util/concurrent/Executors;->unconfigurableScheduledExecutorService(Ljava/util/concurrent/ScheduledExecutorService;)Ljava/util/concurrent/ScheduledExecutorService;" => {
                Some((scheduled::SCHEDULED_SERVICE, scheduled::WRAPPER))
            }
            _ => None,
        };
        if let Some((interface, wrapper)) = facade {
            let target = arg(0)?;
            if !self.subclass(&self.object(target)?.class, interface)? {
                return Err(fault(
                    "Ljava/lang/ClassCastException;",
                    "Executor delegate type",
                ));
            }
            return Ok(Some(
                self.allocate(wrapper, Payload::ExecutorWrapper(target))? as u64,
            ));
        }
        let Some(id) = a.first().copied() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        if let Payload::ThreadFactory(factory) = &object.payload {
            if method != "newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;" {
                return Ok(None);
            }
            let factory = factory.clone();
            let target = arg(1)?;
            if target != 0 {
                self.object(target)?;
            }
            let mut roots = self.scoped_library_roots(&[id, target])?;
            let name = self.string(&format!("pool-{}-thread-{}", factory.pool, factory.next))?;
            roots.keep(name)?;
            let thread = self.instantiate("Ljava/lang/Thread;")?;
            roots.keep(thread)?;
            self.thread_metadata_api("Ljava/lang/Thread;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;)V",&[thread,factory.group,target,name])?.ok_or("Default factory Thread construction")?;
            self.thread_metadata_api("Ljava/lang/Thread;->setDaemon(Z)V", &[thread, 0])?;
            self.thread_metadata_api("Ljava/lang/Thread;->setPriority(I)V", &[thread, 5])?;
            let Payload::ThreadFactory(state) = &mut self.object_mut(id)?.payload else {
                unreachable!()
            };
            state.next = state
                .next
                .checked_add(1)
                .ok_or("Factory thread sequence exhausted")?;
            return Ok(Some(thread as u64));
        }
        if method
            == "rejectedExecution(Ljava/lang/Runnable;Ljava/util/concurrent/ThreadPoolExecutor;)V"
        {
            if self.subclass(&object.class, concurrency::DISCARD_POLICY)? {
                return Ok(Some(0));
            }
            if self.subclass(&object.class, concurrency::ABORT_POLICY)? {
                return Err(fault(
                    "Ljava/util/concurrent/RejectedExecutionException;",
                    "executor rejected task",
                ));
            }
        }
        if matches!(object.payload, Payload::ExecutorWrapper(_)) {
            let (name, descriptor) =
                method.split_at(method.find('(').ok_or("Executor descriptor")?);
            if let Some(target) = self.executor_receiver(object, name, descriptor)? {
                let mut words = a.to_vec();
                words[0] = target;
                if let Some(index) = self.callback_method(target, name, descriptor)? {
                    return self.invoke(index, &words, true).map(Some);
                }
                let class = &self.object(target)?.class;
                return self.hle(&format!("{class}->{method}"), &words).map(Some);
            }
        }
        if !matches!(object.payload, Payload::Executor(_)) {
            return Ok(None);
        }
        Ok(Some(match method {
            "execute(Ljava/lang/Runnable;)V" => self.execute_pool_task(id, arg(1)?)?,
            "setCorePoolSize(I)V" => {
                let size = arg(1)?;
                if size > i32::MAX as u32 || size > self.pool(id)?.maximum {
                    return Err(fault("Ljava/lang/IllegalArgumentException;", "core size"));
                }
                let old = self.pool(id)?.core;
                self.pool_mut(id)?.core = size;
                self.reset_pool_idle_waits(id)?;
                if size > old {
                    while self.pool(id)?.workers.len() < size as usize
                        && self.pool_queue_len(id)? > 0
                        && self.create_pool_worker(id, 0)?
                    {}
                }
                0
            }
            "setMaximumPoolSize(I)V" => {
                let size = arg(1)?;
                if size == 0 || size > i32::MAX as u32 || size < self.pool(id)?.core {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "maximum size",
                    ));
                }
                self.pool_mut(id)?.maximum = size;
                self.reset_pool_idle_waits(id)?;
                0
            }
            "setKeepAliveTime(JLjava/util/concurrent/TimeUnit;)V" => {
                let duration = (arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64;
                let nanos = self.timeout_nanos(duration, arg(3)?)?;
                if duration < 0 || nanos == 0 && self.pool(id)?.timeout {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "keepalive time",
                    ));
                }
                self.pool_mut(id)?.keep_alive = nanos;
                self.reset_pool_idle_waits(id)?;
                0
            }
            "allowCoreThreadTimeOut(Z)V" => {
                let enabled = arg(1)? != 0;
                if enabled && self.pool(id)?.keep_alive <= 0 {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "core timeout requires positive keepalive",
                    ));
                }
                self.pool_mut(id)?.timeout = enabled;
                self.reset_pool_idle_waits(id)?;
                0
            }
            "getPoolSize()I" => self.pool(id)?.workers.len() as u64,
            "getLargestPoolSize()I" => self.pool(id)?.largest as u64,
            "getActiveCount()I" => self
                .pool(id)?
                .workers
                .iter()
                .filter(|worker| {
                    self.pool_worker(**worker)
                        .is_ok_and(|state| state.active != 0 || state.first != 0)
                })
                .count() as u64,
            "getCompletedTaskCount()J" => self.pool(id)?.completed,
            "getTaskCount()J" => {
                let pool = self.pool(id)?;
                pool.completed
                    + self.pool_queue_len(id)? as u64
                    + pool
                        .workers
                        .iter()
                        .filter(|worker| {
                            self.pool_worker(**worker)
                                .is_ok_and(|state| state.active != 0 || state.first != 0)
                        })
                        .count() as u64
            }
            "shutdown()V" => {
                self.pool_mut(id)?.shutdown = true;
                self.prune_scheduled_shutdown(id)?;
                self.try_terminate_pool(id)?;
                0
            }
            "shutdownNow()Ljava/util/List;" => {
                let mut roots = self.scoped_library_roots(&[id])?;
                {
                    let pool = self.pool_mut(id)?;
                    pool.shutdown = true;
                    pool.stopping = true;
                }
                let workers = self.pool(id)?.workers.clone();
                for worker in workers {
                    let thread = self.pool_worker(worker)?.thread;
                    if let Some(record) = self.scheduler.records.get_mut(&thread) {
                        record.interrupted = true;
                    }
                }
                let mut tasks = Vec::new();
                while self.pool_queue_len(id)? > 0 {
                    let task = self.pool_poll(id, true)?;
                    roots.keep(task)?;
                    tasks.push(task);
                }
                let result = self.allocate("Ljava/util/ArrayList;", Payload::List(tasks))?;
                roots.keep(result)?;
                self.try_terminate_pool(id)?;
                result as u64
            }
            "isShutdown()Z" => self.pool(id)?.shutdown as u64,
            "isTerminated()Z" => self.pool(id)?.terminated as u64,
            "isTerminating()Z" => (self.pool(id)?.shutdown && !self.pool(id)?.terminated) as u64,
            "awaitTermination(JLjava/util/concurrent/TimeUnit;)Z" => {
                let duration = (arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64;
                let nanos = self.timeout_nanos(duration, arg(3)?)?;
                if self.pool(id)?.terminated {
                    1
                } else if nanos <= 0 {
                    0
                } else {
                    self.check_interrupted()?;
                    return self
                        .suspend(scheduler::Wait::ExecutorTermination {
                            pool: id,
                            until: Self::deadline(nanos as u64),
                        })
                        .map(Some);
                }
            }
            "prestartCoreThread()Z" => {
                if self.pool(id)?.workers.len() < self.pool(id)?.core as usize {
                    self.create_pool_worker(id, 0)? as u64
                } else {
                    0
                }
            }
            "prestartAllCoreThreads()I" => {
                let mut count = 0;
                while self.pool(id)?.workers.len() < self.pool(id)?.core as usize
                    && self.create_pool_worker(id, 0)?
                {
                    count += 1;
                }
                count
            }
            "beforeExecute(Ljava/lang/Thread;Ljava/lang/Runnable;)V"
            | "afterExecute(Ljava/lang/Runnable;Ljava/lang/Throwable;)V"
            | "terminated()V" => 0,
            _ => return Ok(None),
        }))
    }
}
