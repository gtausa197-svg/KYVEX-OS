//! Per-application, bounded in-memory files. No guest path is opened on the host.
//! These files live for one worker session; persistent preferences use their journal.
use std::collections::BTreeMap;
pub type Path = Vec<u16>;
pub const EXTERNAL_STORAGE_ROOT: &str = "/storage/emulated/0";
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Error {
    Invalid,
    Missing,
    Denied,
    Directory,
    Quota,
    External,
}
impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Self::Invalid => "Invalid virtual path",
            Self::Missing => "No such virtual file",
            Self::Denied => "Virtual file access denied",
            Self::Directory => "Virtual path is a directory",
            Self::Quota => "Application file quota exceeded",
            Self::External => "Archive data requires the preopened APK capability",
        })
    }
}
impl std::error::Error for Error {}
type Result<T> = std::result::Result<T, Error>;
pub fn units(text: &str) -> Path {
    text.encode_utf16().collect()
}
pub fn normalize(path: &[u16]) -> Path {
    let mut out = Vec::new();
    for c in path {
        if *c != 47 || out.last() != Some(&47) {
            out.push(*c);
        }
    }
    if out.len() > 1 && out.last() == Some(&47) {
        out.pop();
    }
    out
}
pub fn join(parent: &[u16], child: &[u16]) -> Path {
    if child.is_empty() {
        return if parent.is_empty() {
            vec![47]
        } else {
            normalize(parent)
        };
    }
    let mut out = parent.to_vec();
    if out.is_empty() {
        out.push(47);
    }
    if out.last() != Some(&47) && child.first() != Some(&47) {
        out.push(47);
    }
    out.extend(child);
    normalize(&out)
}
pub fn parent(path: &[u16]) -> Option<Path> {
    let index = path.iter().rposition(|c| *c == 47)?;
    if path.len() == 1 {
        None
    } else {
        Some(path[..index.max(1)].to_vec())
    }
}
pub fn canonical(path: &[u16], cwd: &[u16]) -> Result<Path> {
    if path.contains(&0) || path.len() > 4096 {
        return Err(Error::Invalid);
    }
    let absolute = if path.first() == Some(&47) {
        normalize(path)
    } else {
        join(cwd, path)
    };
    let mut parts: Vec<&[u16]> = Vec::new();
    for part in absolute.split(|c| *c == 47) {
        match part {
            [] | [46] => {}
            [46, 46] => {
                parts.pop();
            }
            _ => parts.push(part),
        }
    }
    let mut out = vec![47];
    for part in parts {
        if out.len() > 1 {
            out.push(47);
        }
        out.extend(part);
    }
    if out.len() > 4096 {
        return Err(Error::Invalid);
    }
    Ok(out)
}
#[derive(Clone)]
pub struct Stat {
    pub directory: bool,
    pub readable: bool,
    pub writable: bool,
    pub executable: bool,
    pub modified: u64,
    pub length: usize,
}
struct Node {
    stat: Stat,
    data: Vec<u8>,
    open: usize,
    external: Option<String>,
}
pub struct Fs {
    pub cwd: Path,
    device_data: Path,
    paths: BTreeMap<Path, u32>,
    nodes: BTreeMap<u32, Node>,
    next: u32,
    pub limit: usize,
}
fn now() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64
}
impl Fs {
    pub fn new(limit: usize, package: &str) -> Self {
        let mut fs = Self {
            cwd: units(&format!("/data/user/0/{package}")),
            device_data: units(&format!("/data/user_de/0/{package}")),
            paths: BTreeMap::new(),
            nodes: BTreeMap::new(),
            next: 1,
            limit,
        };
        let cwd = fs.cwd.clone();
        for path in [
            units("/"),
            units("/data"),
            units("/data/user"),
            units("/data/user/0"),
            cwd.clone(),
        ] {
            fs.insert(path.clone(), true, path == cwd)
                .expect("fixed virtual root quota");
        }
        fs
    }
    pub fn bytes(&self) -> usize {
        self.paths.keys().map(|p| 64 + p.len() * 2).sum::<usize>()
            + self
                .nodes
                .values()
                .map(|n| 128 + n.data.capacity() + n.external.as_ref().map_or(0, |s| s.len()))
                .sum::<usize>()
    }
    fn insert(&mut self, path: Path, directory: bool, writable: bool) -> Result<u32> {
        if self.nodes.len() >= 1024 || self.bytes() + 192 + path.len() * 2 > self.limit {
            return Err(Error::Quota);
        }
        let id = self.next;
        self.next = self.next.checked_add(1).ok_or(Error::Quota)?;
        self.nodes.insert(
            id,
            Node {
                stat: Stat {
                    directory,
                    readable: true,
                    writable,
                    executable: directory,
                    modified: now(),
                    length: 0,
                },
                data: Vec::new(),
                open: 0,
                external: None,
            },
        );
        self.paths.insert(path, id);
        Ok(id)
    }
    fn id(&self, path: &[u16]) -> Result<u32> {
        self.paths.get(path).copied().ok_or(Error::Missing)
    }
    pub fn mount_directory(&mut self, path: &[u16]) -> Result<()> {
        if let Some(stat) = self.stat(path) {
            return if stat.directory {
                Ok(())
            } else {
                Err(Error::Directory)
            };
        }
        let parent = parent(path).ok_or(Error::Invalid)?;
        self.mount_directory(&parent)?;
        self.insert(path.to_vec(), true, false)?;
        Ok(())
    }
    pub fn external_storage(&mut self) -> Result<Path> {
        let root = units(EXTERNAL_STORAGE_ROOT);
        if !self.paths.contains_key(&root) {
            self.mount_directory(&parent(&root).ok_or(Error::Invalid)?)?;
            self.insert(root.clone(), true, true)?;
        }
        Ok(root)
    }
    pub fn app_data(&mut self, device_protected: bool) -> Result<Path> {
        if !device_protected {
            return Ok(self.cwd.clone());
        }
        let root = self.device_data.clone();
        if !self.paths.contains_key(&root) {
            self.mount_directory(&parent(&root).ok_or(Error::Invalid)?)?;
            self.insert(root.clone(), true, true)?;
        }
        Ok(root)
    }
    fn archive_node(&mut self, member: String, length: usize, open: usize) -> Result<u32> {
        if self.nodes.len() >= 1024 || self.bytes() + 192 + member.len() > self.limit {
            return Err(Error::Quota);
        }
        let id = self.next;
        self.next = self.next.checked_add(1).ok_or(Error::Quota)?;
        self.nodes.insert(
            id,
            Node {
                stat: Stat {
                    directory: false,
                    readable: true,
                    writable: false,
                    executable: false,
                    modified: 0,
                    length,
                },
                data: Vec::new(),
                open,
                external: Some(member),
            },
        );
        Ok(id)
    }
    pub fn mount_archive(&mut self, path: Path, member: String, length: usize) -> Result<()> {
        if self.paths.contains_key(&path) {
            return Err(Error::Denied);
        }
        if self.bytes() + 256 + member.len() + path.len() * 2 > self.limit {
            return Err(Error::Quota);
        }
        let id = self.archive_node(member, length, 0)?;
        self.paths.insert(path, id);
        Ok(())
    }
    pub fn open_archive(&mut self, member: String, length: usize) -> Result<u32> {
        self.archive_node(member, length, 1)
    }
    pub fn mount_memory(&mut self, path: Path, data: Vec<u8>) -> Result<()> {
        if self.paths.contains_key(&path) {
            return Err(Error::Denied);
        }
        if self.bytes() + data.capacity() + path.len() * 2 + 256 > self.limit {
            return Err(Error::Quota);
        }
        let id = self.insert(path, false, false)?;
        self.nodes.get_mut(&id).ok_or(Error::Missing)?.data = data;
        Ok(())
    }
    pub fn archive_member(&self, inode: u32) -> Result<Option<&str>> {
        Ok(self
            .nodes
            .get(&inode)
            .ok_or(Error::Missing)?
            .external
            .as_deref())
    }
    pub fn stat(&self, path: &[u16]) -> Option<Stat> {
        self.paths
            .get(path)
            .and_then(|id| self.nodes.get(id))
            .map(|n| {
                let mut s = n.stat.clone();
                if n.external.is_none() {
                    s.length = n.data.len();
                }
                s
            })
    }
    fn writable_parent(&self, path: &[u16]) -> Result<()> {
        let p = parent(path).ok_or(Error::Denied)?;
        let s = self.stat(&p).ok_or(Error::Missing)?;
        if !s.directory || !s.writable {
            return Err(Error::Denied);
        }
        Ok(())
    }
    pub fn mkdir(&mut self, path: &[u16]) -> Result<bool> {
        if self.paths.contains_key(path) {
            return Ok(false);
        }
        self.writable_parent(path)?;
        self.insert(path.to_vec(), true, true)?;
        Ok(true)
    }
    pub fn mkdirs(&mut self, path: &[u16]) -> Result<bool> {
        if self.paths.contains_key(path) {
            return Ok(false);
        }
        let mut pending = vec![path.to_vec()];
        while let Some(path) = pending.last() {
            let p = parent(path).ok_or(Error::Denied)?;
            if self.paths.contains_key(&p) {
                break;
            }
            if pending.len() >= 512 {
                return Err(Error::Quota);
            }
            pending.push(p);
        }
        for path in pending.into_iter().rev() {
            self.mkdir(&path)?;
        }
        Ok(true)
    }
    pub fn create(&mut self, path: &[u16]) -> Result<bool> {
        if self.paths.contains_key(path) {
            return Ok(false);
        }
        self.writable_parent(path)?;
        self.insert(path.to_vec(), false, true)?;
        Ok(true)
    }
    fn child(parent: &[u16], path: &[u16]) -> bool {
        path.len() > parent.len()
            && path.starts_with(parent)
            && (parent == [47] || path.get(parent.len()) == Some(&47))
    }
    fn discard_orphan(&mut self, id: u32) {
        if self.nodes.get(&id).is_some_and(|n| n.open == 0)
            && !self.paths.values().any(|v| *v == id)
        {
            self.nodes.remove(&id);
        }
    }
    pub fn delete(&mut self, path: &[u16]) -> Result<bool> {
        let Ok(id) = self.id(path) else {
            return Ok(false);
        };
        self.writable_parent(path)?;
        if self.nodes[&id].stat.directory && self.paths.keys().any(|p| Self::child(path, p)) {
            return Ok(false);
        }
        self.paths.remove(path);
        self.discard_orphan(id);
        Ok(true)
    }
    pub fn rename(&mut self, from: &[u16], to: &[u16]) -> Result<bool> {
        let Ok(id) = self.id(from) else {
            return Ok(false);
        };
        self.writable_parent(from)?;
        self.writable_parent(to)?;
        if from == to {
            return Ok(true);
        }
        if Self::child(from, to) {
            return Ok(false);
        }
        let changes: Vec<_> = self
            .paths
            .iter()
            .filter(|(p, _)| p.as_slice() == from || Self::child(from, p))
            .map(|(p, id)| {
                let mut dest = to.to_vec();
                dest.extend(&p[from.len()..]);
                (p.clone(), dest, *id)
            })
            .collect();
        if changes.iter().any(|(_, dest, _)| dest.len() > 4096) {
            return Err(Error::Invalid);
        }
        let delta = changes
            .iter()
            .map(|(old, new, _)| new.len() as i64 - old.len() as i64)
            .sum::<i64>()
            * 2;
        if self.bytes() as i64 + delta > self.limit as i64 {
            return Err(Error::Quota);
        }
        if let Ok(existing) = self.id(to) {
            if self.nodes[&existing].stat.directory != self.nodes[&id].stat.directory {
                return Ok(false);
            }
            if self.nodes[&existing].stat.directory && self.paths.keys().any(|p| Self::child(to, p))
            {
                return Ok(false);
            }
            self.paths.remove(to);
            self.discard_orphan(existing);
        }
        for (old, _, _) in &changes {
            self.paths.remove(old);
        }
        for (_, new, id) in changes {
            self.paths.insert(new, id);
        }
        Ok(true)
    }
    pub fn list(&self, path: &[u16]) -> Option<Vec<Path>> {
        let s = self.stat(path)?;
        if !s.directory || !s.readable {
            return None;
        }
        Some(
            self.paths
                .keys()
                .filter(|p| parent(p).as_deref() == Some(path))
                .map(|p| p[path.len() + usize::from(path != [47])..].to_vec())
                .collect(),
        )
    }
    pub fn open(&mut self, path: &[u16], write: bool, append: bool) -> Result<u32> {
        if write && !self.paths.contains_key(path) {
            self.create(path)?;
        }
        let id = self.id(path)?;
        let node = self.nodes.get_mut(&id).ok_or(Error::Missing)?;
        if node.stat.directory {
            return Err(Error::Directory);
        }
        if if write {
            !node.stat.writable
        } else {
            !node.stat.readable
        } {
            return Err(Error::Denied);
        }
        if node.open >= 1024 {
            return Err(Error::Quota);
        }
        node.open += 1;
        if write && !append {
            node.data = Vec::new();
            node.stat.modified = now();
        }
        Ok(id)
    }
    pub fn close(&mut self, id: u32) {
        if let Some(n) = self.nodes.get_mut(&id) {
            n.open = n.open.saturating_sub(1);
        }
        self.discard_orphan(id);
    }
    /// Reserve a writable file's complete future image before database changes.
    pub fn reserve_inode(&mut self, id: u32, maximum: usize) -> Result<()> {
        let node = self.nodes.get(&id).ok_or(Error::Missing)?;
        if node.external.is_some() || node.stat.directory {
            return Err(Error::Denied);
        }
        if maximum < node.data.len() {
            return Err(Error::Quota);
        }
        if maximum <= node.data.capacity() {
            return Ok(());
        }
        if self
            .bytes()
            .saturating_sub(node.data.capacity())
            .saturating_add(maximum)
            > self.limit
        {
            return Err(Error::Quota);
        }
        let mut data = Vec::new();
        data.try_reserve_exact(maximum).map_err(|_| Error::Quota)?;
        data.extend(&node.data);
        self.nodes.get_mut(&id).ok_or(Error::Missing)?.data = data;
        Ok(())
    }
    /// Replace a reserved image without truncating it before allocation succeeds.
    pub fn replace_reserved_inode(&mut self, id: u32, bytes: &[u8]) -> Result<()> {
        let node = self.nodes.get_mut(&id).ok_or(Error::Missing)?;
        if node.external.is_some() || node.stat.directory {
            return Err(Error::Denied);
        }
        if bytes.len() > node.data.capacity() {
            return Err(Error::Quota);
        }
        node.data.clear();
        node.data.extend(bytes);
        node.stat.modified = now();
        Ok(())
    }
    pub fn release_inode_reservation(&mut self, id: u32) {
        if let Some(node) = self.nodes.get_mut(&id) {
            node.data.shrink_to_fit();
        }
    }
    pub fn length(&self, id: u32) -> Result<usize> {
        let node = self.nodes.get(&id).ok_or(Error::Missing)?;
        Ok(if node.external.is_some() {
            node.stat.length
        } else {
            node.data.len()
        })
    }
    pub fn read(&self, id: u32, position: u64, count: usize) -> Result<Vec<u8>> {
        let node = self.nodes.get(&id).ok_or(Error::Missing)?;
        if node.external.is_some() {
            return Err(Error::External);
        }
        let data = &node.data;
        let start = usize::try_from(position)
            .unwrap_or(usize::MAX)
            .min(data.len());
        Ok(data[start..start.saturating_add(count).min(data.len())].to_vec())
    }
    pub fn write(&mut self, id: u32, position: u64, append: bool, bytes: &[u8]) -> Result<u64> {
        let node = self.nodes.get(&id).ok_or(Error::Missing)?;
        if node.external.is_some() {
            return Err(Error::Denied);
        }
        let start = if append {
            node.data.len()
        } else {
            usize::try_from(position).map_err(|_| Error::Quota)?
        };
        if bytes.is_empty() {
            return Ok(start as u64);
        }
        let end = start.checked_add(bytes.len()).ok_or(Error::Quota)?;
        if self
            .bytes()
            .saturating_add(end.saturating_sub(node.data.capacity()))
            > self.limit
        {
            return Err(Error::Quota);
        }
        let node = self.nodes.get_mut(&id).ok_or(Error::Missing)?;
        if end > node.data.len() {
            node.data
                .try_reserve_exact(end - node.data.len())
                .map_err(|_| Error::Quota)?;
            node.data.resize(end, 0);
        }
        node.data[start..end].copy_from_slice(bytes);
        node.stat.modified = now();
        Ok(end as u64)
    }
    pub fn permissions(&mut self, path: &[u16], kind: char, enabled: bool) -> bool {
        if ![&self.cwd, &self.device_data]
            .into_iter()
            .any(|root| path == root || Self::child(root, path))
        {
            return false;
        }
        let Ok(id) = self.id(path) else {
            return false;
        };
        let n = self.nodes.get_mut(&id).unwrap();
        match kind {
            'r' => n.stat.readable = enabled,
            'w' => n.stat.writable = enabled,
            'x' => n.stat.executable = enabled,
            _ => return false,
        };
        true
    }
    pub fn modified(&mut self, path: &[u16], time: u64) -> bool {
        let Ok(id) = self.id(path) else {
            return false;
        };
        let n = self.nodes.get_mut(&id).unwrap();
        if !n.stat.writable {
            return false;
        }
        n.stat.modified = time;
        true
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn emulated_storage_is_writable_and_belongs_to_one_guest_filesystem() {
        let mut first = Fs::new(65536, "org.kyvex.one");
        let mut second = Fs::new(65536, "org.kyvex.two");
        let root = first.external_storage().unwrap();
        assert_eq!(root, second.external_storage().unwrap());
        let path = join(&root, &units("shared.bin"));
        assert!(first.create(&path).unwrap());
        assert!(first.stat(&path).is_some_and(|stat| stat.writable));
        assert!(second.stat(&path).is_none());
        assert_eq!(first.delete(&root), Err(Error::Denied));
    }
    #[test]
    fn archive_mounts_are_read_only_lazy_and_anonymous_handles_are_reclaimed() {
        let mut fs = Fs::new(16384, "org.kyvex.test");
        let dir = units("/data/app/org.kyvex.test/lib/arm64-v8a");
        let path = join(&dir, &units("liblarge.so"));
        fs.mount_directory(&dir).unwrap();
        fs.mount_archive(
            path.clone(),
            "lib/arm64-v8a/liblarge.so".into(),
            128 * 1024 * 1024,
        )
        .unwrap();
        assert!(fs.bytes() < 8192);
        assert_eq!(fs.stat(&path).unwrap().length, 128 * 1024 * 1024);
        assert_eq!(fs.open(&path, true, false), Err(Error::Denied));
        assert!(!fs.permissions(&path, 'w', true));
        let input = fs.open(&path, false, false).unwrap();
        assert_eq!(fs.read(input, 0, 4), Err(Error::External));
        assert_eq!(fs.write(input, 0, false, b"bad"), Err(Error::Denied));
        assert_eq!(
            fs.archive_member(input).unwrap(),
            Some("lib/arm64-v8a/liblarge.so")
        );
        fs.close(input);
        let before = fs.bytes();
        let asset = fs.open_archive("assets/payload.txt".into(), 16).unwrap();
        assert!(fs.bytes() > before);
        fs.close(asset);
        assert_eq!(fs.bytes(), before);
    }
    #[test]
    fn unix_paths_are_normalized_and_dot_segments_are_only_canonicalized() {
        assert_eq!(normalize(&units("//a//b/../")), units("/a/b/.."));
        assert_eq!(
            join(&units("/parent"), &units("/child")),
            units("/parent/child")
        );
        assert_eq!(parent(&units("/file")), Some(units("/")));
        assert_eq!(parent(&units("file")), None);
        assert_eq!(
            canonical(
                &units("../../../../etc/./passwd"),
                &units("/data/user/0/app")
            )
            .unwrap(),
            units("/etc/passwd")
        );
        assert!(canonical(&[0], &units("/")).is_err());
    }
    #[test]
    fn streams_share_actual_contents_across_append_rename_unlink_and_close() {
        let mut fs = Fs::new(16384, "org.kyvex.test");
        let path = join(&fs.cwd, &units("file"));
        let next = join(&fs.cwd, &units("renamed"));
        let out = fs.open(&path, true, false).unwrap();
        assert_eq!(fs.write(out, 0, false, b"abc").unwrap(), 3);
        let input = fs.open(&path, false, false).unwrap();
        let append = fs.open(&path, true, true).unwrap();
        fs.write(append, 0, true, b"d").unwrap();
        assert!(fs.rename(&path, &next).unwrap());
        assert!(fs.stat(&path).is_none());
        assert_eq!(fs.read(input, 0, 10).unwrap(), b"abcd");
        assert!(fs.delete(&next).unwrap());
        assert_eq!(fs.read(input, 1, 2).unwrap(), b"bc");
        fs.close(input);
        fs.close(out);
        fs.close(append);
        assert!(!fs.nodes.contains_key(&input));
    }
    #[test]
    fn quota_and_private_root_hold_without_partial_writes() {
        let mut fs = Fs::new(8192, "org.kyvex.test");
        let path = join(&fs.cwd, &units("file"));
        assert!(fs.open(&units("/etc/passwd"), false, false).is_err());
        assert!(fs.create(&units("/host-file")).is_err());
        let id = fs.open(&path, true, false).unwrap();
        fs.write(id, 0, false, b"before").unwrap();
        assert_eq!(fs.write(id, 0, false, &vec![0; 8192]), Err(Error::Quota));
        assert_eq!(fs.read(id, 0, 20).unwrap(), b"before");
        assert!(fs.bytes() <= fs.limit);
        fs.permissions(&path, 'w', false);
        assert_eq!(fs.open(&path, true, false), Err(Error::Denied));
    }
    #[test]
    fn reserved_database_images_replace_atomically_even_when_other_files_use_the_quota() {
        let mut fs = Fs::new(16384, "org.kyvex.test");
        let path = join(&fs.cwd, &units("database"));
        let id = fs.open(&path, true, true).unwrap();
        fs.reserve_inode(id, 8192).unwrap();
        fs.replace_reserved_inode(id, b"old").unwrap();
        assert_eq!(
            fs.replace_reserved_inode(id, &vec![0; 9000]),
            Err(Error::Quota)
        );
        assert_eq!(fs.read(id, 0, 100).unwrap(), b"old");
        let filler = fs
            .open(&join(&fs.cwd, &units("filler")), true, false)
            .unwrap();
        let available = fs.limit - fs.bytes();
        fs.write(filler, 0, false, &vec![1; available]).unwrap();
        fs.replace_reserved_inode(id, &vec![2; 8192]).unwrap();
        assert_eq!(fs.read(id, 0, 8192).unwrap(), vec![2; 8192]);
        fs.replace_reserved_inode(id, b"new").unwrap();
        let reserved = fs.bytes();
        fs.release_inode_reservation(id);
        assert!(fs.bytes() + 7000 < reserved);
        assert_eq!(fs.read(id, 0, 100).unwrap(), b"new");
    }
}
