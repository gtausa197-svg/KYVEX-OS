package android.os;

/** Compile-only Android SDK signatures. */
public final class Environment {
    public static final String MEDIA_MOUNTED = "mounted";
    public static java.io.File getExternalStorageDirectory() { return null; }
    public static java.io.File getExternalStoragePublicDirectory(String type) { return null; }
    public static String getExternalStorageState() { return null; }
    public static String getExternalStorageState(java.io.File path) { return null; }
    public static boolean isExternalStorageEmulated() { return false; }
    public static boolean isExternalStorageRemovable() { return false; }
}
