//! Java atomics, owned locks and typed, bounded Android Bundle values.
use super::*;
#[derive(Clone)]
pub(super) struct BundleValue {
    pub kind: char,
    pub value: u64,
}
impl Runtime {
    pub(super) fn object_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Object API signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Object API argument count");
        if matches!(
            class,
            "Ljava/util/concurrent/atomic/AtomicReference;"
                | "Ljava/util/concurrent/atomic/AtomicInteger;"
                | "Ljava/util/concurrent/atomic/AtomicLong;"
                | "Ljava/util/concurrent/atomic/AtomicBoolean;"
        ) {
            let id = arg(0)?;
            let Payload::Atomic { mut value, kind } = self.object(id)?.payload else {
                return Err("Expected atomic object".into());
            };
            let wide = kind == 'J';
            let input = |i: usize| -> Result<u64> {
                Ok(arg(i)? as u64 | if wide { (arg(i + 1)? as u64) << 32 } else { 0 })
            };
            let head = method.split('(').next().unwrap_or("");
            let mut returns = value;
            match head {
                "<init>" => {
                    if a.len() > 1 {
                        value = input(1)?;
                    }
                    returns = 0;
                }
                "get" => {}
                "set" | "lazySet" | "getAndSet" => {
                    value = input(1)?;
                    if head != "getAndSet" {
                        returns = 0;
                    }
                }
                "compareAndSet" | "weakCompareAndSet" => {
                    let expected = input(1)?;
                    let next = input(if wide { 3 } else { 2 })?;
                    returns = (value == expected) as u64;
                    if returns == 1 {
                        value = next;
                    }
                }
                "getAndIncrement" | "incrementAndGet" | "getAndDecrement" | "decrementAndGet"
                | "getAndAdd" | "addAndGet"
                    if matches!(kind, 'I' | 'J') =>
                {
                    let delta = if head.ends_with("Increment") || head == "incrementAndGet" {
                        1
                    } else if head.ends_with("Decrement") || head == "decrementAndGet" {
                        u64::MAX
                    } else {
                        input(1)?
                    };
                    value = value.wrapping_add(delta);
                    if !wide {
                        value = value as u32 as u64;
                    }
                    if !head.starts_with("getAnd") {
                        returns = value;
                    }
                }
                _ => return Ok(None),
            }
            if kind == 'R' && value != 0 {
                self.object(u32::try_from(value)?)?;
            }
            self.object_mut(id)?.payload = Payload::Atomic { value, kind };
            return Ok(Some(returns));
        }
        if class == "Ljava/util/concurrent/locks/ReentrantLock;" {
            return self.lock_api(method, a);
        }
        if let Some(result) = self.rwlock_api(class, method, a)? {
            return Ok(Some(result));
        }
        if matches!(class, "Landroid/os/Bundle;" | "Landroid/os/BaseBundle;") {
            let id = arg(0)?;
            if !matches!(self.object(id)?.payload, Payload::Bundle(_)) {
                return Err("Expected Bundle".into());
            }
            match method {
                "keySet()Ljava/util/Set;" => {
                    return Ok(Some(
                        self.allocate("Ljava/util/HashMap$KeySet;", Payload::BundleKeys(id))?
                            as u64,
                    ));
                }
                "putAll(Landroid/os/Bundle;)V" => {
                    let Payload::Bundle(source) = &self.object(arg(1)?)?.payload else {
                        return Err("putAll source is not Bundle".into());
                    };
                    let source = source.clone();
                    let Payload::Bundle(target) = &self.object(id)?.payload else {
                        unreachable!()
                    };
                    let extra: usize = source
                        .keys()
                        .filter(|k| !target.contains_key(*k))
                        .map(|k| 64 + k.as_ref().map_or(0, |s| s.len() * 2))
                        .sum();
                    if self.heap_bytes().saturating_add(extra) > self.heap_limit {
                        return Err("Bundle putAll memory quota".into());
                    }
                    let mut merged = target.clone();
                    let old_len = merged.len();
                    merged.extend(source);
                    if merged.len() > 1024 {
                        return Err("Bundle entry quota".into());
                    }
                    let structural = merged.len() != old_len;
                    let object = self.object_mut(id)?;
                    object.payload = Payload::Bundle(merged);
                    if structural {
                        object.version = object.version.wrapping_add(1);
                    }
                    return Ok(Some(0));
                }
                "<init>()V" | "<init>(I)V" => return Ok(Some(0)),
                "<init>(Landroid/os/Bundle;)V" => {
                    let Payload::Bundle(v) = &self.object(arg(1)?)?.payload else {
                        return Err("Bundle copy source".into());
                    };
                    let v = v.clone();
                    self.object_mut(id)?.payload = Payload::Bundle(v);
                    return Ok(Some(0));
                }
                "size()I" | "isEmpty()Z" => {
                    let Payload::Bundle(v) = &self.object(id)?.payload else {
                        unreachable!()
                    };
                    return Ok(Some(if method == "size()I" {
                        v.len() as u64
                    } else {
                        v.is_empty() as u64
                    }));
                }
                "clear()V" => {
                    let Payload::Bundle(values) = &self.object(id)?.payload else {
                        unreachable!()
                    };
                    let structural = !values.is_empty();
                    self.object_mut(id)?.payload = Payload::Bundle(BTreeMap::new());
                    if structural {
                        let o = self.object_mut(id)?;
                        o.version = o.version.wrapping_add(1);
                    }
                    return Ok(Some(0));
                }
                _ => {}
            }
            let key = if arg(1)? == 0 {
                None
            } else {
                Some(self.units(arg(1)?)?)
            };
            if method == "containsKey(Ljava/lang/String;)Z" {
                let Payload::Bundle(v) = &self.object(id)?.payload else {
                    unreachable!()
                };
                return Ok(Some(v.contains_key(&key) as u64));
            }
            if method == "remove(Ljava/lang/String;)V" {
                let object = self.object_mut(id)?;
                let Payload::Bundle(v) = &mut object.payload else {
                    unreachable!()
                };
                if v.remove(&key).is_some() {
                    object.version = object.version.wrapping_add(1);
                }
                return Ok(Some(0));
            }
            if method == "get(Ljava/lang/String;)Ljava/lang/Object;" {
                let Payload::Bundle(values) = &self.object(id)?.payload else {
                    unreachable!()
                };
                let value = values.get(&key).cloned();
                return Ok(Some(match value {
                    None => 0,
                    Some(BundleValue {
                        kind: 'S' | 'B',
                        value,
                    }) => value,
                    Some(BundleValue { kind: 'R', .. }) => {
                        return Err(
                            "Manifest metadata value requires Android resource resolution".into(),
                        );
                    }
                    Some(BundleValue { kind, value }) => self.box_value(kind, value)? as u64,
                }));
            }
            let (writing, kind, wide) = match method {
                "putString(Ljava/lang/String;Ljava/lang/String;)V" => (true, 'S', false),
                "putBundle(Ljava/lang/String;Landroid/os/Bundle;)V" => (true, 'B', false),
                "putInt(Ljava/lang/String;I)V" => (true, 'I', false),
                "putBoolean(Ljava/lang/String;Z)V" => (true, 'Z', false),
                "putLong(Ljava/lang/String;J)V" => (true, 'J', true),
                "putFloat(Ljava/lang/String;F)V" => (true, 'F', false),
                "putDouble(Ljava/lang/String;D)V" => (true, 'D', true),
                "getString(Ljava/lang/String;)Ljava/lang/String;"
                | "getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;" => {
                    (false, 'S', false)
                }
                "getBundle(Ljava/lang/String;)Landroid/os/Bundle;" => (false, 'B', false),
                "getInt(Ljava/lang/String;)I" | "getInt(Ljava/lang/String;I)I" => {
                    (false, 'I', false)
                }
                "getBoolean(Ljava/lang/String;)Z" | "getBoolean(Ljava/lang/String;Z)Z" => {
                    (false, 'Z', false)
                }
                "getLong(Ljava/lang/String;)J" | "getLong(Ljava/lang/String;J)J" => {
                    (false, 'J', true)
                }
                "getFloat(Ljava/lang/String;)F" | "getFloat(Ljava/lang/String;F)F" => {
                    (false, 'F', false)
                }
                "getDouble(Ljava/lang/String;)D" | "getDouble(Ljava/lang/String;D)D" => {
                    (false, 'D', true)
                }
                _ => return Ok(None),
            };
            if writing {
                let value = arg(2)? as u64 | if wide { (arg(3)? as u64) << 32 } else { 0 };
                if kind == 'S' && value != 0 {
                    self.units(value as u32)?;
                }
                if kind == 'B'
                    && value != 0
                    && !matches!(self.object(value as u32)?.payload, Payload::Bundle(_))
                {
                    return Err("putBundle type mismatch".into());
                }
                let object = self.object_mut(id)?;
                let Payload::Bundle(v) = &mut object.payload else {
                    unreachable!()
                };
                if v.len() >= 1024 && !v.contains_key(&key) {
                    return Err("Bundle entry quota".into());
                }
                let structural = !v.contains_key(&key);
                v.insert(key, BundleValue { kind, value });
                if structural {
                    object.version = object.version.wrapping_add(1);
                }
                return Ok(Some(0));
            }
            let fallback = a.get(2).copied().unwrap_or(0) as u64
                | if wide {
                    (a.get(3).copied().unwrap_or(0) as u64) << 32
                } else {
                    0
                };
            let Payload::Bundle(v) = &self.object(id)?.payload else {
                unreachable!()
            };
            if v.get(&key).is_some_and(|v| v.kind == 'R') {
                return Err("Manifest metadata value requires Android resource resolution".into());
            }
            return Ok(Some(
                v.get(&key)
                    .filter(|v| v.kind == kind)
                    .map_or(fallback, |v| v.value),
            ));
        }
        Ok(None)
    }
}
