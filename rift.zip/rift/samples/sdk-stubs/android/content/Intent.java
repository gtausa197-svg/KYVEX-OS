package android.content;
import android.os.Bundle;
public class Intent {
    public Intent(){}
    public String getAction(){return null;}
    public ComponentName getComponent(){return null;}
    public Intent putExtra(String key,int value){return this;}
    public int getIntExtra(String key,int fallback){return fallback;}
    public Bundle getExtras(){return null;}
}
