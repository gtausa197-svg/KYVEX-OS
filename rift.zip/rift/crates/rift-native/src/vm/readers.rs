//! Bounded character readers over guest strings and the existing guest byte streams.
use super::*;
use std::collections::VecDeque;
#[derive(Clone, Copy)]
pub(super) enum Encoding {
    Utf8,
    Latin1,
    Ascii,
}
impl Encoding {
    fn name(self) -> &'static str {
        match self {
            Self::Utf8 => "UTF8",
            Self::Latin1 => "ISO8859_1",
            Self::Ascii => "ASCII",
        }
    }
    fn decode(self, input: &[u8], eof: bool) -> (Vec<u16>, usize) {
        match self {
            Self::Utf8 => utf8_units(input, eof),
            Self::Latin1 => (input.iter().map(|b| *b as u16).collect(), input.len()),
            Self::Ascii => (
                input
                    .iter()
                    .map(|b| if *b < 128 { *b as u16 } else { 0xfffd })
                    .collect(),
                input.len(),
            ),
        }
    }
    fn parse(name: &str) -> Option<Self> {
        Some(match name.to_ascii_lowercase().as_str() {
            "utf8" | "utf-8" | "unicode-1-1-utf-8" => Self::Utf8,
            "iso-8859-1" | "iso8859-1" | "iso_8859-1" | "iso_8859-1:1987" | "iso-ir-100"
            | "latin1" | "l1" | "ibm819" | "cp819" | "csisolatin1" => Self::Latin1,
            "us-ascii" | "ascii" | "iso646-us" | "ansi_x3.4-1968" => Self::Ascii,
            _ => return None,
        })
    }
}
pub(super) enum Source {
    Text {
        string: u32,
        length: usize,
        position: usize,
        mark: usize,
    },
    Decoded {
        input: u32,
        encoding: Encoding,
        queued: VecDeque<u16>,
        pending: Vec<u8>,
        eof: bool,
    },
    Buffered {
        reader: u32,
        skip_lf: bool,
        front: Option<u16>,
    },
}

pub(super) struct Reader {
    pub source: Source,
    pub closed: bool,
}
impl Reader {
    pub fn bytes(&self) -> usize {
        match &self.source {
            Source::Text { .. } => 0,
            Source::Decoded {
                queued, pending, ..
            } => queued.capacity() * 2 + pending.capacity(),
            Source::Buffered { .. } => 0,
        }
    }
    pub fn reference(&self) -> u32 {
        match self.source {
            Source::Text { string, .. } => string,
            Source::Decoded { input, .. } => input,
            Source::Buffered { reader, .. } => reader,
        }
    }
}
pub(super) fn payload(class: &str) -> Option<Payload> {
    matches!(
        class,
        "Ljava/io/BufferedReader;"
            | "Ljava/io/InputStreamReader;"
            | "Ljava/io/FileReader;"
            | "Ljava/io/StringReader;"
    )
    .then_some(Payload::Reader(None))
}
pub(super) fn inherits(class: &str, base: &str) -> bool {
    matches!(
        class,
        "Ljava/io/Reader;"
            | "Ljava/io/StringReader;"
            | "Ljava/io/InputStreamReader;"
            | "Ljava/io/FileReader;"
            | "Ljava/io/BufferedReader;"
    ) && matches!(
        base,
        "Ljava/io/Closeable;" | "Ljava/lang/AutoCloseable;" | "Ljava/lang/Readable;"
    )
}
// Return the consumed byte count separately, preserving an incomplete suffix
// across reads. Java's decoder replaces an encoded surrogate as one malformed
// sequence; Rust's general lossy decoder instead replaces each of its bytes.
pub(super) fn utf8_units(bytes: &[u8], final_chunk: bool) -> (Vec<u16>, usize) {
    let mut out = Vec::new();
    let mut at = 0;
    while at < bytes.len() {
        match std::str::from_utf8(&bytes[at..]) {
            Ok(text) => {
                out.extend(text.encode_utf16());
                at = bytes.len();
            }
            Err(error) => {
                let valid = error.valid_up_to();
                if valid != 0 {
                    out.extend(
                        std::str::from_utf8(&bytes[at..at + valid])
                            .expect("validated UTF8 prefix")
                            .encode_utf16(),
                    );
                    at += valid;
                }
                let tail = &bytes[at..];
                if tail[0] == 0xed && tail.get(1).is_some_and(|b| (0xa0..=0xbf).contains(b)) {
                    if tail.len() < 3 && !final_chunk {
                        break;
                    }
                    let n = if tail.get(2).is_some_and(|b| (0x80..=0xbf).contains(b)) {
                        3
                    } else {
                        2
                    };
                    out.push(0xfffd);
                    at += n.min(tail.len());
                } else if let Some(n) = error.error_len() {
                    out.push(0xfffd);
                    at += n;
                } else if final_chunk {
                    out.push(0xfffd);
                    at = bytes.len();
                } else {
                    break;
                }
            }
        }
    }
    (out, at)
}
fn io(message: &str) -> Box<dyn std::error::Error + Send + Sync> {
    fault("Ljava/io/IOException;", message)
}
impl Runtime {
    pub(super) fn reader_unit(&mut self, id: u32, depth: usize) -> Result<Option<u16>> {
        if depth >= 32 {
            return Err("Reader wrapper depth/cycle quota".into());
        }
        let object = self.object_mut(id)?;
        let Payload::Reader(slot) = &mut object.payload else {
            return Err(
                "Custom Reader implementations are not connected to the native reader adapter"
                    .into(),
            );
        };
        let mut reader = slot.take().ok_or("Uninitialized or cyclic Reader")?;
        let result = (|| {
            if reader.closed {
                return Err(io("Reader is closed"));
            }
            match &mut reader.source {
                Source::Text {
                    string, position, ..
                } => {
                    let Payload::String(units) = &self.object(*string)?.payload else {
                        return Err("StringReader source type".into());
                    };
                    let value = units.get(*position).copied();
                    if value.is_some() {
                        *position += 1;
                    }
                    Ok(value)
                }
                Source::Decoded {
                    input,
                    encoding,
                    queued,
                    pending,
                    eof,
                } => {
                    while queued.is_empty() && !*eof {
                        let bytes = self.read_input_bytes(*input, 8192)?;
                        *eof = bytes.is_empty();
                        let mut data = std::mem::take(pending);
                        data.extend(bytes);
                        let (units, consumed) = encoding.decode(&data, *eof);
                        if self
                            .heap_bytes()
                            .saturating_add((units.len() + queued.capacity()) * 2 + 16384)
                            > self.heap_limit
                        {
                            return Err("UTF8 reader buffer memory quota".into());
                        }
                        *pending = data[consumed..].to_vec();
                        queued.extend(units);
                    }
                    Ok(queued.pop_front())
                }
                Source::Buffered {
                    reader,
                    skip_lf,
                    front,
                } => {
                    let mut value = if front.is_some() {
                        front.take()
                    } else {
                        self.reader_unit(*reader, depth + 1)?
                    };
                    if *skip_lf {
                        *skip_lf = false;
                        if value == Some(10) {
                            value = self.reader_unit(*reader, depth + 1)?;
                        }
                    }
                    Ok(value)
                }
            }
        })();
        self.object_mut(id)?.payload = Payload::Reader(Some(reader));
        result
    }
    fn reader_ready(&mut self, id: u32, depth: usize) -> Result<bool> {
        if depth >= 32 {
            return Err("Reader wrapper depth quota".into());
        }
        let Payload::Reader(slot) = &mut self.object_mut(id)?.payload else {
            return Err("Reader type".into());
        };
        let mut reader = slot.take().ok_or("Uninitialized or cyclic Reader")?;
        let result = (|| {
            if reader.closed {
                return Err(io("Reader is closed"));
            }
            match &mut reader.source {
                Source::Text { .. } => Ok(true),
                Source::Decoded {
                    input, queued, eof, ..
                } => {
                    if !queued.is_empty() {
                        return Ok(true);
                    }
                    if *eof {
                        return Ok(false);
                    }
                    if let Payload::ByteInput(Some(byte_state)) = self.object(*input)?.payload {
                        return Ok(self
                            .byte_input_api("Ljava/io/InputStream;->available()I", &[*input])?
                            .ok_or("Byte input available")?
                            as i32
                            > 0
                            && byte_state.position >= 0);
                    }
                    let Payload::FileStream(Some(stream)) = self.object(*input)?.payload else {
                        return Err("Reader requires a supported guest input stream".into());
                    };
                    if stream.closed {
                        return Err(io("Input stream is closed"));
                    }
                    Ok(stream.position < self.files.length(stream.inode)? as u64)
                }
                Source::Buffered {
                    reader,
                    skip_lf,
                    front,
                } => {
                    if front.is_some() {
                        return Ok(true);
                    }
                    if *skip_lf && self.reader_ready(*reader, depth + 1)? {
                        let value = self.reader_unit(*reader, depth + 1)?;
                        *skip_lf = false;
                        if value != Some(10) {
                            *front = value;
                        }
                    }
                    Ok(front.is_some() || self.reader_ready(*reader, depth + 1)?)
                }
            }
        })();
        self.object_mut(id)?.payload = Payload::Reader(Some(reader));
        result
    }
    fn reader_close(&mut self, id: u32, depth: usize) -> Result<()> {
        if depth >= 32 {
            return Err("Reader wrapper depth quota".into());
        }
        let Payload::Reader(Some(reader)) = &self.object(id)?.payload else {
            return Err("Uninitialized Reader".into());
        };
        if reader.closed {
            return Ok(());
        }
        let reference = if matches!(reader.source, Source::Text { .. }) {
            0
        } else {
            reader.reference()
        };
        let buffered = matches!(reader.source, Source::Buffered { .. });
        if reference != 0 {
            if buffered {
                self.reader_close(reference, depth + 1)?;
            } else {
                self.filesystem_api("Ljava/io/InputStream;->close()V", &[reference])?
                    .ok_or("Unsupported input close")?;
            }
        }
        let Payload::Reader(Some(reader)) = &mut self.object_mut(id)?.payload else {
            unreachable!()
        };
        reader.closed = true;
        match &mut reader.source {
            Source::Text { string, .. } => *string = 0,
            Source::Decoded {
                queued, pending, ..
            } => {
                *queued = VecDeque::new();
                *pending = Vec::new();
            }
            _ => {}
        }
        Ok(())
    }
    pub(super) fn readers_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Reader signature")?;
        if !class.starts_with("Ljava/io/") {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Reader argument count");
        if !matches!(
            class,
            "Ljava/io/Reader;"
                | "Ljava/io/StringReader;"
                | "Ljava/io/BufferedReader;"
                | "Ljava/io/InputStreamReader;"
                | "Ljava/io/FileReader;"
        ) {
            return Ok(None);
        }
        let id = arg(0)?;
        self.object(id)?;
        if class == "Ljava/io/Reader;"
            && matches!(method, "<init>()V" | "<init>(Ljava/lang/Object;)V")
        {
            return Ok(Some(0));
        }
        if method.starts_with("<init>") {
            let source = match (class, method) {
                ("Ljava/io/StringReader;", "<init>(Ljava/lang/String;)V") => {
                    let string = arg(1)?;
                    let Payload::String(units) = &self.object(string)?.payload else {
                        return Err("StringReader source type".into());
                    };
                    Source::Text {
                        string,
                        length: units.len(),
                        position: 0,
                        mark: 0,
                    }
                }
                (
                    "Ljava/io/BufferedReader;",
                    "<init>(Ljava/io/Reader;)V" | "<init>(Ljava/io/Reader;I)V",
                ) => {
                    let input = arg(1)?;
                    if !self.subclass(&self.object(input)?.class, "Ljava/io/Reader;")? {
                        return Err("BufferedReader source type".into());
                    }
                    if a.len() == 3 && arg(2)? as i32 <= 0 {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Reader buffer size must be positive",
                        ));
                    }
                    Source::Buffered {
                        reader: input,
                        skip_lf: false,
                        front: None,
                    }
                }
                (
                    "Ljava/io/InputStreamReader;",
                    "<init>(Ljava/io/InputStream;)V"
                    | "<init>(Ljava/io/InputStream;Ljava/lang/String;)V"
                    | "<init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V",
                ) => {
                    let input = arg(1)?;
                    self.object(input)?;
                    let encoding = if method.contains("Ljava/nio/charset/Charset;") {
                        match self.charset_encoding(arg(2)?)? {
                            charsets::Encoding::Utf8 => Encoding::Utf8,
                            charsets::Encoding::Latin1 => Encoding::Latin1,
                            charsets::Encoding::Ascii => Encoding::Ascii,
                            _ => return Err("UTF-16 streaming readers are not implemented".into()),
                        }
                    } else if a.len() == 3 {
                        let name = String::from_utf16(&self.units(arg(2)?)?)?;
                        Encoding::parse(&name)
                            .ok_or_else(|| format!("Reader charset is not implemented: {name}"))?
                    } else {
                        Encoding::Utf8
                    };
                    Source::Decoded {
                        input,
                        encoding,
                        queued: VecDeque::new(),
                        pending: Vec::new(),
                        eof: false,
                    }
                }
                (
                    "Ljava/io/FileReader;",
                    "<init>(Ljava/lang/String;)V" | "<init>(Ljava/io/File;)V",
                ) => {
                    let input = self.instantiate("Ljava/io/FileInputStream;")?;
                    let descriptor = if method.contains("Ljava/lang/String;") {
                        "Ljava/lang/String;"
                    } else {
                        "Ljava/io/File;"
                    };
                    self.filesystem_api(
                        &format!("Ljava/io/FileInputStream;-><init>({descriptor})V"),
                        &[input, arg(1)?],
                    )?
                    .ok_or("FileReader input constructor")?;
                    Source::Decoded {
                        input,
                        encoding: Encoding::Utf8,
                        queued: VecDeque::new(),
                        pending: Vec::new(),
                        eof: false,
                    }
                }
                _ => return Ok(None),
            };
            let state = Reader {
                source,
                closed: false,
            };
            if self.heap_bytes().saturating_add(state.bytes()) > self.heap_limit {
                return Err("Reader memory quota".into());
            }
            self.object_mut(id)?.payload = Payload::Reader(Some(state));
            return Ok(Some(0));
        }
        let Payload::Reader(Some(reader)) = &self.object(id)?.payload else {
            return Err("Uninitialized Reader".into());
        };
        if method == "close()V" {
            self.reader_close(id, 0)?;
            return Ok(Some(0));
        }
        if method == "getEncoding()Ljava/lang/String;"
            && let Source::Decoded { encoding, .. } = reader.source
        {
            return Ok(Some(if reader.closed {
                0
            } else {
                self.string(encoding.name())?
            } as u64));
        }
        if reader.closed {
            return Err(io("Reader is closed"));
        }
        let value = match method {
            "read()I" => self
                .reader_unit(id, 0)?
                .map_or(u32::MAX as u64, |c| c as u64),
            "read([C)I" | "read([CII)I" => {
                let array = arg(1)?;
                let object = self.object(array)?;
                if object.class != "[C" {
                    return Err("Reader destination must be char[]".into());
                }
                let Payload::Array(buffer) = &object.payload else {
                    unreachable!()
                };
                let offset = if a.len() == 4 { arg(2)? as usize } else { 0 };
                let length = if a.len() == 4 {
                    arg(3)? as usize
                } else {
                    buffer.len()
                };
                if offset > buffer.len() || length > buffer.len() - offset {
                    return Err(fault(
                        "Ljava/lang/IndexOutOfBoundsException;",
                        "Reader char array range",
                    ));
                }
                if length > 65536 {
                    return Err("Reader bulk read character quota".into());
                }
                let mut units = Vec::new();
                for _ in 0..length {
                    if let Some(c) = self.reader_unit(id, 0)? {
                        units.push(c);
                    } else {
                        break;
                    }
                }
                let Payload::Array(buffer) = &mut self.object_mut(array)?.payload else {
                    unreachable!()
                };
                for (destination, value) in buffer[offset..].iter_mut().zip(&units) {
                    *destination = *value as u64;
                }
                if units.is_empty() && length != 0 {
                    u32::MAX as u64
                } else {
                    units.len() as u64
                }
            }
            "readLine()Ljava/lang/String;" if matches!(reader.source, Source::Buffered { .. }) => {
                let mut units = Vec::new();
                loop {
                    match self.reader_unit(id, 0)? {
                        None => {
                            if units.is_empty() {
                                return Ok(Some(0));
                            }
                            break;
                        }
                        Some(10) => break,
                        Some(13) => {
                            let Payload::Reader(Some(Reader {
                                source: Source::Buffered { skip_lf, .. },
                                ..
                            })) = &mut self.object_mut(id)?.payload
                            else {
                                unreachable!()
                            };
                            *skip_lf = true;
                            break;
                        }
                        Some(c) => units.push(c),
                    }
                    if units.len() > 65536 {
                        return Err("Reader line length quota".into());
                    }
                }
                self.string_units(units)? as u64
            }
            "ready()Z" => self.reader_ready(id, 0)? as u64,
            "markSupported()Z" if matches!(reader.source, Source::Text { .. }) => 1,
            "markSupported()Z" if matches!(reader.source, Source::Decoded { .. }) => 0,
            "mark(I)V" | "reset()V" => {
                let Payload::Reader(Some(reader)) = &mut self.object_mut(id)?.payload else {
                    unreachable!()
                };
                if let Source::Text { position, mark, .. } = &mut reader.source {
                    if method == "reset()V" {
                        *position = *mark;
                    } else {
                        if (arg(1)? as i32) < 0 {
                            return Err(fault(
                                "Ljava/lang/IllegalArgumentException;",
                                "Negative read-ahead limit",
                            ));
                        }
                        *mark = *position;
                    }
                    0
                } else if matches!(reader.source, Source::Decoded { .. }) {
                    return Err(io("Reader mark/reset is not supported"));
                } else {
                    return Err("BufferedReader mark/reset is not implemented".into());
                }
            }
            "skip(J)J" => {
                let requested = (arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64;
                let Payload::Reader(Some(reader)) = &mut self.object_mut(id)?.payload else {
                    unreachable!()
                };
                if let Source::Text {
                    length, position, ..
                } = &mut reader.source
                {
                    if *position >= *length {
                        0
                    } else {
                        let next = (*position as i128 + requested as i128).clamp(0, *length as i128)
                            as usize;
                        let skipped = next as i64 - *position as i64;
                        *position = next;
                        skipped as u64
                    }
                } else {
                    if requested < 0 {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Negative reader skip",
                        ));
                    }
                    if requested > 1_000_000 {
                        return Err("Reader skip quota".into());
                    }
                    let mut skipped = 0;
                    while skipped < requested && self.reader_unit(id, 0)?.is_some() {
                        skipped += 1;
                    }
                    skipped as u64
                }
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn hex(text: &str, width: usize) -> Vec<u32> {
        text.as_bytes()
            .chunks_exact(width)
            .map(|part| u32::from_str_radix(std::str::from_utf8(part).unwrap(), 16).unwrap())
            .collect()
    }
    #[test]
    fn single_byte_decoders_match_stock_jdk_for_all_256_bytes() {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/reader-utf8-oracle.json");
        let data: serde_json::Value =
            serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
        let input: Vec<u8> = (0..=255).collect();
        for (encoding, key) in [
            (Encoding::Latin1, "latin1_utf16"),
            (Encoding::Ascii, "ascii_utf16"),
        ] {
            let (actual, consumed) = encoding.decode(&input, true);
            let expected: Vec<u16> = hex(data[key].as_str().unwrap(), 4)
                .into_iter()
                .map(|v| v as u16)
                .collect();
            assert_eq!(actual, expected);
            assert_eq!(consumed, input.len());
        }
    }
    #[test]
    fn streaming_utf8_matches_stock_jdk_oracle_at_every_chunk_boundary() {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/reader-utf8-oracle.json");
        let data: serde_json::Value =
            serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
        assert_eq!(data["negative_skip_at_eof"], 0);
        for case in data["cases"].as_array().unwrap() {
            let input: Vec<u8> = hex(case["input"].as_str().unwrap(), 2)
                .into_iter()
                .map(|v| v as u8)
                .collect();
            let expected: Vec<u16> = hex(case["utf16"].as_str().unwrap(), 4)
                .into_iter()
                .map(|v| v as u16)
                .collect();
            for size in [1, 2, 3, 4, 5, 8, 8192] {
                let mut pending = Vec::new();
                let mut actual = Vec::new();
                for chunk in input.chunks(size) {
                    pending.extend(chunk);
                    let (units, consumed) = utf8_units(&pending, false);
                    actual.extend(units);
                    pending.drain(..consumed);
                }
                let (units, consumed) = utf8_units(&pending, true);
                assert_eq!(consumed, pending.len());
                actual.extend(units);
                assert_eq!(actual, expected, "input {} chunk {size}", case["input"]);
            }
        }
    }
}
