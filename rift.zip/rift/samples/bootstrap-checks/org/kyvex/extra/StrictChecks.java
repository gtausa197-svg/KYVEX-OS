package org.kyvex.extra;

import android.content.Context;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public final class StrictChecks {
    private static int checks;

    private static String mask(int bits) { return "[StrictMode.ThreadPolicy; mask=" + bits + "]"; }

    private static void check(boolean pass, String reason) {
        if (!pass) throw new IllegalStateException(reason);
        checks++;
    }

    public static int verify(Context context) {
        checks = 0;
        ThreadPolicy original = StrictMode.getThreadPolicy();
        check(ThreadPolicy.LAX != null && mask(0).equals(original.toString()) && original != ThreadPolicy.LAX,
              "Default LAX policy and independent snapshots");
        ThreadPolicy.Builder builder = new ThreadPolicy.Builder();
        check(builder.detectNetwork().detectResourceMismatches().detectUnbufferedIo() == builder,
              "Fluent Firebase detector chain");
        ThreadPolicy firebase = builder.build();
        check(mask(65588).equals(firebase.toString()), "Detector bits and implicit log penalty");
        check(mask(65584).equals(builder.permitNetwork().build().toString()) && mask(65588).equals(firebase.toString()),
              "Builder changes do not mutate an earlier policy");

        ThreadPolicy disk = new ThreadPolicy.Builder(firebase).detectDiskReads().detectDiskWrites().build();
        StrictMode.setThreadPolicy(disk);
        check(mask(65591).equals(StrictMode.getThreadPolicy().toString()), "Installed policy snapshot");
        ThreadPolicy prior = StrictMode.allowThreadDiskReads();
        check(mask(65591).equals(prior.toString()) && mask(65589).equals(StrictMode.getThreadPolicy().toString()),
              "Temporarily allow disk reads");
        ThreadPolicy priorWrites = StrictMode.allowThreadDiskWrites();
        check(mask(65589).equals(priorWrites.toString()) && mask(65588).equals(StrictMode.getThreadPolicy().toString()),
              "Allow writes and reads while preserving other detectors");
        boolean nullRejected = false;
        try { StrictMode.setThreadPolicy(null); }
        catch (NullPointerException expected) { nullRejected = true; }
        check(nullRejected, "Null policy rejected");

        final int[] child = {0};
        Thread worker = new Thread(new Runnable() {
            public void run() {
                if (mask(0).equals(StrictMode.getThreadPolicy().toString())) child[0]++;
                StrictMode.setThreadPolicy(new ThreadPolicy.Builder().detectCustomSlowCalls().penaltyLog().build());
                StrictMode.noteSlowCall("child strict probe");
                if (mask(65544).equals(StrictMode.getThreadPolicy().toString())) child[0]++;
            }
        });
        worker.start();
        try { worker.join(); }
        catch (InterruptedException unexpected) { throw new IllegalStateException(unexpected); }
        check(child[0] == 2 && mask(65588).equals(StrictMode.getThreadPolicy().toString()), "Guest threads have distinct policies");
        StrictMode.noteSlowCall("suppressed strict probe");

        try {
            FileOutputStream out = context.openFileOutput("strict-probe.bin", 0);
            try { out.write(new byte[16]); }
            finally { out.close(); }
            FileInputStream in = context.openFileInput("strict-probe.bin");
            try {
                int actual = 0;
                for (int i = 0; i < 16; i++) if (in.read() == 0) actual++;
                check(actual == 16 && in.read() == -1, "Strict diagnostics preserve stream results");
            } finally { in.close(); }
        } catch (IOException error) {
            throw new IllegalStateException(error);
        } finally {
            StrictMode.setThreadPolicy(original);
        }
        check(mask(0).equals(StrictMode.getThreadPolicy().toString()), "Original policy restored");
        return checks;
    }
}
