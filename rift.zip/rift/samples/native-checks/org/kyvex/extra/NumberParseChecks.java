package org.kyvex.extra;
public final class NumberParseChecks {
 private static int checks;
 private static void check(boolean value,String why){if(!value)throw new IllegalStateException(why);checks++;}
 public static int deep(int depth){return depth==0?1:deep(depth-1)+1;}
 private static boolean rejected(int width,String input,int radix){try{switch(width){case 8:Byte.parseByte(input,radix);break;case 16:Short.parseShort(input,radix);break;case 32:Integer.parseInt(input,radix);break;default:Long.parseLong(input,radix);break;}return false;}catch(NumberFormatException expected){return true;}}
 public static int verify(){checks=0;
  check(Byte.parseByte("01110000",2)==112,"Firebase binary byte constant");
  check(deep(64)==65,"Ordinary dependency call depth beyond 32 frames");
  check(Byte.parseByte("-128")==-128&&Byte.parseByte("+127")==127,"Byte signed boundaries and default radix");
  check(Short.parseShort("7fff",16)==32767&&Short.parseShort("-8000",16)==-32768,"Short radix boundaries");
  check(Short.parseShort("-32768")==-32768,"Short default radix");
  check(Integer.parseInt("-2147483648")==Integer.MIN_VALUE&&Integer.parseInt("7fffffff",16)==Integer.MAX_VALUE,"Int default and explicit radix");
  check(Long.parseLong("-9223372036854775808")==Long.MIN_VALUE&&Long.parseLong("7fffffffffffffff",16)==Long.MAX_VALUE,"Long full precision and minimum value");
  check(Byte.parseByte("\u0661\u0662\u0667")==127,"Arabic decimal digit units");
  check(Byte.parseByte("\uff17\uff26",16)==127,"Fullwidth hexadecimal digits");
  check(Integer.parseInt("+\u0e51\u0e52")==12,"Thai digits and ASCII sign");
  check(Integer.parseInt("zik0zj",36)==Integer.MAX_VALUE,"Base36 digits");
  check(Byte.parseByte("-0000000000000000000000",2)==0,"Signed long zero spelling");
  check(rejected(8,"128",10)&&rejected(8,"-129",10),"Byte overflow is rejected");
  check(rejected(16,"32768",10)&&rejected(16,"-32769",10),"Short overflow is rejected");
  check(rejected(32,"2147483648",10)&&rejected(32,"-2147483649",10),"Int overflow is rejected");
  check(rejected(64,"9223372036854775808",10)&&rejected(64,"-9223372036854775809",10),"Long overflow is rejected");
  for(int width:new int[]{8,16,32,64}){
   check(rejected(width,null,10),"Null gives NumberFormatException");
   check(rejected(width,"",10)&&rejected(width,"+",10)&&rejected(width,"-",10),"Empty and sign-only values rejected");
   check(rejected(width,"10",1)&&rejected(width,"10",37),"Invalid radix rejected");
   check(rejected(width," 1",10)&&rejected(width,"1 ",10)&&rejected(width,"0xff",16),"No whitespace trimming or implicit prefix");
   check(rejected(width,"\ud835\udfcf",10)&&rejected(width,"\ud800",10),"Parsing uses Java UTF16 char digits");
  }
  return checks;
 }
 public static void main(String[] args){System.out.println("Number parse checks: "+verify());}
}
