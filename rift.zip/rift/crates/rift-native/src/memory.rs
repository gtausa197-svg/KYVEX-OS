use crate::Result;
use std::collections::BTreeMap;
pub const PAGE: u64 = 4096;
pub const READ: u8 = 1;
pub const WRITE: u8 = 2;
pub const EXEC: u8 = 4;
struct Page {
    bytes: Box<[u8; 4096]>,
    permissions: u8,
}
pub struct Memory {
    pages: BTreeMap<u64, Page>,
    limit: usize,
    pub peak: usize,
}
impl Memory {
    pub fn new(limit: usize) -> Self {
        Self {
            pages: BTreeMap::new(),
            limit,
            peak: 0,
        }
    }
    fn range(address: u64, size: usize) -> Result<(u64, u64)> {
        if size == 0 || address < PAGE {
            return Err("Invalid guest mapping range".into());
        }
        let end = address
            .checked_add(size as u64)
            .and_then(|v| v.checked_add(PAGE - 1))
            .ok_or("Guest address overflow")?
            & !(PAGE - 1);
        if end > 0x0000_8000_0000_0000 {
            return Err("Guest address is not canonical".into());
        }
        Ok((address & !(PAGE - 1), end))
    }
    pub fn mapped(&self) -> usize {
        self.pages.len() * PAGE as usize
    }
    /// Build a native image group against the remaining guest memory budget.
    pub(crate) fn staging(&self) -> Self {
        Self::new(self.limit - self.mapped())
    }
    pub(crate) fn commit(&mut self, mut staging: Self) -> Result<()> {
        if staging.mapped() > self.limit - self.mapped() {
            return Err("Guest memory quota exceeded".into());
        }
        if staging
            .pages
            .keys()
            .any(|page| self.pages.contains_key(page))
        {
            return Err("ELF image overlaps an existing guest mapping".into());
        }
        self.pages.append(&mut staging.pages);
        self.peak = self.peak.max(self.mapped());
        Ok(())
    }
    pub fn map(&mut self, address: u64, size: usize, permissions: u8) -> Result<()> {
        if permissions & !7 != 0 || permissions & 6 == 6 {
            return Err("Writable executable guest pages are rejected".into());
        }
        let (start, end) = Self::range(address, size)?;
        if (end - start) > self.limit as u64 {
            return Err("Guest memory quota exceeded".into());
        }
        let mut extra = 0;
        for p in (start..end).step_by(PAGE as usize) {
            if let Some(old) = self.pages.get(&p) {
                if (old.permissions | permissions) & 6 == 6 {
                    return Err("Overlapping ELF segments would violate W^X".into());
                }
            } else {
                extra += PAGE as usize;
            }
        }
        if self
            .mapped()
            .checked_add(extra)
            .is_none_or(|n| n > self.limit)
        {
            return Err("Guest memory quota exceeded".into());
        }
        for p in (start..end).step_by(PAGE as usize) {
            self.pages
                .entry(p)
                .and_modify(|v| v.permissions |= permissions)
                .or_insert_with(|| Page {
                    bytes: Box::new([0; 4096]),
                    permissions,
                });
        }
        self.peak = self.peak.max(self.mapped());
        Ok(())
    }
    fn check(&self, address: u64, size: usize, permission: u8) -> Result<()> {
        let end = address
            .checked_add(size as u64)
            .ok_or("Guest access overflow")?;
        if size == 0 {
            return Ok(());
        }
        for p in (address & !(PAGE - 1)..end).step_by(PAGE as usize) {
            let page = self
                .pages
                .get(&p)
                .ok_or_else(|| format!("Unmapped guest address 0x{p:x}"))?;
            if page.permissions & permission != permission {
                return Err(
                    format!("Guest permission fault at 0x{p:x} (access {permission})").into(),
                );
            }
        }
        Ok(())
    }
    pub fn read(&self, mut address: u64, mut output: &mut [u8], permission: u8) -> Result<()> {
        self.check(address, output.len(), permission)?;
        while !output.is_empty() {
            let page = self
                .pages
                .get(&(address & !(PAGE - 1)))
                .ok_or("Guest page disappeared")?;
            let offset = (address & (PAGE - 1)) as usize;
            let n = output.len().min(4096 - offset);
            output[..n].copy_from_slice(&page.bytes[offset..offset + n]);
            output = &mut output[n..];
            address += n as u64;
        }
        Ok(())
    }
    fn put(&mut self, mut address: u64, mut input: &[u8], permission: u8) -> Result<()> {
        self.check(address, input.len(), permission)?;
        while !input.is_empty() {
            let page = self
                .pages
                .get_mut(&(address & !(PAGE - 1)))
                .ok_or("Guest page disappeared")?;
            let offset = (address & (PAGE - 1)) as usize;
            let n = input.len().min(4096 - offset);
            page.bytes[offset..offset + n].copy_from_slice(&input[..n]);
            input = &input[n..];
            address += n as u64;
        }
        Ok(())
    }
    pub fn write(&mut self, address: u64, input: &[u8]) -> Result<()> {
        self.put(address, input, WRITE)
    }
    pub(crate) fn fill(&mut self, mut address: u64, mut size: usize, byte: u8) -> Result<()> {
        self.check(address, size, WRITE)?;
        while size > 0 {
            let page = self
                .pages
                .get_mut(&(address & !(PAGE - 1)))
                .ok_or("Guest page disappeared")?;
            let offset = (address & (PAGE - 1)) as usize;
            let count = size.min(PAGE as usize - offset);
            page.bytes[offset..offset + count].fill(byte);
            address += count as u64;
            size -= count;
        }
        Ok(())
    }
    /// Only loaders may initialize read-only guest mappings, before execution.
    pub fn initialize(&mut self, address: u64, input: &[u8]) -> Result<()> {
        self.put(address, input, 0)
    }
    pub fn bytes(&self, address: u64, size: usize) -> Result<Vec<u8>> {
        if size > 1024 * 1024 {
            return Err("Guest copy limit".into());
        }
        let mut b = vec![0; size];
        self.read(address, &mut b, READ)?;
        Ok(b)
    }
    pub fn string(&self, address: u64, maximum: usize) -> Result<String> {
        let mut bytes = Vec::new();
        for i in 0..maximum.min(16384) {
            let mut b = [0];
            self.read(
                address
                    .checked_add(i as u64)
                    .ok_or("String address overflow")?,
                &mut b,
                READ,
            )?;
            if b[0] == 0 {
                return Ok(String::from_utf8(bytes)?);
            }
            bytes.push(b[0]);
        }
        Err("Unterminated or excessive guest string".into())
    }
    pub fn protect(&mut self, address: u64, size: usize, permissions: u8) -> Result<()> {
        if !address.is_multiple_of(PAGE) || permissions & !7 != 0 || permissions & 6 == 6 {
            return Err("Invalid guest protection".into());
        }
        self.check(address, size, 0)?;
        let (start, end) = Self::range(address, size)?;
        for p in (start..end).step_by(PAGE as usize) {
            self.pages.get_mut(&p).unwrap().permissions = permissions;
        }
        Ok(())
    }
    pub fn unmap(&mut self, address: u64, size: usize) -> Result<()> {
        if !address.is_multiple_of(PAGE) {
            return Err("Unaligned guest unmap".into());
        }
        let (start, end) = Self::range(address, size)?;
        if end - start > self.limit as u64 {
            return Err("Guest unmap limit".into());
        }
        for p in (start..end).step_by(PAGE as usize) {
            self.pages.remove(&p);
        }
        Ok(())
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn cross_page_permissions_and_atomic_failure() {
        let mut m = Memory::new(8192);
        m.map(4096, 4096, READ | WRITE).unwrap();
        m.map(8192, 4096, READ).unwrap();
        m.write(8188, &[1, 2, 3, 4]).unwrap();
        assert!(m.write(8188, &[9; 8]).is_err());
        assert_eq!(m.bytes(8188, 4).unwrap(), [1, 2, 3, 4]);
        assert!(m.read(4096, &mut [0], EXEC).is_err());
    }
    #[test]
    fn quota_overflow_and_wx() {
        let mut m = Memory::new(4096);
        m.map(4096, 4096, READ | EXEC).unwrap();
        assert!(m.map(8192, 1, READ).is_err());
        assert!(m.map(4096, 1, WRITE).is_err());
        assert!(m.map(u64::MAX, 2, READ).is_err());
        assert!(m.map(0, 4096, READ).is_err());
    }
    #[test]
    fn mapped_pages_are_lazy_and_reclaimed() {
        let mut m = Memory::new(64 * 1024 * 1024);
        assert_eq!(m.mapped(), 0);
        m.map(0x10000, 1, READ | WRITE).unwrap();
        assert_eq!(m.mapped(), 4096);
        m.unmap(0x10000, 1).unwrap();
        assert_eq!(m.mapped(), 0);
        assert_eq!(m.peak, 4096);
    }

    #[test]
    fn staged_image_commit_is_atomic_and_preserves_live_page_permissions() {
        let mut memory = Memory::new(4 * PAGE as usize);
        memory.map(0x30000, 1, READ).unwrap();
        memory.initialize(0x30000, &[7]).unwrap();
        let mut staging = memory.staging();
        staging.map(0x10000, 1, READ | EXEC).unwrap();
        staging.map(0x30000, 1, READ | WRITE).unwrap();
        staging.initialize(0x30000, &[99]).unwrap();
        assert!(
            memory
                .commit(staging)
                .unwrap_err()
                .to_string()
                .contains("overlaps")
        );
        assert_eq!(memory.mapped(), PAGE as usize);
        assert_eq!(memory.peak, PAGE as usize);
        assert_eq!(memory.bytes(0x30000, 1).unwrap(), [7]);
        assert!(memory.write(0x30000, &[0]).is_err());
        assert!(memory.bytes(0x10000, 1).is_err());

        let mut staging = memory.staging();
        staging.map(0x10000, 1, READ | EXEC).unwrap();
        staging.initialize(0x10000, &[11]).unwrap();
        memory.commit(staging).unwrap();
        assert_eq!(memory.mapped(), 2 * PAGE as usize);
        assert_eq!(memory.bytes(0x10000, 1).unwrap(), [11]);
    }
}
