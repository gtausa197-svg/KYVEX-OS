//! Cached Java insertion hashes and a bucket index over ordered guest entries.
use super::*;

#[derive(Default)]
pub(super) struct HashMapData {
    pub entries: Vec<(u32, u32)>,
    hashes: Vec<u32>,
    buckets: BTreeMap<u32, Vec<usize>>,
}

impl HashMapData {
    pub fn bytes(&self) -> usize {
        self.entries.capacity() * 8
            + self.hashes.capacity() * 4
            + self
                .buckets
                .values()
                .map(|bucket| 64 + bucket.capacity() * std::mem::size_of::<usize>())
                .sum::<usize>()
    }

    pub fn candidates(&self, hash: u32) -> &[usize] {
        self.buckets.get(&hash).map_or(&[], Vec::as_slice)
    }

    pub fn insertion_hash(&self, index: usize) -> u32 {
        self.hashes[index]
    }

    pub fn push(&mut self, key: u32, value: u32, hash: u32) {
        self.buckets
            .entry(hash)
            .or_default()
            .push(self.entries.len());
        self.hashes.push(hash);
        self.entries.push((key, value));
    }

    pub fn remove(&mut self, index: usize) -> (u32, u32) {
        let removed = self.entries.remove(index);
        self.hashes.remove(index);
        self.buckets.retain(|_, bucket| {
            bucket.retain(|&candidate| candidate != index);
            for candidate in bucket.iter_mut().filter(|candidate| **candidate > index) {
                *candidate -= 1;
            }
            !bucket.is_empty()
        });
        removed
    }

    pub fn clear(&mut self) {
        self.entries.clear();
        self.hashes.clear();
        self.buckets.clear();
    }
}

impl Runtime {
    pub(super) fn java_key_hash(&mut self, key: u32) -> Result<u32> {
        if key == 0 {
            return Ok(0);
        }
        let object = self.object(key)?;
        if let Payload::String(units) = &object.payload {
            return Ok(units.iter().fold(0u32, |hash, &unit| {
                hash.wrapping_mul(31).wrapping_add(u32::from(unit))
            }));
        }
        let owner = match object.payload {
            Payload::Boxed { .. }
            | Payload::Uuid(..)
            | Payload::Date(_)
            | Payload::Charset(_)
            | Payload::LogLevel(_)
            | Payload::Messenger(_)
            | Payload::File(_) => object.class.clone(),
            _ if object.class == "Ljava/lang/StackTraceElement;"
                || object.class == point::POINT =>
            {
                object.class.clone()
            }
            _ if pair::has_members(object) => pair::PAIR.into(),
            _ => "Ljava/lang/Object;".into(),
        };
        Ok(self.collection_dispatch(key, &owner, "hashCode()I", &[])? as u32)
    }

    pub(super) fn new_hash_map(&mut self, entries: Vec<(u32, u32)>) -> Result<u32> {
        let keys: Vec<_> = entries.iter().map(|&(key, _)| key).collect();
        let values: Vec<_> = entries.iter().map(|&(_, value)| value).collect();
        let _keys = self.scoped_library_roots(&keys)?;
        let _values = self.scoped_library_roots(&values)?;
        let mut data = HashMapData::default();
        for (key, value) in entries {
            let hash = self.java_key_hash(key)?;
            data.push(key, value, hash);
        }
        self.allocate("Ljava/util/HashMap;", Payload::HashedMap(data))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn removal_preserves_collision_positions_and_cached_hashes() {
        let mut map = HashMapData::default();
        map.push(1, 10, 7);
        map.push(2, 20, 8);
        map.push(3, 30, 7);
        map.push(4, 40, 9);
        assert_eq!(map.remove(0), (1, 10));
        assert_eq!(map.candidates(7), &[1]);
        assert_eq!(map.candidates(8), &[0]);
        assert_eq!(map.candidates(9), &[2]);
        assert_eq!(map.insertion_hash(1), 7);
        assert_eq!(map.remove(2), (4, 40));
        assert!(map.candidates(9).is_empty());
    }
}
