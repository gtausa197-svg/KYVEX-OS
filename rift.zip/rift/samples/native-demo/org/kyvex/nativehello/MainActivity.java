package org.kyvex.nativehello;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Ordinary Android code; the same APK can also be checked on Android. */
public final class MainActivity extends Activity {
    private TextView result;
    private int taps;
    static {System.loadLibrary("kyvexdemo");}
    private static native int timesSeven(int value);
    private static native String nativeMessage();
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("Hello from Rift Native");
        LinearLayout layout=new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24,24,24,24);
        layout.setBackgroundColor(0xff101a2a);
        TextView title=new TextView(this);
        title.setText(nativeMessage());
        title.setTextSize(24);
        title.setTextColor(0xff7cf5d8);
        layout.addView(title);
        TextView detail=new TextView(this);
        detail.setText("A Java Activity calling real ARM machine code through JNI.");
        detail.setTextColor(0xffc3cde0);
        layout.addView(detail);
        result=new TextView(this);
        result.setTextSize(30);
        result.setTextColor(0xffeeeeff);
        layout.addView(result);
        Button button=new Button(this);
        button.setText("Run ARM calculation");
        button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {taps++;updateResult();}
        });
        layout.addView(button);
        setContentView(layout);
        updateResult();
    }
    private void updateResult() {result.setText("ARM result: "+timesSeven(taps+1));}
}
