//! Per-thread Android 28 diagnostic policy for the guest's implemented operations.
use super::*;

const STRICT: &str = "Landroid/os/StrictMode;";
pub(super) const POLICY: &str = "Landroid/os/StrictMode$ThreadPolicy;";
const BUILDER: &str = "Landroid/os/StrictMode$ThreadPolicy$Builder;";
pub(super) const DISK_WRITE: u32 = 0x01;
pub(super) const DISK_READ: u32 = 0x02;
const NETWORK: u32 = 0x04;
const SLOW_CALL: u32 = 0x08;
const RESOURCE_MISMATCH: u32 = 0x10;
pub(super) const UNBUFFERED_IO: u32 = 0x20;
const DETECTORS: u32 =
    DISK_WRITE | DISK_READ | NETWORK | SLOW_CALL | RESOURCE_MISMATCH | UNBUFFERED_IO;
const LOG: u32 = 1 << 16;

#[derive(Clone, Copy, Default)]
pub(super) struct IoTracker {
    operations: u8,
    bytes: u16,
    reported: bool,
}

impl IoTracker {
    pub(super) fn track(&mut self, bytes: usize) -> bool {
        if self.reported || self.bytes >= 5120 {
            return false;
        }
        self.operations = self.operations.saturating_add(1);
        self.bytes = (usize::from(self.bytes) + bytes.min(5120)).min(5120) as u16;
        self.reported = self.operations > 10 && self.bytes < 5120;
        self.reported
    }
}

pub(super) fn payload(class: &str) -> Option<Payload> {
    (class == BUILDER).then_some(Payload::StrictPolicyBuilder(0))
}

impl Runtime {
    pub(super) fn new_strict_policy(&mut self, mask: u32) -> Result<u64> {
        Ok(self.allocate(POLICY, Payload::StrictPolicy(mask))? as u64)
    }

    fn strict_policy_mask(&self, id: u32) -> Result<u32> {
        match self.object(id)?.payload {
            Payload::StrictPolicy(mask) => Ok(mask),
            _ => Err(fault(
                "Ljava/lang/ClassCastException;",
                "Expected ThreadPolicy",
            )),
        }
    }

    fn current_strict_mask(&self) -> u32 {
        self.scheduler
            .records
            .get(&self.current_thread)
            .map_or(0, |record| record.strict_mask)
    }

    fn set_strict_mask(&mut self, mask: u32) -> Result<()> {
        self.ensure_main_thread()?;
        self.scheduler
            .records
            .get_mut(&self.current_thread)
            .ok_or("Current guest thread policy")?
            .strict_mask = mask;
        Ok(())
    }

    pub(super) fn strict_log(&mut self, detector: u32, detail: &str) {
        let required = detector | LOG;
        if self.current_strict_mask() & required == required {
            self.append_guest_log(format!("StrictMode: {detail}"));
        }
    }

    pub(super) fn strict_mode_api(&mut self, sig: &str, args: &[u32]) -> Result<Option<u64>> {
        if !sig.starts_with("Landroid/os/StrictMode") {
            return Ok(None);
        }
        let (class, method) = sig.split_once("->").ok_or("StrictMode signature")?;
        let argument = |index: usize| args.get(index).copied().ok_or("StrictMode argument count");
        if class == STRICT {
            return Ok(Some(match method {
                "getThreadPolicy()Landroid/os/StrictMode$ThreadPolicy;" => {
                    self.new_strict_policy(self.current_strict_mask())?
                }
                "setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V" => {
                    let mask = self.strict_policy_mask(argument(0)?)?;
                    self.set_strict_mask(mask)?;
                    0
                }
                "allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;"
                | "allowThreadDiskWrites()Landroid/os/StrictMode$ThreadPolicy;" => {
                    let old = self.current_strict_mask();
                    let previous = self.new_strict_policy(old)?;
                    let remove = if method.starts_with("allowThreadDiskReads") {
                        DISK_READ
                    } else {
                        DISK_READ | DISK_WRITE
                    };
                    self.set_strict_mask(old & !remove)?;
                    previous
                }
                "noteSlowCall(Ljava/lang/String;)V" => {
                    if self.current_strict_mask() & SLOW_CALL != 0 {
                        let detail = self.text(argument(0)?)?;
                        self.strict_log(SLOW_CALL, &detail);
                    }
                    0
                }
                _ => return Ok(None),
            }));
        }
        if class == POLICY && method == "toString()Ljava/lang/String;" {
            let mask = self.strict_policy_mask(argument(0)?)?;
            return Ok(Some(
                self.string(&format!("[StrictMode.ThreadPolicy; mask={mask}]"))? as u64,
            ));
        }
        if class != BUILDER {
            return Ok(None);
        }
        let id = argument(0)?;
        let Payload::StrictPolicyBuilder(mask) = self.object(id)?.payload else {
            return Err("StrictMode ThreadPolicy builder receiver".into());
        };
        let (mask, result) = match method {
            "<init>()V" => (0, 0),
            "<init>(Landroid/os/StrictMode$ThreadPolicy;)V" => {
                (self.strict_policy_mask(argument(1)?)?, 0)
            }
            "build()Landroid/os/StrictMode$ThreadPolicy;" => {
                let mask = if mask != 0 { mask | LOG } else { 0 };
                (mask, self.new_strict_policy(mask)?)
            }
            _ => {
                let Some(operation) =
                    method.strip_suffix("()Landroid/os/StrictMode$ThreadPolicy$Builder;")
                else {
                    return Ok(None);
                };
                let bits = match operation {
                    "detectDiskReads" | "permitDiskReads" => DISK_READ,
                    "detectDiskWrites" | "permitDiskWrites" => DISK_WRITE,
                    "detectNetwork" | "permitNetwork" => NETWORK,
                    "detectCustomSlowCalls" | "permitCustomSlowCalls" => SLOW_CALL,
                    "detectResourceMismatches" | "permitResourceMismatches" => RESOURCE_MISMATCH,
                    "detectUnbufferedIo" | "permitUnbufferedIo" => UNBUFFERED_IO,
                    "permitAll" => DETECTORS,
                    "detectAll" => {
                        let sdk = self
                            .metadata
                            .as_ref()
                            .map_or(28, |metadata| metadata.target_sdk);
                        DISK_READ
                            | DISK_WRITE
                            | NETWORK
                            | if sdk >= 11 { SLOW_CALL } else { 0 }
                            | if sdk >= 23 { RESOURCE_MISMATCH } else { 0 }
                            | if sdk >= 26 { UNBUFFERED_IO } else { 0 }
                    }
                    "penaltyLog" => LOG,
                    _ => return Ok(None),
                };
                let next = if operation.starts_with("permit") {
                    mask & !bits
                } else {
                    mask | bits
                };
                (next, id as u64)
            }
        };
        self.object_mut(id)?.payload = Payload::StrictPolicyBuilder(mask);
        Ok(Some(result))
    }
}
