//! Android's C-locale integer conversion with guest-sized results and pointers.
use super::*;

const MAX_SCAN: usize = 16384;

pub(super) struct Conversion {
    pub(super) value: u64,
    pub(super) end: usize,
    pub(super) error: Option<i32>,
}

fn digit(byte: u8) -> Option<u64> {
    let value = match byte {
        b'0'..=b'9' => byte - b'0',
        b'A'..=b'Z' => byte - b'A' + 10,
        b'a'..=b'z' => byte - b'a' + 10,
        _ => return None,
    };
    Some(u64::from(value))
}

pub(super) fn convert(
    read: impl Fn(usize) -> Result<u8>,
    base: i32,
    bits: u32,
    signed: bool,
) -> Result<Conversion> {
    if base != 0 && !(2..=36).contains(&base) {
        return Ok(Conversion {
            value: 0,
            end: 0,
            error: Some(libc::EINVAL),
        });
    }
    let mut cursor = 0;
    while matches!(read(cursor)?, b' ' | 9..=13) {
        cursor += 1;
    }
    let sign = read(cursor)?;
    if matches!(sign, b'+' | b'-') {
        cursor += 1;
    }
    let negative = sign == b'-';
    let leading_zero = read(cursor)? == b'0';
    let mut radix = match base {
        0 if leading_zero => 8,
        0 => 10,
        _ => base as u64,
    };
    if leading_zero
        && matches!(base, 0 | 16)
        && matches!(read(cursor + 1)?, b'x' | b'X')
        && read(cursor + 2)?.is_ascii_hexdigit()
    {
        cursor += 2;
        radix = 16;
    }
    let first_digit = cursor;
    let mask = u64::MAX >> (64 - bits);
    let limit = if signed {
        (mask >> 1) + u64::from(negative)
    } else {
        mask
    };
    let quotient = limit / radix;
    let remainder = limit % radix;
    let mut value = 0;
    let mut overflow = false;
    while let Some(next) = digit(read(cursor)?).filter(|next| *next < radix) {
        if value > quotient || (value == quotient && next > remainder) {
            overflow = true;
        } else if !overflow {
            value = value * radix + next;
        }
        cursor += 1;
    }
    if overflow {
        value = limit;
    }
    if negative && (signed || !overflow) {
        value = value.wrapping_neg() & mask;
    }
    Ok(Conversion {
        value,
        end: if cursor == first_digit { 0 } else { cursor },
        error: overflow.then_some(libc::ERANGE),
    })
}

impl Machine {
    pub(super) fn integer_call(&mut self, function: &str, state: &mut State) -> Result<u64> {
        // Bionic's explicit-locale integer variants use the same C conversion.
        let function = function.trim_end_matches("_l");
        let [input, endptr, base, ..] = state.regs;
        let bits = if matches!(function, "strtol" | "strtoul") {
            self.arch
        } else {
            64
        };
        let signed = matches!(function, "strtol" | "strtoll" | "strtoimax");
        let conversion = convert(
            |offset| {
                if offset >= MAX_SCAN {
                    return Err("Guest strto* input quota".into());
                }
                let address = input
                    .checked_add(offset as u64)
                    .ok_or("strto* input address overflow")?;
                let mut byte = [0];
                self.cpu.memory().read(address, &mut byte, READ)?;
                Ok(byte[0])
            },
            base as i32,
            bits,
            signed,
        )?;
        if endptr != 0 {
            let end = input
                .checked_add(conversion.end as u64)
                .ok_or("strto* end address overflow")?;
            self.cpu
                .memory_mut()
                .write(endptr, &end.to_le_bytes()[..(self.arch / 8) as usize])?;
        }
        if let Some(error) = conversion.error {
            self.set_guest_errno(error)?;
        }
        if self.arch == 32 && bits == 64 {
            state.regs[1] = conversion.value >> 32;
        }
        Ok(conversion.value)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scans_c_integer_prefixes_and_stops_at_the_first_non_digit() {
        let input = b" \x0b-0x1f!";
        let value = convert(|offset| Ok(input[offset]), 0, 32, true).unwrap();
        assert_eq!(
            (value.value as u32 as i32, value.end, value.error),
            (-31, 7, None)
        );
        let input = b"0x\0";
        let value = convert(|offset| Ok(input[offset]), 16, 64, true).unwrap();
        assert_eq!((value.value, value.end, value.error), (0, 1, None));
        let input = b" +!";
        let value = convert(|offset| Ok(input[offset]), 0, 64, true).unwrap();
        assert_eq!((value.value, value.end, value.error), (0, 0, None));
        let value = convert(|_| panic!("invalid base reads input"), 1, 64, true).unwrap();
        assert_eq!(
            (value.value, value.end, value.error),
            (0, 0, Some(libc::EINVAL))
        );
    }
}
