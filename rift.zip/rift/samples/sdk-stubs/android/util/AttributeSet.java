package android.util;

/** Compile-only Android SDK interface. */
public interface AttributeSet {
    int getAttributeCount();
    String getAttributeName(int index);
    String getAttributeValue(int index);
    String getAttributeValue(String namespace, String name);
    String getPositionDescription();
    int getAttributeNameResource(int index);
    int getAttributeListValue(String namespace, String name, String[] options, int fallback);
    boolean getAttributeBooleanValue(String namespace, String name, boolean fallback);
    int getAttributeResourceValue(String namespace, String name, int fallback);
    int getAttributeIntValue(String namespace, String name, int fallback);
    int getAttributeUnsignedIntValue(String namespace, String name, int fallback);
    float getAttributeFloatValue(String namespace, String name, float fallback);
    int getAttributeListValue(int index, String[] options, int fallback);
    boolean getAttributeBooleanValue(int index, boolean fallback);
    int getAttributeResourceValue(int index, int fallback);
    int getAttributeIntValue(int index, int fallback);
    int getAttributeUnsignedIntValue(int index, int fallback);
    float getAttributeFloatValue(int index, float fallback);
    String getIdAttribute();
    String getClassAttribute();
    int getIdAttributeResourceValue(int fallback);
    int getStyleAttribute();
}
