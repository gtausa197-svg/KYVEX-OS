//! Android logging and checksum calls over guest-owned bytes.
use super::c_format::Arguments;
use super::*;

impl Machine {
    pub(super) fn native_log(&mut self, function: &str, state: &State) -> Result<u64> {
        let asserting = function == "__android_log_assert";
        let priority = if asserting { 7 } else { state.regs[0] as i32 };
        if !(4..=7).contains(&priority) {
            return Ok((-libc::EPERM as i64) as u64);
        }
        let tag = if state.regs[1] == 0 {
            b"Native".to_vec()
        } else {
            self.bounded_text(state.regs[1], 48)?
        };
        let message = if function == "__android_log_write" {
            self.bounded_text(state.regs[2], 512)
        } else if asserting && state.regs[2] == 0 {
            if state.regs[0] == 0 {
                Ok(b"Native assertion failed".to_vec())
            } else {
                self.bounded_text(state.regs[0], 512)
            }
        } else {
            self.format_c(state.regs[2], Arguments::call(self, state, 3), 512, true)
        };
        let message = match message {
            Ok(message) => message,
            Err(_) if asserting => b"Native assertion failed".to_vec(),
            Err(_) => return Ok((-libc::EINVAL as i64) as u64),
        };
        let message = message.split(|byte| *byte == 0).next().unwrap_or_default();
        self.queue_native_log(format!(
            "{priority}/{}: {}",
            String::from_utf8_lossy(&tag),
            String::from_utf8_lossy(message)
        ));
        if asserting {
            return Err("The guest native library asserted".into());
        }
        Ok(1)
    }

    pub(super) fn adler32(&self, seed: u32, address: u64, len: u32) -> Result<u64> {
        if address == 0 {
            return Ok(1);
        }
        if len > 1024 * 1024 {
            return Err("Guest Adler-32 input quota".into());
        }
        let mut low = u64::from(seed & 0xffff);
        let mut high = u64::from(seed >> 16);
        let mut buffer = [0; 4096];
        let mut offset = 0;
        while offset < len {
            let count = ((len - offset) as usize).min(buffer.len());
            let start = address
                .checked_add(u64::from(offset))
                .ok_or("Adler-32 address overflow")?;
            self.cpu.memory().read(start, &mut buffer[..count], READ)?;
            for &byte in &buffer[..count] {
                low += u64::from(byte);
                high += low;
            }
            low %= 65521;
            high %= 65521;
            offset += count as u32;
        }
        Ok(high << 16 | low)
    }
}
