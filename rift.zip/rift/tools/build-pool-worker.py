#!/usr/bin/env python3
"""Build the tiny own pool loop; private bridge declarations stay compile-only."""
import argparse,hashlib,json,pathlib,subprocess,tempfile

parser=argparse.ArgumentParser()
parser.add_argument('--r8',required=True)
args=parser.parse_args()
root=pathlib.Path(__file__).resolve().parents[1]
support=root/'crates/rift-native/support'
r8=pathlib.Path(args.r8)
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
pin=json.loads((root/'samples/TOOLCHAIN.json').read_text())
if digest(r8)!=pin['r8_sha256']:raise SystemExit('Pinned D8 digest mismatch')
worker=support/'java/org/kyvex/rift/internal/PoolWorker.java'
task=worker.with_name('ScheduledTask.java')
bridge=support/'compile-only/org/kyvex/rift/internal/PoolAccess.java'
def run(*words):subprocess.run([str(word) for word in words],check=True)
with tempfile.TemporaryDirectory(prefix='kyvex-pool-worker-') as temporary:
 temp=pathlib.Path(temporary)
 classes=temp/'classes';classes.mkdir()
 dex=temp/'dex';dex.mkdir()
 run('javac','--release','8','-d',classes,worker,task,bridge)
 run('jar','cf',temp/'bridge.jar','-C',classes,'org/kyvex/rift/internal/PoolAccess.class')
 run('java','-cp',r8,'com.android.tools.r8.D8','--release','--min-api','23','--lib','/usr/lib/jvm/default','--classpath',temp/'bridge.jar','--output',dex,*(classes/'org/kyvex/rift/internal'/source.with_suffix('.class').name for source in [worker,task]))
 (support/'pool-worker.dex').write_bytes((dex/'classes.dex').read_bytes())
manifest=dict(purpose='Own resumable guest pool loop and scheduled task entry',
    dex_sha256=digest(support/'pool-worker.dex'),r8=pin,
    sources={path.relative_to(support).as_posix():digest(path) for path in [worker,task,bridge]})
(support/'pool-worker.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(own_dex_bytes=(support/'pool-worker.dex').stat().st_size,sha256=manifest['dex_sha256'])))
