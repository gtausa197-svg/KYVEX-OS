//! Link selected-ABI APK libraries into private pages before publishing any image.
use super::*;
use std::collections::{BTreeSet, VecDeque};

const MAX_OPEN_INPUT: usize = 192 * 1024 * 1024;

type Exports = BTreeMap<String, u64>;
type Platforms = BTreeMap<&'static str, Exports>;

struct Group<'a> {
    arch: u32,
    existing: &'a BTreeMap<String, Image>,
    platforms: &'a Platforms,
    staging: Memory,
    pending: BTreeMap<String, Image>,
    loading: BTreeSet<String>,
    input_bytes: usize,
}

fn import_scope<'a>(
    needed: &[String],
    existing: &'a BTreeMap<String, Image>,
    pending: &'a BTreeMap<String, Image>,
    platforms: &'a Platforms,
) -> Result<Vec<&'a Exports>> {
    let mut queue: VecDeque<_> = needed.iter().map(String::as_str).collect();
    let mut visited = BTreeSet::new();
    let mut scope = Vec::new();
    while let Some(name) = queue.pop_front() {
        if !visited.insert(name) {
            continue;
        }
        if let Some(exports) = platforms.get(name) {
            scope.push(exports);
        } else {
            let library = pending
                .get(name)
                .or_else(|| existing.get(name))
                .ok_or("ELF dependency disappeared during linking")?;
            scope.push(&library.exports);
            queue.extend(library.needed.iter().map(String::as_str));
        }
    }
    // The guest process already has the core C surface available.
    if !visited.contains("libc.so") {
        scope.push(&platforms["libc.so"]);
    }
    Ok(scope)
}

impl Group<'_> {
    fn add(&mut self, name: &str, fetch: &mut impl FnMut(&str) -> Result<Vec<u8>>) -> Result<()> {
        if self.existing.contains_key(name) || self.pending.contains_key(name) {
            return Ok(());
        }
        if self.existing.len() + self.pending.len() + self.loading.len() >= MAX_IMAGES {
            return Err("Native library count quota".into());
        }
        if !self.loading.insert(name.to_owned()) {
            return Err(format!("Cyclic APK ELF dependency: {name}").into());
        }
        let bytes = fetch(name).map_err(|error| format!("{name}: {error}"))?;
        self.input_bytes = self
            .input_bytes
            .checked_add(bytes.len())
            .ok_or("ELF input size overflow")?;
        if self.input_bytes > MAX_OPEN_INPUT {
            return Err("Combined ELF input exceeds 192 MiB".into());
        }
        let plan = elf::plan(&bytes).map_err(|error| format!("{name}: {error}"))?;
        if !plan.shared || plan.arch != self.arch {
            return Err(
                format!("{name}: APK library must match the selected shared-object ABI").into(),
            );
        }
        for dependency in &plan.needed {
            if !self.platforms.contains_key(dependency.as_str()) {
                self.add(dependency, fetch)
                    .map_err(|error| format!("{name} needs {error}"))?;
            }
        }
        let scope = import_scope(&plan.needed, self.existing, &self.pending, self.platforms)?;
        let bias = image_bias(self.existing.len() + self.pending.len());
        let image = elf::link(plan, &mut self.staging, bias, |symbol| {
            scope
                .iter()
                .find_map(|exports| exports.get(symbol).copied())
        })
        .map_err(|error| format!("{name}: {error}"))?;
        self.pending.insert(name.to_owned(), image);
        self.loading.remove(name);
        self.input_bytes -= bytes.len();
        Ok(())
    }
}

impl Machine {
    pub(crate) fn load_apk_library(
        &mut self,
        name: &str,
        mut fetch: impl FnMut(&str) -> Result<Vec<u8>>,
    ) -> Result<()> {
        if !elf::valid_library_name(name) {
            return Err("Invalid APK native library filename".into());
        }
        let mut group = Group {
            arch: self.arch,
            existing: &self.images,
            platforms: &self.platforms,
            staging: self.cpu.memory().staging(),
            pending: BTreeMap::new(),
            loading: BTreeSet::new(),
            input_bytes: 0,
        };
        group.add(name, &mut fetch)?;
        let Group {
            staging,
            mut pending,
            ..
        } = group;
        if !pending.is_empty() {
            self.cpu.memory_mut().commit(staging)?;
            self.images.append(&mut pending);
            self.cpu.clear_cache();
        }
        Ok(())
    }

    pub(crate) fn is_platform_dependency(&self, name: &str) -> bool {
        self.platforms.contains_key(name)
    }

    pub(crate) fn apk_symbol(&self, library: &str, name: &str) -> Option<u64> {
        let image = self.images.get(library)?;
        image.exports.get(name).copied().or_else(|| {
            import_scope(
                &image.needed,
                &self.images,
                &BTreeMap::new(),
                &self.platforms,
            )
            .ok()?
            .iter()
            .find_map(|exports| exports.get(name).copied())
        })
    }
}
