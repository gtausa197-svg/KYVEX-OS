package android.content;
public abstract class ContentProvider {
 public void attachInfo(Context context,android.content.pm.ProviderInfo info){}
 public Context getContext(){return null;}
 public abstract boolean onCreate();
 public abstract android.database.Cursor query(android.net.Uri uri,String[] projection,String selection,String[] args,String sort);
 public abstract String getType(android.net.Uri uri);
 public abstract android.net.Uri insert(android.net.Uri uri,ContentValues values);
 public abstract int delete(android.net.Uri uri,String selection,String[] args);
 public abstract int update(android.net.Uri uri,ContentValues values,String selection,String[] args);
}
