package org.kyvex.extra;
import android.content.Context;
import java.io.*;

/** Actual Java file operations; the runtime must preserve data and open handles. */
public final class FileChecks {
    private static int checks;
    private static void check(boolean valid,String label){if(!valid)throw new IllegalStateException(label);checks++;}
    public static int verify(Context context) {
        checks=0;
        try {
            File base=context.getFilesDir();
            check(base.exists()&&base.isDirectory()&&base.canWrite(),"private file directory");
            File nested=new File(base,"nested");check(nested.mkdir()&&!nested.mkdir(),"mkdir collision");
            File file=new File(base,"nested//../sample.bin");
            check(file.getCanonicalPath().equals(new File(base,"sample.bin").getPath()),"canonical dot segments");
            check(file.createNewFile()&&!file.createNewFile(),"exclusive create");
            FileOutputStream out=new FileOutputStream(file);out.write(new byte[]{0,127,(byte)128,(byte)255});out.close();
            out=new FileOutputStream(file,true);out.write(42);out.close();
            check(file.length()==5&&file.isFile(),"write append length");
            FileInputStream in=new FileInputStream(file);byte[] bytes=new byte[6];
            check(in.read(bytes,1,4)==4&&bytes[1]==0&&bytes[2]==127&&bytes[3]==(byte)128&&bytes[4]==(byte)255,"byte stream range and sign");
            check(in.skip(-2)==-2&&in.read()==128&&in.read()==255&&in.read()==42&&in.read()==-1,"skip backwards and EOF");
            check(in.read(bytes,0,0)==0&&in.available()==0,"zero length read at EOF");
            boolean bounds=false;try{in.read(bytes,-1,1);}catch(IndexOutOfBoundsException expected){bounds=true;}check(bounds,"range validation");
            File renamed=new File(base,"renamed.bin");check(file.renameTo(renamed)&&!file.exists()&&renamed.exists(),"rename metadata");
            check(renamed.delete()&&!renamed.exists(),"unlink open stream");
            check(in.skip(-5)==-5&&in.read()==0,"open stream retains unlinked contents");
            in.close();boolean closed=false;try{in.read();}catch(IOException expected){closed=true;}check(closed,"closed stream errors");
            FileOutputStream privateOut=context.openFileOutput("private.bin",0);privateOut.write(73);privateOut.close();
            privateOut=context.openFileOutput("private.bin",32768);privateOut.write(74);privateOut.close();
            FileInputStream privateIn=context.openFileInput("private.bin");check(privateIn.read()==73&&privateIn.read()==74,"Context private append");privateIn.close();
            check(context.deleteFile("private.bin")&&!context.getFileStreamPath("private.bin").exists(),"Context delete");
            check(base.list().length==1&&"nested".equals(base.list()[0]),"directory listing");
            check(new File("").exists()==false&&new File("/").getParent()==null&&"/".equals(new File("/file").getParent()),"empty and root paths");
            check(!new File("/etc/passwd").exists(),"guest namespace");
            boolean missing=false;try{new FileInputStream("/etc/passwd");}catch(FileNotFoundException expected){missing=true;}check(missing,"host path inaccessible");
            File cache=context.getCacheDir();check(cache.isDirectory()&&new File("/parent","/child").getPath().equals("/parent/child"),"cache and Unix parent resolution");
            return checks;
        } catch(IOException error) {throw new IllegalStateException("Unexpected file I/O: "+error.getMessage());}
    }
}
