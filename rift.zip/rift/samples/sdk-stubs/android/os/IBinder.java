package android.os;
public interface IBinder {
    String getInterfaceDescriptor() throws RemoteException;
    boolean isBinderAlive();
    boolean pingBinder();
    IInterface queryLocalInterface(String descriptor);
}
