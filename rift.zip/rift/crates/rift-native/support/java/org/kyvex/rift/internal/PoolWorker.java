package org.kyvex.rift.internal;

/** Own resumable worker loop. Tasks execute as ordinary owned guest DEX frames. */
public final class PoolWorker implements Runnable {
 public void run(){
  boolean abrupt=true;
  try {
   while(runOne()){}
   abrupt=false;
  } finally {PoolAccess.exit(this,abrupt);}
 }
 private boolean runOne(){
  Runnable task=PoolAccess.next(this);
  if(task==null)return false;
  try {
   PoolAccess.before(this,task);
   Throwable failure=null;
   try {task.run();}
   catch(RuntimeException error){failure=error;throw error;}
   catch(Error error){failure=error;throw error;}
   catch(Throwable error){failure=error;throw new Error(error);}
   finally {PoolAccess.after(this,task,failure);}
  } finally {PoolAccess.done(this);}
  return true;
 }
}
