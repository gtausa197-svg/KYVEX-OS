//! Main event thread and bounded Handler/Message delivery.
use super::*;
mod handler;
mod messenger;
pub(super) const LOCAL_MESSENGER_BINDER: &str = "Lorg/kyvex/rift/internal/LocalMessengerBinder;";
#[derive(Clone)]
pub(super) struct Handler {
    pub looper: u32,
    pub callback: u32,
    pub asynchronous: bool,
    pub messenger_binder: u32,
}
pub(super) struct Pending {
    pub handler: u32,
    pub message: u32,
    pub when: u64,
    pub sequence: u64,
    pub front: bool,
}
pub(super) fn instance_field(class: &str, name: &str, descriptor: &str) -> bool {
    class == "Landroid/os/Message;"
        && matches!(
            (name, descriptor),
            ("what" | "arg1" | "arg2" | "sendingUid", "I")
                | ("obj", "Ljava/lang/Object;")
                | ("replyTo", "Landroid/os/Messenger;")
        )
}
pub(super) fn payload(class: &str) -> Option<Payload> {
    match class {
        "Landroid/os/Handler;" => Some(Payload::Handler(Handler {
            looper: 0,
            callback: 0,
            asynchronous: false,
            messenger_binder: 0,
        })),
        "Landroid/os/Messenger;" => Some(Payload::Messenger(0)),
        "Landroid/os/Message;" => Some(Payload::Record(BTreeMap::from([(
            "sendingUid".into(),
            u32::MAX as u64,
        )]))),
        _ => None,
    }
}
impl Runtime {
    pub(super) fn uptime_millis(&self) -> u64 {
        (self.clock.elapsed().as_millis() as u64).saturating_add(1)
    }
    pub(super) fn process_events(&mut self, limit: usize) -> Result<()> {
        self.pump_handler_events(limit)
    }
    fn main_looper(&mut self) -> Result<u32> {
        if self.main_looper == 0 {
            let thread = self.ensure_main_thread()?;
            self.main_looper = self.allocate("Landroid/os/Looper;", Payload::Looper(thread))?;
        }
        Ok(self.main_looper)
    }
    pub(super) fn events_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        if let Some(value) = self.messenger_api(sig, a)? {
            return Ok(Some(value));
        }
        if let Some(value) = self.handler_api(sig, a)? {
            return Ok(Some(value));
        }
        let (class, method) = sig.split_once("->").ok_or("Event signature")?;
        if class != "Landroid/os/Looper;" {
            return Ok(None);
        }
        match method {
            "getMainLooper()Landroid/os/Looper;" => {
                return Ok(Some(self.main_looper()? as u64));
            }
            "myLooper()Landroid/os/Looper;" => {
                self.ensure_main_thread()?;
                return Ok(Some(if self.current_thread == self.main_thread {
                    self.main_looper()? as u64
                } else {
                    0
                }));
            }
            "prepare()V" | "prepareMainLooper()V" => {
                self.ensure_main_thread()?;
                if self.current_thread != self.main_thread {
                    return Err("Worker Looper preparation is not implemented".into());
                }
                return Err(fault(
                    "Ljava/lang/RuntimeException;",
                    "The Native main event thread already has a Looper",
                ));
            }
            _ => {}
        }
        let Some(&id) = a.first() else {
            return Ok(None);
        };
        let Payload::Looper(thread) = self.object(id)?.payload else {
            return Err("Expected Looper".into());
        };
        Ok(Some(match method {
            "getThread()Ljava/lang/Thread;" => thread as u64,
            "isCurrentThread()Z" => (thread == self.current_thread) as u64,
            "quit()V" | "quitSafely()V" => {
                return Err(fault(
                    "Ljava/lang/IllegalStateException;",
                    "The main Looper cannot be quit",
                ));
            }
            _ => return Ok(None),
        }))
    }
}
