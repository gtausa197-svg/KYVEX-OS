//! A real, live view over a guest byte array, with Java mark/reset/EOF semantics.
use super::*;
#[derive(Clone, Copy)]
pub(super) struct Input {
    pub array: u32,
    pub position: i32,
    limit: i32,
    mark: i32,
}
impl Runtime {
    pub(super) fn byte_input_read(&mut self, id: u32, count: usize) -> Result<Vec<u8>> {
        let Payload::ByteInput(Some(mut input)) = self.object(id)?.payload else {
            return Err("Uninitialized byte input".into());
        };
        if input.position >= input.limit {
            return Ok(Vec::new());
        }
        let count = count.min((input.limit as i64 - input.position as i64) as usize);
        let start = usize::try_from(input.position).map_err(|_| {
            fault(
                "Ljava/lang/ArrayIndexOutOfBoundsException;",
                "Byte input position",
            )
        })?;
        let Payload::Array(array) = &self.object(input.array)?.payload else {
            return Err("Byte input backing array".into());
        };
        let range = array.get(start..start + count).ok_or_else(|| {
            fault(
                "Ljava/lang/ArrayIndexOutOfBoundsException;",
                "Byte input range",
            )
        })?;
        let result = range.iter().map(|v| *v as u8).collect();
        input.position += count as i32;
        self.object_mut(id)?.payload = Payload::ByteInput(Some(input));
        Ok(result)
    }
    pub(super) fn byte_input_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Byte input signature")?;
        if !matches!(
            class,
            "Ljava/io/ByteArrayInputStream;"
                | "Ljava/io/InputStream;"
                | "Ljava/io/Closeable;"
                | "Ljava/lang/AutoCloseable;"
        ) {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Byte input argument count");
        let id = arg(0)?;
        if class == "Ljava/io/ByteArrayInputStream;"
            && matches!(method, "<init>([B)V" | "<init>([BII)V")
        {
            let array = arg(1)?;
            let object = self.object(array)?;
            if object.class != "[B" {
                return Err("Byte input requires byte[]".into());
            }
            let Payload::Array(values) = &object.payload else {
                return Err("Byte input buffer".into());
            };
            let position = if a.len() == 4 { arg(2)? as i32 } else { 0 };
            let limit = if a.len() == 4 {
                position
                    .wrapping_add(arg(3)? as i32)
                    .min(values.len() as i32)
            } else {
                values.len() as i32
            };
            self.object_mut(id)?.payload = Payload::ByteInput(Some(Input {
                array,
                position,
                limit,
                mark: position,
            }));
            return Ok(Some(0));
        }
        let Payload::ByteInput(Some(mut input)) = self.object(id)?.payload else {
            return Ok(None);
        };
        let result = match method {
            "close()V" => 0,
            "markSupported()Z" => 1,
            "mark(I)V" => {
                input.mark = input.position;
                self.object_mut(id)?.payload = Payload::ByteInput(Some(input));
                0
            }
            "reset()V" => {
                input.position = input.mark;
                self.object_mut(id)?.payload = Payload::ByteInput(Some(input));
                0
            }
            "available()I" => input.limit.wrapping_sub(input.position) as u32 as u64,
            "skip(J)J" => {
                let requested = (arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64;
                let skipped = requested
                    .min(input.limit as i64 - input.position as i64)
                    .max(0);
                input.position = input.position.wrapping_add(skipped as i32);
                self.object_mut(id)?.payload = Payload::ByteInput(Some(input));
                skipped as u64
            }
            "read()I" => self
                .byte_input_read(id, 1)?
                .first()
                .map_or(u32::MAX as u64, |v| *v as u64),
            "read([B)I" | "read([BII)I" => {
                let target = arg(1)?;
                let object = self.object(target)?;
                if object.class != "[B" {
                    return Err("Byte input read destination".into());
                }
                let Payload::Array(values) = &object.payload else {
                    return Err("Byte input destination buffer".into());
                };
                let start = if a.len() == 4 { arg(2)? as usize } else { 0 };
                let count = if a.len() == 4 {
                    arg(3)? as usize
                } else {
                    values.len()
                };
                start
                    .checked_add(count)
                    .filter(|end| *end <= values.len())
                    .ok_or_else(|| {
                        fault(
                            "Ljava/lang/IndexOutOfBoundsException;",
                            "Byte input destination range",
                        )
                    })?;
                if input.position >= input.limit {
                    return Ok(Some(u32::MAX as u64));
                }
                let bytes = self.byte_input_read(id, count)?;
                let Payload::Array(values) = &mut self.object_mut(target)?.payload else {
                    unreachable!()
                };
                for (slot, byte) in values[start..].iter_mut().zip(&bytes) {
                    *slot = *byte as i8 as i64 as u64;
                }
                bytes.len() as u64
            }
            _ => return Ok(None),
        };
        Ok(Some(result))
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn byte_stream_keeps_the_live_original_array_through_collection() {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/rift-native-demo.apk");
        let package = crate::package::Package::open(&path, "auto").unwrap();
        let mut vm = Runtime::new(
            package.dex,
            Machine::new(64, 32, 8).unwrap(),
            package.libraries,
            4 * 1024 * 1024,
        );
        let array = vm.allocate("[B", Payload::Array(vec![1, 2, 3])).unwrap();
        let stream = vm.instantiate("Ljava/io/ByteArrayInputStream;").unwrap();
        vm.hle(
            "Ljava/io/ByteArrayInputStream;-><init>([B)V",
            &[stream, array],
        )
        .unwrap();
        let roots = vm.scoped_library_roots(&[stream]).unwrap();
        vm.collect().unwrap();
        let Payload::Array(values) = &mut vm.object_mut(array).unwrap().payload else {
            panic!()
        };
        values[1] = 255;
        assert_eq!(vm.read_input_bytes(stream, 3).unwrap(), vec![1, 255, 3]);
        assert!(vm.read_input_bytes(stream, 1).unwrap().is_empty());
        drop(roots);
        vm.collect().unwrap();
        assert!(!vm.heap.contains_key(&stream) && !vm.heap.contains_key(&array));
    }
}
