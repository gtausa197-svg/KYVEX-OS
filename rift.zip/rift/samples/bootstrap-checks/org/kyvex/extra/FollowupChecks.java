package org.kyvex.extra;

import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class FollowupChecks {
    private static int checks;

    private static void check(boolean condition, String name) {
        if (!condition) throw new IllegalStateException(name);
        checks++;
    }

    private static final class MutatingHash {
        private final Object[] array;

        MutatingHash(Object[] array) { this.array = array; }

        public int hashCode() {
            array[0] = null;
            array[1] = 19;
            System.gc();
            return 3;
        }
    }

    private static final class ThrowsHash {
        public int hashCode() { throw new IllegalStateException("hash callback"); }
    }

    private static final class InheritedDiscard extends ThreadPoolExecutor.DiscardPolicy {}

    private static final class Mark implements Runnable {
        private final AtomicInteger count;
        private final CountDownLatch done;

        Mark(AtomicInteger count, CountDownLatch done) {
            this.count = count;
            this.done = done;
        }

        public void run() {
            count.incrementAndGet();
            if (done != null) done.countDown();
        }
    }

    private static void arrays() {
        check(Arrays.hashCode((Object[]) null) == 0, "Null Object array hash");
        check(Arrays.hashCode(new Object[0]) == 1, "Empty Object array hash");
        Object[] mixed = {"A", null, -17, Long.MAX_VALUE};
        int expected = (((31 + "A".hashCode()) * 31) * 31 - 17) * 31 + Long.valueOf(Long.MAX_VALUE).hashCode();
        check(Arrays.hashCode(mixed) == expected, "Null and boxed values hash in order");
        String[] typed = {"x", "y"};
        check(Arrays.hashCode(typed) == 31 * (31 + "x".hashCode()) + "y".hashCode(), "Reference array subtype");
        Object[] self = new Object[1];
        self[0] = self;
        check(Arrays.hashCode(self) == 31 + System.identityHashCode(self), "Shallow self-referential hash");
        Object[] mutate = {null, 2};
        mutate[0] = new MutatingHash(mutate);
        check(Arrays.hashCode(mutate) == 31 * (31 + 3) + 19 && mutate[0] == null, "Live reads after a GC callback");
        try {
            Arrays.hashCode(new Object[]{new ThrowsHash()});
            throw new IllegalStateException("Missing hash exception");
        } catch (IllegalStateException expectedFailure) {
            check("hash callback".equals(expectedFailure.getMessage()), "Hash exception propagation");
        }
    }

    private static void rejection() throws InterruptedException {
        AtomicInteger ran = new AtomicInteger();
        Mark discarded = new Mark(ran, null);
        RejectedExecutionHandler policy = new InheritedDiscard();
        check(policy instanceof ThreadPoolExecutor.DiscardPolicy, "DiscardPolicy implements handler");
        policy.rejectedExecution(discarded, null);
        check(ran.get() == 0, "Direct DiscardPolicy leaves the task untouched");

        LinkedBlockingQueue<Runnable> queue = new LinkedBlockingQueue<>(1);
        ThreadPoolExecutor pool = new ThreadPoolExecutor(1, 1, 0, TimeUnit.SECONDS, queue, policy);
        CountDownLatch entered = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(1);
        Mark accepted = new Mark(ran, done);
        try {
            pool.execute(new Runnable() {
                public void run() {
                    entered.countDown();
                    try {
                        release.await();
                    } catch (InterruptedException error) {
                        throw new IllegalStateException(error);
                    }
                }
            });
            check(entered.await(3, TimeUnit.SECONDS), "DiscardPolicy pool runs accepted tasks");
            pool.execute(accepted);
            pool.execute(discarded);
            check(pool.getRejectedExecutionHandler() == policy && queue.peek() == accepted
                    && queue.size() == 1 && ran.get() == 0, "Saturation discards only the rejected task");
        } finally {
            release.countDown();
            pool.shutdown();
        }
        check(done.await(3, TimeUnit.SECONDS) && pool.awaitTermination(3, TimeUnit.SECONDS)
                && ran.get() == 1, "Accepted task survives saturation");
        pool.execute(discarded);
        check(ran.get() == 1 && queue.isEmpty(), "DiscardPolicy after shutdown");
        pool.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        try {
            pool.execute(discarded);
            throw new IllegalStateException("Missing AbortPolicy exception");
        } catch (RejectedExecutionException expected) {
            check(ran.get() == 1, "AbortPolicy still throws");
        }
    }

    public static int verify() {
        checks = 0;
        arrays();
        try {
            rejection();
        } catch (InterruptedException error) {
            throw new IllegalStateException(error);
        }
        return checks;
    }

    public static void main(String[] args) {
        System.out.println("Discard and array hash checks: " + verify());
    }
}
