package android.os;

/** Compile-only signatures for the local Messenger fixture. */
public final class Messenger {
    public Messenger(Handler target) {}
    public Messenger(IBinder target) {}
    public IBinder getBinder() { return null; }
    public void send(Message message) throws RemoteException {}
    public int describeContents() { return 0; }
}
