//! Java File and byte streams over a private, session-local virtual filesystem.
use super::*;
use crate::vfs;
#[derive(Clone, Copy)]
pub(super) struct Stream {
    pub inode: u32,
    pub position: u64,
    pub output: bool,
    pub append: bool,
    pub closed: bool,
    pub io: Option<strict_mode::IoTracker>,
}
pub(super) fn payload(class: &str) -> Option<Payload> {
    match class {
        "Ljava/io/File;" => Some(Payload::File(Vec::new())),
        "Ljava/io/ByteArrayInputStream;" => Some(Payload::ByteInput(None)),
        "Ljava/io/FileInputStream;" | "Ljava/io/FileOutputStream;" => {
            Some(Payload::FileStream(None))
        }
        _ => None,
    }
}
pub(super) fn inherits(class: &str, base: &str) -> bool {
    match class {
        "Ljava/io/File;" => matches!(base, "Ljava/lang/Comparable;" | "Ljava/io/Serializable;"),
        "Ljava/io/FileInputStream;"
        | "Ljava/io/ByteArrayInputStream;"
        | "Landroid/content/res/AssetManager$AssetInputStream;" => {
            matches!(
                base,
                "Ljava/io/InputStream;" | "Ljava/io/Closeable;" | "Ljava/lang/AutoCloseable;"
            )
        }
        "Ljava/io/FileOutputStream;" => matches!(
            base,
            "Ljava/io/OutputStream;" | "Ljava/io/Closeable;" | "Ljava/lang/AutoCloseable;"
        ),
        "Ljava/io/InputStream;" | "Ljava/io/OutputStream;" | "Ljava/io/Closeable;" => {
            base == "Ljava/lang/AutoCloseable;" || base == "Ljava/io/Closeable;"
        }
        _ => false,
    }
}
fn io_error(error: vfs::Error) -> Box<dyn std::error::Error + Send + Sync> {
    fault("Ljava/io/IOException;", &error.to_string())
}
impl Runtime {
    pub(super) fn read_input_bytes(&mut self, id: u32, count: usize) -> Result<Vec<u8>> {
        if matches!(self.object(id)?.payload, Payload::ByteInput(_)) {
            return self.byte_input_read(id, count);
        }
        let Payload::FileStream(Some(mut stream)) = self.object(id)?.payload else {
            return Err("Reader requires a supported guest input stream".into());
        };
        if stream.closed || stream.output {
            return Err(fault(
                "Ljava/io/IOException;",
                "Input stream is closed or not readable",
            ));
        }
        let bytes = self.stream_read(&mut stream, count)?;
        stream.position += bytes.len() as u64;
        self.object_mut(id)?.payload = Payload::FileStream(Some(stream));
        Ok(bytes)
    }
    fn track_stream_io(&mut self, stream: &mut Stream, count: usize) {
        if count == 0 {
            return;
        }
        if let Some(tracker) = &mut stream.io {
            let (detector, detail) = if stream.output {
                (strict_mode::DISK_WRITE, "guest file write")
            } else {
                (strict_mode::DISK_READ, "guest file read")
            };
            self.strict_log(detector, detail);
            if tracker.track(count) {
                self.strict_log(strict_mode::UNBUFFERED_IO, "unbuffered guest file I/O");
            }
        }
    }
    fn stream_read(&mut self, stream: &mut Stream, count: usize) -> Result<Vec<u8>> {
        let bytes =
            if let Some(member) = self.files.archive_member(stream.inode).map_err(io_error)? {
                let member = member.to_owned();
                self.libraries
                    .read_range(&member, stream.position, count)
                    .map_err(|e| fault("Ljava/io/IOException;", &e.to_string()))?
            } else {
                self.files
                    .read(stream.inode, stream.position, count)
                    .map_err(io_error)?
            };
        self.track_stream_io(stream, count);
        Ok(bytes)
    }
    fn file_path(&self, id: u32) -> Result<Vec<u16>> {
        let Payload::File(path) = &self.object(id)?.payload else {
            return Err("Expected java.io.File".into());
        };
        Ok(path.clone())
    }
    fn new_file(&mut self, path: &[u16]) -> Result<u64> {
        Ok(self.allocate("Ljava/io/File;", Payload::File(vfs::normalize(path)))? as u64)
    }
    fn absolute_file(&self, path: &[u16]) -> Vec<u16> {
        if path.first() == Some(&47) {
            path.to_vec()
        } else {
            vfs::join(&self.files.cwd, path)
        }
    }
    fn canonical_file(&self, path: &[u16]) -> Result<Vec<u16>> {
        vfs::canonical(path, &self.files.cwd).map_err(io_error)
    }
    fn app_dir(&mut self, root: &[u16], leaf: &[u16]) -> Result<Vec<u16>> {
        let path = vfs::join(root, leaf);
        if self.files.stat(&path).is_none() {
            self.files.mkdirs(&path).map_err(io_error)?;
        }
        Ok(path)
    }
    fn external_storage_type(&self, id: u32) -> Result<Vec<u16>> {
        let name = if id == 0 { Vec::new() } else { self.units(id)? };
        if name.len() > 255
            || name.contains(&47)
            || name.contains(&0)
            || matches!(name.as_slice(), [46] | [46, 46])
        {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Invalid external directory type",
            ));
        }
        Ok(name)
    }
    fn external_app_dir(&mut self, method: &str, kind: u32) -> Result<u64> {
        let media = method.starts_with("getExternalMedia");
        let cache = method.starts_with("getExternalCache");
        let root = self.files.external_storage().map_err(io_error)?;
        let mut path = vfs::join(
            &root,
            &vfs::units(&if media {
                format!("Android/media/{}", self.package_name)
            } else {
                let leaf = if cache { "cache" } else { "files" };
                format!("Android/data/{}/{leaf}", self.package_name)
            }),
        );
        if !cache && !media {
            path = vfs::join(&path, &self.external_storage_type(kind)?);
        }
        self.files.mkdirs(&path).map_err(io_error)?;
        if !self.files.stat(&path).is_some_and(|stat| stat.directory) {
            return Err(fault(
                "Ljava/io/IOException;",
                "External application directory is not a directory",
            ));
        }
        let file = self.new_file(&path)?;
        if method.ends_with(")[Ljava/io/File;") {
            self.allocate("[Ljava/io/File;", Payload::Array(vec![file]))
                .map(u64::from)
        } else {
            Ok(file)
        }
    }
    fn stream_open(&mut self, id: u32, path: &[u16], output: bool, append: bool) -> Result<()> {
        let path = vfs::canonical(path, &self.files.cwd)
            .map_err(|e| fault("Ljava/io/FileNotFoundException;", &e.to_string()))?;
        let inode = self
            .files
            .open(&path, output, append)
            .map_err(|e| fault("Ljava/io/FileNotFoundException;", &e.to_string()))?;
        if let Payload::FileStream(Some(old)) = &self.object(id)?.payload
            && !old.closed
        {
            self.files.close(old.inode);
        }
        self.object_mut(id)?.payload = Payload::FileStream(Some(Stream {
            inode,
            position: 0,
            output,
            append,
            closed: false,
            io: Some(strict_mode::IoTracker::default()),
        }));
        Ok(())
    }
    fn byte_range(
        &self,
        id: u32,
        offset: Option<u32>,
        length: Option<u32>,
    ) -> Result<(usize, usize)> {
        let object = self.object(id)?;
        if object.class != "[B" {
            return Err("Expected Java byte array".into());
        }
        let Payload::Array(bytes) = &object.payload else {
            return Err("Byte array payload".into());
        };
        let start = offset.unwrap_or(0) as usize;
        let length = length.map_or(bytes.len(), |n| n as usize);
        let end = start
            .checked_add(length)
            .filter(|end| *end <= bytes.len())
            .ok_or_else(|| {
                fault(
                    "Ljava/lang/IndexOutOfBoundsException;",
                    "Byte stream array range",
                )
            })?;
        Ok((start, end))
    }
    pub(super) fn filesystem_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        if let Some(value) = self.byte_input_api(sig, a)? {
            return Ok(Some(value));
        }
        let (class, method) = sig.split_once("->").ok_or("Filesystem API signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Filesystem argument count");
        if class == "Landroid/os/Environment;" {
            return Ok(Some(match method {
                "getExternalStorageDirectory()Ljava/io/File;" => {
                    let path = self.files.external_storage().map_err(io_error)?;
                    self.new_file(&path)?
                }
                "getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;" => {
                    let kind = self.external_storage_type(arg(0)?)?;
                    let root = self.files.external_storage().map_err(io_error)?;
                    self.new_file(&vfs::join(&root, &kind))?
                }
                "getExternalStorageState()Ljava/lang/String;" => self.string("mounted")? as u64,
                "getExternalStorageState(Ljava/io/File;)Ljava/lang/String;" => {
                    let path = self.canonical_file(&self.file_path(arg(0)?)?)?;
                    let root = vfs::units(vfs::EXTERNAL_STORAGE_ROOT);
                    let on_volume = path == root
                        || path
                            .strip_prefix(root.as_slice())
                            .is_some_and(|suffix| suffix.first() == Some(&47));
                    self.string(if on_volume { "mounted" } else { "unknown" })? as u64
                }
                "isExternalStorageEmulated()Z" => 1,
                "isExternalStorageRemovable()Z" => 0,
                _ => return Ok(None),
            }));
        }
        if class == "Ljava/io/File;" && method.starts_with("<init>(") {
            let path = match method {
                "<init>(Ljava/lang/String;)V" => vfs::normalize(&self.units(arg(1)?)?),
                "<init>(Ljava/lang/String;Ljava/lang/String;)V" => {
                    let child = self.units(arg(2)?)?;
                    if arg(1)? == 0 {
                        vfs::normalize(&child)
                    } else {
                        vfs::join(&self.units(arg(1)?)?, &child)
                    }
                }
                "<init>(Ljava/io/File;Ljava/lang/String;)V" => {
                    let child = self.units(arg(2)?)?;
                    if arg(1)? == 0 {
                        vfs::normalize(&child)
                    } else {
                        vfs::join(&self.file_path(arg(1)?)?, &child)
                    }
                }
                _ => return Ok(None),
            };
            self.object_mut(arg(0)?)?.payload = Payload::File(path);
            return Ok(Some(0));
        }
        if matches!(
            class,
            "Ljava/io/FileInputStream;" | "Ljava/io/FileOutputStream;"
        ) && matches!(
            method,
            "<init>(Ljava/lang/String;)V"
                | "<init>(Ljava/io/File;)V"
                | "<init>(Ljava/lang/String;Z)V"
                | "<init>(Ljava/io/File;Z)V"
        ) {
            let output = class == "Ljava/io/FileOutputStream;";
            if !output && method.contains(";Z") {
                return Ok(None);
            }
            let path = if method.starts_with("<init>(Ljava/io/File;") {
                self.file_path(arg(1)?)?
            } else {
                self.units(arg(1)?)?
            };
            let append = method.contains(";Z") && arg(2)? != 0;
            self.stream_open(arg(0)?, &path, output, append)?;
            return Ok(Some(0));
        }
        let Some(&id) = a.first() else {
            return Ok(None);
        };
        if !self.heap.contains_key(&id) {
            return Ok(None);
        }
        let context_method = matches!(
            method,
            "getFilesDir()Ljava/io/File;"
                | "getCacheDir()Ljava/io/File;"
                | "getNoBackupFilesDir()Ljava/io/File;"
                | "getCodeCacheDir()Ljava/io/File;"
                | "getDataDir()Ljava/io/File;"
                | "getDir(Ljava/lang/String;I)Ljava/io/File;"
                | "getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;"
                | "getExternalFilesDirs(Ljava/lang/String;)[Ljava/io/File;"
                | "getExternalCacheDir()Ljava/io/File;"
                | "getExternalCacheDirs()[Ljava/io/File;"
                | "getExternalMediaDirs()[Ljava/io/File;"
                | "openFileInput(Ljava/lang/String;)Ljava/io/FileInputStream;"
                | "openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;"
                | "getFileStreamPath(Ljava/lang/String;)Ljava/io/File;"
                | "deleteFile(Ljava/lang/String;)Z"
        );
        if context_method && self.subclass(&self.object(id)?.class, "Landroid/content/Context;")? {
            if method.starts_with("getExternal") {
                let kind = if method.starts_with("getExternalFiles") {
                    arg(1)?
                } else {
                    0
                };
                return self.external_app_dir(method, kind).map(Some);
            }
            let device = self.context_device_storage(id)?;
            let root = self.files.app_data(device).map_err(io_error)?;
            let leaf = match method {
                "getFilesDir()Ljava/io/File;" => Some("files"),
                "getCacheDir()Ljava/io/File;" => Some("cache"),
                "getNoBackupFilesDir()Ljava/io/File;" => Some("no_backup"),
                "getCodeCacheDir()Ljava/io/File;" => Some("code_cache"),
                _ => None,
            };
            if let Some(leaf) = leaf {
                let path = self.app_dir(&root, &vfs::units(leaf))?;
                return Ok(Some(self.new_file(&path)?));
            }
            if method == "getDataDir()Ljava/io/File;" {
                return Ok(Some(self.new_file(&root)?));
            }
            if method == "getDir(Ljava/lang/String;I)Ljava/io/File;" {
                if arg(2)? != 0 {
                    return Err(fault(
                        "Ljava/lang/SecurityException;",
                        "Only private application directories are available",
                    ));
                }
                let name = self.units(arg(1)?)?;
                if name.contains(&47) || name.contains(&0) {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Directory name contains a separator",
                    ));
                }
                let mut leaf = vfs::units("app_");
                leaf.extend(name);
                let path = self.app_dir(&root, &leaf)?;
                return Ok(Some(self.new_file(&path)?));
            }
            if matches!(
                method,
                "openFileInput(Ljava/lang/String;)Ljava/io/FileInputStream;"
                    | "openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;"
                    | "getFileStreamPath(Ljava/lang/String;)Ljava/io/File;"
                    | "deleteFile(Ljava/lang/String;)Z"
            ) {
                let name = self.units(arg(1)?)?;
                if name.is_empty() || name.contains(&47) || name.contains(&0) {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Invalid private filename",
                    ));
                }
                let files = self.app_dir(&root, &vfs::units("files"))?;
                let path = vfs::join(&files, &name);
                if method.starts_with("getFileStreamPath") {
                    return Ok(Some(self.new_file(&path)?));
                }
                if method.starts_with("deleteFile") {
                    return Ok(Some(self.files.delete(&path).unwrap_or(false) as u64));
                }
                let output = method.starts_with("openFileOutput");
                let mode = if output { arg(2)? } else { 0 };
                if mode & !0x8000 != 0 {
                    return Err(fault(
                        "Ljava/lang/SecurityException;",
                        "Only private/append file modes are available",
                    ));
                }
                let stream = self.allocate(
                    if output {
                        "Ljava/io/FileOutputStream;"
                    } else {
                        "Ljava/io/FileInputStream;"
                    },
                    Payload::FileStream(None),
                )?;
                self.stream_open(stream, &path, output, mode & 0x8000 != 0)?;
                return Ok(Some(stream as u64));
            }
        }
        if let Payload::File(path) = &self.object(id)?.payload {
            let path = path.clone();
            match method {
                "getPath()Ljava/lang/String;" | "toString()Ljava/lang/String;" => {
                    return Ok(Some(self.string_units(path)? as u64));
                }
                "getName()Ljava/lang/String;" => {
                    let start = path.iter().rposition(|c| *c == 47).map_or(0, |i| i + 1);
                    return Ok(Some(self.string_units(path[start..].to_vec())? as u64));
                }
                "getParent()Ljava/lang/String;" => {
                    return Ok(Some(match vfs::parent(&path) {
                        Some(p) => self.string_units(p)? as u64,
                        None => 0,
                    }));
                }
                "getParentFile()Ljava/io/File;" => {
                    return Ok(Some(match vfs::parent(&path) {
                        Some(p) => self.new_file(&p)?,
                        None => 0,
                    }));
                }
                "isAbsolute()Z" => return Ok(Some((path.first() == Some(&47)) as u64)),
                "getAbsolutePath()Ljava/lang/String;" => {
                    let p = self.absolute_file(&path);
                    return Ok(Some(self.string_units(p)? as u64));
                }
                "getAbsoluteFile()Ljava/io/File;" => {
                    let p = self.absolute_file(&path);
                    return Ok(Some(self.new_file(&p)?));
                }
                "getCanonicalPath()Ljava/lang/String;" => {
                    let p = self.canonical_file(&path)?;
                    return Ok(Some(self.string_units(p)? as u64));
                }
                "getCanonicalFile()Ljava/io/File;" => {
                    let p = self.canonical_file(&path)?;
                    return Ok(Some(self.new_file(&p)?));
                }
                "equals(Ljava/lang/Object;)Z" => {
                    return Ok(Some(
                        self.heap
                            .get(&arg(1)?)
                            .is_some_and(|o| matches!(&o.payload,Payload::File(p) if *p==path))
                            as u64,
                    ));
                }
                "hashCode()I" => {
                    return Ok(Some(
                        (path.iter().fold(0u32, |hash, c| {
                            hash.wrapping_mul(31).wrapping_add(*c as u32)
                        }) ^ 1234321) as u64,
                    ));
                }
                "compareTo(Ljava/io/File;)I" | "compareTo(Ljava/lang/Object;)I" => {
                    let other = self.file_path(arg(1)?)?;
                    let order = path
                        .iter()
                        .zip(&other)
                        .find_map(|(x, y)| (*x != *y).then_some(*x as i32 - *y as i32))
                        .unwrap_or(path.len() as i32 - other.len() as i32);
                    return Ok(Some(order as u32 as u64));
                }
                _ => {}
            }
            let canonical = vfs::canonical(&path, &self.files.cwd);
            let stat = canonical
                .as_ref()
                .ok()
                .filter(|_| !path.is_empty())
                .and_then(|p| self.files.stat(p));
            let value = match method {
                "exists()Z" => stat.is_some() as u64,
                "isFile()Z" => stat.is_some_and(|s| !s.directory) as u64,
                "isDirectory()Z" => stat.is_some_and(|s| s.directory) as u64,
                "canRead()Z" => stat.is_some_and(|s| s.readable) as u64,
                "canWrite()Z" => stat.is_some_and(|s| s.writable) as u64,
                "canExecute()Z" => stat.is_some_and(|s| s.executable) as u64,
                "length()J" => stat.map_or(0, |s| s.length as u64),
                "lastModified()J" => stat.map_or(0, |s| s.modified),
                "isHidden()Z" => path
                    .iter()
                    .rposition(|c| *c == 47)
                    .map_or(path.first() == Some(&46), |i| path.get(i + 1) == Some(&46))
                    as u64,
                "createNewFile()Z" => {
                    if path.is_empty() {
                        return Err(fault("Ljava/io/IOException;", "Empty file path"));
                    }
                    self.files
                        .create(&canonical.map_err(io_error)?)
                        .map_err(io_error)? as u64
                }
                "mkdir()Z" => canonical
                    .ok()
                    .is_some_and(|p| self.files.mkdir(&p).unwrap_or(false))
                    as u64,
                "mkdirs()Z" => canonical
                    .ok()
                    .is_some_and(|p| self.files.mkdirs(&p).unwrap_or(false))
                    as u64,
                "delete()Z" => {
                    (!path.is_empty()
                        && canonical
                            .ok()
                            .is_some_and(|p| self.files.delete(&p).unwrap_or(false)))
                        as u64
                }
                "deleteOnExit()V" => 0,
                "renameTo(Ljava/io/File;)Z" => {
                    let other = self.file_path(arg(1)?)?;
                    let to = vfs::canonical(&other, &self.files.cwd);
                    if path.is_empty() || other.is_empty() {
                        0
                    } else {
                        canonical.ok().zip(to.ok()).is_some_and(|(from, to)| {
                            self.files.rename(&from, &to).unwrap_or(false)
                        }) as u64
                    }
                }
                "setReadOnly()Z" => canonical
                    .ok()
                    .is_some_and(|p| self.files.permissions(&p, 'w', false))
                    as u64,
                "setReadable(Z)Z" | "setReadable(ZZ)Z" | "setWritable(Z)Z" | "setWritable(ZZ)Z"
                | "setExecutable(Z)Z" | "setExecutable(ZZ)Z" => {
                    let kind = if method.starts_with("setReadable") {
                        'r'
                    } else if method.starts_with("setWritable") {
                        'w'
                    } else {
                        'x'
                    };
                    let enabled = arg(1)? != 0;
                    canonical
                        .ok()
                        .is_some_and(|p| self.files.permissions(&p, kind, enabled))
                        as u64
                }
                "setLastModified(J)Z" => {
                    let time = arg(1)? as u64 | ((arg(2)? as u64) << 32);
                    if (time as i64) < 0 {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Negative modification time",
                        ));
                    }
                    canonical
                        .ok()
                        .is_some_and(|p| self.files.modified(&p, time)) as u64
                }
                "getFreeSpace()J" | "getUsableSpace()J" => {
                    if stat.is_some() {
                        self.files.limit.saturating_sub(self.files.bytes()) as u64
                    } else {
                        0
                    }
                }
                "getTotalSpace()J" => {
                    if stat.is_some() {
                        self.files.limit as u64
                    } else {
                        0
                    }
                }
                "list()[Ljava/lang/String;" | "listFiles()[Ljava/io/File;" => {
                    let Some(p) = canonical.ok().filter(|_| !path.is_empty()) else {
                        return Ok(Some(0));
                    };
                    let Some(entries) = self.files.list(&p) else {
                        return Ok(Some(0));
                    };
                    let files = method.starts_with("listFiles");
                    let mut values = Vec::new();
                    for entry in entries {
                        values.push(if files {
                            self.new_file(&vfs::join(&path, &entry))?
                        } else {
                            self.string_units(entry)? as u64
                        });
                    }
                    return Ok(Some(self.allocate(
                        if files {
                            "[Ljava/io/File;"
                        } else {
                            "[Ljava/lang/String;"
                        },
                        Payload::Array(values),
                    )? as u64));
                }
                _ => return Ok(None),
            };
            return Ok(Some(value));
        }
        let Payload::FileStream(Some(mut stream)) = self.object(id)?.payload else {
            return Ok(None);
        };
        if self.object(id)?.class == "Landroid/content/res/AssetManager$AssetInputStream;" {
            if method == "markSupported()Z" {
                return Ok(Some(1));
            }
            if matches!(method, "mark(I)V" | "reset()V" | "skip(J)J") {
                if stream.closed {
                    return Err(fault("Ljava/io/IOException;", "Asset stream is closed"));
                }
                let result = match method {
                    "mark(I)V" => {
                        self.object_mut(id)?
                            .fields
                            .insert(usize::MAX - 90, stream.position);
                        0
                    }
                    "reset()V" => {
                        stream.position = self
                            .object(id)?
                            .fields
                            .get(&(usize::MAX - 90))
                            .copied()
                            .unwrap_or(0);
                        0
                    }
                    _ => {
                        let amount = (arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64;
                        let amount = (amount.max(0) as u64).min(
                            (self.files.length(stream.inode).map_err(io_error)? as u64)
                                .saturating_sub(stream.position),
                        );
                        stream.position += amount;
                        amount
                    }
                };
                self.object_mut(id)?.payload = Payload::FileStream(Some(stream));
                return Ok(Some(result));
            }
        }
        if method == "close()V" {
            if !stream.closed {
                self.files.close(stream.inode);
                stream.closed = true;
                self.object_mut(id)?.payload = Payload::FileStream(Some(stream));
            }
            return Ok(Some(0));
        }
        let supported = if stream.output {
            matches!(
                method,
                "write(I)V" | "write([B)V" | "write([BII)V" | "flush()V"
            )
        } else {
            matches!(
                method,
                "read()I"
                    | "read([B)I"
                    | "read([BII)I"
                    | "available()I"
                    | "skip(J)J"
                    | "markSupported()Z"
                    | "mark(I)V"
                    | "reset()V"
            )
        };
        if !supported {
            return Ok(None);
        }
        if method == "flush()V" || matches!(method, "markSupported()Z" | "mark(I)V") {
            return Ok(Some(0));
        }
        if stream.closed {
            return Err(fault("Ljava/io/IOException;", "Stream is closed"));
        }
        let value = match method {
            "flush()V" | "mark(I)V" => 0,
            "markSupported()Z" => 0,
            "reset()V" => return Err(fault("Ljava/io/IOException;", "Mark/reset not supported")),
            "available()I" => (self.files.length(stream.inode).map_err(io_error)? as u64)
                .saturating_sub(stream.position)
                .min(i32::MAX as u64),
            "skip(J)J" => {
                let amount = (arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64;
                let next = stream.position as i128 + amount as i128;
                if !(0..=i64::MAX as i128).contains(&next) {
                    return Err(fault("Ljava/io/IOException;", "Invalid stream offset"));
                }
                stream.position = next as u64;
                amount as u64
            }
            "read()I" => {
                let bytes = self.stream_read(&mut stream, 1)?;
                if let Some(byte) = bytes.first() {
                    stream.position += 1;
                    *byte as u64
                } else {
                    u32::MAX as u64
                }
            }
            "read([B)I" | "read([BII)I" => {
                let array = arg(1)?;
                let explicit = method == "read([BII)I";
                let (start, end) = self.byte_range(
                    array,
                    if explicit { Some(arg(2)?) } else { None },
                    if explicit { Some(arg(3)?) } else { None },
                )?;
                let bytes = self.stream_read(&mut stream, end - start)?;
                let Payload::Array(buffer) = &mut self.object_mut(array)?.payload else {
                    unreachable!()
                };
                for (dest, byte) in buffer[start..start + bytes.len()].iter_mut().zip(&bytes) {
                    *dest = *byte as u64;
                }
                stream.position += bytes.len() as u64;
                if end > start && bytes.is_empty() {
                    u32::MAX as u64
                } else {
                    bytes.len() as u64
                }
            }
            "write(I)V" => {
                stream.position = self
                    .files
                    .write(
                        stream.inode,
                        stream.position,
                        stream.append,
                        &[arg(1)? as u8],
                    )
                    .map_err(io_error)?;
                self.track_stream_io(&mut stream, 1);
                0
            }
            "write([B)V" | "write([BII)V" => {
                let array = arg(1)?;
                let explicit = method == "write([BII)V";
                let (start, end) = self.byte_range(
                    array,
                    if explicit { Some(arg(2)?) } else { None },
                    if explicit { Some(arg(3)?) } else { None },
                )?;
                let Payload::Array(buffer) = &self.object(array)?.payload else {
                    unreachable!()
                };
                let bytes: Vec<u8> = buffer[start..end].iter().map(|b| *b as u8).collect();
                stream.position = self
                    .files
                    .write(stream.inode, stream.position, stream.append, &bytes)
                    .map_err(io_error)?;
                self.track_stream_io(&mut stream, bytes.len());
                0
            }
            _ => return Ok(None),
        };
        self.object_mut(id)?.payload = Payload::FileStream(Some(stream));
        Ok(Some(value))
    }
}
