package org.kyvex.extra;
import java.io.*;
import java.nio.charset.*;
import java.util.*;
/** Identical stock-Java and DEX assertions on actual text conversions. */
public final class CharsetChecks {
 private static int checks;
 private static void check(boolean value,String why){if(!value)throw new IllegalStateException(why);checks++;}
 private static boolean same(byte[] left,int...right){if(left.length!=right.length)return false;for(int i=0;i<left.length;i++)if((left[i]&255)!=right[i])return false;return true;}
 public static int verify() throws Exception {checks=0;
  Charset utf=Charset.forName("uTf8");
  check(utf==StandardCharsets.UTF_8&&utf==Charset.forName("unicode-1-1-utf-8"),"Canonical UTF8 cache and static identity");
  check("UTF-8".equals(utf.name())&&"UTF-8".equals(utf.toString())&&"UTF-8".equals(utf.displayName()),"Canonical charset names");
  check(utf.hashCode()=="UTF-8".hashCode()&&utf.equals(StandardCharsets.UTF_8)&&!utf.equals("UTF-8")&&!utf.equals(null),"Charset hash and typed equality");
  check(utf.compareTo(StandardCharsets.US_ASCII)>0&&utf.compareTo(utf)==0,"Charset name order");
  check(utf.contains(StandardCharsets.UTF_16)&&StandardCharsets.ISO_8859_1.contains(StandardCharsets.US_ASCII)&&!StandardCharsets.US_ASCII.contains(utf),"Charset containment");
  check(utf.isRegistered()&&utf.canEncode()&&Charset.isSupported("utf-16le")&&!Charset.isSupported("x-kyvex-unsupported"),"Availability without silent charset fallback");
  check(utf.aliases().contains("UTF8")&&utf.aliases().contains("unicode-1-1-utf-8"),"Declared UTF8 aliases");
  boolean threw=false;try{utf.aliases().add("bad");}catch(UnsupportedOperationException expected){threw=true;}
  check(threw,"Alias set cannot be modified");
  threw=false;try{Charset.forName("bad name");}catch(IllegalCharsetNameException expected){threw=true;}
  check(threw,"Illegal charset syntax");
  threw=false;try{Charset.forName("x-kyvex-unsupported");}catch(UnsupportedCharsetException expected){threw=true;}
  check(threw,"Unknown charset rejected");
  threw=false;try{Charset.forName(null);}catch(IllegalArgumentException expected){threw=true;}
  check(threw,"Null lookup follows Java exception type");
  String text="A\u0000\u043a\u20ac\ud83d\ude00";
  check(same(text.getBytes(utf),65,0,0xd0,0xba,0xe2,0x82,0xac,0xf0,0x9f,0x98,0x80),"UTF8 actual byte encoding including NUL and supplementary character");
  check(text.equals(new String(text.getBytes(utf),utf)),"UTF8 decode round trip");
  check(same("\ud800A\udc00".getBytes(utf),63,65,63),"Malformed UTF16 input uses Java UTF8 replacement");
  check("\ufffd".equals(new String(new byte[]{(byte)0xed,(byte)0xa0,(byte)0x80},utf)),"Encoded surrogate is one malformed sequence");
  check(same("A\u00ff\u0100\ud83d\ude00".getBytes(StandardCharsets.ISO_8859_1),65,255,63,63),"Latin1 representable and unmappable characters");
  check(same("A\u00ff\ud83d\ude00".getBytes(StandardCharsets.US_ASCII),65,63,63),"ASCII replacement is per code point");
  check("\u0000\u00ff".equals(new String(new byte[]{0,(byte)255},StandardCharsets.ISO_8859_1)),"Latin1 decode preserves byte values");
  check("\ufffd".equals(new String(new byte[]{(byte)255},StandardCharsets.US_ASCII)),"ASCII malformed input replacement");
  check(same("A\u043a".getBytes(StandardCharsets.UTF_16BE),0,65,4,0x3a)&&same("A\u043a".getBytes(StandardCharsets.UTF_16LE),65,0,0x3a,4),"UTF16 explicit byte order");
  check(same("A".getBytes(StandardCharsets.UTF_16),0xfe,0xff,0,65)&&same("".getBytes(StandardCharsets.UTF_16)),"UTF16 BOM and empty input");
  check("A".equals(new String(new byte[]{(byte)255,(byte)254,65,0},StandardCharsets.UTF_16)),"UTF16 detects little endian BOM");
  check("\ufeffA".equals(new String(new byte[]{(byte)254,(byte)255,0,65},StandardCharsets.UTF_16BE)),"Explicit UTF16BE preserves BOM as data");
  check("\ufffd".equals(new String(new byte[]{(byte)0xd8,0,0,65},StandardCharsets.UTF_16BE)),"Malformed UTF16 consumes both units like Java");
  check("A".equals(new String(new byte[]{9,0,65,8},1,2,StandardCharsets.UTF_16BE)),"Byte slice offset and length");
  check(same("\u043a".getBytes("UTF8"),0xd0,0xba)&&"\u043a".equals(new String(new byte[]{(byte)0xd0,(byte)0xba},"UTF-8")),"String charset name overloads");
  check("A".equals(new String(new byte[]{9,65,8},1,1,"ASCII")),"Named byte slice overload");
  check(same("hello".getBytes(),104,101,108,108,111)&&"hello".equals(new String(new byte[]{104,101,108,108,111})),"Default conversion is usable");
  threw=false;try{"x".getBytes("bad name");}catch(UnsupportedEncodingException expected){threw=true;}
  check(threw,"Named String illegal charset is checked encoding exception");
  threw=false;try{new String(new byte[1],-1,1,utf);}catch(IndexOutOfBoundsException expected){threw=true;}
  check(threw,"Negative byte offset rejected");
  threw=false;try{"x".getBytes((Charset)null);}catch(NullPointerException expected){threw=true;}
  check(threw,"Null Charset rejected");
  byte[] original={1,2,3};ByteArrayInputStream stream=new ByteArrayInputStream(original);
  check(stream.markSupported()&&stream.available()==3,"Byte input size and mark support");
  original[0]=(byte)255;check(stream.read()==255,"Byte input reads original backing array");
  stream.mark(0);int marked=stream.read();stream.reset();check(marked==2&&stream.read()==2,"Byte input mark and reset");
  stream.close();check(stream.read()==3&&stream.read()==-1,"Byte input remains usable after close");
  stream=new ByteArrayInputStream(original,1,99);check(stream.available()==2&&stream.skip(Long.MAX_VALUE)==2&&stream.read()==-1,"Slice clamps length and wide skip to available bytes");
  check(stream.read(new byte[0])==-1&&stream.skip(-1)==0,"Byte input EOF zero length and negative skip");
  stream=new ByteArrayInputStream(original);byte[] target={9,9,9,9};check(stream.read(target,1,2)==2&&target[0]==9&&target[1]==(byte)255&&target[2]==2&&target[3]==9,"Byte input bulk read destination and signed bytes");
  threw=false;try{new ByteArrayInputStream(null);}catch(NullPointerException expected){threw=true;}check(threw,"Null byte input rejected");
  InputStreamReader reader=new InputStreamReader(new ByteArrayInputStream(text.getBytes(utf)),utf);StringBuilder read=new StringBuilder();int c;
  while((c=reader.read())!=-1)read.append((char)c);reader.close();
  check(text.equals(read.toString()),"Charset object connects to real streaming reader");
  System.gc();check(Charset.forName("UTF-8")==utf,"Cached charset survives collection");
  return checks;
 }
 public static String report(){try{return Integer.toString(verify());}catch(Exception failure){throw new IllegalStateException(failure);}}
 public static void main(String[] args)throws Exception{System.out.println("Charset checks: "+verify());}
}
