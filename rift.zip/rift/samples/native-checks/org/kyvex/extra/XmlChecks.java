package org.kyvex.extra;
import android.content.Context;
import android.util.Xml;
import org.xmlpull.v1.*;
import java.io.*;
public final class XmlChecks {
 private static int checks;
 private static void check(boolean ok,String reason){if(!ok)throw new IllegalStateException(reason);checks++;}
 public static int verify(Context context){try{
  XmlPullParser p=Xml.newPullParser();check(p.getEventType()==0&&p.getDepth()==0&&p.getFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES),"initial namespace-aware document state");
  InputStream input=context.getAssets().open("parser-check.xml");p.setInput(input,null);check(p.nextTag()==2&&"config".equals(p.getName())&&p.getDepth()==1&&"urn:kyvex".equals(p.getNamespace()),"read actual APK asset root");
  p.require(2,"urn:kyvex","config");check(p.getAttributeCount()==1&&"KYVEX & Native".equals(p.getAttributeValue(null,"title"))&&"CDATA".equals(p.getAttributeType(0)),"attribute entities and namespace declarations");
  check(p.getNamespaceCount(1)==2&&p.getNamespacePrefix(0)==null&&"urn:values".equals(p.getNamespace("k"))&&"http://www.w3.org/XML/1998/namespace".equals(p.getNamespace("xml")),"namespace stack and implicit xml binding");
  check(p.nextTag()==2&&"value".equals(p.getName())&&"k".equals(p.getPrefix())&&"urn:values".equals(p.getNamespace())&&p.getDepth()==2,"qualified child element");
  check(p.getAttributeCount()==2&&"7".equals(p.getAttributeValue("urn:values","number"))&&"yes".equals(p.getAttributeValue("","plain"))&&p.getAttributeValue(null,"number")==null,"default namespace does not apply to attributes");
  check("A&B\ud83d\ude00".equals(p.nextText())&&p.getEventType()==3&&p.getDepth()==2,"nextText coalesces entities CDATA comments and supplementary characters");
  check(p.nextTag()==2&&"empty".equals(p.getName())&&p.isEmptyElementTag()&&p.next()==3&&p.getDepth()==2&&p.nextTag()==3&&p.getDepth()==1,"empty tags emit real start/end events and retain depth");
  check(p.next()==1&&p.getDepth()==0&&p.getAttributeCount()==-1&&p.next()==1,"end document and stable EOF");input.close();
  p.setInput(new StringReader("<root xmlns='outer'><child xmlns='inner'/><tail/></root>"));p.nextTag();p.nextTag();check("inner".equals(p.getNamespace())&&p.getNamespaceCount(2)==2,"nested namespace override");p.nextTag();p.nextTag();check("outer".equals(p.getNamespace())&&p.getNamespaceCount(2)==1,"namespace scope restored after empty end");
  p.setInput(new StringReader("<r>a<![CDATA[b]]>&amp;<!--c--><?p x?></r>"));p.nextToken();check(p.nextToken()==4&&"a".equals(p.getText())&&p.nextToken()==5&&"b".equals(p.getText())&&p.nextToken()==6&&"amp".equals(p.getName())&&"&".equals(p.getText())&&p.nextToken()==9&&"c".equals(p.getText())&&p.nextToken()==8,"nextToken exposes distinct actual XML tokens");
  p.setInput(new StringReader("<x a='line\r\nnext\tvalue'>\r\ntext\r</x>"));p.nextTag();check("line next value".equals(p.getAttributeValue(0))&&"\ntext\n".equals(p.nextText())&&p.getLineNumber()>=3,"XML line-end and attribute normalization");
  p.setInput(new StringReader("<p:r xmlns:p='u' p:a='v'/>"));p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES,false);p.nextTag();check("p:r".equals(p.getName())&&"".equals(p.getNamespace())&&p.getPrefix()==null&&p.getAttributeCount()==2&&"v".equals(p.getAttributeValue(null,"p:a")),"namespace-disabled mode preserves raw names");
  boolean rejected=false;p.setInput(new StringReader("<r/>"));p.nextTag();try{p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES,true);}catch(XmlPullParserException expected){rejected=true;}check(rejected,"features cannot change while parsing");
  rejected=false;try{p.getAttributeValue(-1);}catch(IndexOutOfBoundsException expected){rejected=true;}check(rejected,"attribute bounds throw a real Java exception");
  rejected=false;p.setInput(new StringReader("<r><a></r>"));try{while(p.next()!=1){}}catch(XmlPullParserException expected){rejected=true;}check(rejected,"malformed XML is rejected during next");
  rejected=false;p.setInput(new StringReader("<!DOCTYPE r SYSTEM 'file:///etc/passwd'><r/>"));try{p.next();}catch(XmlPullParserException expected){rejected=true;}check(rejected,"DTD input is explicitly unsupported and cannot open host files");
  p.setInput(new StringReader("<ok/>"));check(p.nextTag()==2&&p.isEmptyElementTag(),"setInput resets a failed parser");
  rejected=false;p.setInput((Reader)null);try{p.next();}catch(XmlPullParserException expected){rejected=true;}check(rejected&&p.getEventType()==0,"setInput null releases the source");
  return checks;
 }catch(Exception e){throw new IllegalStateException("XML check failed: "+e.getMessage());}}
}
