/* Exercise Bionic calls from real ARM code without linking the host libc. */
typedef long thread_t;
typedef long mutex_attr_t;
typedef struct {
#ifdef __LP64__
    int data[10];
#else
    int data[1];
#endif
} mutex_t;
typedef struct { const void **functions; } Vm;
typedef struct { const void **functions; } Env;

extern int pthread_create(thread_t *, const void *, void *(*)(void *), void *);
extern thread_t pthread_self(void);
extern int pthread_equal(thread_t, thread_t);
extern int pthread_join(thread_t, void **);
extern int pthread_detach(thread_t);
extern void pthread_exit(void *) __attribute__((noreturn));
extern int pthread_once(int *, void (*)(void));
extern int pthread_mutexattr_init(mutex_attr_t *);
extern int pthread_mutexattr_destroy(mutex_attr_t *);
extern int pthread_mutexattr_settype(mutex_attr_t *, int);
extern int pthread_mutex_init(mutex_t *, const mutex_attr_t *);
extern int pthread_mutex_destroy(mutex_t *);
extern int pthread_mutex_lock(mutex_t *);
extern int pthread_mutex_trylock(mutex_t *);
extern int pthread_mutex_unlock(mutex_t *);
extern int sched_yield(void);
extern int *__errno(void);

enum { EPERM = 1, ESRCH = 3, EFAULT = 14, EBUSY = 16, EINVAL = 22, EDEADLK = 35, ENOTSUP = 95 };

struct shared {
    thread_t root;
    thread_t worker;
    int *root_errno;
    int *worker_errno;
    volatile int release;
    int completed;
    mutex_t mutex;
    Vm *vm;
};

static void *record_thread(void *argument) {
    struct shared *s = argument;
    s->worker = pthread_self();
    s->worker_errno = __errno();
    if (pthread_equal(s->root, s->worker) || !pthread_equal(s->worker, pthread_self())) return 0;
    if (s->worker_errno == s->root_errno || *s->worker_errno != 0) return 0;
    *s->worker_errno = 73;
    if (s->vm) {
        int (*get_env)(Vm *, Env **, int) = (void *)s->vm->functions[6];
        Env *env = (Env *)1;
        if (get_env(s->vm, &env, 0x10006) != -2 || env) return 0;
    }
    while (!s->release) sched_yield();
    if (*__errno() != 73) return 0;
    return (void *)(__UINTPTR_TYPE__)0x1234567887654321ULL;
}

static void *return_argument(void *argument) {
    return argument;
}

static void *exit_thread(void *argument) {
    pthread_exit(argument);
}

static void *detach_worker(void *argument) {
    struct shared *s = argument;
    while (!s->release) sched_yield();
    s->completed++;
    return 0;
}

static void *contend(void *argument) {
    struct shared *s = argument;
    if (pthread_mutex_trylock(&s->mutex) != EBUSY) return 0;
    if (pthread_mutex_unlock(&s->mutex) != EPERM) return 0;
    s->completed = 1;
    if (pthread_mutex_lock(&s->mutex) != 0) return 0;
    s->completed = 2;
    if (pthread_mutex_unlock(&s->mutex) != 0) return 0;
    return argument;
}

static void *join_child(void *argument) {
    thread_t child;
    void *result;
    if (pthread_create(&child, 0, return_argument, argument) != 0) return 0;
    if (pthread_join(child, &result) != 0) return 0;
    return result;
}

static int outer_once, nested_once;
static int outer_calls, nested_calls, recursive_error;
static volatile int release_once;

static void init_nested(void) {
    nested_calls++;
}

static void init_outer(void) {
    outer_calls++;
    recursive_error = pthread_once(&outer_once, init_outer);
    if (pthread_once(&nested_once, init_nested) != 0) return;
    while (!release_once) sched_yield();
    outer_calls++;
}

static void *run_once(void *argument) {
    if (pthread_once(&outer_once, init_outer) != 0) return 0;
    return outer_calls == 2 ? argument : 0;
}

static int verify(Vm *vm) {
    thread_t thread = 0;
    void *result = 0;
    struct shared shared = {0};
    shared.root = pthread_self();
    shared.root_errno = __errno();
    shared.vm = vm;
    *shared.root_errno = 91;
    if (!shared.root || pthread_join(shared.root, 0) != EDEADLK) return -1;
    if (pthread_create(&thread, 0, 0, 0) != EINVAL || thread) return -2;
    if (pthread_create(&thread, &shared, return_argument, 0) != ENOTSUP || thread) return -3;
    if (pthread_create(0, 0, return_argument, 0) != EFAULT) return -4;
    if (pthread_create(&thread, 0, record_thread, &shared) != 0) return -5;
    if (thread != shared.worker || shared.root == thread || *__errno() != 91) return -6;
    shared.release = 1;
    if (pthread_join(thread, &result) != 0 || *__errno() != 91 ||
        result != (void *)(__UINTPTR_TYPE__)0x1234567887654321ULL) return -7;
    if (pthread_join(thread, 0) != ESRCH) return -8;
    if (pthread_create(&thread, 0, exit_thread, &shared) != 0 ||
        pthread_join(thread, &result) != 0 || result != &shared) return -9;
    if (pthread_create(&thread, 0, return_argument, &shared) != 0 ||
        pthread_join(thread, (void **)1) != EFAULT ||
        pthread_join(thread, &result) != 0 || result != &shared) return -10;
    if (pthread_create(&thread, 0, return_argument, &shared) != 0 ||
        pthread_detach(thread) != 0 || pthread_join(thread, 0) != ESRCH) return -11;

    shared.release = 0;
    if (pthread_create(&thread, 0, detach_worker, &shared) != 0 ||
        pthread_detach(thread) != 0 || pthread_detach(thread) != EINVAL ||
        pthread_join(thread, 0) != EINVAL) return -12;
    shared.release = 1;
    if (sched_yield() || shared.completed != 1 || pthread_detach(thread) != ESRCH) return -13;
    if (pthread_create(&thread, 0, join_child, &shared) != 0 ||
        pthread_join(thread, &result) != 0 || result != &shared) return -14;

    shared.completed = 0;
    if (pthread_mutex_lock(&shared.mutex) != 0 ||
        pthread_mutex_trylock(&shared.mutex) != EBUSY ||
        pthread_mutex_lock(&shared.mutex) != EDEADLK) return -15;
    if (pthread_create(&thread, 0, contend, &shared) != 0 || shared.completed != 1 ||
        pthread_mutex_destroy(&shared.mutex) != EBUSY ||
        pthread_join(thread, 0) != EDEADLK) return -16;
    if (pthread_mutex_unlock(&shared.mutex) != 0 ||
        pthread_join(thread, &result) != 0 || result != &shared || shared.completed != 2) return -17;
    if (pthread_mutex_destroy(&shared.mutex) != 0 || pthread_mutex_lock(&shared.mutex) != EINVAL) return -18;

    mutex_attr_t attr;
    if (pthread_mutexattr_init(&attr) != 0 || pthread_mutexattr_settype(&attr, 3) != EINVAL ||
        pthread_mutexattr_settype(&attr, 1) != 0 || pthread_mutex_init(&shared.mutex, &attr) != 0 ||
        pthread_mutexattr_destroy(&attr) != 0) return -19;
    if (pthread_mutex_lock(&shared.mutex) != 0 || pthread_mutex_trylock(&shared.mutex) != 0 ||
        pthread_mutex_unlock(&shared.mutex) != 0 || pthread_mutex_destroy(&shared.mutex) != EBUSY ||
        pthread_mutex_unlock(&shared.mutex) != 0 || pthread_mutex_destroy(&shared.mutex) != 0) return -20;
    for (int i = 0; i < 40; i++) {
        if (pthread_create(&thread, 0, return_argument, 0) != 0 || pthread_join(thread, 0) != 0) return -21;
    }
    outer_once = nested_once = 0;
    outer_calls = nested_calls = recursive_error = release_once = 0;
    if (pthread_once(&outer_once, 0) != EINVAL || outer_once != 0) return -22;
    if (pthread_create(&thread, 0, run_once, &shared) != 0 || outer_calls != 1 ||
        nested_calls != 1 || recursive_error != EDEADLK) return -23;
    thread_t waiter;
    if (pthread_create(&waiter, 0, run_once, &shared) != 0 || outer_calls != 1) return -24;
    release_once = 1;
    if (pthread_once(&outer_once, init_outer) != 0 || outer_once != 2 || nested_once != 2 ||
        outer_calls != 2 || nested_calls != 1) return -25;
    if (pthread_join(thread, &result) != 0 || result != &shared ||
        pthread_join(waiter, &result) != 0 || result != &shared) return -26;
    return 26;
}

int Java_org_kyvex_extra_LinkChecks_nativePthreads(Env *env, void *type) {
    (void)type;
    Vm *vm = 0;
    int (*get_vm)(Env *, Vm **) = (void *)env->functions[219];
    if (get_vm(env, &vm) != 0 || !vm) return -27;
    return verify(vm);
}

#ifdef RIFT_PTHREAD_STANDALONE
__attribute__((noreturn)) void rift_pthread_entry(void) {
    int result = verify(0);
    int code = result == 26 ? 0 : -result;
#ifdef __aarch64__
    register long argument __asm__("x0") = code;
    register long number __asm__("x8") = 93;
#else
    register long argument __asm__("r0") = code;
    register long number __asm__("r7") = 1;
#endif
    __asm__ volatile("svc #0" : : "r"(argument), "r"(number) : "memory");
    __builtin_unreachable();
}
#endif
