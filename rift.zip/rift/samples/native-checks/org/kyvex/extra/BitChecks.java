package org.kyvex.extra;
/** Real DEX call/result transport on both ABIs, plus a stock Java8 oracle. */
public final class BitChecks {
 private static int checks;
 private static volatile int opaqueInt;
 private static volatile long opaqueLong;
 private static int dynamic(int value){return value+opaqueInt;}
 private static long dynamicLong(long value){return value+opaqueLong;}
 private static void check(boolean v,String reason){if(!v)throw new IllegalStateException(reason);checks++;}
 public static int verify(){checks=0;
  check(Integer.numberOfLeadingZeros(dynamic(0))==32&&Integer.numberOfLeadingZeros(dynamic(4))==29&&Integer.numberOfLeadingZeros(dynamic(-1))==0,"Int leading zero boundaries and array scale");
  check(Integer.numberOfTrailingZeros(dynamic(0))==32&&Integer.numberOfTrailingZeros(dynamic(Integer.MIN_VALUE))==31,"Int trailing zero boundaries");
  check(Integer.bitCount(dynamic(-1))==32&&Integer.bitCount(dynamic(0x55555555))==16,"Int population count");
  check(Integer.highestOneBit(dynamic(0))==0&&Integer.highestOneBit(dynamic(0x12345678))==0x10000000&&Integer.highestOneBit(dynamic(Integer.MIN_VALUE))==Integer.MIN_VALUE,"Int highest bit");
  check(Integer.lowestOneBit(dynamic(0))==0&&Integer.lowestOneBit(dynamic(0x12345678))==8&&Integer.lowestOneBit(dynamic(Integer.MIN_VALUE))==Integer.MIN_VALUE,"Int lowest bit");
  check(Integer.reverse(dynamic(1))==Integer.MIN_VALUE&&Integer.reverse(dynamic(0x12345678))==0x1e6a2c48,"Int bit reversal");
  check(Integer.reverseBytes(dynamic(0x12345678))==0x78563412,"Int byte reversal");
  check(Integer.signum(dynamic(Integer.MIN_VALUE))==-1&&Integer.signum(dynamic(0))==0&&Integer.signum(dynamic(Integer.MAX_VALUE))==1,"Int sign");
  check(Integer.rotateLeft(dynamic(0x12345678),4)==0x23456781&&Integer.rotateLeft(dynamic(0x12345678),-4)==0x81234567,"Int left rotation signed distance");
  check(Integer.rotateRight(dynamic(0x12345678),4)==0x81234567&&Integer.rotateRight(dynamic(0x12345678),36)==0x81234567,"Int right rotation masked distance");
  check(Long.numberOfLeadingZeros(dynamicLong(0))==64&&Long.numberOfLeadingZeros(dynamicLong(1L<<32))==31&&Long.numberOfLeadingZeros(dynamicLong(-1))==0,"Wide leading zeros");
  check(Long.numberOfTrailingZeros(dynamicLong(0))==64&&Long.numberOfTrailingZeros(dynamicLong(Long.MIN_VALUE))==63,"Wide trailing zeros");
  check(Long.bitCount(dynamicLong(-1))==64&&Long.bitCount(dynamicLong(0x5555555555555555L))==32,"Wide population count");
  check(Long.highestOneBit(dynamicLong(0))==0&&Long.highestOneBit(dynamicLong(0x123456789abcdef0L))==0x1000000000000000L&&Long.highestOneBit(dynamicLong(Long.MIN_VALUE))==Long.MIN_VALUE,"Wide highest bit");
  check(Long.lowestOneBit(dynamicLong(0))==0&&Long.lowestOneBit(dynamicLong(0x123456789abcdef0L))==16&&Long.lowestOneBit(dynamicLong(Long.MIN_VALUE))==Long.MIN_VALUE,"Wide lowest bit");
  check(Long.reverse(dynamicLong(1))==Long.MIN_VALUE&&Long.reverse(dynamicLong(0x0123456789abcdefL))==0xf7b3d591e6a2c480L,"Wide bit reversal");
  check(Long.reverseBytes(dynamicLong(0x0123456789abcdefL))==0xefcdab8967452301L,"Wide byte reversal");
  check(Long.signum(dynamicLong(Long.MIN_VALUE))==-1&&Long.signum(dynamicLong(0))==0&&Long.signum(dynamicLong(Long.MAX_VALUE))==1,"Wide sign result uses int");
  check(Long.rotateLeft(dynamicLong(0x0123456789abcdefL),8)==0x23456789abcdef01L&&Long.rotateLeft(dynamicLong(0x0123456789abcdefL),-8)==0xef0123456789abcdL,"Wide left rotation and signed distance");
  check(Long.rotateRight(dynamicLong(0x0123456789abcdefL),8)==0xef0123456789abcdL&&Long.rotateRight(dynamicLong(0x0123456789abcdefL),72)==0xef0123456789abcdL,"Wide right rotation and mask");
  check(Integer.rotateLeft(dynamic(0x12345678),Integer.MIN_VALUE)==0x12345678&&Long.rotateRight(dynamicLong(0x0123456789abcdefL),Integer.MIN_VALUE)==0x0123456789abcdefL,"Extreme negative rotations");
  return checks;
 }
 public static void main(String[] args){System.out.println("Bit checks: "+verify());}
}
