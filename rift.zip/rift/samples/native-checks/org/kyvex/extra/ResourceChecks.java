package org.kyvex.extra;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Configuration;
import android.util.TypedValue;
import android.util.DisplayMetrics;
import android.content.res.AssetManager;
import java.io.*;
public final class ResourceChecks {
 private static int checks;
 private static void check(boolean ok,String message){if(!ok)throw new IllegalStateException(message);checks++;}
 private static int id(Resources r,String kind,String name){int result=r.getIdentifier(name,kind,"org.kyvex.nativehello");if(result==0)throw new IllegalStateException("Missing actual compiled resource "+name);return result;}
 public static int verify(Context c){
  Resources r=c.getResources();check(r==c.getResources(),"Resources context identity");
  int greeting=id(r,"string","greeting");String text="Hello from APK resources \ud83c\udf0d";
  check(text.equals(r.getString(greeting))&&text.contentEquals(r.getText(greeting)),"actual UTF8 resource pool");
  check(text.equals(c.getString(greeting))&&text.contentEquals(c.getText(greeting)),"Context resource delegation");
  check(text.equals(r.getString(id(r,"string","greeting_alias"))),"reference resolution");
  check("US locale".equals(r.getString(id(r,"string","locale_choice"))),"en US resource selection");
  check("portrait default".equals(r.getString(id(r,"string","orientation_choice"))),"landscape excluded");
  check("API 28 fallback".equals(r.getString(id(r,"string","sdk_choice"))),"newer SDK resource excluded");
  check("org.kyvex.nativehello:string/greeting".equals(r.getResourceName(greeting))&&"string".equals(r.getResourceTypeName(greeting))&&"greeting".equals(r.getResourceEntryName(greeting)),"resource names from ARSC");
  check("org.kyvex.nativehello".equals(r.getResourcePackageName(greeting))&&greeting==r.getIdentifier("org.kyvex.nativehello:string/greeting",null,null),"fully qualified resource lookup");
  check(r.getIdentifier("missing","string",c.getPackageName())==0,"missing identifier returns zero");
  boolean missing=false;try{r.getString(0x7f7f7777);}catch(Resources.NotFoundException expected){missing=true;}check(missing,"missing value throws NotFoundException");
  check("fallback".contentEquals(r.getText(0,"fallback")),"getText fallback");
  check(r.getBoolean(id(r,"bool","enabled"))&&r.getInteger(id(r,"integer","answer"))==42,"typed booleans and integers");
  check(r.getColor(id(r,"color","accent"))==0xff345678,"actual compiled color");
  int spacing=id(r,"dimen","spacing");check(r.getDimension(spacing)==25.0f&&r.getDimensionPixelOffset(spacing)==25&&r.getDimensionPixelSize(spacing)==25,"dimension conversion to virtual pixels");
  int negative=id(r,"dimen","negative");check(r.getDimension(negative)==-0.5f&&r.getDimensionPixelOffset(negative)==0&&r.getDimensionPixelSize(negative)==-1,"negative nonzero dimension rounding");
  String[] words=r.getStringArray(id(r,"array","words"));check(words.length==3&&"first".equals(words[0])&&text.equals(words[1])&&"Україна".equals(words[2]),"string array with reference");
  int[] numbers=r.getIntArray(id(r,"array","numbers"));check(numbers.length==3&&numbers[0]==7&&numbers[1]==-3&&numbers[2]==42,"integer array");
  TypedValue value=new TypedValue();r.getValue(greeting,value,true);check(value.type==3&&text.contentEquals(value.string)&&value.resourceId==greeting&&value.assetCookie==1,"TypedValue from compiled string");
  int alias=id(r,"string","greeting_alias");r.getValue(alias,value,false);check(value.type==1&&value.data==greeting&&value.string==null,"unresolved TypedValue reference");
  r.getValue(alias,value,true);check(value.type==3&&value.resourceId==greeting,"resolved TypedValue identity");
  Configuration config=r.getConfiguration();DisplayMetrics metrics=r.getDisplayMetrics();
  check(config.orientation==1&&config.screenWidthDp==360&&config.screenHeightDp==640&&config.densityDpi==320&&config.getLayoutDirection()==0,"virtual display configuration");
  check(metrics.widthPixels==720&&metrics.heightPixels==1280&&metrics.density==2.0f&&metrics.densityDpi==config.densityDpi,"configuration and metrics agree");
  check("en".equals(config.locale.getLanguage())&&"US".equals(config.locale.getCountry())&&"en-US".equals(config.locale.toLanguageTag()),"configuration locale");
  try{verifyStreams(c,r);}catch(IOException error){throw new IllegalStateException(error);}
  return checks;
 }
 private static void verifyStreams(Context c,Resources r)throws IOException {
  AssetManager assets=c.getAssets();check(assets==r.getAssets(),"context and resources share APK assets");
  InputStream input=assets.open("payload.txt");check(input.available()==16&&input.read()==75,"asset bytes and size");
  input.mark(10);byte[] bytes=new byte[4];check(input.read(bytes)==4&&bytes[0]==89&&bytes[3]==88,"asset reads actual member bytes");
  input.reset();check(input.read()==89&&input.skip(-2)==0,"asset mark reset and negative skip");
  check(input.skip(10000)==14&&input.read()==-1&&input.read(new byte[0])==0,"asset EOF and bounded skip");
  input.close();boolean denied=false;try{input.read();}catch(IOException expected){denied=true;}check(denied,"closed asset stream fails");
  denied=false;try{assets.open("../AndroidManifest.xml");}catch(FileNotFoundException expected){denied=true;}check(denied,"asset traversal rejected");
  input=r.openRawResource(id(r,"raw","payload"));check(input.read()==75&&input.available()==18,"raw resource resolves to actual APK member");input.close();
  File directory=new File(c.getApplicationInfo().nativeLibraryDir);File library=new File(directory,"libkyvexdemo.so");
  check(directory.isDirectory()&&directory.canRead()&&!directory.canWrite()&&library.isFile()&&library.length()>4&&!library.canWrite(),"read-only APK native library mount");
  FileInputStream elf=new FileInputStream(library);check(elf.read()==127&&elf.read()==69&&elf.read()==76&&elf.read()==70,"native library header comes from APK");elf.close();
  System.load(library.getAbsolutePath());denied=false;try{System.load("/etc/libkyvexdemo.so");}catch(UnsatisfiedLinkError expected){denied=true;}check(denied,"System.load stays inside guest APK namespace");
  int failures=0;try{System.loadLibrary("badversion");}catch(UnsatisfiedLinkError expected){failures++;}try{System.loadLibrary("badversion");}catch(UnsatisfiedLinkError expected){failures++;}check(failures==2,"rejected JNI_OnLoad remains rejected on retry");
 }
}
