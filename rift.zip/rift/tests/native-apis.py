#!/usr/bin/env python3
"""Real API fixtures in sandboxed ordinary-user ARM32/ARM64 release processes."""
import hashlib,importlib.util,json,os,pathlib,subprocess,tempfile,time,unittest

SOURCE=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('worker_helpers',SOURCE/'tests/native-workers.py')
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
WORKER=pathlib.Path('/usr/lib/kyvex/rift-native')
RECORDS=[]

class NativeAPIs(unittest.TestCase):
    def spawn(self,fixture,abi,*args):
        process=subprocess.Popen([str(WORKER),'--apk',str(SOURCE/'samples/built'/fixture),'--abi',abi,*args],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0,preexec_fn=helpers.ordinary_user,env={'LANG':'C.UTF-8'})
        self.addCleanup(helpers.NativeWorkers.reap,process)
        return process

    def frame(self,process):
        value=helpers.packet(process)
        self.assertTrue(value.get('ok'),value);self.assertTrue(value['metrics']['sandbox'])
        return value

    @staticmethod
    def texts(value):return [widget['text'] for widget in value['scene']['widgets']]

    def close(self,process):
        self.assertTrue(helpers.send(process,{'method':'close'})['closed'])
        self.assertEqual(process.wait(timeout=3),0)

    def test_preferences_persist_in_new_processes_for_both_abis(self):
        fixture='rift-platform-demo.apk'
        with tempfile.TemporaryDirectory(prefix='rift-preferences-api-') as root:
            os.chown(root,helpers.UID,helpers.UID)
            for abi in ['arm64-v8a','armeabi-v7a']:
                for launch in [1,2]:
                    with self.subTest(abi=abi,launch=launch):
                        process=self.spawn(fixture,abi,'--state',root+'/'+abi+'.journal')
                        first=self.frame(process)
                        self.assertIn(f'Platform checks: 19 / launch_count: {launch}',self.texts(first))
                        self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,launch=launch,start=first))

    def test_device_storage_json_and_native_bootstrap_run_in_the_guest(self):
        fixture = 'rift-bootstrap-demo.apk'
        with tempfile.TemporaryDirectory(prefix='rift-storage-api-') as root:
            os.chown(root, helpers.UID, helpers.UID)
            for abi in ['arm64-v8a', 'armeabi-v7a']:
                for launch in [1, 2]:
                    with self.subTest(abi=abi, launch=launch):
                        process = self.spawn(fixture, abi, '--state', root + '/' + abi + '.journal')
                        first = self.frame(process)
                        self.assertEqual(first['metrics']['loaded_dex'], 2)
                        self.assertIn(f'Storage checks: 23 / launch {launch}', self.texts(first))
                        self.assertIn('JSON checks: 54', self.texts(first))
                        self.assertIn('Executor delegate checks: 13', self.texts(first))
                        self.assertIn('ELF link checks: 9', self.texts(first))
                        self.assertIn('Native heap checks: 13', self.texts(first))
                        self.assertIn('StrictMode checks: 11', self.texts(first))
                        self.assertIn('Regex replacement checks: 19', self.texts(first))
                        self.assertIn('Native integer checks: 15', self.texts(first))
                        self.assertIn('Native stdio checks: 14', self.texts(first))
                        self.assertIn('Managed text checks: 20', self.texts(first))
                        self.assertIn('TextPaint checks: 12', self.texts(first))
                        self.assertIn('System.arraycopy checks: 8', self.texts(first))
                        self.assertIn('Rounding checks: 19', self.texts(first))
                        self.assertIn('Read/write lock checks: 11', self.texts(first))
                        self.assertIn('Android coordination checks: 18', self.texts(first))
                        self.assertIn('Native scanf checks: 13', self.texts(first))
                        self.assertIn('Native allocated format checks: 4', self.texts(first))
                        self.assertIn('Android graphics checks: 45', self.texts(first))
                        self.assertIn('Pair and Settings checks: 27', self.texts(first))
                        self.assertIn('Discard and array hash checks: 14', self.texts(first))
                        self.assertIn('Native string checks: 16', self.texts(first))
                        self.assertIn('Native pthread checks: 26', self.texts(first))
                        self.assertIn('Native C locale checks: 13', self.texts(first))
                        logs = first['metrics']['app_logs']
                        self.assertIn('4/RiftLink: ELF dependency initialized', logs)
                        self.assertIn('4/RiftLink: value=-12345678901234 hex=0000CAFE word=ARM %', logs)
                        self.assertTrue(all('filtered native message' not in line for line in logs))
                        self.assertEqual(logs.count('StrictMode: child strict probe'), 1)
                        self.assertEqual(logs.count('StrictMode: unbuffered guest file I/O'), 1)
                        self.assertTrue(all('suppressed strict probe' not in line for line in logs))
                        self.assertIn('stdout: io-v34', logs)
                        self.assertIn('stderr: direct=-4294967297 ok 17', logs)
                        self.assertIn('stderr: saved:11/-4294967298/ARM/3/4/5/6/7/8', logs)
                        self.assertIn('stderr: close-v34', logs)
                        self.assertTrue(any(line.startswith('RiftCoordination: bootstrap throwable') for line in logs))
                        button = next(widget['id'] for widget in first['scene']['widgets'] if widget['kind'] == 'button')
                        click = helpers.send(process, {'method': 'click', 'id': button})
                        self.assertTrue(click['ok'], click)
                        self.assertIn('ARM result: 14', self.texts(click))
                        self.close(process)
                        RECORDS.append(dict(fixture=fixture, abi=abi, launch=launch, start=first, click=click))

    def test_main_handler_runs_orders_cancels_and_delivers_after_delay(self):
        fixture='rift-event-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Events: FABM / ticks 0',self.texts(first));self.assertEqual(first['metrics']['pending_events'],1)
                before=helpers.send(process,{'method':'tick'});self.assertTrue(before['ok'],before)
                self.assertIn('Events: FABM / ticks 0',self.texts(before))
                time.sleep(.65)
                after=helpers.send(process,{'method':'tick'});self.assertTrue(after['ok'],after)
                self.assertIn('Events: FABMT / ticks 1',self.texts(after));self.assertEqual(after['metrics']['pending_events'],0)
                button=next(w['id'] for w in after['scene']['widgets'] if w['kind']=='button')
                click=helpers.send(process,{'method':'click','id':button});self.assertTrue(click['ok'],click)
                self.assertIn('ARM result: 14',self.texts(click))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first,before=before,after=after,click=click))

    def test_private_files_streams_and_open_unlinked_files_execute_real_java(self):
        fixture='rift-files-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('File checks: 20',self.texts(first))
                button=next(w['id'] for w in first['scene']['widgets'] if w['kind']=='button')
                click=helpers.send(process,{'method':'click','id':button});self.assertTrue(click['ok'],click)
                self.assertIn('ARM result: 14',self.texts(click))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first,click=click))

    def test_application_info_package_manager_thread_constructor_and_declared_fields(self):
        fixture='rift-bridge-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Bridge checks: 123',self.texts(first))
                button=next(w['id'] for w in first['scene']['widgets'] if w['kind']=='button')
                click=helpers.send(process,{'method':'click','id':button});self.assertTrue(click['ok'],click)
                self.assertIn('ARM result: 14',self.texts(click))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first,click=click))

    def test_compiled_apk_resources_configurations_and_arrays(self):
        fixture='rift-resource-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Resource checks: 36',self.texts(first))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_manifest_providers_execute_before_application_in_actual_init_order(self):
        fixture='rift-provider-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Provider lifecycle: verified',self.texts(first))
                self.assertIn('Compiled XML checks: 44',self.texts(first))
                button=next(w['id'] for w in first['scene']['widgets'] if w['kind']=='button')
                click=helpers.send(process,{'method':'click','id':button});self.assertTrue(click['ok'],click)
                self.assertIn('ARM result: 14',self.texts(click))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first,click=click))

    def test_readers_decode_utf8_and_read_actual_guest_process_metadata(self):
        fixture='rift-reader-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Reader checks: 17',self.texts(first))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_xml_pull_parser_reads_real_apk_asset_and_rejects_malformed_input(self):
        fixture='rift-xml-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('XML checks: 20',self.texts(first))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_hash_map_bucket_callbacks_and_typed_array_copies(self):
        fixture = 'rift-hash-map-demo.apk'
        for abi in ['arm64-v8a', 'armeabi-v7a']:
            with self.subTest(abi=abi):
                process = self.spawn(fixture, abi)
                first = self.frame(process)
                self.assertIn('HashMap checks: 39', self.texts(first))
                button = next(widget['id'] for widget in first['scene']['widgets'] if widget['kind'] == 'button')
                click = helpers.send(process, {'method': 'click', 'id': button})
                self.assertTrue(click['ok'], click)
                self.assertIn('ARM result: 14', self.texts(click))
                self.close(process)
                RECORDS.append(dict(fixture=fixture, abi=abi, start=first, click=click))

    def test_zero_capacity_handoffs_cached_workers_and_real_java_callbacks(self):
        fixture = 'rift-handoff-demo.apk'
        for abi in ['arm64-v8a', 'armeabi-v7a']:
            with self.subTest(abi=abi):
                process = self.spawn(fixture, abi)
                first = self.frame(process)
                self.assertIn('Handoff checks: 48', self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'], 1)
                button = next(widget['id'] for widget in first['scene']['widgets'] if widget['kind'] == 'button')
                click = helpers.send(process, {'method': 'click', 'id': button})
                self.assertTrue(click['ok'], click)
                self.assertIn('ARM result: 14', self.texts(click))
                self.close(process)
                RECORDS.append(dict(fixture=fixture, abi=abi, start=first, click=click))

    def test_scheduled_tasks_run_with_delays_periods_results_and_interruptible_waits(self):
        fixture = 'rift-scheduled-demo.apk'
        for abi in ['arm64-v8a', 'armeabi-v7a']:
            with self.subTest(abi=abi):
                process = self.spawn(fixture, abi)
                first = self.frame(process)
                self.assertIn('Scheduled checks: 44', self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'], 1)
                button = next(widget['id'] for widget in first['scene']['widgets'] if widget['kind'] == 'button')
                click = helpers.send(process, {'method': 'click', 'id': button})
                self.assertTrue(click['ok'], click)
                self.assertIn('ARM result: 14', self.texts(click))
                self.close(process)
                RECORDS.append(dict(fixture=fixture, abi=abi, start=first, click=click))

    def test_messenger_aliases_deliver_real_ordered_request_and_reply_on_main_looper(self):
        fixture = 'rift-messenger-demo.apk'
        for abi in ['arm64-v8a', 'armeabi-v7a']:
            with self.subTest(abi=abi):
                process = self.spawn(fixture, abi)
                first = self.frame(process)
                self.assertIn('Messenger checks: 9 pending', self.texts(first))
                self.assertEqual(first['metrics']['pending_events'], 1)

                time.sleep(1.1)
                after = helpers.send(process, {'method': 'tick'})
                self.assertTrue(after['ok'], after)
                self.assertIn('Messenger checks: 18 delivered', self.texts(after))
                self.assertEqual(after['metrics']['pending_events'], 0)
                self.assertEqual(after['metrics']['events'] - first['metrics']['events'], 3)

                button = next(widget['id'] for widget in after['scene']['widgets'] if widget['kind'] == 'button')
                click = helpers.send(process, {'method': 'click', 'id': button})
                self.assertTrue(click['ok'], click)
                self.assertIn('ARM result: 14', self.texts(click))
                self.close(process)
                RECORDS.append(dict(fixture=fixture, abi=abi, start=first, after=after, click=click))

    def test_formatter_preserves_utf16_typed_errors_and_real_object_callbacks(self):
        fixture = 'rift-formatter-demo.apk'
        for abi in ['arm64-v8a', 'armeabi-v7a']:
            with self.subTest(abi=abi):
                process = self.spawn(fixture, abi)
                first = self.frame(process)
                self.assertIn('Formatter checks: 36', self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'], 1)
                button = next(widget['id'] for widget in first['scene']['widgets'] if widget['kind'] == 'button')
                click = helpers.send(process, {'method': 'click', 'id': button})
                self.assertTrue(click['ok'], click)
                self.assertIn('ARM result: 14', self.texts(click))
                self.close(process)
                RECORDS.append(dict(fixture=fixture, abi=abi, start=first, click=click))

    def test_executor_runs_real_tasks_with_reusable_threads_factories_hooks_waits_and_shutdown(self):
        fixture='rift-executor-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Executor checks: 47',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                button=next(w['id'] for w in first['scene']['widgets'] if w['kind']=='button')
                click=helpers.send(process,{'method':'click','id':button});self.assertTrue(click['ok'],click)
                self.assertIn('ARM result: 14',self.texts(click))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first,click=click))

    def test_logging_matches_java8_hierarchy_levels_and_preserves_bounded_real_diagnostics(self):
        fixture='rift-logging-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Logging checks: 123',self.texts(first))
                logs=first['metrics']['app_logs']
                self.assertEqual(len(logs),32)
                self.assertTrue(all(len(line)<=2048 for line in logs))
                self.assertFalse(any('must-not-appear' in line for line in logs))
                self.assertTrue(any('FINE ' in line and 'fine-probe' in line for line in logs))
                self.assertTrue(any('diagnostic-probe | java.lang.IllegalStateException: log-cause' in line for line in logs))
                self.assertTrue(any(line.endswith(': null') for line in logs))
                self.assertTrue(any('unicode-київ-😀' in line for line in logs))
                self.assertTrue(any('long-probe-' in line and len(line)==2048 for line in logs))
                button=next(w['id'] for w in first['scene']['widgets'] if w['kind']=='button')
                click=helpers.send(process,{'method':'click','id':button});self.assertTrue(click['ok'],click)
                self.assertIn('ARM result: 14',self.texts(click))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first,click=click))

    def test_sqlite_real_callbacks_rows_migrations_and_transaction_rollback(self):
        fixture='rift-sqlite-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('SQLite checks: 48',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_android_base64_flags_padding_slices_and_actual_persistence_key_bytes(self):
        fixture='rift-base64-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Base64 checks: 40',self.texts(first))
                self.assertIn('Number parse checks: 36',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_standard_charsets_encode_decode_actual_bytes_and_connect_to_readers(self):
        fixture='rift-charset-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Charset checks: 41',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_live_map_sets_invoke_real_dex_backing_and_read_only_iterators(self):
        fixture='rift-map-set-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Map set checks: 42',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_primitive_bit_calls_transport_int_long_results_and_signed_rotation_distances_in_dex(self):
        fixture='rift-bit-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Bit checks: 21',self.texts(first))
                self.assertGreaterEqual(first['metrics']['bit_operations'],20)
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_guest_unsafe_executes_real_typed_atomic_field_and_array_operations(self):
        fixture='rift-unsafe-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Unsafe checks: 35',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_bulk_declared_and_inherited_fields_access_actual_dex_storage(self):
        fixture='rift-field-array-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Field array checks: 27',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_serializable_field_descriptions_preserve_types_signatures_and_offsets(self):
        fixture='rift-stream-field-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Stream field checks: 37',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_guest_thread_groups_enumerate_interrupt_inherit_and_run_suspendable_handlers(self):
        fixture='rift-group-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Group checks: 49',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_actual_throwable_and_thread_stacks_are_owned_and_native_frames_identified(self):
        fixture='rift-stack-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Stack checks: 40 / Native stack checks: 1',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_owned_class_initializers_wait_publish_once_and_keep_erroneous_state(self):
        fixture='rift-initialization-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Initialization checks: 25',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],1)
                self.assertGreaterEqual(first['metrics']['thread_switches'],8)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

    def test_guest_threads_wait_resume_with_distinct_jni_and_native_tls(self):
        fixture='rift-thread-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Thread checks: 32 / JNI thread checks: 7',self.texts(first))
                self.assertIn('Worker timer: pending',self.texts(first))
                self.assertEqual(first['metrics']['guest_threads'],2)
                self.assertGreaterEqual(first['metrics']['thread_switches'],20)
                time.sleep(.7)
                after=helpers.send(process,{'method':'tick'});self.assertTrue(after['ok'],after)
                self.assertIn('Worker timer: delivered',self.texts(after))
                self.assertEqual(after['metrics']['guest_threads'],1)
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first,after=after))

    def test_atomic_field_updaters_mutate_real_volatile_fields_and_report_vm_budgets(self):
        fixture='rift-concurrency-demo.apk'
        for abi in ['arm64-v8a','armeabi-v7a']:
            with self.subTest(abi=abi):
                process=self.spawn(fixture,abi);first=self.frame(process)
                self.assertIn('Atomic field checks: 27 / Runtime checks: 4 / Execution result: 1760',self.texts(first))
                self.close(process);RECORDS.append(dict(fixture=fixture,abi=abi,start=first))

if __name__=='__main__':
    if os.geteuid()!=0:raise SystemExit('The test harness requires root only to drop uid/gid for every worker.')
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(NativeAPIs)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if os.environ.get('RIFT_TEST_REPORT'):
        fixtures={r['fixture'] for r in RECORDS}
        pathlib.Path(os.environ['RIFT_TEST_REPORT']).write_text(json.dumps(dict(ok=result.wasSuccessful(),worker_sha256=hashlib.sha256(WORKER.read_bytes()).hexdigest(),fixtures={name:hashlib.sha256((SOURCE/'samples/built'/name).read_bytes()).hexdigest() for name in fixtures},records=RECORDS),indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
