import java.util.*;
public class SplitOracle {
  public static void main(String[] args) {
    String[] inputs={"a,,b,,",",a","abc","","\ud83d\ude00x"};String[] patterns={",","","(?=b)","."};
    for(String input:inputs)for(String regex:patterns)for(int limit:new int[]{0,-1,1,2}){
      String[] pieces=input.split(regex,limit);StringBuilder out=new StringBuilder();
      for(String piece:pieces){out.append('[');for(char c:piece.toCharArray())out.append(Integer.toHexString(c)).append(',');out.append(']');}
      System.out.println(input.length()+" / "+regex+" / "+limit+" -> "+pieces.length+" "+out);
    }
  }
}
