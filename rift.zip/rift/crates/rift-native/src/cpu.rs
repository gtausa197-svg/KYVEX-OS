use crate::{Result, memory::Memory};
use std::{
    cell::UnsafeCell,
    ffi::{CStr, c_char, c_void},
    ptr::NonNull,
};
#[derive(Clone, Debug)]
#[repr(C)]
pub struct State {
    pub regs: [u64; 32],
    pub vectors: [u64; 64],
    pub pc: u64,
    pub flags: u32,
    pub fp_control: u32,
    pub fp_status: u32,
    pub reason: u32,
    pub svc: u32,
    pub ticks: u64,
}
impl Default for State {
    fn default() -> Self {
        Self {
            regs: [0; 32],
            vectors: [0; 64],
            pc: 0,
            flags: 0,
            fp_control: 0,
            fp_status: 0,
            reason: 0,
            svc: 0,
            ticks: 0,
        }
    }
}
struct Context {
    memory: Memory,
    fault: Option<String>,
}
type Read = unsafe extern "C" fn(*mut c_void, u64, *mut u8, usize, u32) -> i32;
type Write = unsafe extern "C" fn(*mut c_void, u64, *const u8, usize) -> i32;
unsafe extern "C" {
    fn kv_cpu_set_thread_pointer(cpu: *mut c_void, address: u64);
    fn kv_dynarmic_abi() -> u32;
    fn kv_dynarmic_state_size() -> usize;
    fn kv_cpu_new(
        arch: u32,
        context: *mut c_void,
        read: Read,
        write: Write,
        cache: usize,
        error: *mut c_char,
        error_size: usize,
    ) -> *mut c_void;
    fn kv_cpu_run(
        cpu: *mut c_void,
        state: *mut State,
        budget: u64,
        step: u32,
        error: *mut c_char,
        error_size: usize,
    ) -> i32;
    fn kv_cpu_free(cpu: *mut c_void);
    fn kv_cpu_clear_cache(cpu: *mut c_void);
}
unsafe extern "C" fn read(
    context: *mut c_void,
    address: u64,
    out: *mut u8,
    n: usize,
    access: u32,
) -> i32 {
    if context.is_null() || out.is_null() || n > 16 || !matches!(access, 1 | 4) {
        return -1;
    }
    let c = unsafe { &mut *(*context.cast::<UnsafeCell<Context>>()).get() };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        c.memory.read(
            address,
            unsafe { std::slice::from_raw_parts_mut(out, n) },
            access as u8,
        )
    }));
    match result {
        Ok(Ok(())) => 0,
        Ok(Err(e)) => {
            c.fault = Some(e.to_string());
            -1
        }
        Err(_) => {
            c.fault = Some("Memory callback panic was contained".into());
            -1
        }
    }
}
unsafe extern "C" fn write(context: *mut c_void, address: u64, input: *const u8, n: usize) -> i32 {
    if context.is_null() || input.is_null() || n > 16 {
        return -1;
    }
    let c = unsafe { &mut *(*context.cast::<UnsafeCell<Context>>()).get() };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        c.memory
            .write(address, unsafe { std::slice::from_raw_parts(input, n) })
    }));
    match result {
        Ok(Ok(())) => 0,
        Ok(Err(e)) => {
            c.fault = Some(e.to_string());
            -1
        }
        Err(_) => {
            c.fault = Some("Memory callback panic was contained".into());
            -1
        }
    }
}
pub struct Cpu {
    handle: NonNull<c_void>,
    context: Box<UnsafeCell<Context>>,
    pub arch: u32,
}
impl Cpu {
    pub fn new(arch: u32, memory: Memory, cache: usize) -> Result<Self> {
        if !matches!(arch, 32 | 64) {
            return Err("Unsupported CPU architecture".into());
        }
        if unsafe { kv_dynarmic_abi() } != 1
            || unsafe { kv_dynarmic_state_size() } != std::mem::size_of::<State>()
        {
            return Err("Dynarmic adapter ABI/layout mismatch".into());
        }
        let mut context = Box::new(UnsafeCell::new(Context {
            memory,
            fault: None,
        }));
        let mut error = [0 as c_char; 256];
        let handle = NonNull::new(unsafe {
            kv_cpu_new(
                arch,
                (&mut *context as *mut UnsafeCell<Context>).cast(),
                read,
                write,
                cache,
                error.as_mut_ptr(),
                error.len(),
            )
        })
        .ok_or_else(|| {
            unsafe { CStr::from_ptr(error.as_ptr()) }
                .to_string_lossy()
                .into_owned()
        })?;
        Ok(Self {
            handle,
            context,
            arch,
        })
    }
    pub fn memory(&self) -> &Memory {
        unsafe { &(*self.context.get()).memory }
    }
    pub fn memory_mut(&mut self) -> &mut Memory {
        unsafe { &mut (*self.context.get()).memory }
    }
    pub fn clear_cache(&mut self) {
        unsafe { kv_cpu_clear_cache(self.handle.as_ptr()) }
    }
    pub fn set_thread_pointer(&mut self, address: u64) {
        unsafe { kv_cpu_set_thread_pointer(self.handle.as_ptr(), address) }
    }
    pub fn run(&mut self, state: &mut State, budget: u64, step: bool) -> Result<()> {
        unsafe { (*self.context.get()).fault = None };
        let mut error = [0 as c_char; 256];
        if unsafe {
            kv_cpu_run(
                self.handle.as_ptr(),
                state,
                budget,
                u32::from(step),
                error.as_mut_ptr(),
                error.len(),
            )
        } != 0
        {
            return Err(unsafe { CStr::from_ptr(error.as_ptr()) }
                .to_string_lossy()
                .into_owned()
                .into());
        }
        if let Some(fault) = unsafe { (*self.context.get()).fault.take() } {
            return Err(fault.into());
        }
        if state.reason == 4 {
            return Err(
                format!("Unsupported ARM instruction/exception at 0x{:x}", state.pc).into(),
            );
        }
        Ok(())
    }
}
impl Drop for Cpu {
    fn drop(&mut self) {
        unsafe { kv_cpu_free(self.handle.as_ptr()) }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use crate::memory::{EXEC, READ, WRITE};
    fn cpu(arch: u32, code: &[u8]) -> Cpu {
        let mut m = Memory::new(1024 * 1024);
        m.map(0x10000, 4096, READ | EXEC).unwrap();
        m.initialize(0x10000, code).unwrap();
        Cpu::new(arch, m, 8 * 1024 * 1024).unwrap()
    }
    #[test]
    fn arm64_executes_real_machine_instructions() {
        let code = [0xd28000c0u32, 0xd28000e1, 0x9b017c00, 0xd4000001];
        let mut c = cpu(
            64,
            &code
                .iter()
                .flat_map(|v| v.to_le_bytes())
                .collect::<Vec<_>>(),
        );
        let mut s = State {
            pc: 0x10000,
            ..Default::default()
        };
        c.run(&mut s, 100, false).unwrap();
        assert_eq!(s.regs[0], 42);
        assert_eq!(s.reason, 2);
        assert_eq!(s.pc, 0x10010);
    }
    #[test]
    fn arm32_and_thumb_execute_real_code() {
        let code = [0xe3a00006u32, 0xe3a01007, 0xe0000190, 0xef000000];
        let mut c = cpu(
            32,
            &code
                .iter()
                .flat_map(|v| v.to_le_bytes())
                .collect::<Vec<_>>(),
        );
        let mut s = State {
            pc: 0x10000,
            flags: 0x10,
            ..Default::default()
        };
        c.run(&mut s, 100, false).unwrap();
        assert_eq!(s.regs[0], 42);
        let mut c = cpu(32, &[6, 0x20, 7, 0x21, 0x48, 0x43, 0, 0xdf]);
        let mut s = State {
            pc: 0x10000,
            flags: 0x30,
            ..Default::default()
        };
        c.run(&mut s, 100, false).unwrap();
        assert_eq!(s.regs[0], 42);
    }
    #[test]
    fn arm32_thread_pointer_is_read_from_current_context_even_in_cached_code() {
        let code = [0xee1d1f70u32, 0xef000000];
        let bytes = code
            .iter()
            .flat_map(|v| v.to_le_bytes())
            .collect::<Vec<_>>();
        let mut cpu = cpu(32, &bytes);
        for pointer in [0x7000a000, 0x70011000, 0x7000a000] {
            cpu.set_thread_pointer(pointer);
            let mut state = State {
                pc: 0x10000,
                flags: 0x10,
                ..Default::default()
            };
            cpu.run(&mut state, 100, false).unwrap();
            assert_eq!(state.reason, 2);
            assert_eq!(state.regs[1], pointer);
        }
    }
    #[test]
    fn unsupported_arm32_coprocessors_return_guest_errors_without_aborting_host() {
        for instruction in [0xee1d1e70u32, 0xee101f10, 0xee0d1f70] {
            let bytes = [instruction, 0xef000000]
                .iter()
                .flat_map(|v| v.to_le_bytes())
                .collect::<Vec<_>>();
            let mut cpu = cpu(32, &bytes);
            let mut state = State {
                pc: 0x10000,
                flags: 0x10,
                ..Default::default()
            };
            assert!(
                cpu.run(&mut state, 100, false)
                    .unwrap_err()
                    .to_string()
                    .contains("Unsupported ARM")
            );
        }
    }
    #[test]
    fn endless_guest_is_bounded_and_non_executable_memory_faults() {
        let mut c = cpu(64, &0x14000000u32.to_le_bytes());
        let mut s = State {
            pc: 0x10000,
            ..Default::default()
        };
        c.run(&mut s, 500, false).unwrap();
        assert_eq!(s.reason, 1);
        assert!(s.ticks >= 500 && s.ticks < 5000);
        c.memory_mut().map(0x20000, 4096, READ | WRITE).unwrap();
        s.pc = 0x20000;
        assert!(c.run(&mut s, 20, false).is_err());
    }
    #[test]
    fn arm_guest_reads_and_writes_obey_page_permissions() {
        // mov w0,#42; str w0,[x1]; ldr w2,[x1]; svc #0
        let code = [0x52800540u32, 0xb9000020, 0xb9400022, 0xd4000001];
        let bytes = code
            .iter()
            .flat_map(|w| w.to_le_bytes())
            .collect::<Vec<_>>();
        let mut c = cpu(64, &bytes);
        c.memory_mut().map(0x20000, 4096, READ | WRITE).unwrap();
        let mut state = State {
            pc: 0x10000,
            ..Default::default()
        };
        state.regs[1] = 0x20000;
        c.run(&mut state, 100, false).unwrap();
        assert_eq!(state.regs[2], 42);
        assert_eq!(c.memory().bytes(0x20000, 4).unwrap(), 42u32.to_le_bytes());
        c.memory_mut().protect(0x20000, 4096, READ).unwrap();
        state.pc = 0x10000;
        assert!(c.run(&mut state, 100, false).is_err());
    }
}
