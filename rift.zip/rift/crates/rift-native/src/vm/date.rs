//! java.util.Date's signed epoch-millisecond state.
use super::*;
use std::cmp::Ordering;

pub(super) const DATE: &str = "Ljava/util/Date;";

impl Runtime {
    fn date_millis(&self, id: u32) -> Result<i64> {
        match self.object(id)?.payload {
            Payload::Date(time) => Ok(time),
            _ => Err(fault(
                "Ljava/lang/ClassCastException;",
                "Expected java.util.Date",
            )),
        }
    }

    fn virtual_date_millis(&mut self, id: u32) -> Result<i64> {
        Ok(self.collection_dispatch(id, DATE, "getTime()J", &[])? as i64)
    }

    pub(super) fn date_api(&mut self, signature: &str, args: &[u32]) -> Result<Option<u64>> {
        let Some(&id) = args.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        let (class, method) = signature.split_once("->").ok_or("Date signature")?;
        let arg = |i: usize| args.get(i).copied().ok_or("Date argument count");
        let millis =
            || -> Result<i64> { Ok((u64::from(arg(1)?) | (u64::from(arg(2)?) << 32)) as i64) };
        if class == DATE && matches!(method, "<init>()V" | "<init>(J)V") {
            if !self.subclass(&object.class, DATE)? {
                return Err("Expected Date constructor receiver".into());
            }
            let time = if method == "<init>()V" {
                self.hle("Ljava/lang/System;->currentTimeMillis()J", &[])? as i64
            } else {
                millis()?
            };
            self.object_mut(id)?.payload = Payload::Date(time);
            return Ok(Some(0));
        }
        let Payload::Date(time) = object.payload else {
            return Ok(None);
        };
        let result = match method {
            "getTime()J" => time as u64,
            "setTime(J)V" => {
                self.object_mut(id)?.payload = Payload::Date(millis()?);
                0
            }
            "before(Ljava/util/Date;)Z" => (time < self.date_millis(arg(1)?)?) as u64,
            "after(Ljava/util/Date;)Z" => (time > self.date_millis(arg(1)?)?) as u64,
            "compareTo(Ljava/util/Date;)I" | "compareTo(Ljava/lang/Object;)I" => {
                match time.cmp(&self.date_millis(arg(1)?)?) {
                    Ordering::Less => u32::MAX as u64,
                    Ordering::Equal => 0,
                    Ordering::Greater => 1,
                }
            }
            "equals(Ljava/lang/Object;)Z" => {
                let other = arg(1)?;
                if other == 0 || !matches!(self.object(other)?.payload, Payload::Date(_)) {
                    0
                } else {
                    let _roots = self.scoped_library_roots(&[id, other])?;
                    (self.virtual_date_millis(id)? == self.virtual_date_millis(other)?) as u64
                }
            }
            "hashCode()I" => {
                let millis = self.virtual_date_millis(id)? as u64;
                (millis as u32 ^ (millis >> 32) as u32) as u64
            }
            "clone()Ljava/lang/Object;" => {
                let class = object.class.clone();
                let fields = object.fields.clone();
                let copy = self.allocate(&class, Payload::Date(time))?;
                self.object_mut(copy)?.fields = fields;
                copy as u64
            }
            _ => return Ok(None),
        };
        Ok(Some(result))
    }
}
