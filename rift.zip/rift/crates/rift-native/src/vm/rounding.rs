//! Stable Java rounding mode values shared by Java and ICU-backed formatters.
use super::*;

pub(super) const CLASS: &str = "Ljava/math/RoundingMode;";
const NAMES: [&str; 8] = [
    "UP",
    "DOWN",
    "CEILING",
    "FLOOR",
    "HALF_UP",
    "HALF_DOWN",
    "HALF_EVEN",
    "UNNECESSARY",
];

fn unknown_mode() -> Box<dyn std::error::Error + Send + Sync> {
    fault(
        "Ljava/lang/IllegalArgumentException;",
        "Unknown RoundingMode",
    )
}

impl Runtime {
    pub(super) fn rounding_mode(&mut self, index: u32) -> Result<u32> {
        let name = NAMES.get(index as usize).ok_or_else(unknown_mode)?;
        let cached = self.rounding_modes[index as usize];
        if cached != 0 {
            return Ok(cached);
        }
        let name = self.literal(name.encode_utf16().collect())?;
        let id = self.allocate(
            CLASS,
            Payload::Enum {
                name,
                ordinal: index,
            },
        )?;
        self.rounding_modes[index as usize] = id;
        Ok(id)
    }

    pub(super) fn named_rounding_mode(&mut self, name: &[u16]) -> Result<u32> {
        let index = NAMES
            .iter()
            .position(|mode| mode.encode_utf16().eq(name.iter().copied()))
            .ok_or_else(unknown_mode)?;
        self.rounding_mode(index as u32)
    }

    pub(super) fn rounding_ordinal(&self, id: u32) -> Result<i32> {
        match self.object(id)? {
            Object {
                class,
                payload: Payload::Enum { ordinal, .. },
                ..
            } if class == CLASS => Ok(*ordinal as i32),
            _ => Err(fault(
                "Ljava/lang/ClassCastException;",
                "Expected RoundingMode",
            )),
        }
    }

    pub(super) fn rounding_api(&mut self, signature: &str, args: &[u32]) -> Result<Option<u64>> {
        let arg = |index: usize| args.get(index).copied().ok_or("RoundingMode argument");
        if signature
            == "Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;"
            && matches!(&self.object(arg(0)?)?.payload, Payload::Class(class) if class == CLASS)
        {
            return Ok(Some(u64::from(
                self.named_rounding_mode(&self.units(arg(1)?)?)?,
            )));
        }
        let Some(method) = signature.strip_prefix("Ljava/math/RoundingMode;->") else {
            return Ok(None);
        };
        let value = match method {
            "valueOf(I)Ljava/math/RoundingMode;" => u64::from(self.rounding_mode(arg(0)?)?),
            "valueOf(Ljava/lang/String;)Ljava/math/RoundingMode;" => {
                u64::from(self.named_rounding_mode(&self.units(arg(0)?)?)?)
            }
            "values()[Ljava/math/RoundingMode;" => {
                let mut values = Vec::with_capacity(NAMES.len());
                for ordinal in 0..NAMES.len() as u32 {
                    values.push(u64::from(self.rounding_mode(ordinal)?));
                }
                u64::from(self.allocate("[Ljava/math/RoundingMode;", Payload::Array(values))?)
            }
            _ => return self.lang_api(&format!("Ljava/lang/Enum;->{method}"), args),
        };
        Ok(Some(value))
    }
}
