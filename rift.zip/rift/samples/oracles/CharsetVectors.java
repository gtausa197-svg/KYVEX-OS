import java.nio.charset.*;
import java.util.*;
/** Emits independent stock-Java vectors; no runtime-specific test oracle. */
public final class CharsetVectors {
 static String bytes(byte[] value){StringBuilder text=new StringBuilder();for(byte b:value)text.append(String.format("%02x",b&255));return text.toString();}
 static String units(String value){StringBuilder text=new StringBuilder();for(int i=0;i<value.length();i++)text.append(String.format("%04x",(int)value.charAt(i)));return text.toString();}
 public static void main(String[] args){
  Charset[] charsets={StandardCharsets.UTF_8,StandardCharsets.ISO_8859_1,StandardCharsets.US_ASCII,StandardCharsets.UTF_16BE,StandardCharsets.UTF_16LE,StandardCharsets.UTF_16};
  Random random=new Random(0x4b59564558L);boolean comma=false;
  System.out.println("[");
  for(Charset charset:charsets){for(int i=0;i<160;i++){
   char[] chars=new char[i%31];for(int j=0;j<chars.length;j++)chars[j]=(char)random.nextInt(65536);
   byte[] data=new byte[i%37];random.nextBytes(data);
   if(i==0){chars=new char[]{0,65,0x7f,0x80,0xff,0x100,0x20ac,0xd83d,0xde00,0xd800,65,0xdc00};data=new byte[]{(byte)0xfe,(byte)0xff,(byte)0xd8,0,0,65,0,66,0};}
   if(i==1)data=new byte[]{(byte)0xff,(byte)0xfe,65,0,0,(byte)0xd8,66,0,0};
   if(i==2)data=new byte[]{(byte)0xd8,0,0};
   String source=new String(chars);
   if(comma)System.out.println(",");comma=true;
   System.out.print("{\"name\":\""+charset.name()+"\",\"units\":\""+units(source)+"\",\"encoded\":\""+bytes(source.getBytes(charset))+"\",\"bytes\":\""+bytes(data)+"\",\"decoded\":\""+units(new String(data,charset))+"\"}");
  }}
  System.out.println("\n]");
 }
}
