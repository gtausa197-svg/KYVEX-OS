//! Read-only loader diagnostics; never executes guest code.
use rift_native::{Result, package::Package};
fn main() -> Result<()> {
    let a = std::env::args().skip(1).collect::<Vec<_>>();
    if a.len() != 2 {
        return Err("Usage: class-info APK Lpackage/Class;".into());
    }
    let mut p = Package::open(std::path::Path::new(&a[0]), "auto")?;
    let mut dex = p.dex;
    if !dex.classes.keys().any(|i| dex.ty(*i) == a[1])
        && let Some(next) = p.libraries.dex_for_class(&a[1])?
    {
        dex = next;
    }
    let class = dex.classes.iter().find(|(i, _)| dex.ty(**i) == a[1]);
    let Some((_, class)) = class else {
        return Err("No class definition".into());
    };
    println!("parent={:?}", class.parent.map(|i| dex.ty(i)));
    for (i, m) in dex
        .methods
        .iter()
        .enumerate()
        .filter(|(_, m)| dex.ty(m.class) == a[1])
    {
        println!(
            "index={i} signature={} name={:?} body={:?}",
            dex.signature(i),
            dex.strings[m.name],
            dex.bodies
                .get(&i)
                .map(|b| (b.access, b.registers, b.incoming, b.code.len()))
        );
    }
    Ok(())
}
