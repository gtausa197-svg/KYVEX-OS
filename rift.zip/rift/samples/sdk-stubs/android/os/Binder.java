package android.os;

/** Signatures used to compile fixtures. The class is excluded from the APK. */
public class Binder implements IBinder {
    public Binder() {}
    public native void attachInterface(IInterface owner, String descriptor);
    public native String getInterfaceDescriptor();
    public native IInterface queryLocalInterface(String descriptor);
    public native boolean pingBinder();
    public native boolean isBinderAlive();
}
