//! Legacy Bionic FILE exports and virtual standard streams.
use super::c_format::{Arguments, call_word, read_word};
use super::*;

const BASE: u64 = 0x7000b000;
const PAGE: u64 = 4096;
const POINTERS: u64 = BASE + 512;
const F_EOF: u32 = 0x20;
const F_ERROR: u32 = 0x40;
const EOF: u64 = u64::MAX;
const CONSOLE_LIMIT: usize = 65536;
const FORMAT_LIMIT: usize = 16384;
type IoResult<T> = std::result::Result<T, i32>;

struct FileLayout {
    stride: u64,
    width: usize,
    flag_width: usize,
}

impl FileLayout {
    fn new(arch: u32) -> Self {
        if arch == 64 {
            Self {
                stride: 152,
                width: 8,
                flag_width: 4,
            }
        } else {
            Self {
                stride: 84,
                width: 4,
                flag_width: 2,
            }
        }
    }

    fn file(&self, fd: u64) -> u64 {
        BASE + fd * self.stride
    }

    fn flags(&self, fd: u64) -> u64 {
        self.file(fd) + self.width as u64 + 8
    }

    fn pointer(&self, fd: u64) -> u64 {
        POINTERS + fd * self.width as u64
    }

    fn descriptor(&self, file: u64) -> Option<u64> {
        (0..3).find(|&fd| self.file(fd) == file)
    }
}

pub(super) fn initialize(
    memory: &mut Memory,
    arch: u32,
    exports: &mut BTreeMap<String, u64>,
) -> Result<()> {
    memory.map(BASE, PAGE as usize, READ | WRITE)?;
    let layout = FileLayout::new(arch);
    exports.insert("__sF".into(), BASE);
    for (fd, (name, flags)) in [("stdin", 4u32), ("stdout", 8), ("stderr", 10)]
        .into_iter()
        .enumerate()
    {
        let fd = fd as u64;
        memory.initialize(layout.flags(fd), &flags.to_le_bytes()[..layout.flag_width])?;
        memory.initialize(
            layout.flags(fd) + layout.flag_width as u64,
            &fd.to_le_bytes()[..layout.flag_width],
        )?;
        memory.initialize(
            layout.pointer(fd),
            &layout.file(fd).to_le_bytes()[..layout.width],
        )?;
        exports.insert(name.into(), layout.pointer(fd));
    }
    Ok(())
}

pub(super) fn overlaps(address: u64, length: u64) -> bool {
    length != 0 && address < BASE + PAGE && address.saturating_add(length) > BASE
}

impl Machine {
    pub(super) fn queue_native_log(&mut self, message: String) {
        if self.pending_logs.len() >= 16 {
            self.pending_logs.remove(0);
        }
        self.pending_logs.push(message);
    }

    fn console_check(&self, fd: u64, len: u64) -> IoResult<()> {
        if !matches!(fd, 1 | 2) {
            return Err(libc::EBADF);
        }
        if len > (CONSOLE_LIMIT - self.stdout.len().min(CONSOLE_LIMIT)) as u64 {
            return Err(libc::EFBIG);
        }
        Ok(())
    }

    fn console_flush(&mut self, fd: u64) {
        let index = fd as usize - 1;
        if self.console_lines[index].is_empty() {
            return;
        }
        let text = String::from_utf8_lossy(&self.console_lines[index]);
        let name = if fd == 1 { "stdout" } else { "stderr" };
        let message = format!("{name}: {}", text.trim_end_matches('\r'));
        self.console_lines[index].clear();
        self.queue_native_log(message);
    }

    fn console_write(&mut self, fd: u64, bytes: &[u8]) -> IoResult<()> {
        self.console_check(fd, bytes.len() as u64)?;
        self.stdout.extend_from_slice(bytes);
        for part in bytes.split_inclusive(|&byte| byte == b'\n') {
            let newline = part.last() == Some(&b'\n');
            let part = if newline {
                &part[..part.len() - 1]
            } else {
                part
            };
            let line = &mut self.console_lines[fd as usize - 1];
            line.extend_from_slice(&part[..part.len().min(512 - line.len())]);
            if newline {
                self.console_flush(fd);
            }
        }
        Ok(())
    }

    pub(super) fn console_write_guest(&mut self, fd: u64, address: u64, len: u64) -> IoResult<()> {
        self.console_check(fd, len)?;
        let bytes = self
            .cpu
            .memory()
            .bytes(address, len as usize)
            .map_err(|_| libc::EFAULT)?;
        self.console_write(fd, &bytes)
    }

    fn file_flags(&self, layout: &FileLayout, fd: u64) -> Result<u32> {
        Ok(read_word(self.cpu.memory(), layout.flags(fd), layout.flag_width)? as u32)
    }

    fn change_flags(&mut self, layout: &FileLayout, fd: u64, clear: u32, set: u32) -> Result<()> {
        let flags = (self.file_flags(layout, fd)? & !clear) | set;
        self.cpu
            .memory_mut()
            .write(layout.flags(fd), &flags.to_le_bytes()[..layout.flag_width])
    }

    fn stdio_result(
        &mut self,
        layout: &FileLayout,
        fd: Option<u64>,
        result: IoResult<u64>,
        failure: u64,
    ) -> Result<u64> {
        match result {
            Ok(value) => Ok(value),
            Err(errno) => {
                self.set_guest_errno(errno)?;
                if let Some(fd) = fd {
                    self.change_flags(layout, fd, 0, F_ERROR)?;
                }
                Ok(failure)
            }
        }
    }

    fn element_bytes(&self, size: u64, count: u64) -> IoResult<u64> {
        size.checked_mul(count)
            .filter(|&bytes| self.arch == 64 || u32::try_from(bytes).is_ok())
            .ok_or(libc::EOVERFLOW)
    }

    pub(super) fn stdio_call(&mut self, function: &str, state: &State) -> Result<u64> {
        let [first, second, third, fourth, ..] = state.regs;
        let layout = FileLayout::new(self.arch);
        let file = match function {
            "fwrite" | "fread" => fourth,
            "fputc" | "fputs" => second,
            "putchar" | "puts" => read_word(self.cpu.memory(), layout.pointer(1), layout.width)?,
            "getchar" => read_word(self.cpu.memory(), layout.pointer(0), layout.width)?,
            _ => first,
        };
        if matches!(function, "fwrite" | "fread") && (second == 0 || third == 0) {
            return Ok(0);
        }
        if function == "fflush" && file == 0 {
            self.console_flush(1);
            self.console_flush(2);
            return Ok(0);
        }
        let failure = if matches!(function, "fwrite" | "fread") {
            0
        } else {
            EOF
        };
        let Some(fd) = layout.descriptor(file) else {
            return self.stdio_result(&layout, None, Err(libc::EBADF), failure);
        };
        let result = match function {
            "fflush" => {
                if fd != 0 {
                    self.console_flush(fd);
                }
                Ok(0)
            }
            "fileno" => Ok(fd),
            "feof" => Ok(u64::from(self.file_flags(&layout, fd)? & F_EOF != 0)),
            "ferror" => Ok(u64::from(self.file_flags(&layout, fd)? & F_ERROR != 0)),
            "clearerr" => {
                self.change_flags(&layout, fd, F_EOF | F_ERROR, 0)?;
                Ok(0)
            }
            "fread" if self.element_bytes(second, third).is_err() => Err(libc::EOVERFLOW),
            "fread" | "fgetc" | "getchar" if fd == 0 => {
                // The guest console has no input source. The host input is the worker protocol.
                self.change_flags(&layout, fd, 0, F_EOF)?;
                Ok(failure)
            }
            "fread" | "fgetc" | "getchar" => Err(libc::EBADF),
            "fwrite" => self
                .element_bytes(second, third)
                .and_then(|len| self.console_write_guest(fd, first, len))
                .map(|()| third),
            "fputc" | "putchar" => self
                .console_write(fd, &[first as u8])
                .map(|()| u64::from(first as u8)),
            "fputs" | "puts" => self
                .cbytes(first, FORMAT_LIMIT)
                .map_err(|_| libc::EFAULT)
                .and_then(|mut bytes| {
                    if function == "puts" {
                        bytes.push(b'\n');
                    }
                    self.console_write(fd, &bytes)
                })
                .map(|()| 0),
            "fprintf" | "vfprintf" => {
                let output = if function == "vfprintf" {
                    Arguments::list(self, third)
                        .and_then(|args| self.format_c(second, args, FORMAT_LIMIT, false))
                } else {
                    self.format_c(second, Arguments::call(self, state, 2), FORMAT_LIMIT, false)
                };
                output
                    .map_err(|_| libc::EINVAL)
                    .and_then(|bytes| self.console_write(fd, &bytes).map(|()| bytes.len() as u64))
            }
            _ => return Err("Unknown standard stream operation".into()),
        };
        self.stdio_result(&layout, Some(fd), result, failure)
    }

    pub(super) fn stdio_format_buffer(&mut self, function: &str, state: &State) -> Result<u64> {
        let [dest, size, third, fourth, ..] = state.regs;
        let (cap, format_slot) = match function {
            "snprintf" | "vsnprintf" => (size, 2),
            "__vsprintf_chk" => (third, 3),
            "__vsnprintf_chk" if size <= fourth => (size, 4),
            "__vsnprintf_chk" => return Err("Guest __vsnprintf_chk buffer bound exceeded".into()),
            _ => return Err("Unknown C buffer formatter".into()),
        };
        let format = call_word(self, state, format_slot)?;
        let args = if function == "snprintf" {
            Ok(Arguments::call(self, state, format_slot + 1))
        } else {
            call_word(self, state, format_slot + 1)
                .and_then(|address| Arguments::list(self, address))
        };
        let Ok(mut output) = args.and_then(|args| self.format_c(format, args, FORMAT_LIMIT, false))
        else {
            self.set_guest_errno(libc::EINVAL)?;
            return Ok(EOF);
        };
        let len = output.len() as u64;
        if function == "__vsprintf_chk" && len >= cap {
            return Err("Guest __vsprintf_chk buffer bound exceeded".into());
        }
        if cap != 0 {
            output.truncate(len.min(cap - 1) as usize);
            output.push(0);
            if self.cpu.memory_mut().write(dest, &output).is_err() {
                self.set_guest_errno(libc::EFAULT)?;
                return Ok(EOF);
            }
        }
        Ok(len)
    }

    pub(super) fn stdio_format_alloc(&mut self, function: &str, state: &State) -> Result<u64> {
        let [dest, format, list, ..] = state.regs;
        let args = if function == "vasprintf" {
            Arguments::list(self, list)
        } else {
            Ok(Arguments::call(self, state, 2))
        };
        let formatted = args.and_then(|args| self.format_c(format, args, FORMAT_LIMIT, false));
        let width = (self.arch / 8) as usize;
        if self.cpu.memory_mut().write(dest, &[0; 8][..width]).is_err() {
            self.set_guest_errno(libc::EFAULT)?;
            return Ok(EOF);
        }
        let Ok(mut output) = formatted else {
            self.set_guest_errno(libc::EINVAL)?;
            return Ok(EOF);
        };
        let len = output.len();
        output.push(0);
        let mut arguments = [0; 32];
        arguments[0] = output.len() as u64;
        let address = self.heap_call("malloc", &arguments)?;
        if address == 0 {
            return Ok(EOF);
        }
        let memory = self.cpu.memory_mut();
        if memory.write(address, &output).is_err()
            || memory.write(dest, &address.to_le_bytes()[..width]).is_err()
        {
            arguments[0] = address;
            self.heap_call("free", &arguments)?;
            self.set_guest_errno(libc::EFAULT)?;
            return Ok(EOF);
        }
        Ok(len as u64)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fortified_format_overflow_leaves_guest_buffer_intact() {
        let mut machine = Machine::new(64, 32, 8).unwrap();
        let dest = STACK_TOP - 128;
        let format = dest + 16;
        let list = dest + 32;
        let memory = machine.cpu.memory_mut();
        memory.write(dest, b"keep").unwrap();
        memory.write(format, b"longer\0").unwrap();
        memory.fill(list, 32, 0).unwrap();
        let mut state = State::default();
        state.regs[..5].copy_from_slice(&[dest, 0, 4, format, list]);
        let result = machine.stdio_format_buffer("__vsprintf_chk", &state);
        assert!(
            result
                .unwrap_err()
                .to_string()
                .contains("buffer bound exceeded")
        );
        state.regs[..6].copy_from_slice(&[dest, 8, 0, 4, format, list]);
        let result = machine.stdio_format_buffer("__vsnprintf_chk", &state);
        assert!(
            result
                .unwrap_err()
                .to_string()
                .contains("buffer bound exceeded")
        );
        assert_eq!(machine.cpu.memory().bytes(dest, 4).unwrap(), b"keep");
    }
}
