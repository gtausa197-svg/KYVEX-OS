package android.os;
public class Handler {
    public interface Callback {boolean handleMessage(Message message);}
    public Handler(){}
    public Handler(Looper looper,Callback callback){}
    public void handleMessage(Message message){}
    public void dispatchMessage(Message message){}
    public boolean post(Runnable task){return false;}
    public boolean postDelayed(Runnable task,long delay){return false;}
    public boolean postAtFrontOfQueue(Runnable task){return false;}
    public void removeCallbacks(Runnable task){}
    public void removeMessages(int what){}
    public Message obtainMessage(int what,int arg1,int arg2,Object object){return null;}
    public boolean sendMessage(Message message){return false;}
    public boolean sendMessageAtTime(Message message,long uptimeMillis){return false;}
    public boolean sendEmptyMessage(int what){return false;}
}
