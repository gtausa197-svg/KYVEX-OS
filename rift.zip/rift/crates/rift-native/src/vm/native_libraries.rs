//! Constructors belong to ELF dependencies. JNI_OnLoad belongs to Java's load request.
use super::*;

pub(super) enum Status {
    Constructing,
    Constructed,
    LoadingJni,
    Ready,
    Failed(String),
}

impl Status {
    pub(super) fn bytes(&self) -> usize {
        match self {
            Self::Failed(detail) => detail.capacity(),
            _ => 0,
        }
    }
}

impl Runtime {
    pub(super) fn advance_native(&mut self, state: &mut crate::cpu::State) -> Result<Trap> {
        let result = self.machine.advance(state);
        self.flush_native_logs();
        result
    }

    pub(super) fn flush_native_logs(&mut self) {
        for entry in std::mem::take(&mut self.machine.pending_logs) {
            self.append_guest_log(entry);
        }
    }

    fn store_native_status(
        &mut self,
        name: &str,
        result: Result<()>,
        success: Status,
    ) -> Result<()> {
        let status = match &result {
            Ok(()) => success,
            Err(error) => {
                let detail = error.to_string().chars().take(1024).collect::<String>();
                self.trace_native_load_failure(name, &detail);
                Status::Failed(detail)
            }
        };
        self.library_status.insert(name.to_owned(), status);
        result
    }

    fn construct_native_library(&mut self, name: &str) -> Result<()> {
        match self.library_status.get(name) {
            Some(Status::Constructed | Status::LoadingJni | Status::Ready) => return Ok(()),
            Some(Status::Failed(detail)) => return Err(detail.clone().into()),
            Some(Status::Constructing) => return Err("Recursive ELF initialization".into()),
            None => {}
        }
        if self.library_status.len() >= 512 {
            return Err("Native library load count quota".into());
        }
        let image = self
            .machine
            .images
            .get(name)
            .ok_or("ELF image not linked")?;
        let constructors = image.constructors.clone();
        let dependencies = image.needed.clone();
        self.library_status
            .insert(name.to_owned(), Status::Constructing);
        let result = (|| {
            for dependency in dependencies {
                if !self.machine.is_platform_dependency(&dependency) {
                    self.construct_native_library(&dependency)?;
                }
            }
            for address in constructors {
                let mut state = self.machine.prepare(address, &[])?;
                if !matches!(self.advance_native(&mut state)?, Trap::Returned(_)) {
                    return Err("Unsupported native library initializer".into());
                }
            }
            Ok(())
        })()
        .map_err(|error: Box<dyn std::error::Error + Send + Sync>| {
            format!("{name}: {error}").into()
        });
        self.store_native_status(name, result, Status::Constructed)
    }

    pub(super) fn load_library_file(&mut self, name: &str) -> Result<()> {
        if !crate::elf::valid_library_name(name) {
            return Err("Invalid APK native library filename".into());
        }
        match self.library_status.get(name) {
            Some(Status::Ready) => return Ok(()),
            Some(Status::Failed(detail)) => return Err(detail.clone().into()),
            Some(Status::Constructing | Status::LoadingJni) => {
                return Err("Recursive native library load".into());
            }
            Some(Status::Constructed) => {}
            None => {
                if self.library_status.len() >= 512 {
                    return Err("Native library load count quota".into());
                }
                let libraries = &mut self.libraries;
                if let Err(error) = self
                    .machine
                    .load_apk_library(name, |dependency| libraries.library(dependency))
                {
                    return self.store_native_status(name, Err(error), Status::Constructed);
                }
                self.construct_native_library(name)?;
            }
        }

        if let Some(&address) = self.machine.images[name].exports.get("JNI_OnLoad") {
            let old_registrations = self.registered.clone();
            let old_exception = self.pending_jni_exception;
            let _roots = self.scoped_library_roots(&[old_exception])?;
            self.library_status
                .insert(name.to_owned(), Status::LoadingJni);
            self.pending_jni_exception = 0;
            let result = self
                .native_bridge(address, &[JAVA_VM, 0])
                .and_then(|version| {
                    let version = version as u32;
                    if matches!(version, 0x10002 | 0x10004 | 0x10006 | 0x10008) {
                        Ok(())
                    } else {
                        Err(format!(
                            "{name}: JNI_OnLoad returned unsupported JNI version 0x{version:x}"
                        )
                        .into())
                    }
                });
            self.pending_jni_exception = old_exception;
            if result.is_err() {
                self.registered = old_registrations;
            }
            return self.store_native_status(name, result, Status::Ready);
        }
        self.store_native_status(name, Ok(()), Status::Ready)
    }

    pub(super) fn native_export(&self, name: &str) -> Result<u64> {
        self.library_status
            .iter()
            .filter(|(_, status)| matches!(status, Status::Ready | Status::LoadingJni))
            .find_map(|(library, _)| self.machine.apk_symbol(library, name))
            .ok_or_else(|| format!("Native JNI symbol is unavailable: {name}").into())
    }
}
