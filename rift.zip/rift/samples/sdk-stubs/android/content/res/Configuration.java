package android.content.res;
public class Configuration {
 public float fontScale;
 public java.util.Locale locale;
 public int orientation,screenLayout,screenWidthDp,screenHeightDp,smallestScreenWidthDp,densityDpi,uiMode;
 public int getLayoutDirection(){return 0;}
}
