//! Java array copies with their real runtime component types.
use super::*;

const OBJECT_ARRAY: &str = "[Ljava/lang/Object;";

fn reference_array(class: &str) -> bool {
    class.starts_with("[L") || class.starts_with("[[")
}

fn copy_range(start: u32, count: u32, len: usize) -> Result<std::ops::Range<usize>> {
    let start = start as usize;
    let end = start
        .checked_add(count as usize)
        .filter(|&end| end <= len)
        .ok_or_else(|| {
            fault(
                "Ljava/lang/ArrayIndexOutOfBoundsException;",
                "System.arraycopy range",
            )
        })?;
    Ok(start..end)
}

impl Runtime {
    fn system_arraycopy(&mut self, args: &[u32]) -> Result<()> {
        let [source_id, source_pos, target_id, target_pos, count] = *args else {
            return Err("System.arraycopy argument count".into());
        };
        let source = self.object(source_id)?;
        let target = self.object(target_id)?;
        let (Payload::Array(source_values), Payload::Array(target_values)) =
            (&source.payload, &target.payload)
        else {
            return Err(fault(
                "Ljava/lang/ArrayStoreException;",
                "System.arraycopy requires arrays",
            ));
        };
        let references = reference_array(&source.class) && reference_array(&target.class);
        if !references && source.class != target.class {
            return Err(fault(
                "Ljava/lang/ArrayStoreException;",
                "System.arraycopy primitive component mismatch",
            ));
        }
        let source_range = copy_range(source_pos, count, source_values.len())?;
        let target_range = copy_range(target_pos, count, target_values.len())?;
        if source_id == target_id {
            let Payload::Array(values) = &mut self.object_mut(target_id)?.payload else {
                unreachable!()
            };
            values.copy_within(source_range, target_range.start);
            return Ok(());
        }

        let mut copied = source_values[source_range].to_vec();
        if references && !self.class_assignable(&target.class, &source.class)? {
            let component = &target.class[1..];
            for (index, &value) in copied.iter().enumerate() {
                if value != 0
                    && !self.class_assignable(component, &self.object(value as u32)?.class)?
                {
                    copied.truncate(index);
                    break;
                }
            }
        }
        let Payload::Array(values) = &mut self.object_mut(target_id)?.payload else {
            unreachable!()
        };
        values[target_range.start..target_range.start + copied.len()].copy_from_slice(&copied);
        if copied.len() != count as usize {
            return Err(fault(
                "Ljava/lang/ArrayStoreException;",
                "System.arraycopy incompatible element",
            ));
        }
        Ok(())
    }

    fn object_array_values(&self, id: u32) -> Result<&[u64]> {
        let array = self.object(id)?;
        if reference_array(&array.class)
            && let Payload::Array(values) = &array.payload
        {
            return Ok(values);
        }
        Err(fault("Ljava/lang/ClassCastException;", "Expected Object[]"))
    }

    fn object_array_hash(&mut self, id: u32) -> Result<u32> {
        if id == 0 {
            return Ok(0);
        }
        let length = self.object_array_values(id)?.len();
        let _array_root = self.scoped_library_roots(&[id])?;
        let mut hash = 1u32;
        for index in 0..length {
            // A hashCode override may mutate the array before the next read.
            let element = *self
                .object_array_values(id)?
                .get(index)
                .ok_or("Object array changed length while hashing")?
                as u32;
            let _element_root = self.scoped_library_roots(&[element])?;
            hash = hash
                .wrapping_mul(31)
                .wrapping_add(self.java_key_hash(element)?);
        }
        Ok(hash)
    }

    pub(super) fn arrays_api(&mut self, sig: &str, args: &[u32]) -> Result<Option<u64>> {
        if sig == "Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V" {
            self.system_arraycopy(args)?;
            return Ok(Some(0));
        }
        let Some(method) = sig.strip_prefix("Ljava/util/Arrays;->") else {
            return Ok(None);
        };
        if method == "hashCode([Ljava/lang/Object;)I" {
            let [id] = args else {
                return Err("Object array hash argument count".into());
            };
            return self
                .object_array_hash(*id)
                .map(|hash| Some(u64::from(hash)));
        }
        if method == "fill([CC)V" {
            let [id, value] = args else {
                return Err("Char array fill argument count".into());
            };
            let array = self.object_mut(*id)?;
            if array.class != "[C" {
                return Err("Char array fill requires char[]".into());
            }
            let Payload::Array(values) = &mut array.payload else {
                return Err("Invalid char array payload".into());
            };
            values.fill(u64::from(*value as u16));
            return Ok(Some(0));
        }
        let Some((name, prototype)) = method.split_once('(') else {
            return Ok(None);
        };
        let range = match name {
            "copyOf" => false,
            "copyOfRange" => true,
            _ => return Ok(None),
        };
        let (params, result) = prototype.split_once(')').ok_or("Array copy descriptor")?;
        let reference = result == OBJECT_ARRAY;
        if !reference
            && !matches!(
                result,
                "[Z" | "[B" | "[C" | "[S" | "[I" | "[J" | "[F" | "[D"
            )
        {
            return Ok(None);
        }
        let Some(tail) = params.strip_prefix(result) else {
            return Ok(None);
        };
        let ints = if range { "II" } else { "I" };
        let typed = match tail.strip_prefix(ints) {
            Some("") => false,
            Some("Ljava/lang/Class;") if reference => true,
            _ => return Ok(None),
        };
        let arg = |i: usize| args.get(i).copied().ok_or("Array copy argument count");
        let original = arg(0)?;
        let from = if range { arg(1)? as i32 } else { 0 };
        let length = (arg(if range { 2 } else { 1 })? as i32).wrapping_sub(from);
        let source_type = if reference && !typed {
            Some(self.object(original)?.class.clone())
        } else {
            None
        };
        if range && length < 0 {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Reversed array copy range",
            ));
        }
        let target = if typed {
            let Payload::Class(target) = &self.object(arg(if range { 3 } else { 2 })?)?.payload
            else {
                return Err("Array copy requires a target Class".into());
            };
            if !target.starts_with('[') {
                return Err(fault(
                    "Ljava/lang/NullPointerException;",
                    "Target Class has no array component",
                ));
            }
            if !reference_array(target) {
                return Err(fault(
                    "Ljava/lang/ClassCastException;",
                    "Target must be a reference array",
                ));
            }
            target.clone()
        } else {
            source_type.unwrap_or_else(|| result.to_owned())
        };
        if length < 0 {
            return Err(fault(
                "Ljava/lang/NegativeArraySizeException;",
                "Negative array copy length",
            ));
        }
        let length = length as usize;
        if length > MAX_ARRAY_ELEMENTS {
            return Err("Java array quota".into());
        }
        let source = self.object(original)?;
        let Payload::Array(values) = &source.payload else {
            return Err(fault(
                "Ljava/lang/ArrayStoreException;",
                "Expected an array source",
            ));
        };
        if reference && !reference_array(&source.class) || !reference && source.class != result {
            return Err(fault(
                "Ljava/lang/ArrayStoreException;",
                "Incompatible array copy source",
            ));
        }
        let slice = usize::try_from(from)
            .ok()
            .and_then(|start| values.get(start..))
            .ok_or_else(|| {
                fault(
                    "Ljava/lang/ArrayIndexOutOfBoundsException;",
                    "Array copy start index",
                )
            })?;
        let copied = &slice[..slice.len().min(length)];
        if reference && !self.class_assignable(&target, &source.class)? {
            let component = target
                .strip_prefix('[')
                .ok_or("Array copy destination component")?;
            for &value in copied {
                if value != 0
                    && !self.class_assignable(component, &self.object(value as u32)?.class)?
                {
                    return Err(fault(
                        "Ljava/lang/ArrayStoreException;",
                        "Incompatible array copy element",
                    ));
                }
            }
        }
        if length * 8 + 128 + target.len() > self.heap_limit.saturating_sub(self.heap_bytes()) {
            return Err("Java array copy exceeds the heap quota".into());
        }
        let mut array = Vec::with_capacity(length);
        array.extend_from_slice(copied);
        array.resize(length, 0);
        Ok(Some(self.allocate(&target, Payload::Array(array))? as u64))
    }
}
