#!/usr/bin/env python3
"""Rebuild and verify the pinned Apache-licensed Android JSON DEX offline."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(*args):
    subprocess.run([str(value) for value in args], check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--r8', type=Path, required=True)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    support = root / 'crates/rift-native/support'
    upstream = support / 'aosp-json'
    pin = json.loads((support / 'android-json.json').read_text())
    r8_pin = json.loads((root / 'samples/TOOLCHAIN.json').read_text())
    if digest(args.r8) != r8_pin['r8_sha256']:
        raise SystemExit('Pinned D8 digest mismatch')
    if digest(upstream / 'LICENSE') != pin['license_sha256']:
        raise SystemExit('Android JSON license digest mismatch')
    sources = sorted(upstream / name for name in pin['sources'])
    for source in sources:
        if digest(source) != pin['sources'][source.name]:
            raise SystemExit(f'Android JSON upstream digest mismatch: {source.name}')

    with tempfile.TemporaryDirectory(prefix='kyvex-android-json-') as temporary:
        classes = Path(temporary) / 'java'
        dex = Path(temporary) / 'dex'
        classes.mkdir()
        dex.mkdir()
        run('javac', '--release', '8', '-d', classes, *sources)
        run('java', '-cp', args.r8, 'com.android.tools.r8.D8', '--release', '--min-api',
            '23', '--lib', '/usr/lib/jvm/default', '--output', dex,
            *sorted(classes.rglob('*.class')))
        artifact = dex / 'classes.dex'
        if digest(artifact) != pin['dex_sha256']:
            raise SystemExit('Android JSON DEX build differs from the pinned module')
        destination = support / 'android-json.dex'
        if not destination.exists() or destination.read_bytes() != artifact.read_bytes():
            destination.write_bytes(artifact.read_bytes())
        print(f'Android JSON DEX {artifact.stat().st_size} bytes {pin["dex_sha256"]}')


if __name__ == '__main__':
    main()
