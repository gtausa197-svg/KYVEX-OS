package org.kyvex.extra;

import java.nio.charset.StandardCharsets;
import java.util.DuplicateFormatFlagsException;
import java.util.FormatFlagsConversionMismatchException;
import java.util.IllegalFormatCodePointException;
import java.util.IllegalFormatConversionException;
import java.util.IllegalFormatException;
import java.util.IllegalFormatFlagsException;
import java.util.IllegalFormatPrecisionException;
import java.util.IllegalFormatWidthException;
import java.util.Locale;
import java.util.MissingFormatArgumentException;
import java.util.MissingFormatWidthException;
import java.util.UnknownFormatConversionException;

/** Checks the same static calls on stock Java 8 and in the Native APK. */
public final class FormatterChecks {
    private static int checks;
    private static int stringCalls;
    private static int hashCalls;

    private static void check(boolean ok, String reason) {
        if (!ok) throw new IllegalStateException(reason);
        checks++;
    }

    private static void expect(String expected, String format, Object... args) {
        String actual = String.format(format, args);
        check(expected.equals(actual), "Formatting " + format + " produced [" + actual + "]");
    }

    private static void reject(Class<?> expected, String format, Object... args) {
        try {
            String.format(format, args);
        } catch (IllegalFormatException error) {
            check(error.getClass() == expected, "Wrong exception for " + format);
            return;
        }
        throw new IllegalStateException("Accepted malformed format " + format);
    }

    private static final class Tracked {
        public String toString() { stringCalls++; return "real text"; }
        public int hashCode() { hashCalls++; return 0xab12; }
    }

    private static final class ReplacingArgument {
        final Object[] arguments;
        ReplacingArgument(Object[] arguments) { this.arguments = arguments; }
        public String toString() {
            arguments[0] = null;
            arguments[1] = "after";
            System.gc();
            return "callback";
        }
    }

    private static final class NullText {
        public String toString() { return null; }
    }

    public static int verify() {
        checks = stringCalls = hashCalls = 0;
        expect("literal \u043a\u0438\u0457\u0432", "literal \u043a\u0438\u0457\u0432");
        expect("second/first/first/second", "%2$s/%s/%<s/%s", "first", "second");
        expect("a/%/\na", "%s/%%/%n%<s", "a");
        expect("%/\n", "%10%/%2$n");
        expect("first/first", "%0$s/%2147483648$s", "first");
        expect("null/false/null/null/null", "%s/%b/%h/%c/%d", (Object[]) null);
        expect("[   xy][xy   ]", "[%5.2s][%-5.2s]", "xyz", "xyz");
        expect("[ SS]", "[%3.1S]", "\u00dfx");
        expect("\ud801\udc00X", "%S", "\ud801\udc28x");
        expect("\ud83d", "%.1s", "\ud83d\ude00");
        expect("\ud800X", "%S", "\ud800x");
        expect("\ud83d\ude00/\ud800/SS", "%c/%c/%C", 0x1f600, 0xd800, '\u00df');
        expect("-9,223,372,036,854,775,808", "%,d", Long.MIN_VALUE);
        expect("+0000042/(000042)/ 0000042", "%+08d/%(08d/% 08d", 42, -42, 42);
        expect("0xff/0177777/0XFFFFFFFF/ffffffffffffffff", "%#x/%#o/%#X/%x", (byte)-1, (short)-1, -1, -1L);
        expect("false/true/TRUE", "%b/%b/%B", false, "", true);
        expect("4cf/ffffff80/0/7fc00000/7ff80000/80000000", "%h/%h/%h/%h/%h/%h", true, (byte)-128, 0x100000001L, Float.NaN, Double.NaN, -0.0d);
        expect("null", "%s", new NullText());

        Tracked tracked = new Tracked();
        expect("true/ab12/real text", "%1$b/%1$h/%1$s", tracked);
        check(stringCalls == 1 && hashCalls == 1, "Conversions call the real object methods once");
        Object[] changing = {null, "before"};
        changing[0] = new ReplacingArgument(changing);
        expect("callback:after", "%s:%s", changing);

        reject(UnknownFormatConversionException.class, "%s%q", tracked);
        check(stringCalls == 1, "Validate the whole pattern before calling toString");
        reject(MissingFormatArgumentException.class, "%<s", "unused");
        reject(MissingFormatArgumentException.class, "%s");
        reject(MissingFormatWidthException.class, "%-0s", "x");
        reject(DuplicateFormatFlagsException.class, "%--4s", "x");
        reject(FormatFlagsConversionMismatchException.class, "%#s", tracked);
        check(stringCalls == 1, "Reject alternate string conversion before toString");
        reject(IllegalFormatFlagsException.class, "%+ 8.2d", 3);
        reject(IllegalFormatPrecisionException.class, "%-.1c", 'x');
        reject(IllegalFormatWidthException.class, "%5n");
        reject(IllegalFormatConversionException.class, "%d", "3");
        reject(IllegalFormatCodePointException.class, "%c", 0x110000);
        boolean nullFormat = false;
        try { String.format((String)null, 1); }
        catch (NullPointerException expected) { nullFormat = true; }
        check(nullFormat, "Null format throws NullPointerException");

        String extras = String.format("%s%s%s%s", "1$", "https://example.invalid", "\\", "");
        byte[] encoded = extras.getBytes(StandardCharsets.UTF_8);
        String expected = "1$https://example.invalid\\";
        boolean correctBytes = encoded.length == expected.length();
        for (int i = 0; correctBytes && i < encoded.length; i++) {
            correctBytes = encoded[i] == expected.charAt(i);
        }
        check(correctBytes, "Format and encode transport extras");
        return checks;
    }

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        System.out.println("Formatter checks: " + verify());
    }
}
