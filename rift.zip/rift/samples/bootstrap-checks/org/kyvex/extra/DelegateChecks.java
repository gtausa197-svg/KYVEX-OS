package org.kyvex.extra;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class DelegateChecks {
    private static int checks;
    private static int calls;

    private static void check(boolean condition, String label) {
        if (!condition) throw new IllegalStateException(label);
        checks++;
    }

    private static final class Custom extends AbstractExecutorService {
        private boolean stopped;

        public void execute(Runnable action) {
            calls++;
            action.run();
        }

        public <V> Future<V> submit(Callable<V> callable) {
            calls += 10;
            try { return new Result<V>(callable.call(), null); }
            catch (Exception failure) { return new Result<V>(null, failure); }
        }

        public void shutdown() { stopped = true; }
        public List<Runnable> shutdownNow() { stopped = true; return Collections.emptyList(); }
        public boolean isShutdown() { return stopped; }
        public boolean isTerminated() { return stopped; }

        public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
            Thread.sleep(unit.toMillis(timeout));
            calls += 100;
            return stopped;
        }
    }

    private static final class Result<V> implements Future<V> {
        private final V value;
        private final Exception failure;

        Result(V value, Exception failure) { this.value = value; this.failure = failure; }
        public boolean cancel(boolean interrupt) { return false; }
        public boolean isCancelled() { return false; }
        public boolean isDone() { return true; }
        public V get() throws ExecutionException {
            if (failure != null) throw new ExecutionException(failure);
            return value;
        }
        public V get(long timeout, TimeUnit unit) throws ExecutionException { return get(); }
    }

    private static Callable<Integer> result(final int value) {
        return new Callable<Integer>() {
            public Integer call() { return value; }
        };
    }

    public static int verify() {
        checks = calls = 0;
        try {
            boolean rejectsNull = false;
            try { Executors.unconfigurableExecutorService(null); }
            catch (NullPointerException expected) { rejectsNull = true; }
            check(rejectsNull, "Null executor rejected");

            ExecutorService first = Executors.unconfigurableExecutorService(new Custom());
            ExecutorService nested = Executors.unconfigurableExecutorService(first);
            check(first != nested && !(first instanceof Custom), "Wrapper retains its own identity and type");
            System.gc();
            nested.execute(new Runnable() { public void run() { calls += 2; } });
            check(calls == 3, "Real custom execute override survives wrapper chain and GC");
            check(nested.submit(result(13)).get().intValue() == 13 && calls == 13, "Real custom submit override and result");
            nested.shutdown();
            check(first.isShutdown() && nested.isTerminated(), "Wrapper reflects shared delegate shutdown");
            check(first.awaitTermination(2, TimeUnit.MILLISECONDS) && calls == 113, "Delegate wait resumes the Java frame");

            ExecutorService pool = Executors.newFixedThreadPool(1);
            ExecutorService wrapped = Executors.unconfigurableExecutorService(pool);
            check(pool instanceof ThreadPoolExecutor && !(wrapped instanceof ThreadPoolExecutor), "Wrapper hides configuration methods");
            final CountDownLatch done = new CountDownLatch(1);
            try {
                wrapped.execute(new Runnable() { public void run() { calls += 21; done.countDown(); } });
                check(done.await(2, TimeUnit.SECONDS) && calls == 134, "Wrapped pool executes real work");
            } finally {
                wrapped.shutdown();
            }
            check(pool.isShutdown() && wrapped.awaitTermination(2, TimeUnit.SECONDS), "Wrapped pool terminates");

            ScheduledExecutorService timed = Executors.unconfigurableScheduledExecutorService(
                Executors.newScheduledThreadPool(1));
            ExecutorService ordinary = Executors.unconfigurableExecutorService(timed);
            check(!(ordinary instanceof ScheduledExecutorService), "Ordinary wrapper hides scheduling");
            try {
                check(timed.schedule(result(34), 2, TimeUnit.MILLISECONDS).get(2, TimeUnit.SECONDS).intValue() == 34,
                      "Scheduled wrapper runs delayed callable");
                check(ordinary.submit(result(55)).get(2, TimeUnit.SECONDS).intValue() == 55,
                      "Nested ordinary wrapper delegates scheduled pool submission");
            } finally {
                ordinary.shutdown();
            }
            check(timed.awaitTermination(2, TimeUnit.SECONDS), "Nested scheduled pool terminates");
        } catch (Exception failure) {
            throw new IllegalStateException("Executor delegation check failed", failure);
        }
        return checks;
    }

    public static void main(String[] args) {
        System.out.println("Executor delegate checks: " + verify());
    }
}
