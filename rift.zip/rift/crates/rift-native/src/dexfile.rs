//! Real DEX tables and class-data loader, bounded before allocation.
use crate::Result;
use sha1::{Digest, Sha1};
use std::{
    collections::{BTreeMap, HashMap},
    sync::Arc,
};
#[derive(Clone, Debug, Default)]
pub struct Refs {
    pub strings: Vec<usize>,
    pub types: Vec<usize>,
    pub fields: Vec<usize>,
    pub methods: Vec<usize>,
}
impl Refs {
    pub fn index(map: &[usize], index: usize) -> Result<usize> {
        if map.is_empty() {
            Ok(index)
        } else {
            map.get(index)
                .copied()
                .ok_or_else(|| "DEX reference index out of bounds".into())
        }
    }
}
#[derive(Clone, Debug)]
pub struct Proto {
    pub result: usize,
    pub parameters: Vec<usize>,
}
#[derive(Clone, Debug)]
pub struct Method {
    pub class: usize,
    pub proto: usize,
    pub name: usize,
}
#[derive(Clone, Debug)]
pub struct Field {
    pub class: usize,
    pub ty: usize,
    pub name: usize,
}
#[derive(Clone, Debug)]
pub struct Body {
    pub access: u32,
    pub registers: usize,
    pub incoming: usize,
    pub tries: Vec<TryBlock>,
    pub code: Vec<u16>,
    pub refs: Arc<Refs>,
}
#[derive(Clone, Debug)]
pub struct TryBlock {
    pub start: usize,
    pub end: usize,
    pub handlers: Vec<(Option<usize>, usize)>,
}
#[derive(Clone, Debug)]
pub enum StaticValue {
    Bits(u64),
    String(usize),
}
#[derive(Clone, Debug)]
pub struct Class {
    pub access: u32,
    pub parent: Option<usize>,
    pub interfaces: Vec<usize>,
    pub fields: Vec<usize>,
    pub field_access: Vec<u32>,
    pub methods: Vec<usize>,
    pub static_values: Vec<(usize, StaticValue)>,
}
#[derive(Debug)]
pub struct Dex {
    pub strings: Vec<String>,
    pub utf16: BTreeMap<usize, Vec<u16>>,
    pub types: Vec<usize>,
    pub protos: Vec<Proto>,
    pub fields: Vec<Field>,
    pub methods: Vec<Method>,
    pub classes: BTreeMap<usize, Class>,
    pub bodies: BTreeMap<usize, Body>,
    type_index: HashMap<String, usize>,
    method_index: HashMap<usize, Vec<usize>>,
}
struct R<'a>(&'a [u8]);
impl R<'_> {
    fn bytes(&self, p: usize, n: usize) -> Result<&[u8]> {
        self.0
            .get(p..p.checked_add(n).ok_or("DEX offset overflow")?)
            .ok_or_else(|| "DEX field exceeds file bounds".into())
    }
    fn u16(&self, p: usize) -> Result<u16> {
        Ok(u16::from_le_bytes(self.bytes(p, 2)?.try_into()?))
    }
    fn u32(&self, p: usize) -> Result<u32> {
        Ok(u32::from_le_bytes(self.bytes(p, 4)?.try_into()?))
    }
    fn leb(&self, p: &mut usize) -> Result<u32> {
        let mut v = 0;
        for i in 0..5 {
            let b = *self.bytes(*p, 1)?.first().unwrap();
            *p += 1;
            if i == 4 && b > 15 {
                return Err("DEX LEB128 overflow".into());
            }
            v |= ((b & 127) as u32) << (i * 7);
            if b & 128 == 0 {
                return Ok(v);
            }
        }
        Err("Unterminated DEX LEB128".into())
    }
    fn sleb(&self, p: &mut usize) -> Result<i64> {
        let mut v = 0i64;
        for i in 0..5 {
            let b = self.bytes(*p, 1)?[0];
            *p += 1;
            v |= ((b & 127) as i64) << (7 * i);
            if b & 128 == 0 {
                if b & 64 != 0 {
                    v |= !0i64 << (7 * (i + 1));
                }
                if i32::try_from(v).is_err() {
                    return Err("DEX signed LEB128 overflow".into());
                }
                return Ok(v);
            }
        }
        Err("Unterminated DEX signed LEB128".into())
    }
    fn tries(
        &self,
        code: usize,
        words: usize,
        count: usize,
        types: usize,
    ) -> Result<Vec<TryBlock>> {
        if count == 0 {
            return Ok(Vec::new());
        }
        if count > 4096 {
            return Err("DEX try table budget".into());
        }
        let items = code + 16 + words * 2 + (words % 2) * 2;
        self.bytes(items, count * 8)?;
        let base = items + count * 8;
        let mut p = base;
        let lists = self.leb(&mut p)? as usize;
        if lists > 4096 {
            return Err("DEX exception handler budget".into());
        }
        let mut table = BTreeMap::new();
        for _ in 0..lists {
            let key = p - base;
            let size = self.sleb(&mut p)?;
            if size.unsigned_abs() > 1024 {
                return Err("DEX typed catch budget".into());
            }
            let mut handlers = Vec::new();
            for _ in 0..size.unsigned_abs() {
                let ty = self.leb(&mut p)? as usize;
                let at = self.leb(&mut p)? as usize;
                if ty >= types || at >= words {
                    return Err("DEX catch type/target bounds".into());
                }
                handlers.push((Some(ty), at));
            }
            if size <= 0 {
                let at = self.leb(&mut p)? as usize;
                if at >= words {
                    return Err("DEX catch-all target bounds".into());
                }
                handlers.push((None, at));
            }
            table.insert(key, handlers);
        }
        let mut result = Vec::new();
        let mut previous_end = 0;
        for i in 0..count {
            let at = items + i * 8;
            let start = self.u32(at)? as usize;
            let end = start
                .checked_add(self.u16(at + 4)? as usize)
                .ok_or("DEX try overflow")?;
            if end > words || start >= end || start < previous_end {
                return Err("DEX try range/order bounds".into());
            }
            previous_end = end;
            let handlers = table
                .get(&(self.u16(at + 6)? as usize))
                .ok_or("DEX catch handler offset")?
                .clone();
            result.push(TryBlock {
                start,
                end,
                handlers,
            });
        }
        Ok(result)
    }
    fn table(&self, header: usize, stride: usize, max: usize) -> Result<(usize, usize)> {
        let n = self.u32(header)? as usize;
        let p = self.u32(header + 4)? as usize;
        if n > max {
            return Err(format!("Native DEX table quota exceeded at header {header}").into());
        }
        if n != 0 && (p < 112 || !p.is_multiple_of(4)) {
            return Err("DEX table alignment/bounds".into());
        }
        self.bytes(p, n.checked_mul(stride).ok_or("DEX table overflow")?)?;
        Ok((n, p))
    }
}
pub fn mutf8_units(bytes: &[u8]) -> Result<Vec<u16>> {
    let mut words = Vec::new();
    let mut p = 0;
    while p < bytes.len() {
        let b = bytes[p];
        p += 1;
        let v = if (1..128).contains(&b) {
            b as u16
        } else if b & 0xe0 == 0xc0 {
            let c = *bytes.get(p).ok_or("Truncated MUTF-8")?;
            p += 1;
            if c & 0xc0 != 0x80 {
                return Err("Invalid MUTF-8 continuation".into());
            }
            let v = (((b & 31) as u16) << 6) | (c & 63) as u16;
            if v < 128 && v != 0 {
                return Err("Overlong MUTF-8".into());
            }
            v
        } else if b & 0xf0 == 0xe0 {
            let c = *bytes.get(p).ok_or("Truncated MUTF-8")?;
            let d = *bytes.get(p + 1).ok_or("Truncated MUTF-8")?;
            p += 2;
            if c & 0xc0 != 0x80 || d & 0xc0 != 0x80 {
                return Err("Invalid MUTF-8 continuation".into());
            }
            let v = (((b & 15) as u16) << 12) | (((c & 63) as u16) << 6) | (d & 63) as u16;
            if v < 2048 {
                return Err("Overlong MUTF-8".into());
            }
            v
        } else {
            return Err("Invalid modified UTF-8".into());
        };
        words.push(v);
    }
    Ok(words)
}
pub fn mutf8_decode(bytes: &[u8]) -> Result<String> {
    Ok(String::from_utf16(&mutf8_units(bytes)?)?)
}
pub fn mutf8_encode(s: &str) -> Vec<u8> {
    mutf8_from_units(&s.encode_utf16().collect::<Vec<_>>())
}
pub fn mutf8_from_units(words: &[u16]) -> Vec<u8> {
    let mut b = Vec::new();
    for &w in words {
        if (1..128).contains(&w) {
            b.push(w as u8)
        } else if w < 2048 {
            b.extend([0xc0 | ((w >> 6) as u8), 0x80 | ((w & 63) as u8)])
        } else {
            b.extend([
                0xe0 | ((w >> 12) as u8),
                0x80 | (((w >> 6) & 63) as u8),
                0x80 | ((w & 63) as u8),
            ])
        }
    }
    b
}
fn adler(bytes: &[u8]) -> u32 {
    let (mut a, mut b) = (1u32, 0u32);
    for &v in bytes {
        a = (a + v as u32) % 65521;
        b = (b + a) % 65521;
    }
    (b << 16) | a
}
impl Dex {
    pub fn parse(bytes: &[u8]) -> Result<Self> {
        let r = R(bytes);
        if bytes.len() < 112 || bytes.len() > 32 * 1024 * 1024 {
            return Err("Native DEX file quota (32 MiB)".into());
        }
        if ![
            b"dex\n035\0".as_slice(),
            b"dex\n037\0",
            b"dex\n038\0",
            b"dex\n039\0",
        ]
        .contains(&r.bytes(0, 8)?)
        {
            return Err("Unsupported DEX version".into());
        }
        if r.u32(32)? as usize != bytes.len() || r.u32(36)? != 112 || r.u32(40)? != 0x12345678 {
            return Err("DEX header size/endian mismatch".into());
        }
        if r.u32(8)? != adler(&bytes[12..])
            || Sha1::digest(&bytes[32..]).as_slice() != r.bytes(12, 20)?
        {
            return Err("DEX integrity checksum mismatch".into());
        }
        let (n, p) = r.table(56, 4, 524288)?;
        let mut strings = Vec::with_capacity(n);
        let mut utf16 = BTreeMap::new();
        let mut allocation = 0;
        for i in 0..n {
            let mut pos = r.u32(p + i * 4)? as usize;
            let chars = r.leb(&mut pos)? as usize;
            if chars > 65536 {
                return Err("DEX string length quota".into());
            }
            let tail = bytes.get(pos..).ok_or("DEX string data offset")?;
            let end = tail
                .iter()
                .take(262145)
                .position(|v| *v == 0)
                .ok_or("DEX string terminator quota")?;
            allocation += end;
            if allocation > 24 * 1024 * 1024 {
                return Err("DEX string allocation budget".into());
            }
            let units = mutf8_units(&tail[..end])?;
            if units.len() != chars {
                return Err("DEX UTF-16 length mismatch".into());
            }
            let s = match String::from_utf16(&units) {
                Ok(s) if !s.starts_with('\0') => s,
                _ => {
                    let key = format!("\0{:04x?}", units);
                    utf16.insert(i, units);
                    key
                }
            };
            strings.push(s);
        }
        let (n, p) = r.table(64, 4, 65536)?;
        let mut types = Vec::with_capacity(n);
        for i in 0..n {
            let s = r.u32(p + i * 4)? as usize;
            if s >= strings.len() || strings[s].len() > 512 {
                return Err("DEX type index/length".into());
            }
            types.push(s);
        }
        let (n, p) = r.table(72, 12, 65536)?;
        let mut protos = Vec::with_capacity(n);
        for i in 0..n {
            let o = p + i * 12;
            let result = r.u32(o + 4)? as usize;
            if result >= types.len() {
                return Err("DEX result type index".into());
            }
            let mut parameters = Vec::new();
            let list = r.u32(o + 8)? as usize;
            if list != 0 {
                let count = r.u32(list)? as usize;
                if count > 512 {
                    return Err("DEX parameter count quota".into());
                }
                r.bytes(list + 4, count * 2)?;
                for j in 0..count {
                    let ty = r.u16(list + 4 + j * 2)? as usize;
                    if ty >= types.len() {
                        return Err("DEX parameter type index".into());
                    }
                    parameters.push(ty);
                }
            }
            protos.push(Proto { result, parameters });
        }
        let (n, p) = r.table(80, 8, 65536)?;
        let mut fields = Vec::with_capacity(n);
        for i in 0..n {
            let o = p + i * 8;
            let (class, ty, name) = (
                r.u16(o)? as usize,
                r.u16(o + 2)? as usize,
                r.u32(o + 4)? as usize,
            );
            if class >= types.len() || ty >= types.len() || name >= strings.len() {
                return Err("DEX field references".into());
            }
            fields.push(Field { class, ty, name });
        }
        let (n, p) = r.table(88, 8, 65536)?;
        let mut methods = Vec::with_capacity(n);
        for i in 0..n {
            let o = p + i * 8;
            let (class, proto, name) = (
                r.u16(o)? as usize,
                r.u16(o + 2)? as usize,
                r.u32(o + 4)? as usize,
            );
            if class >= types.len() || proto >= protos.len() || name >= strings.len() {
                return Err("DEX method references".into());
            }
            methods.push(Method { class, proto, name });
        }
        let (n, p) = r.table(96, 32, 65536)?;
        let mut classes = BTreeMap::new();
        let mut bodies = BTreeMap::new();
        let mut code_budget = 0usize;
        for i in 0..n {
            let o = p + i * 32;
            let ty = r.u32(o)? as usize;
            let parent = r.u32(o + 8)?;
            if ty >= types.len() || (parent != u32::MAX && parent as usize >= types.len()) {
                return Err("DEX class hierarchy references".into());
            }
            let parent = if parent == u32::MAX {
                None
            } else {
                Some(parent as usize)
            };
            let mut class = Class {
                access: r.u32(o + 4)?,
                parent,
                interfaces: Vec::new(),
                fields: Vec::new(),
                field_access: Vec::new(),
                methods: Vec::new(),
                static_values: Vec::new(),
            };
            let interfaces = r.u32(o + 12)? as usize;
            if interfaces != 0 {
                let count = r.u32(interfaces)? as usize;
                if count > 1024 {
                    return Err("DEX implemented-interface quota".into());
                }
                for i in 0..count {
                    let ty = r.u16(interfaces + 4 + i * 2)? as usize;
                    if ty >= types.len() {
                        return Err("DEX implemented-interface index".into());
                    }
                    class.interfaces.push(ty);
                }
            }
            let mut static_fields = Vec::new();
            let mut data = r.u32(o + 24)? as usize;
            if data != 0 {
                let counts = [
                    r.leb(&mut data)?,
                    r.leb(&mut data)?,
                    r.leb(&mut data)?,
                    r.leb(&mut data)?,
                ];
                if counts.iter().any(|n| *n > 65536) {
                    return Err("DEX class-data count quota".into());
                }
                for (group, count) in counts.into_iter().enumerate() {
                    let mut idx = 0usize;
                    for _ in 0..count {
                        idx = idx
                            .checked_add(r.leb(&mut data)? as usize)
                            .ok_or("DEX delta index overflow")?;
                        let access = r.leb(&mut data)?;
                        if group < 2 {
                            let field = fields.get(idx).ok_or("DEX encoded field index")?;
                            if field.class != ty {
                                return Err("DEX field belongs to another class".into());
                            }
                            class.fields.push(idx);
                            class.field_access.push(access);
                            if group == 0 {
                                static_fields.push(idx);
                            }
                            continue;
                        }
                        let method = methods.get(idx).ok_or("DEX encoded method index")?;
                        if method.class != ty {
                            return Err("DEX method belongs to another class".into());
                        }
                        let code = r.leb(&mut data)? as usize;
                        let body = if code == 0 {
                            if access & (0x100 | 0x400) == 0 {
                                return Err("Concrete DEX method has no code".into());
                            }
                            Body {
                                access,
                                registers: 0,
                                incoming: 0,
                                tries: Vec::new(),
                                code: Vec::new(),
                                refs: Arc::default(),
                            }
                        } else {
                            if !code.is_multiple_of(4) {
                                return Err("Unaligned DEX code item".into());
                            }
                            let registers = r.u16(code)? as usize;
                            let incoming = r.u16(code + 2)? as usize;
                            let tries = r.u16(code + 6)? as usize;
                            let words = r.u32(code + 12)? as usize;
                            code_budget = code_budget
                                .checked_add(words)
                                .ok_or("DEX code budget overflow")?;
                            if registers > 8192
                                || incoming > registers
                                || words > 1024 * 1024
                                || code_budget > 12 * 1024 * 1024
                            {
                                return Err("Native DEX code/register quota".into());
                            }
                            let b = r.bytes(code + 16, words * 2)?;
                            Body {
                                access,
                                registers,
                                incoming,
                                tries: r.tries(code, words, tries, types.len())?,
                                refs: Arc::default(),
                                code: b
                                    .as_chunks::<2>()
                                    .0
                                    .iter()
                                    .map(|v| u16::from_le_bytes([v[0], v[1]]))
                                    .collect(),
                            }
                        };
                        if bodies.insert(idx, body).is_some() {
                            return Err("Duplicate DEX method definition".into());
                        }
                        class.methods.push(idx);
                    }
                }
            }
            let values = r.u32(o + 28)? as usize;
            if values != 0 {
                let mut q = values;
                let count = r.leb(&mut q)? as usize;
                if count > static_fields.len() {
                    return Err("DEX static value count".into());
                }
                for field in static_fields.iter().take(count) {
                    let tag = *r.bytes(q, 1)?.first().unwrap();
                    q += 1;
                    let kind = tag & 31;
                    let count = (tag >> 5) as usize + 1;
                    let value = match kind {
                        0x1e => {
                            if tag >> 5 != 0 {
                                return Err("Invalid DEX null value".into());
                            }
                            0
                        }
                        0x1f => {
                            if tag >> 5 > 1 {
                                return Err("Invalid DEX boolean".into());
                            }
                            (tag >> 5) as u64
                        }
                        0 | 2 | 3 | 4 | 6 | 0x10 | 0x11 | 0x17 => {
                            if count > 8 {
                                return Err("DEX encoded value width".into());
                            }
                            let b = r.bytes(q, count)?;
                            q += count;
                            let mut v = 0u64;
                            for (i, b) in b.iter().enumerate() {
                                v |= (*b as u64) << (8 * i);
                            }
                            if matches!(kind, 0 | 2 | 4 | 6) && count < 8 && b[count - 1] & 128 != 0
                            {
                                v |= u64::MAX << (count * 8);
                            }
                            if kind == 0x10 {
                                v <<= (4usize.checked_sub(count).ok_or("DEX float width")?) * 8;
                            }
                            if kind == 0x11 {
                                v <<= (8 - count) * 8;
                            }
                            if kind == 0x17 && v as usize >= strings.len() {
                                return Err("DEX static string index".into());
                            }
                            v
                        }
                        _ => {
                            return Err(
                                format!("Unsupported DEX encoded static value 0x{kind:x}").into()
                            );
                        }
                    };
                    class.static_values.push((
                        *field,
                        if kind == 0x17 {
                            StaticValue::String(value as usize)
                        } else {
                            StaticValue::Bits(value)
                        },
                    ));
                }
            }
            if classes.insert(ty, class).is_some() {
                return Err("Duplicate DEX class".into());
            }
        }
        let mut result = Self {
            strings,
            utf16,
            types,
            protos,
            fields,
            methods,
            classes,
            bodies,
            type_index: HashMap::new(),
            method_index: HashMap::new(),
        };
        result.reindex();
        Ok(result)
    }
    pub fn ty(&self, index: usize) -> &str {
        &self.strings[self.types[index]]
    }
    /// Only class descriptors are indexed; bytecode and other pools remain unloaded.
    pub fn class_names(bytes: &[u8]) -> Result<Vec<String>> {
        let r = R(bytes);
        if bytes.len() < 112
            || bytes.len() > 32 * 1024 * 1024
            || !bytes.starts_with(b"dex\n")
            || r.u32(32)? as usize != bytes.len()
        {
            return Err("Invalid DEX class index header".into());
        }
        let (strings, sp) = r.table(56, 4, 524288)?;
        let (types, tp) = r.table(64, 4, 65536)?;
        let (classes, cp) = r.table(96, 32, 65536)?;
        let mut names = Vec::with_capacity(classes);
        for i in 0..classes {
            let ty = r.u32(cp + i * 32)? as usize;
            if ty >= types {
                return Err("DEX class type index".into());
            }
            let s = r.u32(tp + ty * 4)? as usize;
            if s >= strings {
                return Err("DEX class descriptor index".into());
            }
            let mut at = r.u32(sp + s * 4)? as usize;
            let len = r.leb(&mut at)? as usize;
            if len > 512 {
                return Err("DEX class descriptor length".into());
            }
            let tail = bytes.get(at..).ok_or("DEX class descriptor offset")?;
            let n = tail
                .iter()
                .take(1537)
                .position(|v| *v == 0)
                .ok_or("DEX class descriptor terminator")?;
            let name = mutf8_decode(&tail[..n])?;
            if name.encode_utf16().count() != len || !name.starts_with('L') || !name.ends_with(';')
            {
                return Err("Invalid DEX class descriptor".into());
            }
            names.push(name);
        }
        Ok(names)
    }
    /// Intern pools while keeping each method's original 16-bit references intact.
    /// This permits more than 65,536 methods across multiple DEX files.
    pub fn append(&mut self, other: Self) -> Result<()> {
        if self.methods.len() + other.methods.len() > 1_000_000
            || self.strings.len() + other.strings.len() > 1_000_000
        {
            return Err("Loaded multidex pool budget exhausted".into());
        }
        let intern = |values: &mut Vec<String>, incoming: Vec<String>| {
            let mut lookup: HashMap<String, usize> = values
                .iter()
                .cloned()
                .enumerate()
                .map(|(i, s)| (s, i))
                .collect();
            incoming
                .into_iter()
                .map(|s| {
                    if let Some(&i) = lookup.get(&s) {
                        i
                    } else {
                        let i = values.len();
                        values.push(s.clone());
                        lookup.insert(s, i);
                        i
                    }
                })
                .collect::<Vec<_>>()
        };
        let sm = intern(&mut self.strings, other.strings);
        for (i, units) in other.utf16 {
            self.utf16.insert(sm[i], units);
        }
        let mut types: HashMap<usize, usize> = self
            .types
            .iter()
            .copied()
            .enumerate()
            .map(|(i, v)| (v, i))
            .collect();
        let tm = other
            .types
            .iter()
            .map(|i| {
                let s = sm[*i];
                *types.entry(s).or_insert_with(|| {
                    let n = self.types.len();
                    self.types.push(s);
                    n
                })
            })
            .collect::<Vec<_>>();
        let mut protos: HashMap<(usize, Vec<usize>), usize> = self
            .protos
            .iter()
            .enumerate()
            .map(|(i, p)| ((p.result, p.parameters.clone()), i))
            .collect();
        let pm = other
            .protos
            .iter()
            .map(|p| {
                let key = (
                    tm[p.result],
                    p.parameters.iter().map(|i| tm[*i]).collect::<Vec<_>>(),
                );
                *protos.entry(key.clone()).or_insert_with(|| {
                    let i = self.protos.len();
                    self.protos.push(Proto {
                        result: key.0,
                        parameters: key.1,
                    });
                    i
                })
            })
            .collect::<Vec<_>>();
        let mut fields: HashMap<(usize, usize, usize), usize> = self
            .fields
            .iter()
            .enumerate()
            .map(|(i, f)| ((f.class, f.ty, f.name), i))
            .collect();
        let fm = other
            .fields
            .iter()
            .map(|f| {
                let key = (tm[f.class], tm[f.ty], sm[f.name]);
                *fields.entry(key).or_insert_with(|| {
                    let i = self.fields.len();
                    self.fields.push(Field {
                        class: key.0,
                        ty: key.1,
                        name: key.2,
                    });
                    i
                })
            })
            .collect::<Vec<_>>();
        let mut methods: HashMap<(usize, usize, usize), usize> = self
            .methods
            .iter()
            .enumerate()
            .map(|(i, m)| ((m.class, m.proto, m.name), i))
            .collect();
        let mm = other
            .methods
            .iter()
            .map(|m| {
                let key = (tm[m.class], pm[m.proto], sm[m.name]);
                *methods.entry(key).or_insert_with(|| {
                    let i = self.methods.len();
                    self.methods.push(Method {
                        class: key.0,
                        proto: key.1,
                        name: key.2,
                    });
                    i
                })
            })
            .collect::<Vec<_>>();
        for (ty, c) in other.classes {
            let mut values = Vec::new();
            for (f, v) in c.static_values {
                values.push((
                    fm[f],
                    match v {
                        StaticValue::String(i) => StaticValue::String(sm[i]),
                        v => v,
                    },
                ));
            }
            if self
                .classes
                .insert(
                    tm[ty],
                    Class {
                        access: c.access,
                        parent: c.parent.map(|p| tm[p]),
                        interfaces: c.interfaces.iter().map(|i| tm[*i]).collect(),
                        methods: c.methods.iter().map(|i| mm[*i]).collect(),
                        static_values: values,
                        fields: c.fields.iter().map(|i| fm[*i]).collect(),
                        field_access: c.field_access,
                    },
                )
                .is_some()
            {
                return Err("Duplicate class definition across DEX files".into());
            }
        }
        let refs = Arc::new(Refs {
            strings: sm,
            types: tm,
            fields: fm,
            methods: mm.clone(),
        });
        for (i, mut b) in other.bodies {
            for t in &mut b.tries {
                for (ty, _) in &mut t.handlers {
                    if let Some(i) = ty {
                        *i = refs.types[*i];
                    }
                }
            }
            b.refs = refs.clone();
            if self.bodies.insert(mm[i], b).is_some() {
                return Err("Duplicate multidex method definition".into());
            }
        }
        self.reindex();
        Ok(())
    }
    /// Keep symbolic references for resolution against the platform definition.
    pub(crate) fn remove_class_definitions(&mut self, reserved: impl Fn(&str) -> bool) {
        let replaced: Vec<_> = self
            .classes
            .keys()
            .copied()
            .filter(|ty| reserved(self.ty(*ty)))
            .collect();
        for ty in replaced {
            if let Some(class) = self.classes.remove(&ty) {
                for method in class.methods {
                    self.bodies.remove(&method);
                }
            }
        }
    }
    fn reindex(&mut self) {
        self.type_index = self
            .types
            .iter()
            .enumerate()
            .map(|(i, s)| (self.strings[*s].clone(), i))
            .collect();
        self.method_index.clear();
        for (i, m) in self.methods.iter().enumerate() {
            self.method_index.entry(m.class).or_default().push(i);
        }
    }
    pub fn type_id(&self, class: &str) -> Option<usize> {
        self.type_index.get(class).copied()
    }
    pub fn has_class(&self, class: &str) -> bool {
        self.type_id(class)
            .is_some_and(|i| self.classes.contains_key(&i))
    }
    pub fn signature(&self, index: usize) -> String {
        let m = &self.methods[index];
        let p = &self.protos[m.proto];
        format!(
            "{}->{}({}){}",
            self.ty(m.class),
            self.strings[m.name],
            p.parameters.iter().map(|i| self.ty(*i)).collect::<String>(),
            self.ty(p.result)
        )
    }
    pub fn find(&self, class: &str, name: &str, descriptor: &str) -> Option<usize> {
        let mut reference = None;
        let class_id = self.type_id(class)?;
        for &i in self.method_index.get(&class_id)? {
            let m = &self.methods[i];
            if self.ty(m.class) == class && self.strings[m.name] == name {
                let s = self.signature(i);
                if s.split_once("->")
                    .and_then(|(_, tail)| tail.strip_prefix(name))
                    == Some(descriptor)
                {
                    if self.bodies.contains_key(&i) {
                        return Some(i);
                    }
                    reference = Some(i);
                }
            }
        }
        reference
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn modified_utf8_handles_null_and_supplementary_characters() {
        let s = "KYVEX\0 українська 🦀";
        let bytes = mutf8_encode(s);
        assert!(!bytes.contains(&0));
        assert_eq!(mutf8_decode(&bytes).unwrap(), s);
        assert!(mutf8_decode(&[0xf0, 0x9f, 0xa6, 0x80]).is_err());
    }
    #[test]
    fn malformed_dex_is_rejected_before_allocating_tables() {
        for n in [0, 4, 111, 112, 4096] {
            assert!(Dex::parse(&vec![0; n]).is_err())
        }
    }
}
