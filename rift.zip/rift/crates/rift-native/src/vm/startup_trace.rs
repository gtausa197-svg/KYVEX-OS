//! Optional bounded startup diagnostics. Never writes to the protocol stream.
use super::*;
use std::time::Instant;
pub(super) struct Trace {
    started: Instant,
    next_ms: u128,
    emitted: u16,
}
impl Runtime {
    pub fn enable_startup_trace(&mut self, started: Instant) {
        self.startup_trace = Some(Trace {
            started,
            next_ms: 0,
            emitted: 0,
        });
    }
    pub fn finish_startup_trace(&mut self) {
        self.startup_trace = None;
    }
    pub(super) fn trace_native_load_failure(&mut self, library: &str, detail: &str) {
        let Some(trace) = self
            .startup_trace
            .as_mut()
            .filter(|trace| trace.emitted < 80)
        else {
            return;
        };
        trace.emitted += 1;
        eprintln!(
            "{}",
            serde_json::json!({
                "rift_startup_trace":"native-load-failure",
                "elapsed_ms":trace.started.elapsed().as_millis(),
                "library":library,
                "detail":detail,
            })
        );
    }
    pub(super) fn trace_startup_call(&mut self, index: usize) {
        let elapsed = {
            let Some(trace) = self.startup_trace.as_mut() else {
                return;
            };
            if trace.emitted >= 80 {
                return;
            }
            let elapsed = trace.started.elapsed().as_millis();
            if elapsed < trace.next_ms {
                return;
            }
            trace.next_ms = elapsed.saturating_add(500);
            trace.emitted += 1;
            elapsed
        };
        let method: String = self.dex.signature(index).chars().take(512).collect();
        eprintln!(
            "{}",
            serde_json::json!({"rift_startup_trace":"call","elapsed_ms":elapsed,"thread":self.current_guest_tid(),"depth":self.depth,"dex_instructions":self.instructions,"objects":self.heap.len(),"loaded_dex":self.libraries.dex_loaded,"method":method})
        );
    }

    pub(super) fn trace_initialization_failure(&mut self, class: &str, detail: &str) {
        let Some(trace) = self
            .startup_trace
            .as_mut()
            .filter(|trace| trace.emitted < 80)
        else {
            return;
        };
        trace.emitted += 1;
        let class: String = class.chars().take(512).collect();
        let detail: String = detail.chars().take(768).collect();
        eprintln!(
            "{}",
            serde_json::json!({
                "rift_startup_trace": "class-init-failure",
                "elapsed_ms": trace.started.elapsed().as_millis(),
                "class": class,
                "detail": detail,
            })
        );
    }
}
