package org.kyvex.extra;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Same source runs on stock Java8 and as real DEX, including foreign callbacks. */
public final class MapSetChecks {
 private static int checks;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 static final class TrackedMap extends AbstractMap<String,Boolean> {
  final HashMap<String,Boolean> data=new HashMap<String,Boolean>();
  final Keys keys=new Keys(this);
  int puts,removes,contains,clears,empties,sizes,keyCalls,iterations,nexts,iteratorRemoves;
  public boolean isEmpty(){empties++;return data.isEmpty();}
  public int size(){sizes++;return data.size();}
  public Boolean put(String key,Boolean value){puts++;System.gc();return data.put(key,value);}
  public Boolean remove(Object key){removes++;return data.remove(key);}
  public boolean containsKey(Object key){contains++;return data.containsKey(key);}
  public void clear(){clears++;data.clear();}
  public Set<String> keySet(){keyCalls++;return keys;}
  public Set<Map.Entry<String,Boolean>> entrySet(){return data.entrySet();}
 }
 static final class Keys extends AbstractSet<String> {
  final TrackedMap map;
  Keys(TrackedMap map){this.map=map;}
  public int size(){return map.data.size();}
  public boolean contains(Object key){return map.data.containsKey(key);}
  public void clear(){map.data.clear();}
  public boolean remove(Object key){return map.data.remove(key)!=null;}
  public Object[] toArray(){return map.data.keySet().toArray();}
  public <T>T[] toArray(T[] target){return map.data.keySet().toArray(target);}
  public Iterator<String> iterator(){map.iterations++;return new KeysIterator(map,map.data.keySet().iterator());}
 }
 static final class KeysIterator implements Iterator<String> {
  final TrackedMap map;
  final Iterator<String> inner;
  KeysIterator(TrackedMap map,Iterator<String> inner){this.map=map;this.inner=inner;}
  public boolean hasNext(){return inner.hasNext();}
  public String next(){map.nexts++;System.gc();return inner.next();}
  public void remove(){map.iteratorRemoves++;inner.remove();}
 }
 public static int verify(){checks=0;
  boolean threw=false;try{Collections.newSetFromMap((Map<String,Boolean>)null);}catch(NullPointerException expected){threw=true;}
  check(threw,"Null backing map rejected");
  Map<String,Boolean> full=new HashMap<String,Boolean>();full.put("already",Boolean.TRUE);
  threw=false;try{Collections.newSetFromMap(full);}catch(IllegalArgumentException expected){threw=true;}
  check(threw&&full.size()==1,"Nonempty backing rejected unchanged");
  HashMap<String,Boolean> raw=new HashMap<String,Boolean>();Set<String> set=Collections.newSetFromMap(raw);
  check(set.isEmpty()&&set.size()==0,"Initially empty");
  check(set.add("alpha"),"First insertion");
  check(raw.get("alpha")==Boolean.TRUE,"Actual Boolean.TRUE stored in backing");
  check(!set.add(new String("alpha"))&&set.size()==1,"Equal duplicate is not new");
  check(set.contains(new String("alpha"))&&!set.contains("absent"),"Contains key uses equality");
  check(set.add(null)&&set.contains(null)&&!set.add(null),"Null policy follows HashMap");
  check(set.remove(null)&&!set.remove(null),"Null removal returns presence");
  check(Collections.addAll(set,"beta","gamma","alpha")&&set.size()==3,"Static bulk add reaches map-backed set");
  check(!set.addAll(Arrays.asList("alpha","beta")),"Duplicate bulk add result");
  check(set.addAll(Arrays.asList("delta","epsilon"))&&set.size()==5,"Instance bulk add modifies backing");
  Object[] all=set.toArray();check(all.length==5,"Object array reflects contents");
  String[] small=set.toArray(new String[0]);check(small.length==5&&set.contains(small[0]),"Typed small array allocation");
  String[] large=new String[7];large[6]="tail";
  check(set.toArray(large)==large&&large[5]==null&&"tail".equals(large[6]),"Typed large array terminator and tail");
  threw=false;try{set.toArray(new Integer[0]);}catch(ArrayStoreException expected){threw=true;}
  check(threw,"Wrong destination component rejected");
  Iterator<String> it=set.iterator();String removed=it.next();it.remove();
  check(!raw.containsKey(removed)&&set.size()==4,"Iterator removal changes actual backing");
  Set<String> readonly=Collections.unmodifiableSet(set);Iterator<String> ro=readonly.iterator();String first=ro.next();
  threw=false;try{ro.remove();}catch(UnsupportedOperationException expected){threw=true;}
  check(threw&&set.contains(first),"Read-only iterator preserves data");
  threw=false;try{readonly.add("no");}catch(UnsupportedOperationException expected){threw=true;}
  check(threw&&!set.contains("no"),"Read-only add rejected");
  Set<String> sync=Collections.synchronizedSet(set);check(sync.add("sync")&&set.contains("sync"),"Synchronized wrapper delegates");
  check(sync.remove("sync")&&!set.contains("sync"),"Wrapper removal delegates");
  ArrayList<String> copied=new ArrayList<String>(readonly);check(copied.size()==set.size()&&copied.contains(first),"Collection constructor traverses delegated set");
  set.clear();check(set.isEmpty()&&raw.isEmpty(),"Clear changes actual map");
  Set<String> concurrent=Collections.newSetFromMap(new ConcurrentHashMap<String,Boolean>());
  threw=false;try{concurrent.add(null);}catch(NullPointerException expected){threw=true;}
  check(threw&&concurrent.isEmpty(),"Concurrent map rejects null");
  check(concurrent.add("worker")&&!concurrent.add("worker")&&concurrent.remove("worker"),"Concurrent backing mutations");

  TrackedMap foreign=new TrackedMap();Set<String> delegated=Collections.newSetFromMap(foreign);
  check(foreign.empties==1&&foreign.keyCalls==1,"Factory invokes real DEX map methods");
  check(delegated.add("one")&&foreign.puts==1&&foreign.data.get("one")==Boolean.TRUE,"Foreign put callback and Boolean identity");
  check(!delegated.add(new String("one"))&&foreign.puts==2,"Foreign duplicate still invokes put");
  check(delegated.contains("one")&&foreign.contains==1,"Foreign contains callback");
  check(delegated.size()==1&&foreign.sizes==1,"Foreign size callback");
  check(Collections.addAll(delegated,"two","three")&&foreign.puts==4,"Static addAll invokes foreign put");
  check(delegated.addAll(Arrays.asList("three","four"))&&foreign.puts==6,"Instance addAll invokes foreign put");
  int before=foreign.iterations;Iterator<String> foreignIt=delegated.iterator();String item=foreignIt.next();
  check(foreign.iterations==before+1&&foreign.nexts==1&&delegated.contains(item),"Real DEX keySet iterator callbacks");
  foreignIt.remove();check(foreign.iteratorRemoves==1&&!foreign.data.containsKey(item),"Foreign iterator remove callback");
  Set<String> foreignReadonly=Collections.unmodifiableSet(delegated);before=foreign.nexts;
  Iterator<String> foreignRo=foreignReadonly.iterator();String kept=foreignRo.next();
  check(foreign.nexts==before+1&&foreignReadonly.contains(kept),"Read-only wrapper executes actual DEX iterator");
  before=foreign.iteratorRemoves;threw=false;try{foreignRo.remove();}catch(UnsupportedOperationException expected){threw=true;}
  check(threw&&foreign.iteratorRemoves==before&&delegated.contains(kept),"Read-only foreign iterator denies removal before callback");
  copied=new ArrayList<String>(foreignReadonly);check(copied.size()==delegated.size()&&copied.contains(kept),"Foreign collection traversal retains results through GC");
  String[] foreignArray=foreignReadonly.toArray(new String[0]);check(foreignArray.length==delegated.size(),"Foreign typed array delegates");
  check(delegated.remove(kept)&&foreign.removes==1&&!foreign.data.containsKey(kept),"Foreign remove callback");
  check(!delegated.remove("missing")&&foreign.removes==2,"Foreign missing remove result");
  delegated.clear();check(foreign.clears==1&&delegated.isEmpty()&&foreign.empties==2,"Foreign clear and emptiness callbacks");
  check(delegated.equals(delegated),"Set identity equality");
  return checks;
 }
 public static void main(String[] args){System.out.println("Map set checks: "+verify());}
}
