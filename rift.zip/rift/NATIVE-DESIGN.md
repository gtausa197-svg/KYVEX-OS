# Rift Native 0.3 architecture

APK snapshot → bounded archive reader → primary DEX → lazy secondary class loader
→ original Java register interpreter → selected Java/Android APIs or JNI
→ ELF/APS2/RELR loader → Dynarmic ARM32/Thumb/ARM64 → checked guest memory.
Real Activity scenes and events pass through a supervised private JSON channel
to Qt Studio. No Android container backend remains.

One APK descriptor is explicitly kept through the worker's syscall filter.
Unloaded DEX/library data remains on media. Classes are indexed on demand;
each loaded method retains maps from its original DEX reference indexes to
interned pools. Native code never gets host pointers or host file descriptors.
Global/local Java handles remain opaque guest integers. GC runs at registered safe points,
tracing activity/application, statics, views/listeners, collections, monitors,
global JNI references and outstanding string-copy buffers. Java execution uses
owned register/PC/exception frames with explicit call/return continuations.
Detached stacks keep GC root leases for local registers and returned references.
Every 4096 DEX instructions the synchronous entry point detaches/reattaches its
context and can process an advisory GC request at top level. Java-to-Java calls
do not require a Rust call stack. Library callbacks and class initialization
remain synchronous. A full thread scheduler, waits, thread-owned monitors and
native thread contexts are not connected; Thread.start still rejects that gap.

Typed Java exceptions propagate separately from runtime capability errors.
DEX handlers can catch implemented Java faults; they cannot hide an unsupported
framework call by catching a manufactured success/error. VM/class/JNI tables are
read-only guest data, stubs are executable-only where required, and JNI buffers
are bounded guest mappings. C stack guards are randomized before guest code.
General ELF TLS modules and multithreading are still unsupported.

The process supervisor owns lifetime and deadlines. Non-root execution, W^X,
RLIMITs, no_new_privs, syscall filtering, descriptor closure and checked memory
form the containment boundary. Dynarmic alone is not treated as a security
boundary. The prototype is not independently audited.

Full Android Framework/ART behavior, resources, GPU surfaces, media, system
services and general networking/filesystem support remain major work. A Java
or native call is implemented only when its behavior can be tested; unknown
calls do not return success. Corpus reports record the first blocker, rather
than a claim that resolving that blocker will make an entire app work.

Implementation inventory, budgets, build and tests are in README.md. Required
evidence includes actual ARM32/64 execution, multidex calls, typed exceptions,
registered JNI, packed relocations, malformed-input limits, process containment,
supervisor cleanup, legacy profile migration, Qt loading, corpus results and a
fresh Live boot. Historical compatibility results from old releases do not
apply to current Native.
