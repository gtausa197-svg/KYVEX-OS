package org.kyvex.extra;
import java.io.ObjectStreamField;
import java.lang.reflect.Constructor;
/** Unchanged source runs on a stock JRE and the guest's field description API. */
public final class StreamFieldChecks {
 private static int checks;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 private static final class OffsetField extends ObjectStreamField {
  OffsetField(String name,Class<?> type){super(name,type,true);}
  void offset(int value){setOffset(value);}
 }
 public static int verify() throws Exception {
  checks=0;String name=new String(new char[]{'g','u','e','s','t'});
  ObjectStreamField integer=new ObjectStreamField(name,int.class);
  check(integer.getName()==name,"Name identity");check(integer.getType()==int.class,"Primitive Class identity");
  check(integer.getTypeCode()=='I'&&integer.isPrimitive(),"Primitive type code");check(integer.getTypeString()==null,"Primitive signature getter is null");
  check(!integer.isUnshared()&&integer.getOffset()==0,"Default flags and offset");check(integer.toString().equals("I guest"),"Primitive text");
  Class<?>[] types={boolean.class,byte.class,char.class,short.class,int.class,long.class,float.class,double.class,void.class};String codes="ZBCSIJFDV";
  for(int i=0;i<types.length;i++){ObjectStreamField next=new ObjectStreamField("field",types[i],true);check(next.getType()==types[i]&&next.getTypeCode()==codes.charAt(i)&&next.isPrimitive()&&next.getTypeString()==null&&next.isUnshared(),"All primitive type descriptors");}
  ObjectStreamField string=new ObjectStreamField("text",String.class,true);
  check(string.getType()==String.class&&string.getTypeCode()=='L'&&!string.isPrimitive()&&string.isUnshared(),"Reference Class and flags");
  check(string.getTypeString().equals("Ljava/lang/String;"),"Class signature");check(string.getTypeString()==new ObjectStreamField("other",String.class).getTypeString(),"Reference signatures are interned");
  check(string.toString().equals("Ljava/lang/String; text")&&String.valueOf(string).equals(string.toString()),"Reference text through Object conversion");
  ObjectStreamField array=new ObjectStreamField("array",String[][].class);check(array.getType()==String[][].class&&array.getTypeCode()=='['&&!array.isPrimitive()&&array.getTypeString().equals("[[Ljava/lang/String;"),"Nested reference array signature");
  ObjectStreamField primitiveArray=new ObjectStreamField("array",int[][].class);check(primitiveArray.getType()==int[][].class&&primitiveArray.getTypeCode()=='['&&!primitiveArray.isPrimitive()&&primitiveArray.getTypeString().equals("[[I"),"Nested primitive array is reference");
  check(integer.compareTo(string)<0&&string.compareTo(integer)>0,"Primitives sort before references");
  check(new ObjectStreamField("z",long.class).compareTo(new ObjectStreamField("a",double.class))==25,"Primitive names use actual Java character comparison");
  check(new ObjectStreamField("ab",String.class).compareTo(new ObjectStreamField("abcd",Object.class))==-2,"Name comparison preserves prefix length difference");
  check(new ObjectStreamField("same",int.class).compareTo(new ObjectStreamField("same",long.class))==0,"Equal primitive names compare equal across types");
  check(new ObjectStreamField("same",String.class).compareTo(new ObjectStreamField("same",Object.class))==0,"Equal reference names compare equal across types");
  check(integer instanceof Comparable&&integer.compareTo(integer)==0,"Comparable identity and self comparison");
  ObjectStreamField equalName=new ObjectStreamField(name,int.class);check(integer!=equalName&&!integer.equals(equalName),"Field descriptors retain Object identity equality");
  OffsetField offset=new OffsetField("offset",Object.class);offset.offset(1234);check(offset.getOffset()==1234&&offset.isUnshared(),"Protected offset setter works from guest subclass");offset.offset(-7);check(offset.getOffset()==-7,"Signed offset preserved");
  ObjectStreamField unicode=new ObjectStreamField(new String(new char[]{'x','\ud800','y'}),String.class);check(unicode.getName().charAt(1)=='\ud800'&&unicode.toString().charAt(20)=='\ud800',"UTF16 including isolated surrogate is preserved");
  try{new ObjectStreamField(null,String.class);throw new IllegalStateException("Null name accepted");}catch(NullPointerException expected){checks++;}
  try{new ObjectStreamField("bad",null);throw new IllegalStateException("Null type accepted");}catch(NullPointerException expected){checks++;}
  try{integer.compareTo(null);throw new IllegalStateException("Null comparison accepted");}catch(NullPointerException expected){checks++;}
  try{integer.compareTo("wrong");throw new IllegalStateException("Wrong comparison accepted");}catch(ClassCastException expected){checks++;}
  Constructor<ObjectStreamField> constructor=ObjectStreamField.class.getDeclaredConstructor(String.class,Class.class,boolean.class);
  ObjectStreamField reflected=constructor.newInstance("reflect",long[].class,true);check(reflected.getType()==long[].class&&reflected.getTypeString().equals("[J")&&reflected.isUnshared(),"Reflective public constructor preserves arguments");
  System.gc();check(integer.getName()==name&&string.getTypeString().equals("Ljava/lang/String;")&&offset.getOffset()==-7,"Actual descriptors survive collection while live");
  return checks;
 }
 public static int report(){try{return verify();}catch(Exception e){throw new IllegalStateException(e);}}
 public static void main(String[] args)throws Exception{System.out.println("Stream field checks: "+verify());}
}
