//! Public coordinate fields and local geometry for Android Rect and RectF.
use super::*;

pub(super) const PARCELABLE: &str = "Landroid/os/Parcelable;";
const RECT: &str = "Landroid/graphics/Rect;";
const RECT_F: &str = "Landroid/graphics/RectF;";
const NAMES: [&str; 4] = ["left", "top", "right", "bottom"];

pub(super) fn parent(class: &str) -> Option<&'static str> {
    matches!(class, RECT | RECT_F | PARCELABLE).then_some("Ljava/lang/Object;")
}

pub(super) fn inherits(class: &str, base: &str) -> bool {
    matches!(class, RECT | RECT_F) && base == PARCELABLE
}

pub(super) fn declared_field(class: &str, name: &str) -> Option<(&'static str, u32)> {
    if !NAMES.contains(&name) {
        return None;
    }
    Some((
        match class {
            RECT => "I",
            RECT_F => "F",
            _ => return None,
        },
        1,
    ))
}

pub(super) fn payload(class: &str) -> Option<Payload> {
    matches!(class, RECT | RECT_F).then(|| Payload::Record(BTreeMap::new()))
}

fn nonempty<T: PartialOrd>([left, top, right, bottom]: [T; 4]) -> bool {
    left < right && top < bottom
}

fn contains_point<T: PartialOrd + Copy>(edges: [T; 4], x: T, y: T) -> bool {
    let [left, top, right, bottom] = edges;
    nonempty(edges) && left <= x && x < right && top <= y && y < bottom
}

fn contains_bounds<T: PartialOrd + Copy>(outer: [T; 4], inner: [T; 4]) -> bool {
    let [l, t, r, b] = outer;
    let [left, top, right, bottom] = inner;
    nonempty(outer) && l <= left && t <= top && right <= r && bottom <= b
}

fn intersects<T: PartialOrd>([l, t, r, b]: [T; 4], [left, top, right, bottom]: [T; 4]) -> bool {
    l < right && left < r && t < bottom && top < b
}

fn lesser<T: PartialOrd>(a: T, b: T) -> T {
    if b < a { b } else { a }
}

fn greater<T: PartialOrd>(a: T, b: T) -> T {
    if b > a { b } else { a }
}

fn intersection<T: PartialOrd>([l, t, r, b]: [T; 4], [left, top, right, bottom]: [T; 4]) -> [T; 4] {
    [
        greater(l, left),
        greater(t, top),
        lesser(r, right),
        lesser(b, bottom),
    ]
}

fn union<T: PartialOrd + Copy>(a: [T; 4], b: [T; 4]) -> [T; 4] {
    if !nonempty(b) {
        return a;
    }
    if !nonempty(a) {
        return b;
    }
    let [l, t, r, bottom] = a;
    let [left, top, right, other_bottom] = b;
    [
        lesser(l, left),
        lesser(t, top),
        greater(r, right),
        greater(bottom, other_bottom),
    ]
}

fn arg(args: &[u32], i: usize) -> Result<u32> {
    args.get(i)
        .copied()
        .ok_or_else(|| "Rectangle argument".into())
}

fn coordinates(args: &[u32]) -> Result<[u32; 4]> {
    Ok([arg(args, 1)?, arg(args, 2)?, arg(args, 3)?, arg(args, 4)?])
}

fn hash(words: [u32; 4]) -> u64 {
    u64::from(
        words
            .into_iter()
            .fold(0u32, |acc, word| acc.wrapping_mul(31).wrapping_add(word)),
    )
}

fn float_hash(value: f32) -> u32 {
    if value == 0.0 {
        0
    } else if value.is_nan() {
        0x7fc0_0000
    } else {
        value.to_bits()
    }
}

fn round_coordinate(value: f32) -> i32 {
    // API 28 RectF uses fixed-point FastMath rounding.
    ((value * 16_777_216.0) as i64)
        .wrapping_add(0x0080_0000)
        .wrapping_shr(24) as i32
}

fn boolean(value: bool) -> Result<Option<u64>> {
    Ok(Some(u64::from(value)))
}

impl Runtime {
    fn rectangle_words(&self, id: u32, class: &str) -> Result<[u32; 4]> {
        let object = self.object(id)?;
        if object.class == class
            && let Payload::Record(fields) = &object.payload
        {
            return Ok(NAMES.map(|name| fields.get(name).copied().unwrap_or(0) as u32));
        }
        Err(fault(
            "Ljava/lang/ClassCastException;",
            "Expected an Android rectangle",
        ))
    }

    fn rectangle_ints(&self, id: u32) -> Result<[i32; 4]> {
        Ok(self.rectangle_words(id, RECT)?.map(|value| value as i32))
    }

    fn rectangle_floats(&self, id: u32) -> Result<[f32; 4]> {
        Ok(self.rectangle_words(id, RECT_F)?.map(f32::from_bits))
    }

    fn write_rectangle(&mut self, id: u32, class: &str, words: [u32; 4]) -> Result<()> {
        let object = self.object_mut(id)?;
        if object.class == class
            && let Payload::Record(fields) = &mut object.payload
        {
            for (name, value) in NAMES.into_iter().zip(words) {
                fields.insert(name.into(), u64::from(value));
            }
            return Ok(());
        }
        Err(fault(
            "Ljava/lang/ClassCastException;",
            "Expected an Android rectangle",
        ))
    }

    pub(super) fn rect_api(&mut self, sig: &str, args: &[u32]) -> Result<Option<u64>> {
        let Some((class, method)) = sig.split_once("->") else {
            return Ok(None);
        };
        match class {
            RECT => self.rect_int_api(method, args),
            RECT_F => self.rect_float_api(method, args),
            _ => Ok(None),
        }
    }

    fn rect_int_api(&mut self, method: &str, args: &[u32]) -> Result<Option<u64>> {
        let Some(&id) = args.first() else {
            return Ok(None);
        };
        let bounds = self.rectangle_ints(id)?;
        let [left, top, right, bottom] = bounds;
        let integer = |i| -> Result<i32> { Ok(arg(args, i)? as i32) };
        let value = |integer: i32| Ok(Some(u64::from(integer as u32)));
        let coords = || -> Result<[i32; 4]> { Ok(coordinates(args)?.map(|value| value as i32)) };
        let new_bounds = match method {
            "<init>()V" | "setEmpty()V" => [0; 4],
            "<init>(IIII)V" | "set(IIII)V" => coords()?,
            "<init>(Landroid/graphics/Rect;)V" if arg(args, 1)? == 0 => [0; 4],
            "<init>(Landroid/graphics/Rect;)V" | "set(Landroid/graphics/Rect;)V" => {
                self.rectangle_ints(arg(args, 1)?)?
            }
            "width()I" => return value(right.wrapping_sub(left)),
            "height()I" => return value(bottom.wrapping_sub(top)),
            "centerX()I" => return value(left.wrapping_add(right) >> 1),
            "centerY()I" => return value(top.wrapping_add(bottom) >> 1),
            "exactCenterX()F" => {
                return value((left.wrapping_add(right) as f32 * 0.5).to_bits() as i32);
            }
            "exactCenterY()F" => {
                return value((top.wrapping_add(bottom) as f32 * 0.5).to_bits() as i32);
            }
            "isEmpty()Z" => return boolean(left >= right || top >= bottom),
            "contains(II)Z" => return boolean(contains_point(bounds, integer(1)?, integer(2)?)),
            "contains(IIII)Z" => return boolean(contains_bounds(bounds, coords()?)),
            "contains(Landroid/graphics/Rect;)Z" => {
                return boolean(contains_bounds(bounds, self.rectangle_ints(arg(args, 1)?)?));
            }
            "intersects(Landroid/graphics/Rect;Landroid/graphics/Rect;)Z" => {
                return boolean(intersects(bounds, self.rectangle_ints(arg(args, 1)?)?));
            }
            "intersect(IIII)Z" | "intersect(Landroid/graphics/Rect;)Z" => {
                let other = if method == "intersect(IIII)Z" {
                    coords()?
                } else {
                    self.rectangle_ints(arg(args, 1)?)?
                };
                let overlaps = intersects(bounds, other);
                if overlaps {
                    self.write_rectangle(id, RECT, intersection(bounds, other).map(|v| v as u32))?;
                }
                return boolean(overlaps);
            }
            "offset(II)V" | "inset(II)V" => {
                let (x, y) = (integer(1)?, integer(2)?);
                let (right_delta, bottom_delta) = if method == "offset(II)V" {
                    (x, y)
                } else {
                    (x.wrapping_neg(), y.wrapping_neg())
                };
                [
                    left.wrapping_add(x),
                    top.wrapping_add(y),
                    right.wrapping_add(right_delta),
                    bottom.wrapping_add(bottom_delta),
                ]
            }
            "offsetTo(II)V" => {
                let (x, y) = (integer(1)?, integer(2)?);
                [
                    x,
                    y,
                    right.wrapping_add(x.wrapping_sub(left)),
                    bottom.wrapping_add(y.wrapping_sub(top)),
                ]
            }
            "equals(Ljava/lang/Object;)Z" => {
                let other = arg(args, 1)?;
                return boolean(
                    other != 0
                        && self.object(other)?.class == RECT
                        && bounds == self.rectangle_ints(other)?,
                );
            }
            "hashCode()I" => return Ok(Some(hash(bounds.map(|v| v as u32)))),
            "toString()Ljava/lang/String;" => {
                return Ok(Some(u64::from(
                    self.string(&format!("Rect({left}, {top} - {right}, {bottom})"))?,
                )));
            }
            "describeContents()I" => return Ok(Some(0)),
            _ => return Ok(None),
        };
        self.write_rectangle(id, RECT, new_bounds.map(|v| v as u32))?;
        Ok(Some(0))
    }

    fn rect_float_api(&mut self, method: &str, args: &[u32]) -> Result<Option<u64>> {
        let Some(&id) = args.first() else {
            return Ok(None);
        };
        let bounds = self.rectangle_floats(id)?;
        let [left, top, right, bottom] = bounds;
        let float = |i| -> Result<f32> { Ok(f32::from_bits(arg(args, i)?)) };
        let value = |float: f32| Ok(Some(u64::from(float.to_bits())));
        let coords = || -> Result<[f32; 4]> { Ok(coordinates(args)?.map(f32::from_bits)) };
        let new_bounds = match method {
            "<init>()V" | "setEmpty()V" => [0.0; 4],
            "<init>(FFFF)V" | "set(FFFF)V" => coords()?,
            "<init>(Landroid/graphics/RectF;)V" | "<init>(Landroid/graphics/Rect;)V"
                if arg(args, 1)? == 0 =>
            {
                [0.0; 4]
            }
            "<init>(Landroid/graphics/RectF;)V" | "set(Landroid/graphics/RectF;)V" => {
                self.rectangle_floats(arg(args, 1)?)?
            }
            "<init>(Landroid/graphics/Rect;)V" | "set(Landroid/graphics/Rect;)V" => self
                .rectangle_ints(arg(args, 1)?)?
                .map(|value| value as f32),
            "width()F" => return value(right - left),
            "height()F" => return value(bottom - top),
            "centerX()F" => return value((left + right) * 0.5),
            "centerY()F" => return value((top + bottom) * 0.5),
            "isEmpty()Z" => return boolean(left >= right || top >= bottom),
            "contains(FF)Z" => return boolean(contains_point(bounds, float(1)?, float(2)?)),
            "contains(FFFF)Z" => return boolean(contains_bounds(bounds, coords()?)),
            "contains(Landroid/graphics/RectF;)Z" => {
                return boolean(contains_bounds(
                    bounds,
                    self.rectangle_floats(arg(args, 1)?)?,
                ));
            }
            "intersects(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z" => {
                return boolean(intersects(bounds, self.rectangle_floats(arg(args, 1)?)?));
            }
            "intersect(FFFF)Z" | "intersect(Landroid/graphics/RectF;)Z" => {
                let other = if method == "intersect(FFFF)Z" {
                    coords()?
                } else {
                    self.rectangle_floats(arg(args, 1)?)?
                };
                let overlaps = intersects(bounds, other);
                if overlaps {
                    self.write_rectangle(
                        id,
                        RECT_F,
                        intersection(bounds, other).map(f32::to_bits),
                    )?;
                }
                return boolean(overlaps);
            }
            "setIntersect(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z" => {
                let a = self.rectangle_floats(arg(args, 1)?)?;
                let b = self.rectangle_floats(arg(args, 2)?)?;
                let overlaps = intersects(a, b);
                if overlaps {
                    let mut result = intersection(a, b).map(f32::to_bits);
                    for (i, word) in result.iter_mut().enumerate() {
                        if a[i] == 0.0 && b[i] == 0.0 {
                            // Math.max chooses positive zero, Math.min negative zero.
                            *word = if i < 2 {
                                a[i].to_bits() & b[i].to_bits()
                            } else {
                                a[i].to_bits() | b[i].to_bits()
                            };
                        }
                    }
                    self.write_rectangle(id, RECT_F, result)?;
                }
                return boolean(overlaps);
            }
            "union(FFFF)V" => union(bounds, coords()?),
            "union(Landroid/graphics/RectF;)V" => {
                union(bounds, self.rectangle_floats(arg(args, 1)?)?)
            }
            "union(FF)V" => {
                let (x, y) = (float(1)?, float(2)?);
                [
                    lesser(left, x),
                    lesser(top, y),
                    if x < left { right } else { greater(right, x) },
                    if y < top { bottom } else { greater(bottom, y) },
                ]
            }
            "offset(FF)V" | "inset(FF)V" => {
                let (x, y) = (float(1)?, float(2)?);
                if method == "offset(FF)V" {
                    [left + x, top + y, right + x, bottom + y]
                } else {
                    [left + x, top + y, right - x, bottom - y]
                }
            }
            "round(Landroid/graphics/Rect;)V" | "roundOut(Landroid/graphics/Rect;)V" => {
                let integer = if method == "round(Landroid/graphics/Rect;)V" {
                    bounds.map(round_coordinate)
                } else {
                    [
                        left.floor() as i32,
                        top.floor() as i32,
                        right.ceil() as i32,
                        bottom.ceil() as i32,
                    ]
                };
                self.write_rectangle(arg(args, 1)?, RECT, integer.map(|v| v as u32))?;
                return Ok(Some(0));
            }
            "equals(Ljava/lang/Object;)Z" => {
                let other = arg(args, 1)?;
                return boolean(
                    other == id
                        || (other != 0
                            && self.object(other)?.class == RECT_F
                            && bounds == self.rectangle_floats(other)?),
                );
            }
            "hashCode()I" => return Ok(Some(hash(bounds.map(float_hash)))),
            "describeContents()I" => return Ok(Some(0)),
            _ => return Ok(None),
        };
        self.write_rectangle(id, RECT_F, new_bounds.map(f32::to_bits))?;
        Ok(Some(0))
    }
}
