package org.kyvex.extra;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public final class ReadWriteChecks {
    private static int checks;

    private static void check(boolean condition, String name) {
        if (!condition) throw new IllegalStateException(name);
        checks++;
    }

    private static void queued(ReentrantReadWriteLock lock, Thread worker) {
        for (int attempt = 0; attempt < 65536 && !lock.hasQueuedThread(worker); attempt++) {
            Thread.yield();
        }
        if (!lock.hasQueuedThread(worker)) throw new IllegalStateException("Guest waiter never queued");
    }

    private static void join(Thread thread) {
        try { thread.join(); }
        catch (InterruptedException unexpected) { throw new IllegalStateException(unexpected); }
    }

    public static int verify() {
        checks = 0;
        final ReentrantReadWriteLock lock = new ReentrantReadWriteLock(true);
        ReadWriteLock api = lock;
        final Lock read = api.readLock();
        final Lock write = api.writeLock();
        check(lock.isFair() && read == lock.readLock() && write == lock.writeLock(), "Fair lock with stable views");
        read.lock();
        read.lock();
        check(lock.getReadHoldCount() == 2 && lock.getReadLockCount() == 2 && !write.tryLock(), "Reader reentrancy and blocked promotion");
        read.unlock();
        read.unlock();
        write.lock();
        write.lock();
        read.lock();
        check(lock.getWriteHoldCount() == 2 && lock.writeLock().isHeldByCurrentThread()
                && lock.getReadHoldCount() == 1, "Writer reentrancy and nested read");
        write.unlock();
        write.unlock();
        check(!lock.isWriteLocked() && lock.getReadLockCount() == 1, "Downgrade preserves read hold");

        final int[] shared = {0};
        Thread secondReader = new Thread(new Runnable() {
            public void run() {
                read.lock();
                try { shared[0] = lock.getReadLockCount(); }
                finally { read.unlock(); }
            }
        });
        secondReader.start();
        join(secondReader);
        check(shared[0] == 2 && lock.getReadLockCount() == 1, "Two simultaneous guest readers");

        final int[] order = {0, 0};
        Thread writer = new Thread(new Runnable() {
            public void run() {
                write.lock();
                try { order[0] = 1; }
                finally { write.unlock(); }
            }
        });
        Thread laterReader = new Thread(new Runnable() {
            public void run() {
                read.lock();
                try { order[1] = order[0] + 1; }
                finally { read.unlock(); }
            }
        });
        writer.start();
        queued(lock, writer);
        laterReader.start();
        queued(lock, laterReader);
        check(lock.hasQueuedThreads() && lock.getQueueLength() == 2 && read.tryLock(), "Queued writer and reader with reentrant tryLock");
        read.unlock();
        read.unlock();
        join(writer);
        join(laterReader);
        check(order[1] == 2 && !lock.hasQueuedThreads(), "Fair writer precedes later reader");

        final boolean[] timedOut = {false};
        write.lock();
        Thread timer = new Thread(new Runnable() {
            public void run() {
                try {
                    boolean acquired = read.tryLock(5L, TimeUnit.MILLISECONDS);
                    if (acquired) read.unlock();
                    timedOut[0] = !acquired;
                } catch (InterruptedException unexpected) {
                    throw new IllegalStateException(unexpected);
                }
            }
        });
        timer.start();
        join(timer);
        check(timedOut[0] && lock.isWriteLockedByCurrentThread(), "Timed reader waits behind writer");
        write.unlock();

        final boolean[] interrupted = {false};
        read.lock();
        Thread cancelled = new Thread(new Runnable() {
            public void run() {
                try {
                    write.lockInterruptibly();
                    write.unlock();
                } catch (InterruptedException expected) {
                    interrupted[0] = !Thread.currentThread().isInterrupted();
                }
            }
        });
        cancelled.start();
        queued(lock, cancelled);
        cancelled.interrupt();
        join(cancelled);
        check(interrupted[0] && !lock.hasQueuedThreads() && lock.getReadHoldCount() == 1,
                "Interrupted writer leaves the queue and clears interruption");
        read.unlock();

        boolean invalidOwner = false;
        try { write.unlock(); }
        catch (IllegalMonitorStateException expected) { invalidOwner = true; }
        check(invalidOwner && !lock.isWriteLocked(), "Foreign unlock rejected");
        boolean conditionUnsupported = false;
        try { read.newCondition(); }
        catch (UnsupportedOperationException expected) { conditionUnsupported = true; }
        check(conditionUnsupported, "Read locks cannot create conditions");
        return checks;
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Read/write lock checks: " + verify());
    }
}
