//! APK loading never extracts archive paths to the host filesystem.
use crate::{
    Result,
    assets::{Assets, member},
    dexfile::Dex,
};
use rift_core::apk::{self, Apk};
use std::{collections::BTreeMap, fs::File, os::fd::AsRawFd, path::Path};
pub struct Package {
    pub info: Apk,
    pub dex: Dex,
    pub libraries: Assets,
    pub arch: u32,
    pub abi: String,
}
impl Package {
    pub fn open(path: &Path, abi: &str) -> Result<Self> {
        let file = File::open(path)?;
        if !file.metadata()?.is_file() || file.metadata()?.len() > 2 * 1024 * 1024 * 1024 {
            return Err("Native APK size quota (2 GiB)".into());
        }
        let info = apk::inspect(path)?;
        if info.split || info.dex_files == 0 || info.dex_files > 128 {
            return Err("Native requires a standalone APK with 1–128 DEX files; split-install sets are not implemented".into());
        }
        if info.launcher.is_empty() {
            return Err("APK has no launcher activity".into());
        }
        let selected = match abi {
            "auto" => {
                if info.abis.contains(&"arm64-v8a".into()) {
                    "arm64-v8a"
                } else if info.abis.contains(&"armeabi-v7a".into()) {
                    "armeabi-v7a"
                } else if info.abis.is_empty() {
                    "arm64-v8a"
                } else {
                    return Err("Native 0.3 implements ARM ABIs, not x86 Android libraries".into());
                }
            }
            "arm64-v8a" | "armeabi-v7a" => abi,
            _ => return Err("Native ABI must be Auto, ARM32 or ARM64".into()),
        };
        if !info.abis.is_empty() && !info.abis.iter().any(|a| a == selected) {
            return Err("The APK has no libraries for the selected ARM ABI".into());
        }
        let fd = file.as_raw_fd();
        let mut zip = zip::ZipArchive::new(rift_core::archive::CachedReader::new(file)?)?;
        let dex = Dex::parse(&member(&mut zip, "classes.dex", 32 * 1024 * 1024)?)?;
        let prefix = format!("lib/{selected}/");
        let mut names = Vec::new();
        let mut dex_names = Vec::new();
        for i in 0..zip.len() {
            let f = zip.by_index(i)?;
            let name = f.name();
            if let Some(number) = name
                .strip_prefix("classes")
                .and_then(|n| n.strip_suffix(".dex"))
            {
                let index = if number.is_empty() {
                    1
                } else {
                    number
                        .parse::<usize>()
                        .map_err(|_| "Noncanonical multidex filename")?
                };
                if index == 0 || index > 128 || (index > 1 && number != index.to_string()) {
                    return Err("Noncanonical multidex filename".into());
                }
                dex_names.push((index, name.to_owned()));
            }
            if let Some(base) = name.strip_prefix(&prefix)
                && base.ends_with(".so")
            {
                if base.contains('/')
                    || base.len() > 100
                    || !base.bytes().all(|c| {
                        c.is_ascii_alphanumeric() || matches!(c, b'_' | b'.' | b'-' | b'+')
                    })
                {
                    return Err("Invalid native library archive name".into());
                }
                names.push(name.to_owned());
            }
        }
        if names.len() > 512 {
            return Err("Native library count quota (512 per ABI)".into());
        }
        let mut libraries = BTreeMap::new();
        for name in names {
            if libraries
                .insert(name[prefix.len()..].to_owned(), name)
                .is_some()
            {
                return Err("Duplicate APK native library".into());
            }
        }
        dex_names.sort_by_key(|n| n.0);
        if dex_names.iter().enumerate().any(|(i, n)| n.0 != i + 1) {
            return Err("Multidex filenames must be contiguous from classes.dex".into());
        }
        let libraries = Assets::new(
            zip,
            fd,
            libraries,
            dex_names.into_iter().map(|n| n.1).collect(),
        );
        Ok(Self {
            info,
            dex,
            libraries,
            arch: if selected == "arm64-v8a" { 64 } else { 32 },
            abi: selected.into(),
        })
    }
}
