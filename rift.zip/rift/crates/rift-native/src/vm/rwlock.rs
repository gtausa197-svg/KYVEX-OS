//! Reentrant read/write locking on the existing cooperative guest wait queue.
use super::*;

pub(super) const RW_LOCK: &str = "Ljava/util/concurrent/locks/ReentrantReadWriteLock;";
pub(super) const READ_VIEW: &str = "Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;";
pub(super) const WRITE_VIEW: &str = "Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;";
pub(super) const RW_INTERFACE: &str = "Ljava/util/concurrent/locks/ReadWriteLock;";
pub(super) const LOCK_INTERFACE: &str = "Ljava/util/concurrent/locks/Lock;";
const HOLD_LIMIT: u32 = 65535;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Mode {
    Read,
    Write,
}

#[derive(Clone, Copy)]
pub(super) struct View {
    pub(super) parent: u32,
    mode: Mode,
}

#[derive(Default)]
pub(super) struct RwLock {
    views: [u32; 2],
    readers: BTreeMap<u32, u32>,
    writer: u32,
    write_holds: u32,
    fair: bool,
}

impl RwLock {
    pub(super) fn roots(&self) -> impl Iterator<Item = u32> + '_ {
        self.views
            .into_iter()
            .chain([self.writer])
            .chain(self.readers.keys().copied())
    }

    pub(super) fn bytes(&self) -> usize {
        self.readers.len() * 32
    }

    fn read_count(&self) -> u32 {
        self.readers.values().copied().sum()
    }

    fn read_holds(&self, thread: u32) -> u32 {
        self.readers.get(&thread).copied().unwrap_or(0)
    }

    fn write_holds(&self, thread: u32) -> u32 {
        if self.writer == thread {
            self.write_holds
        } else {
            0
        }
    }
}

pub(super) fn inherits(class: &str, base: &str) -> bool {
    (class == RW_LOCK && matches!(base, RW_INTERFACE | "Ljava/io/Serializable;"))
        || (matches!(class, READ_VIEW | WRITE_VIEW)
            && matches!(base, LOCK_INTERFACE | "Ljava/io/Serializable;"))
}

fn owner_error() -> Box<dyn std::error::Error + Send + Sync> {
    fault(
        "Ljava/lang/IllegalMonitorStateException;",
        "Current thread does not own the lock",
    )
}

impl Runtime {
    fn rw(&self, id: u32) -> Result<&RwLock> {
        match &self.object(id)?.payload {
            Payload::RwLock(lock) => Ok(lock),
            _ => Err("Expected ReentrantReadWriteLock".into()),
        }
    }

    fn rw_mut(&mut self, id: u32) -> Result<&mut RwLock> {
        match &mut self.object_mut(id)?.payload {
            Payload::RwLock(lock) => Ok(lock),
            _ => Err("Expected ReentrantReadWriteLock".into()),
        }
    }

    fn rw_waiters(&self, [read, write]: [u32; 2]) -> impl Iterator<Item = (u32, Mode, u64)> + '_ {
        self.scheduler
            .records
            .iter()
            .filter_map(move |(&thread, record)| {
                let scheduler::State::Waiting(scheduler::Wait::Lock { object, .. }) = &record.state
                else {
                    return None;
                };
                let mode = if *object == read {
                    Mode::Read
                } else if *object == write {
                    Mode::Write
                } else {
                    return None;
                };
                Some((thread, mode, record.wait_order))
            })
    }

    fn rw_view(&mut self, parent: u32, mode: Mode) -> Result<u32> {
        let (slot, class) = match mode {
            Mode::Read => (0, READ_VIEW),
            Mode::Write => (1, WRITE_VIEW),
        };
        let current = self.rw(parent)?.views[slot];
        if current != 0 {
            return Ok(current);
        }
        let id = self.allocate(class, Payload::RwView(View { parent, mode }))?;
        self.rw_mut(parent)?.views[slot] = id;
        Ok(id)
    }

    pub(super) fn acquire_rw_for(&mut self, view: View, thread: u32, queued: bool) -> Result<bool> {
        let lock = self.rw(view.parent)?;
        if lock.writer != 0 && lock.writer != thread {
            return Ok(false);
        }
        if view.mode == Mode::Write && lock.writer != thread && !lock.readers.is_empty() {
            return Ok(false);
        }
        let reentrant =
            lock.writer == thread || (view.mode == Mode::Read && lock.read_holds(thread) != 0);
        if queued
            && !reentrant
            && let Some((head, mode, _)) = self.rw_waiters(lock.views).min_by_key(|waiter| waiter.2)
            && head != thread
            && (lock.fair || (view.mode == Mode::Read && mode == Mode::Write))
        {
            return Ok(false);
        }
        let lock = self.rw_mut(view.parent)?;
        match view.mode {
            Mode::Read => {
                if lock.read_count() >= HOLD_LIMIT {
                    return Err(fault(
                        "Ljava/lang/Error;",
                        "Maximum read lock count exceeded",
                    ));
                }
                *lock.readers.entry(thread).or_default() += 1;
            }
            Mode::Write => {
                if lock.write_holds >= HOLD_LIMIT {
                    return Err(fault(
                        "Ljava/lang/Error;",
                        "Maximum write lock count exceeded",
                    ));
                }
                lock.writer = thread;
                lock.write_holds += 1;
            }
        }
        Ok(true)
    }

    fn release_rw(&mut self, view: View) -> Result<()> {
        let thread = self.current_thread;
        let lock = self.rw_mut(view.parent)?;
        match view.mode {
            Mode::Read => {
                let held = lock.readers.get_mut(&thread).ok_or_else(owner_error)?;
                *held -= 1;
                if *held == 0 {
                    lock.readers.remove(&thread);
                }
            }
            Mode::Write => {
                if lock.write_holds(thread) == 0 {
                    return Err(owner_error());
                }
                lock.write_holds -= 1;
                if lock.write_holds == 0 {
                    lock.writer = 0;
                }
            }
        }
        Ok(())
    }

    pub(super) fn rwlock_api(
        &mut self,
        class: &str,
        method: &str,
        args: &[u32],
    ) -> Result<Option<u64>> {
        if !matches!(
            class,
            RW_LOCK | RW_INTERFACE | READ_VIEW | WRITE_VIEW | LOCK_INTERFACE
        ) {
            return Ok(None);
        }
        let arg = |index: usize| args.get(index).copied().ok_or("Read/write lock argument");
        let id = arg(0)?;
        if let Payload::RwView(view) = self.object(id)?.payload {
            if let Some(result) = self.wait_for_lock(method, args)? {
                return Ok(Some(result));
            }
            self.ensure_main_thread()?;
            return Ok(Some(match method {
                "unlock()V" => {
                    self.release_rw(view)?;
                    0
                }
                "isHeldByCurrentThread()Z" if view.mode == Mode::Write => {
                    u64::from(self.rw(view.parent)?.write_holds(self.current_thread) != 0)
                }
                "getHoldCount()I" if view.mode == Mode::Write => {
                    u64::from(self.rw(view.parent)?.write_holds(self.current_thread))
                }
                "newCondition()Ljava/util/concurrent/locks/Condition;"
                    if view.mode == Mode::Read =>
                {
                    return Err(fault(
                        "Ljava/lang/UnsupportedOperationException;",
                        "Read locks have no Condition",
                    ));
                }
                _ => return Ok(None),
            }));
        }
        if !matches!(class, RW_LOCK | RW_INTERFACE) {
            return Ok(None);
        }
        if matches!(method, "<init>()V" | "<init>(Z)V") {
            self.rw_mut(id)?.fair = method == "<init>(Z)V" && arg(1)? != 0;
            return Ok(Some(0));
        }
        match method {
            "readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;"
            | "readLock()Ljava/util/concurrent/locks/Lock;" => {
                return Ok(Some(u64::from(self.rw_view(id, Mode::Read)?)));
            }
            "writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;"
            | "writeLock()Ljava/util/concurrent/locks/Lock;" => {
                return Ok(Some(u64::from(self.rw_view(id, Mode::Write)?)));
            }
            _ => {}
        }
        self.ensure_main_thread()?;
        let lock = self.rw(id)?;
        let value = match method {
            "isFair()Z" => u64::from(lock.fair),
            "getReadLockCount()I" => u64::from(lock.read_count()),
            "getReadHoldCount()I" => u64::from(lock.read_holds(self.current_thread)),
            "getWriteHoldCount()I" => u64::from(lock.write_holds(self.current_thread)),
            "isWriteLocked()Z" => u64::from(lock.writer != 0),
            "isWriteLockedByCurrentThread()Z" => {
                u64::from(lock.write_holds(self.current_thread) != 0)
            }
            "hasQueuedThreads()Z" => u64::from(self.rw_waiters(lock.views).next().is_some()),
            "getQueueLength()I" => self.rw_waiters(lock.views).count() as u64,
            "hasQueuedThread(Ljava/lang/Thread;)Z" => {
                let target = arg(1)?;
                self.object(target)?;
                u64::from(
                    self.rw_waiters(lock.views)
                        .any(|(thread, _, _)| thread == target),
                )
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}
