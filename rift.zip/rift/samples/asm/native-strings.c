/* One ARM ELF/JNI fixture for the API 28 Bionic character and string surface. */
typedef __SIZE_TYPE__ Size;
typedef __WCHAR_TYPE__ Wide;
typedef __WINT_TYPE__ WideInt;

extern int isalnum(int);
extern int isalpha(int);
extern int isblank(int);
extern int iscntrl(int);
extern int isdigit(int);
extern int isgraph(int);
extern int islower(int);
extern int isprint(int);
extern int ispunct(int);
extern int isspace(int);
extern int isupper(int);
extern int isxdigit(int);
extern int tolower(int);
extern int toupper(int);
extern int iswalnum(WideInt);
extern int iswalpha(WideInt);
extern int iswblank(WideInt);
extern int iswcntrl(WideInt);
extern int iswdigit(WideInt);
extern int iswgraph(WideInt);
extern int iswlower(WideInt);
extern int iswprint(WideInt);
extern int iswpunct(WideInt);
extern int iswspace(WideInt);
extern int iswupper(WideInt);
extern int iswxdigit(WideInt);
extern WideInt towlower(WideInt);
extern WideInt towupper(WideInt);
extern int strcmp(const char *, const char *);
extern int strcoll(const char *, const char *);
extern int strncmp(const char *, const char *, Size);
extern Size strxfrm(char *, const char *, Size);
extern char *strncpy(char *, const char *, Size);
extern char *strstr(const char *, const char *);
extern void *memchr(const void *, int, Size);
extern int wcscoll(const Wide *, const Wide *);
extern Size wcslen(const Wide *);
extern Size wcsxfrm(Wide *, const Wide *, Size);
extern Wide *wmemchr(const Wide *, Wide, Size);
extern int wmemcmp(const Wide *, const Wide *, Size);
extern Wide *wmemcpy(Wide *, const Wide *, Size);
extern Wide *wmemmove(Wide *, const Wide *, Size);
extern Wide *wmemset(Wide *, Wide, Size);
extern WideInt btowc(int);
extern int wctob(WideInt);
extern int *__errno(void);

int Java_org_kyvex_extra_LinkChecks_nativeStrings(void *env, void *type) {
    (void)env;
    (void)type;
    if (isxdigit('A') != 0x40 || isxdigit('0') != 0x04 || isxdigit('g') ||
        isxdigit(-1) || isalpha(0xe9) || isalnum('z') != 0x02 || isalpha('Z') != 1)
        return -1;
    if (isblank(' ') != 1 || isblank('\t') != 1 || isblank('\n') ||
        iscntrl(0x7f) != 0x20 || isspace('\v') != 8 || isdigit('9') != 4)
        return -2;
    if (isgraph(' ') || isgraph('!') != 0x10 || isprint(' ') != 0x80 ||
        isprint('\t') || ispunct('A') || ispunct('!') != 0x10 ||
        islower('f') != 2 || isupper('F') != 1)
        return -3;
    if (tolower('A') != 'a' || toupper('z') != 'Z' || tolower(-1) != -1 ||
        toupper(0xe9) != 0xe9 || tolower(0x141) != 0x141)
        return -4;

    const char high[] = { (char)0xff, 0 };
    const char low[] = { 0x7f, 0 };
    if (strcmp(high, low) <= 0 || strcmp("ab", "abc") >= 0 || strcmp("abc", "abc") ||
        strcoll("Z", "a") >= 0 || strncmp("abc", "abd", 2) || strncmp("abc", "abd", 3) >= 0)
        return -5;
    const char raw[] = { 'x', 0, (char)0xfe, 'y' };
    if (memchr(raw, 0, sizeof(raw)) != raw + 1 || memchr(raw, 0x1fe, sizeof(raw)) != raw + 2 ||
        memchr(raw, 0xfe, 2) || memchr(raw, 'x', 0))
        return -6;
    const char text[] = { 'a', (char)0xff, 'b', (char)0xff, 'b', 0 };
    if (strstr(text, "") != text || strstr(text, "\xff" "b") != text + 1 ||
        strstr(text, "\xff" "ba") || strstr("abababa", "ababa") == 0)
        return -7;
    char out[6] = { '?', '?', '?', '?', '?', '?' };
    if (strncpy(out, "ab", 5) != out || out[0] != 'a' || out[1] != 'b' ||
        out[2] || out[3] || out[4] || out[5] != '?' ||
        strncpy(out, "xyz", 2) != out || out[0] != 'x' || out[1] != 'y' || out[2] ||
        strncpy(out, "!", 0) != out || out[0] != 'x')
        return -8;
    if (strxfrm(0, "aBb", 0) != 3 || strxfrm(out, "aBb", 2) != 3 ||
        out[0] != 'a' || out[1] || strxfrm(out, "aBb", sizeof(out)) != 3 ||
        strcmp(out, "aBb") || out[5] != '?')
        return -9;

    if (!iswalpha(0x0490) || !iswalnum(0x0661) || !iswdigit(0x0661) ||
        !iswxdigit(0xff26) || iswxdigit('g') || !iswblank(0x2003) ||
        !iswspace(0x2003) || !iswcntrl(0x0085) || !iswpunct(0x2014) ||
        !iswgraph(0x1f680) || !iswprint(0x1f680) || iswgraph(0x2003) ||
        iswalpha((WideInt)-1) || iswprint((WideInt)-1))
        return -10;
    if (!iswlower(0x0491) || !iswupper(0x0490) || towlower(0x0490) != 0x0491 ||
        towupper(0x0491) != 0x0490 || towupper(0x10428) != 0x10400 ||
        towlower(0x05d0) != 0x05d0 || towlower((WideInt)-1) != (WideInt)-1)
        return -11;
    const Wide wide[] = { 0x0490, 0x1f680, 0 };
    const Wide prefix[] = { 0x0490, 0 };
    if (wcslen(wide) != 2 || wcscoll(wide, wide) || wcscoll(wide, prefix) <= 0 ||
        wcscoll(prefix, wide) >= 0)
        return -12;
    Wide keys[4] = { '?', '?', '?', '?' };
    if (wcsxfrm(0, wide, 0) != 2 || wcsxfrm(keys, wide, 2) != 2 ||
        keys[0] != 0x0490 || keys[1] || keys[2] != '?' ||
        wcsxfrm(keys, wide, 3) != 2 || keys[1] != 0x1f680 || keys[2] || keys[3] != '?')
        return -13;
    const Wide words[] = { 0, 0x1f680, (Wide)-1, 0x0490 };
    if (wmemchr(words, 0, 4) != words || wmemchr(words, 0x1f680, 4) != words + 1 ||
        wmemchr(words, 0x0490, 3) || wmemcmp(words, words, 4) ||
        wmemcmp(words + 2, words + 1, 1) <= 0 || wmemcmp(words + 1, words + 2, 1) >= 0)
        return -14;
    if (wmemcpy(keys, words, 4) != keys || wmemcmp(keys, words, 4) ||
        wmemmove(keys + 1, keys, 3) != keys + 1 || keys[0] || keys[1] ||
        keys[2] != 0x1f680 || keys[3] != (Wide)-1 ||
        wmemset(keys + 1, 0x04af, 2) != keys + 1 || keys[0] ||
        keys[1] != 0x04af || keys[2] != 0x04af || keys[3] != (Wide)-1)
        return -15;
    *__errno() = 0;
    if (btowc('X') != 'X' || btowc(0) || btowc(-1) != (WideInt)-1 ||
        btowc(0xe2) != (WideInt)-1 || *__errno() ||
        btowc(0xff) != (WideInt)-1 || *__errno() != 84 ||
        wctob('X') != 'X' || wctob(0) || wctob(0x0490) != -1 || wctob((WideInt)-1) != -1)
        return -16;
    return 16;
}

#ifdef RIFT_STRING_STANDALONE
__attribute__((noreturn)) void rift_string_entry(void) {
    int result = Java_org_kyvex_extra_LinkChecks_nativeStrings(0, 0);
    int code = result == 16 ? 0 : -result;
#ifdef __aarch64__
    register long argument __asm__("x0") = code;
    register long number __asm__("x8") = 93;
#else
    register long argument __asm__("r0") = code;
    register long number __asm__("r7") = 1;
#endif
    __asm__ volatile("svc #0" : : "r"(argument), "r"(number) : "memory");
    __builtin_unreachable();
}
#endif
