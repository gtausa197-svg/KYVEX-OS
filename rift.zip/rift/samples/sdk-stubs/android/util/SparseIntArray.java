package android.util;
/** Compile-only API signatures, excluded from the APK. */
public class SparseIntArray implements Cloneable {
    public SparseIntArray(){}public SparseIntArray(int capacity){}
    public void put(int key,int value){}public void append(int key,int value){}
    public int get(int key){return 0;}public int get(int key,int fallback){return fallback;}
    public int size(){return 0;}public int keyAt(int index){return 0;}public int valueAt(int index){return 0;}
    public void setValueAt(int index,int value){}public void delete(int key){}public void clear(){}
    public int indexOfKey(int key){return 0;}public int indexOfValue(int value){return 0;}
    public SparseIntArray clone(){return null;}
}
