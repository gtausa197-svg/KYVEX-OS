package org.kyvex.extra;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
/** Reflection order is deliberately not assumed. Runs unchanged on Java 8. */
public final class FieldArrayChecks {
 private static int checks,initializations;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 public interface Top {int TOP=7;}
 public interface Left extends Top {int LEFT=8;}
 public interface Right extends Top {int RIGHT=9;}
 public static class Parent {public int inherited=1;public int hidden=2;private int secret=3;protected int protectedValue;}
 public static final class Child extends Parent implements Left,Right {
  public int hidden=4;
  private int count=5;
  public static String text="before";
  public volatile long stamp;
  transient Object temp;
 }
 public static final class Empty {}
 public static final class Lazy {public static int value=initialize();private static int initialize(){initializations++;return 77;}}
 public enum Choice {ONE,TWO;}
 public static Object retained;
 private static Field find(Field[] fields,Class<?> owner,String name){for(Field field:fields)if(field!=null&&field.getDeclaringClass()==owner&&field.getName().equals(name))return field;throw new IllegalStateException("Field missing: "+name);}
 public static int verify() throws Exception {
  checks=0;initializations=0;
  Field[] declared=Child.class.getDeclaredFields();
  check(declared.length==5,"All declared fields including private/package/static");
  for(Field field:declared)if(field.getDeclaringClass()!=Child.class)throw new IllegalStateException("Inherited field in declared array");checks++;
  Field count=find(declared,Child.class,"count");check(count.getType()==int.class&&Modifier.isPrivate(count.getModifiers())&&!count.isAccessible(),"Private declaration and default access");
  Field stamp=find(declared,Child.class,"stamp");check(stamp.getType()==long.class&&Modifier.isVolatile(stamp.getModifiers()),"Volatile type/flags");
  Field temp=find(declared,Child.class,"temp");check(temp.getType()==Object.class&&Modifier.isTransient(temp.getModifiers()),"Package/transient declaration");
  Field text=find(declared,Child.class,"text");check(text.getType()==String.class&&Modifier.isStatic(text.getModifiers())&&Modifier.isPublic(text.getModifiers()),"Static public declaration");
  Child child=new Child();count.setAccessible(true);count.setInt(child,12);check(child.count==12&&count.getInt(child)==12,"Bulk description accesses real private instance storage");
  text.set(null,"after");check(Child.text.equals("after")&&text.get(null).equals("after"),"Bulk description accesses actual static storage");
  Field[] fresh=Child.class.getDeclaredFields();Field freshCount=find(fresh,Child.class,"count");
  check(fresh!=declared&&freshCount!=count&&!freshCount.isAccessible(),"New array and independent accessibility flags");
  check(freshCount.equals(count)&&freshCount.hashCode()==count.hashCode()&&count.hashCode()==(Child.class.getName().hashCode()^"count".hashCode()),"Field equality/hash use declaration identity");
  check(!count.equals(null)&&!count.equals("count")&&!count.equals(find(declared,Child.class,"hidden")),"Field equality rejects null/type/other declaration");
  declared[0]=null;check(find(fresh,Child.class,"count")!=null,"Returned field arrays are independent");
  Field[] publicFields=Child.class.getFields();
  check(publicFields.length==8,"Public fields include ancestor, hidden declarations and diamond interfaces once");
  check(find(publicFields,Child.class,"hidden").getInt(child)==4&&find(publicFields,Parent.class,"hidden").getInt(child)==2,"Hidden public fields retain both declaring classes");
  check(find(publicFields,Parent.class,"inherited").getInt(child)==1,"Public inherited field reads parent storage");
  check(find(publicFields,Top.class,"TOP").getInt(null)==7&&find(publicFields,Left.class,"LEFT").getInt(null)==8&&find(publicFields,Right.class,"RIGHT").getInt(null)==9,"Interface constants use actual declaration and initializer");
  int topCount=0;for(Field field:publicFields){if(!Modifier.isPublic(field.getModifiers()))throw new IllegalStateException("Nonpublic getFields result");if(field.getDeclaringClass()==Top.class)topCount++;}check(topCount==1,"Diamond interface field is not duplicated");
  check(Left.class.getDeclaredFields().length==1&&Left.class.getFields().length==2,"Interface declared versus inherited fields");
  check(Empty.class.getDeclaredFields().length==0&&Empty.class.getFields().length==0&&Object.class.getDeclaredFields().length==0,"Classes with no fields return empty arrays");
  check(int.class.getDeclaredFields().length==0&&void.class.getDeclaredFields().length==0&&int.class.getFields().length==0,"Primitive and void classes have no fields");
  check(String[].class.getDeclaredFields().length==0&&int[][].class.getFields().length==0,"Array length is not a reflected Field");
  Field[] lazy=Lazy.class.getDeclaredFields();check(initializations==0,"Metadata enumeration does not initialize target class");
  check(find(lazy,Lazy.class,"value").getInt(null)==77&&initializations==1,"Actual static read performs initialization once");
  Field[] choice=Choice.class.getDeclaredFields();int constants=0,synthetic=0;for(Field field:choice){if(field.isEnumConstant())constants++;if(field.isSynthetic())synthetic++;}check(constants==2&&synthetic>=1,"Actual enum constants and compiler synthetic fields included");
  Object captured=new Object();final Object capturedFinal=captured;Runnable runnable=new Runnable(){public void run(){retained=capturedFinal;}};
  Field capturedField=null;for(Field field:runnable.getClass().getDeclaredFields())if(field.getType()==Object.class&&field.isSynthetic())capturedField=field;
  check(capturedField!=null,"Anonymous captured synthetic field is exposed");capturedField.setAccessible(true);check(capturedField.get(runnable)==captured,"Captured field points to actual object");
  retained=fresh;fresh=null;declared=null;System.gc();check(find((Field[])retained,Child.class,"count").getType()==int.class,"Reflected array owns elements through collection");retained=null;
  return checks;
 }
 public static Field[] retainedArray(){return Child.class.getDeclaredFields();}
 public static int report(){try{return verify();}catch(Exception e){throw new IllegalStateException(e);}}
 public static void main(String[] args)throws Exception{System.out.println("Field array checks: "+verify());}
}
