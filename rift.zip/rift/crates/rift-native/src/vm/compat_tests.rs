use super::*;

#[test]
fn read_write_view_keeps_parent_and_peer_alive_until_released() {
    let mut vm = fixture_runtime("rift-field-array-demo.apk");
    let lock = vm.instantiate(rwlock::RW_LOCK).unwrap();
    let read = "Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/Lock;";
    let write = "Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;";
    let reader = call(&mut vm, read, &[lock]) as u32;
    let writer = call(&mut vm, write, &[lock]) as u32;
    let root = vm.scoped_library_roots(&[reader]).unwrap();
    vm.collect().unwrap();
    assert_eq!(call(&mut vm, write, &[lock]), u64::from(writer));
    assert_eq!(call(&mut vm, read, &[lock]), u64::from(reader));
    drop(root);
    vm.collect().unwrap();
    assert!(
        [lock, reader, writer]
            .iter()
            .all(|id| !vm.heap.contains_key(id))
    );
}

#[test]
fn android_loggability_checks_the_default_level_and_missing_tags() {
    let mut vm = fixture_runtime("rift-logging-demo.apk");
    let tag = vm.string("Default Android log threshold").unwrap();
    let loggable = "Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z";
    assert_eq!(call(&mut vm, loggable, &[tag, 3]), 0);
    assert_eq!(call(&mut vm, loggable, &[tag, 4]), 1);
    assert_eq!(call(&mut vm, loggable, &[tag, 6]), 1);
    assert_eq!(call(&mut vm, loggable, &[0, 6]), 0);
}

#[test]
fn malformed_compiled_xml_has_typed_failure_and_close_releases_the_cursor() {
    let mut vm = fixture_runtime("rift-provider-demo.apk");
    let bytes = vm
        .libraries
        .resource("res/xml/kyvex_paths.xml", 1024 * 1024)
        .unwrap();
    let mut truncated = bytes.clone();
    truncated.pop();
    assert!(vm.allocate_compiled_xml(truncated).is_err());

    let mut malformed = bytes;
    let mut offset = 8;
    let count_at = loop {
        let (kind, head, node) = crate::resources::chunk(&malformed, offset).unwrap();
        if kind == 0x0102 {
            break offset + head + 12;
        }
        offset += node.len();
    };
    malformed[count_at..count_at + 2].copy_from_slice(&u16::MAX.to_le_bytes());
    let parser = vm.allocate_compiled_xml(malformed).unwrap();
    let next = "Landroid/content/res/XmlResourceParser;->next()I";
    let before = vm.heap_bytes();
    let error = vm.hle(next, &[parser]).unwrap_err();
    assert_eq!(
        error.downcast_ref::<JavaFault>().unwrap().class,
        "Lorg/xmlpull/v1/XmlPullParserException;"
    );
    assert!(
        vm.hle(next, &[parser])
            .unwrap_err()
            .to_string()
            .contains("parser failed")
    );
    call(&mut vm, "Ljava/lang/AutoCloseable;->close()V", &[parser]);
    assert_eq!(call(&mut vm, next, &[parser]), 1);
    assert!(vm.heap_bytes() + 65536 < before);
}

#[test]
fn matched_handoff_keeps_reference_alive_until_waiting_java_frame_resumes() {
    let mut vm = fixture_runtime("rift-handoff-demo.apk");
    let queue = vm.instantiate(scheduler::HANDOFF_QUEUE).unwrap();
    call(
        &mut vm,
        "Ljava/util/concurrent/SynchronousQueue;-><init>()V",
        &[queue],
    );
    let class = "Lorg/kyvex/extra/HandoffChecks$Receiver;";
    let receiver = vm.instantiate(class).unwrap();
    let roots = vm.scoped_library_roots(&[queue, receiver]).unwrap();
    let init = vm
        .dex
        .find(
            class,
            "<init>",
            "(Ljava/util/concurrent/SynchronousQueue;)V",
        )
        .unwrap();
    vm.invoke(init, &[receiver, queue], false).unwrap();
    call(&mut vm, "Ljava/lang/Thread;->start()V", &[receiver]);
    vm.pump_guest_workers(256).unwrap();
    assert!(matches!(
        vm.scheduler.records[&receiver].state,
        scheduler::State::Waiting(scheduler::Wait::Handoff { value: 0, .. })
    ));

    let value = vm.instantiate("Ljava/lang/Object;").unwrap();
    assert_eq!(
        call(
            &mut vm,
            "Ljava/util/concurrent/SynchronousQueue;->offer(Ljava/lang/Object;)Z",
            &[queue, value]
        ),
        1
    );
    assert!(matches!(vm.scheduler.records[&receiver].ready,
        Some(scheduler::Completion::Reference(id)) if id == value));
    vm.collect().unwrap();
    assert!(
        vm.heap.contains_key(&value),
        "The transfer slot owns the only result reference"
    );
    vm.pump_guest_workers(256).unwrap();
    assert!(
        vm.object(receiver)
            .unwrap()
            .fields
            .values()
            .any(|&field| field == value as u64)
    );
    assert_eq!(vm.guest_threads(), 1);
    drop(roots);
    vm.collect().unwrap();
    assert!(
        [queue, receiver, value]
            .iter()
            .all(|id| !vm.heap.contains_key(id))
    );
}

#[test]
fn scheduled_queue_keeps_pending_commands_and_releases_cancelled_work_and_idle_worker() {
    let mut vm = fixture_runtime("rift-scheduled-demo.apk");
    let pool = vm
        .instantiate("Ljava/util/concurrent/ScheduledThreadPoolExecutor;")
        .unwrap();
    let counter = vm
        .instantiate("Ljava/util/concurrent/atomic/AtomicInteger;")
        .unwrap();
    let command = vm
        .instantiate("Lorg/kyvex/extra/ExecutorChecks$Mark;")
        .unwrap();
    let roots = vm.scoped_library_roots(&[pool, counter, command]).unwrap();
    let constructor = vm
        .dex
        .find(
            "Lorg/kyvex/extra/ExecutorChecks$Mark;",
            "<init>",
            "(Ljava/util/concurrent/atomic/AtomicInteger;)V",
        )
        .unwrap();
    vm.invoke(constructor, &[command, counter], false).unwrap();
    call(
        &mut vm,
        "Ljava/util/concurrent/ScheduledThreadPoolExecutor;-><init>(I)V",
        &[pool, 0],
    );
    let day = vm.time_unit(6).unwrap();
    let future = call(
        &mut vm,
        "Ljava/util/concurrent/ScheduledThreadPoolExecutor;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;",
        &[pool, command, 1, 0, day],
    ) as u32;
    assert!(vm.hle(
        "Lorg/kyvex/rift/internal/PoolAccess;->startTask(Lorg/kyvex/rift/internal/ScheduledTask;)Ljava/lang/Object;",
        &[future],
    ).is_err());
    vm.pump_guest_workers(256).unwrap();
    drop(roots);
    vm.collect().unwrap();
    assert_eq!(vm.guest_threads(), 2);
    assert!(
        [pool, future, command, counter]
            .iter()
            .all(|id| vm.heap.contains_key(id))
    );

    assert_eq!(
        call(
            &mut vm,
            "Ljava/util/concurrent/Future;->cancel(Z)Z",
            &[future, 0]
        ),
        1
    );
    vm.collect().unwrap();
    assert!(vm.heap.contains_key(&future));
    assert!(!vm.heap.contains_key(&command) && !vm.heap.contains_key(&counter));
    call(
        &mut vm,
        "Ljava/util/concurrent/ThreadPoolExecutor;->purge()V",
        &[pool],
    );
    vm.pump_guest_workers(256).unwrap();
    assert_eq!(
        vm.guest_threads(),
        1,
        "The removed timer must not keep the zero-core worker asleep"
    );
    vm.collect().unwrap();
    assert!(!vm.heap.contains_key(&future) && !vm.heap.contains_key(&pool));
}

#[test]
fn messenger_alias_keeps_local_target_alive_without_leaking_the_handler_binder_cycle() {
    let mut vm = runtime();
    let handler = vm.instantiate("Landroid/os/Handler;").unwrap();
    call(&mut vm, "Landroid/os/Handler;-><init>()V", &[handler]);
    let route = vm.instantiate("Landroid/os/Messenger;").unwrap();
    call(
        &mut vm,
        "Landroid/os/Messenger;-><init>(Landroid/os/Handler;)V",
        &[route, handler],
    );
    let binder = call(
        &mut vm,
        "Landroid/os/Messenger;->getBinder()Landroid/os/IBinder;",
        &[route],
    ) as u32;
    let alias = vm.instantiate("Landroid/os/Messenger;").unwrap();
    call(
        &mut vm,
        "Landroid/os/Messenger;-><init>(Landroid/os/IBinder;)V",
        &[alias, binder],
    );

    let roots = vm.scoped_library_roots(&[alias]).unwrap();
    vm.collect().unwrap();
    assert!(!vm.heap.contains_key(&route));
    assert!(vm.heap.contains_key(&handler) && vm.heap.contains_key(&binder));
    assert!(
        vm.subclass(events::LOCAL_MESSENGER_BINDER, "Landroid/os/IBinder;")
            .unwrap()
    );
    assert_eq!(
        call(
            &mut vm,
            "Landroid/os/Messenger;->getBinder()Landroid/os/IBinder;",
            &[alias]
        ),
        binder as u64
    );

    drop(roots);
    vm.collect().unwrap();
    assert!(
        [handler, binder, alias]
            .iter()
            .all(|id| !vm.heap.contains_key(id))
    );
}
#[test]
fn actual_executor_fixture_runs_real_owned_tasks_factories_hooks_waits_and_shutdown() {
    let vm = fixture_runtime("rift-executor-demo.apk");
    assert!(
        vm.scene
            .widgets
            .iter()
            .any(|widget| widget.text == "Executor checks: 47")
    );
    assert!(vm.dex.has_class("Lorg/kyvex/rift/internal/PoolWorker;"));
    assert!(!vm.dex.has_class("Lorg/kyvex/rift/internal/PoolAccess;"));
    assert!(
        !vm.dex
            .has_class("Ljava/util/concurrent/ThreadPoolExecutor;")
    );
    assert_eq!(vm.guest_threads(), 1);
    assert!(vm.callers.is_empty() && vm.execution_roots.borrow().is_empty());
}
#[test]
fn live_executor_roots_queued_work_but_releases_completed_tasks_and_shutdown_cycles() {
    let mut vm = fixture_runtime("rift-executor-demo.apk");
    let counter = vm
        .instantiate("Ljava/util/concurrent/atomic/AtomicInteger;")
        .unwrap();
    call(
        &mut vm,
        "Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V",
        &[counter, 0],
    );
    let task = vm
        .instantiate("Lorg/kyvex/extra/ExecutorChecks$Mark;")
        .unwrap();
    let mut roots = vm.scoped_library_roots(&[counter, task]).unwrap();
    let constructor = vm
        .dex
        .find(
            "Lorg/kyvex/extra/ExecutorChecks$Mark;",
            "<init>",
            "(Ljava/util/concurrent/atomic/AtomicInteger;)V",
        )
        .unwrap();
    vm.invoke(constructor, &[task, counter], false).unwrap();
    let queue = vm
        .instantiate("Ljava/util/concurrent/LinkedBlockingQueue;")
        .unwrap();
    roots.keep(queue).unwrap();
    call(
        &mut vm,
        "Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V",
        &[queue],
    );
    let pool = vm
        .instantiate("Ljava/util/concurrent/ThreadPoolExecutor;")
        .unwrap();
    roots.keep(pool).unwrap();
    let unit = vm.time_unit(3).unwrap();
    call(
        &mut vm,
        "Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;)V",
        &[pool, 1, 1, 1, 0, unit, queue],
    );
    call(
        &mut vm,
        "Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V",
        &[pool, task],
    );
    let Payload::Executor(state) = &vm.object(pool).unwrap().payload else {
        panic!("Pool payload")
    };
    let worker = state.workers[0];
    assert!(vm.hle("Lorg/kyvex/rift/internal/PoolAccess;->next(Lorg/kyvex/rift/internal/PoolWorker;)Ljava/lang/Runnable;",&[worker]).is_err(),"Main thread cannot invoke another worker's private bridge");
    drop(roots);
    vm.collect().unwrap();
    assert!(
        [pool, queue, task, counter, worker]
            .iter()
            .all(|id| vm.heap.contains_key(id))
    );
    let counter_root = vm.scoped_library_roots(&[counter]).unwrap();
    vm.pump_guest_workers(256).unwrap();
    assert_eq!(
        call(
            &mut vm,
            "Ljava/util/concurrent/atomic/AtomicInteger;->get()I",
            &[counter]
        ),
        1
    );
    vm.collect().unwrap();
    assert!(
        !vm.heap.contains_key(&task),
        "Completed task must not stay in an idle worker's conservative frame roots"
    );
    assert!(
        [pool, queue, worker]
            .iter()
            .all(|id| vm.heap.contains_key(id))
    );
    call(
        &mut vm,
        "Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V",
        &[pool],
    );
    vm.pump_guest_workers(256).unwrap();
    vm.collect().unwrap();
    assert!(
        [pool, queue, task, worker]
            .iter()
            .all(|id| !vm.heap.contains_key(id))
    );
    drop(counter_root);
    vm.collect().unwrap();
    assert!(!vm.heap.contains_key(&counter));
}
#[test]
fn actual_logging_fixture_matches_java8_and_contains_no_logging_framework_classes() {
    let vm = fixture_runtime("rift-logging-demo.apk");
    assert!(
        vm.scene
            .widgets
            .iter()
            .any(|w| w.text == "Logging checks: 123")
    );
    assert!(!vm.dex.has_class("Ljava/util/logging/Logger;"));
    assert!(!vm.dex.has_class("Ljava/util/logging/Level;"));
    assert_eq!(vm.logs.len(), 32);
    assert!(vm.callers.is_empty() && vm.execution_roots.borrow().is_empty());
}
#[test]
fn logger_children_keep_real_parents_levels_and_names_alive_but_lookup_cache_is_weak() {
    let mut vm = fixture_runtime("rift-logging-demo.apk");
    let parent_name = vm.string("gc-logging-parent").unwrap();
    let child_name = vm.string("gc-logging-parent.child").unwrap();
    let unused_name = vm.string("gc-unretained-logger").unwrap();
    let factory =
        "Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;";
    let parent = call(&mut vm, factory, &[parent_name]) as u32;
    let child = call(&mut vm, factory, &[child_name]) as u32;
    let unused = call(&mut vm, factory, &[unused_name]) as u32;
    let level_name = vm.string("held-custom-level").unwrap();
    let level = vm
        .instantiate("Lorg/kyvex/extra/LoggingChecks$Custom;")
        .unwrap();
    call(
        &mut vm,
        "Ljava/util/logging/Level;-><init>(Ljava/lang/String;I)V",
        &[level, level_name, 750],
    );
    call(
        &mut vm,
        "Ljava/util/logging/Logger;->setLevel(Ljava/util/logging/Level;)V",
        &[parent, level],
    );
    let roots = vm.scoped_library_roots(&[child]).unwrap();
    vm.collect().unwrap();
    assert!(
        [parent_name, child_name, parent, child, level_name, level]
            .iter()
            .all(|id| vm.heap.contains_key(id))
    );
    assert!(!vm.heap.contains_key(&unused) && !vm.heap.contains_key(&unused_name));
    assert_eq!(
        call(
            &mut vm,
            "Ljava/util/logging/Logger;->getParent()Ljava/util/logging/Logger;",
            &[child]
        ),
        parent as u64
    );
    assert_eq!(
        call(&mut vm, "Ljava/util/logging/Level;->intValue()I", &[level]),
        750
    );
    drop(roots);
    vm.collect().unwrap();
    assert!(
        [parent_name, child_name, parent, child, level_name, level]
            .iter()
            .all(|id| !vm.heap.contains_key(id))
    );
    assert!(
        !vm.logging
            .named
            .values()
            .any(|id| [parent, child, unused].contains(id))
    );
    let fresh_name = vm.string("gc-logging-parent.child").unwrap();
    assert_ne!(call(&mut vm, factory, &[fresh_name]), child as u64);
}
#[test]
fn diagnostic_flood_keeps_latest_messages_and_fits_protocol_even_with_json_expansion() {
    let mut vm = runtime();
    for _ in 0..64 {
        vm.append_guest_log("\0\n\"\\😀".repeat(1500));
    }
    vm.append_guest_log("last diagnostic survives".into());
    assert!(vm.logs.len() <= 32 && vm.logs.last().unwrap() == "last diagnostic survives");
    assert!(vm.logs.iter().all(|line| line.chars().count() <= 2048));
    let logs = serde_json::to_vec(&vm.logs).unwrap();
    assert!(logs.len() <= 16386, "Actual JSON bytes: {}", logs.len());
    let packet =
        serde_json::to_vec(&serde_json::json!({"scene":vm.scene,"metrics":{"app_logs":vm.logs}}))
            .unwrap();
    assert!(
        packet.len() < 65536,
        "Diagnostics must leave room for the real scene"
    );
}
#[test]
fn actual_sqlite_fixture_runs_real_migrations_and_does_not_package_framework_stubs() {
    let vm = fixture_runtime("rift-sqlite-demo.apk");
    assert!(
        vm.scene
            .widgets
            .iter()
            .any(|w| w.text == "SQLite checks: 48")
    );
    assert!(
        !vm.dex
            .has_class("Landroid/database/sqlite/SQLiteOpenHelper;")
    );
    assert!(!vm.dex.has_class("Landroid/database/sqlite/SQLiteDatabase;"));
    assert!(!vm.dex.has_class("Landroid/database/Cursor;"));
    assert!(vm.callers.is_empty() && vm.execution_roots.borrow().is_empty());
}
#[test]
fn sqlite_helper_roots_actual_database_and_gc_releases_reserved_private_image_capacity() {
    let mut vm = fixture_runtime("rift-sqlite-demo.apk");
    let class = "Lorg/kyvex/extra/SqliteChecks$Helper;";
    let constructor = vm
        .dex
        .find(
            class,
            "<init>",
            "(Landroid/content/Context;Ljava/lang/String;I)V",
        )
        .unwrap();
    let name = vm.string("gc-native.db").unwrap();
    let helper = vm.instantiate(class).unwrap();
    let roots = vm.scoped_library_roots(&[helper]).unwrap();
    vm.invoke(constructor, &[helper, vm.activity, name, 1], false)
        .unwrap();
    let db=vm.hle("Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;",&[helper]).unwrap() as u32;
    vm.collect().unwrap();
    assert!(vm.heap.contains_key(&name) && vm.heap.contains_key(&db));
    let reserved = vm.files.bytes();
    drop(roots);
    vm.collect().unwrap();
    assert!(
        !vm.heap.contains_key(&name)
            && !vm.heap.contains_key(&helper)
            && !vm.heap.contains_key(&db)
    );
    assert!(
        vm.files.bytes() + 262144 < reserved,
        "Dead DB reservation must be released"
    );
    let path = crate::vfs::join(&vm.files.cwd, &crate::vfs::units("databases/gc-native.db"));
    let inode = vm.files.open(&path, false, false).unwrap();
    let image = vm
        .files
        .read(inode, 0, vm.files.length(inode).unwrap())
        .unwrap();
    vm.files.close(inode);
    let restored = crate::database::Database::new(Some(&image), 262144).unwrap();
    assert_eq!(
        restored
            .query("SELECT number FROM events", &[], 4096)
            .unwrap()
            .values[0][0],
        crate::database::Cell::Integer(i64::MAX)
    );
    assert!(vm.execution_roots.borrow().is_empty());
}
#[test]
fn owned_deep_java_stacks_survive_detach_gc_resume_and_still_enforce_a_bound() {
    let mut vm = fixture_runtime("rift-base64-demo.apk");
    let method = vm
        .dex
        .find("Lorg/kyvex/extra/NumberParseChecks;", "deep", "(I)I")
        .unwrap();
    let mut running = vm.begin_execution(method, &[72], false).unwrap();
    let mut paused = false;
    let mut result = None;
    for _ in 0..4000 {
        match vm.execution_slice(&mut running, 1).unwrap() {
            execution::Status::Return(value) => {
                result = Some(value);
                break;
            }
            execution::Status::Yield => {}
            execution::Status::Blocked(_) => panic!("Pure Java recursion must not wait"),
        }
        if !paused && vm.depth > 64 {
            vm.detach_execution(&mut running).unwrap();
            assert!(vm.callers.is_empty() && vm.depth == 0);
            vm.collect().unwrap();
            vm.attach_execution(&mut running).unwrap();
            paused = true;
        }
    }
    assert!(paused);
    assert_eq!(result, Some(73));
    vm.detach_execution(&mut running).unwrap();
    drop(running);
    assert!(vm.callers.is_empty() && vm.depth == 0 && vm.execution_roots.borrow().is_empty());
    let error = vm
        .invoke(method, &[(execution::MAX_CALL_DEPTH * 2) as u32], false)
        .unwrap_err();
    assert!(error.to_string().contains("DEX call stack limit"));
    assert!(vm.callers.is_empty() && vm.depth == 0 && vm.execution_roots.borrow().is_empty());
    vm.collect().unwrap();
}
#[test]
fn real_dex_base64_calls_use_native_framework_implementation_and_real_data() {
    let mut vm = fixture_runtime("rift-base64-demo.apk");
    assert!(
        vm.scene
            .widgets
            .iter()
            .any(|w| w.text == "Number parse checks: 36")
    );
    assert!(
        vm.scene
            .widgets
            .iter()
            .any(|w| w.text == "Base64 checks: 40")
    );
    assert!(
        !vm.dex.has_class("Landroid/util/Base64;"),
        "Compile-only framework signatures must never be packaged as implementation"
    );
    assert!(vm.callers.is_empty() && vm.execution_roots.borrow().is_empty());
    vm.collect().unwrap();
}
#[test]
fn static_integer_and_long_decimal_conversion_never_treat_primitives_as_handles() {
    let mut vm = runtime();
    let boxed = vm.box_value('I', 123).unwrap();
    for value in [0, i32::MIN, i32::MAX, -1, 41, boxed as i32] {
        let result = vm
            .hle(
                "Ljava/lang/Integer;->toString(I)Ljava/lang/String;",
                &[value as u32],
            )
            .unwrap() as u32;
        assert_eq!(vm.text(result).unwrap(), value.to_string());
    }
    for value in [0, i64::MIN, i64::MAX, -1, boxed as i64, 0x1122334455667788] {
        let result = vm
            .hle(
                "Ljava/lang/Long;->toString(J)Ljava/lang/String;",
                &[value as u32, (value as u64 >> 32) as u32],
            )
            .unwrap() as u32;
        assert_eq!(vm.text(result).unwrap(), value.to_string());
    }
}
#[test]
fn real_dex_charset_calls_preserve_signed_byte_arrays_unicode_and_exception_types() {
    let mut v = fixture_runtime("rift-charset-demo.apk");
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|w| w.text == "Charset checks: 41")
    );
    assert!(v.callers.is_empty() && v.execution_roots.borrow().is_empty());
    v.collect().unwrap();
}
#[test]
fn map_backed_sets_dispatch_foreign_dex_maps_and_iterators_through_gc() {
    let mut v = fixture_runtime("rift-map-set-demo.apk");
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|w| w.text == "Map set checks: 42")
    );
    assert!(v.callers.is_empty() && v.execution_roots.borrow().is_empty());
    v.collect().unwrap();
}
#[test]
fn primitive_bit_calls_preserve_wide_arguments_results_and_signed_distances_in_dex() {
    let mut v = fixture_runtime("rift-bit-demo.apk");
    assert!(v.scene.widgets.iter().any(|w| w.text == "Bit checks: 21"));
    assert!(
        v.bit_operations >= 20,
        "DEX must actually invoke the numeric library"
    );
    assert!(v.callers.is_empty() && v.execution_roots.borrow().is_empty());
    v.collect().unwrap();
}
#[test]
fn integer_and_long_bit_operations_match_1024_stock_java8_vectors() {
    let mut v = runtime();
    let cases: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../tests/fixtures/bit-ops.json"
    )))
    .unwrap();
    let cases = cases.as_array().unwrap();
    assert_eq!(cases.len(), 1024);
    for row in cases {
        let narrow = row["width"].as_u64().unwrap() == 32;
        let raw = row["value"].as_i64().unwrap() as u64;
        let args = if narrow {
            vec![raw as u32]
        } else {
            vec![raw as u32, (raw >> 32) as u32]
        };
        let class = if narrow { "Integer" } else { "Long" };
        let input = if narrow { "I" } else { "J" };
        for (key, name, count) in [
            ("leading", "numberOfLeadingZeros", true),
            ("trailing", "numberOfTrailingZeros", true),
            ("count", "bitCount", true),
            ("highest", "highestOneBit", false),
            ("lowest", "lowestOneBit", false),
            ("reverse", "reverse", false),
            ("bytes", "reverseBytes", false),
            ("sign", "signum", true),
            ("left", "rotateLeft", false),
            ("right", "rotateRight", false),
        ] {
            let output = if count || narrow { "I" } else { "J" };
            let mut args = args.clone();
            let rotate = name.starts_with("rotate");
            if rotate {
                args.push(row["distance"].as_i64().unwrap() as u32);
            }
            let signature = format!(
                "Ljava/lang/{class};->{name}({input}{}){output}",
                if rotate { "I" } else { "" }
            );
            let expected = row[key].as_i64().unwrap() as u64;
            let expected = if output == "I" {
                expected as u32 as u64
            } else {
                expected
            };
            assert_eq!(
                v.hle(&signature, &args)
                    .unwrap_or_else(|error| panic!("{signature}: {row}: {error}")),
                expected,
                "{signature}: {row}"
            );
        }
    }
    assert_eq!(v.bit_operations, 10240);
}
#[test]
fn guest_unsafe_runs_the_unchanged_java8_typed_and_atomic_contract() {
    let mut v = fixture_runtime("rift-unsafe-demo.apk");
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|w| w.text == "Unsafe checks: 35")
    );
    assert!(
        !v.dex.has_class(guest_unsafe::CLASS),
        "Compile-only SDK class must not be bundled in the APK"
    );
    assert!(v.callers.is_empty() && v.execution_roots.borrow().is_empty());
    v.collect().unwrap();
    assert!(v.heap.contains_key(&v.guest_unsafe.singleton));
}
#[test]
fn unsafe_reference_writes_keep_actual_heap_values_and_offsets_do_not_retain_instances() {
    let mut v = fixture_runtime("rift-unsafe-demo.apk");
    let object = v
        .instantiate("Lorg/kyvex/extra/UnsafeChecks$Values;")
        .unwrap();
    let description = v
        .declared_field("Lorg/kyvex/extra/UnsafeChecks$Values;", "ref")
        .unwrap();
    let field = v
        .allocate(
            "Ljava/lang/reflect/Field;",
            Payload::ReflectedField(description),
        )
        .unwrap();
    let u = v.guest_unsafe_singleton().unwrap();
    let offset = call(
        &mut v,
        "Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J",
        &[u, field],
    );
    let value = v.string("Unsafe-owned-reference").unwrap();
    let mut args = vec![u, object, offset as u32, (offset >> 32) as u32, value];
    call(
        &mut v,
        "Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V",
        &args,
    );
    v.globals.insert(object, 1);
    v.collect().unwrap();
    assert!(v.heap.contains_key(&value));
    args[4] = 0;
    call(
        &mut v,
        "Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V",
        &args,
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&value));
    v.globals.remove(&object);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&object));
}
#[test]
fn unsafe_rejects_out_of_bounds_misaligned_wrong_type_and_raw_memory_operations() {
    let mut v = runtime();
    let u = v.guest_unsafe_singleton().unwrap();
    let array = v.allocate("[I", Payload::Array(vec![123])).unwrap();
    for offset in [15u32, 17, 20, u32::MAX] {
        assert!(
            v.hle(
                "Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V",
                &[u, array, offset, 0, 99]
            )
            .is_err()
        );
    }
    assert!(
        v.hle(
            "Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V",
            &[u, array, 16, 0, 99, 0]
        )
        .is_err()
    );
    assert!(
        v.hle("Lsun/misc/Unsafe;->allocateMemory(J)J", &[u, 4096, 0])
            .unwrap_err()
            .to_string()
            .contains("Unsupported guest Unsafe")
    );
    assert!(
        v.hle(
            "Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J",
            &[u, 0, 0, 0]
        )
        .is_err()
    );
    let Payload::Array(values) = &v.object(array).unwrap().payload else {
        panic!("Int array");
    };
    assert_eq!(values, &[123]);
}
#[test]
fn reflected_field_hash_preserves_a_class_name_beginning_with_l() {
    let mut v = runtime();
    let field = v
        .allocate(
            "Ljava/lang/reflect/Field;",
            Payload::ReflectedField(reflection::Field {
                owner: "LLpkg/LName;".into(),
                name: "member".into(),
                descriptor: "I".into(),
                access: 1,
                index: None,
                accessible: false,
            }),
        )
        .unwrap();
    // Stock Java8 reflects actual Lpkg.LName.member in v15/field-hash-oracle.
    assert_eq!(
        call(&mut v, "Ljava/lang/reflect/Field;->hashCode()I", &[field]) as u32 as i32,
        -711845613
    );
}
#[test]
fn reflected_declared_and_public_field_arrays_execute_the_unchanged_java_contract() {
    let mut v = fixture_runtime("rift-field-array-demo.apk");
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|w| w.text == "Field array checks: 27")
    );
    assert!(v.callers.is_empty() && v.execution_roots.borrow().is_empty());
    assert!(v.trace_contexts.borrow().is_empty());
    v.collect().unwrap();
}
#[test]
fn reflected_field_array_retains_fresh_descriptions_and_releases_them_with_the_array() {
    let mut v = fixture_runtime("rift-field-array-demo.apk");
    let method = v
        .dex
        .find(
            "Lorg/kyvex/extra/FieldArrayChecks;",
            "retainedArray",
            "()[Ljava/lang/reflect/Field;",
        )
        .unwrap();
    let array = v.invoke(method, &[], false).unwrap() as u32;
    let Payload::Array(fields) = &v.object(array).unwrap().payload else {
        panic!("Real reflected array");
    };
    let fields: Vec<u32> = fields.iter().map(|id| *id as u32).collect();
    assert_eq!(fields.len(), 5);
    v.globals.insert(array, 1);
    v.collect().unwrap();
    assert!(fields.iter().all(|id| v.heap.contains_key(id)));
    v.globals.remove(&array);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&array) && fields.iter().all(|id| !v.heap.contains_key(id)));
}
#[test]
fn unknown_native_field_layout_never_returns_an_invented_empty_array() {
    let mut v = runtime();
    let class = v.class_object("Ljava/lang/String;").unwrap();
    let error = v
        .hle(
            "Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;",
            &[class],
        )
        .unwrap_err();
    assert!(
        error
            .to_string()
            .contains("not implemented for Ljava/lang/String;"),
        "{error}"
    );
}
#[test]
fn stream_field_descriptions_execute_the_unchanged_java_contract() {
    let mut v = fixture_runtime("rift-stream-field-demo.apk");
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|w| w.text == "Stream field checks: 37")
    );
    assert!(v.callers.is_empty() && v.execution_roots.borrow().is_empty());
    assert!(v.trace_contexts.borrow().is_empty());
    v.collect().unwrap();
}
#[test]
fn stream_field_owns_its_name_and_preserves_real_class_and_signature_identity() {
    let mut v = runtime();
    let name = v.string("owned-field-name").unwrap();
    let ty = v.class_object("[[Ljava/lang/String;").unwrap();
    let field = v.instantiate("Ljava/io/ObjectStreamField;").unwrap();
    call(
        &mut v,
        "Ljava/io/ObjectStreamField;-><init>(Ljava/lang/String;Ljava/lang/Class;Z)V",
        &[field, name, ty, 1],
    );
    let signature = call(
        &mut v,
        "Ljava/io/ObjectStreamField;->getTypeString()Ljava/lang/String;",
        &[field],
    ) as u32;
    v.globals.insert(field, 1);
    v.collect().unwrap();
    assert_eq!(
        call(
            &mut v,
            "Ljava/io/ObjectStreamField;->getName()Ljava/lang/String;",
            &[field]
        ),
        name as u64
    );
    assert_eq!(
        call(
            &mut v,
            "Ljava/io/ObjectStreamField;->getType()Ljava/lang/Class;",
            &[field]
        ),
        ty as u64
    );
    assert_eq!(v.text(signature).unwrap(), "[[Ljava/lang/String;");
    assert!(v.heap.contains_key(&name));
    v.globals.remove(&field);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&field) && !v.heap.contains_key(&name));
    assert!(
        v.heap.contains_key(&signature),
        "Interned signatures are shared guest strings"
    );
}
#[test]
fn guest_groups_run_real_lifecycle_and_suspendable_uncaught_handlers() {
    let mut v = fixture_runtime("rift-group-demo.apk");
    assert!(v.scene.widgets.iter().any(|w| w.text == "Group checks: 49"));
    assert!(v.callers.is_empty() && v.execution_roots.borrow().is_empty());
    assert!(v.trace_contexts.borrow().is_empty());
    assert_eq!(v.guest_threads(), 1);
    v.collect().unwrap();
    assert_eq!(v.scheduler.records.len(), 1);
}
#[test]
fn queued_uncaught_handler_roots_real_fault_arguments_before_first_slice() {
    let mut v = fixture_runtime("rift-group-demo.apk");
    let method = v
        .dex
        .find(
            "Lorg/kyvex/extra/GroupChecks;",
            "queuedFault",
            "()Ljava/lang/Thread;",
        )
        .unwrap();
    let thread = v.invoke(method, &[], false).unwrap() as u32;
    v.start_guest_thread(thread).unwrap();
    v.pump_guest_workers(1).unwrap();
    let record = &v.scheduler.records[&thread];
    assert!(record.alive() && record.uncaught_handler);
    let args = &record.entry.as_ref().expect("Real queued handler entry").1;
    let handler = args[0];
    let throwable = args[2];
    v.collect().unwrap();
    assert!(v.heap.contains_key(&handler) && v.heap.contains_key(&throwable));
    v.pump_guest_workers(32).unwrap();
    assert!(!v.scheduler.records[&thread].alive());
    let field = v
        .dex
        .fields
        .iter()
        .enumerate()
        .find(|(_, f)| {
            v.dex.ty(f.class) == "Lorg/kyvex/extra/GroupChecks;"
                && v.dex.strings[f.name] == "queuedResult"
        })
        .unwrap()
        .0;
    assert_eq!(
        v.statics[&field], 321,
        "Actual handler consumed the retained fault"
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&handler) && !v.heap.contains_key(&throwable));
}
#[test]
fn group_hierarchy_owns_children_until_destroy_and_does_not_own_unstarted_threads() {
    let mut v = runtime();
    v.ensure_main_thread().unwrap();
    let name = v.string("retained-child").unwrap();
    let group = v.instantiate("Ljava/lang/ThreadGroup;").unwrap();
    call(
        &mut v,
        "Ljava/lang/ThreadGroup;-><init>(Ljava/lang/String;)V",
        &[group, name],
    );
    let thread = v.instantiate("Ljava/lang/Thread;").unwrap();
    let thread_name = v.string("unstarted").unwrap();
    call(
        &mut v,
        "Ljava/lang/Thread;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/String;)V",
        &[thread, group, thread_name],
    );
    v.collect().unwrap();
    assert!(v.heap.contains_key(&group) && v.heap.contains_key(&name));
    assert!(
        !v.heap.contains_key(&thread),
        "A group must not strongly retain a New thread"
    );
    assert_eq!(
        v.group(group).unwrap().unstarted,
        1,
        "Java 8 keeps the unstarted count after GC"
    );
    call(&mut v, "Ljava/lang/ThreadGroup;->destroy()V", &[group]);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&group) && !v.heap.contains_key(&name));
}
#[test]
fn throwable_snapshots_own_their_elements_and_release_them_when_exception_dies() {
    let mut v = fixture_runtime("rift-stack-demo.apk");
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|widget| widget.text == "Stack checks: 40 / Native stack checks: 1")
    );
    assert!(v.trace_contexts.borrow().is_empty() && v.execution_roots.borrow().is_empty());
    let field = v
        .dex
        .fields
        .iter()
        .enumerate()
        .find(|(_, field)| {
            v.dex.ty(field.class) == "Lorg/kyvex/extra/StackChecks;"
                && v.dex.strings[field.name] == "retained"
        })
        .unwrap()
        .0;
    let exception = v.statics[&field] as u32;
    let trace = v.object(exception).unwrap().fields[&stack_trace::TRACE] as u32;
    v.collect().unwrap();
    let Payload::Array(values) = &v.object(trace).unwrap().payload else {
        panic!("Stored trace array");
    };
    let first = values[0] as u32;
    let method = call(
        &mut v,
        "Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;",
        &[first],
    ) as u32;
    assert_eq!(v.text(method).unwrap(), "buildRetained");
    v.statics.insert(field, 0);
    v.collect().unwrap();
    assert!(
        !v.heap.contains_key(&exception)
            && !v.heap.contains_key(&trace)
            && !v.heap.contains_key(&first)
    );
}
#[test]
fn owned_class_initializers_wait_publish_once_and_preserve_failure_causes() {
    let mut v = fixture_runtime("rift-initialization-demo.apk");
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|widget| widget.text == "Initialization checks: 25")
    );
    assert!(
        !v.initialization_states
            .values()
            .any(|state| matches!(state, initialization::State::Running { .. }))
    );
    assert!(v.execution_roots.borrow().is_empty() && v.callers.is_empty());
    v.collect().unwrap();
    for state in v.initialization_states.values() {
        if let initialization::State::Failed(initialization::Failure::Java(object)) = state {
            assert!(
                v.heap.contains_key(object),
                "Erroneous class must retain its actual cause"
            );
        }
    }
}
#[test]
fn cancelling_a_pending_initializer_releases_its_stack_without_faking_java_success() {
    let mut v = fixture_runtime("rift-initialization-demo.apk");
    let class = "Lorg/kyvex/extra/InitializationChecks;";
    let begin = v.dex.find(class, "beginPending", "()V").unwrap();
    let touch = v.dex.find(class, "touchPending", "()I").unwrap();
    v.invoke(begin, &[], false).unwrap();
    assert!(
        v.initialization_states
            .values()
            .any(|state| matches!(state, initialization::State::Running { .. }))
    );
    assert!(!v.execution_roots.borrow().is_empty());
    v.shutdown_guest_threads().unwrap();
    assert!(v.execution_roots.borrow().is_empty() && v.callers.is_empty());
    let error = v.invoke(touch, &[], false).unwrap_err();
    assert!(
        !error.is::<JavaFault>() && error.to_string().contains("cancelled"),
        "{error}"
    );
}
#[test]
fn java_threads_execute_wait_resume_and_restore_native_identity() {
    let mut v = fixture_runtime("rift-thread-demo.apk");
    assert_eq!(v.guest_threads(), 2);
    std::thread::sleep(std::time::Duration::from_millis(700));
    v.tick().unwrap();
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|w| w.text == "Worker timer: delivered")
    );
    assert!(
        v.scene
            .widgets
            .iter()
            .any(|w| w.text == "Thread checks: 32 / JNI thread checks: 7")
    );
    assert!(
        v.scheduler.switches >= 20,
        "Actual worker contexts must have run"
    );
    assert_eq!(v.current_thread, v.main_thread);
    assert_eq!(v.current_guest_tid(), crate::identity::MAIN_TID);
    assert!(
        v.scheduler
            .records
            .iter()
            .all(|(id, r)| *id == v.main_thread || matches!(r.state, scheduler::State::Terminated))
    );
    assert!(v.execution_roots.borrow().is_empty());
    assert!(v.callers.is_empty());
    assert!(v.monitors.is_empty());
    v.collect().unwrap();
    assert_eq!(
        v.scheduler.records.len(),
        1,
        "Unreferenced terminated threads must be reclaimable"
    );
}
#[test]
fn a_closed_guest_join_cycle_reports_deadlock_and_releases_owned_stacks() {
    let mut v = fixture_runtime("rift-thread-demo.apk");
    std::thread::sleep(std::time::Duration::from_millis(700));
    v.tick().unwrap();
    let index = v
        .dex
        .find("Lorg/kyvex/extra/ThreadChecks;", "deadlockJoin", "()V")
        .unwrap();
    let error = v.invoke(index, &[], false).unwrap_err();
    assert!(error.to_string().contains("deadlocked"), "{error}");
    assert!(v.callers.is_empty());
    assert_eq!(v.depth, 0);
    assert!(
        !v.execution_roots.borrow().is_empty(),
        "Waiting workers own live stacks until shutdown"
    );
    v.shutdown_guest_threads().unwrap();
    assert!(v.execution_roots.borrow().is_empty());
    v.collect().unwrap();
    assert_eq!(v.scheduler.records.len(), 1);
}
#[test]
fn atomic_reference_array_owns_copied_elements_and_releases_replaced_values() {
    let mut v = runtime();
    let value = v.string("array-owned value").unwrap();
    let source = v
        .allocate("[Ljava/lang/String;", Payload::Array(vec![value as u64]))
        .unwrap();
    let array = v
        .instantiate("Ljava/util/concurrent/atomic/AtomicReferenceArray;")
        .unwrap();
    call(
        &mut v,
        "Ljava/util/concurrent/atomic/AtomicReferenceArray;-><init>([Ljava/lang/Object;)V",
        &[array, source],
    );
    v.globals.insert(array, 1);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&source) && v.heap.contains_key(&value));
    call(
        &mut v,
        "Ljava/util/concurrent/atomic/AtomicReferenceArray;->set(ILjava/lang/Object;)V",
        &[array, 0, 0],
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&value));
}
#[test]
fn owned_java_call_stacks_interleave_without_using_rust_call_stack_continuations() {
    let mut v = fixture_runtime("rift-concurrency-demo.apk");
    let class = "Lorg/kyvex/extra/ExecutionChecks;";
    let index = v.dex.find(class, "sequence", "(I)I").unwrap();
    let calls = v
        .dex
        .fields
        .iter()
        .enumerate()
        .find(|(_, f)| v.dex.ty(f.class) == class && v.dex.strings[f.name] == "calls")
        .unwrap()
        .0;
    v.statics.insert(calls, 0);
    let atomic_field = v
        .dex
        .fields
        .iter()
        .enumerate()
        .find(|(_, f)| v.dex.ty(f.class) == class && v.dex.strings[f.name] == "committedCalls")
        .unwrap()
        .0;
    let atomic = v.statics[&atomic_field] as u32;
    call(
        &mut v,
        "Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V",
        &[atomic, 0],
    );
    let mut a = v.begin_execution(index, &[37], false).unwrap();
    v.detach_execution(&mut a).unwrap();
    let mut b = v.begin_execution(index, &[15], false).unwrap();
    v.detach_execution(&mut b).unwrap();
    let mut results = [None, None];
    for _ in 0..10000 {
        for (i, execution) in [&mut a, &mut b].into_iter().enumerate() {
            if results[i].is_some() {
                continue;
            }
            assert!(v.execution_slice(execution, 1).is_err());
            v.attach_execution(execution).unwrap();
            match v.execution_slice(execution, 1).unwrap() {
                execution::Status::Return(value) => results[i] = Some(value),
                execution::Status::Yield => {}
                execution::Status::Blocked(_) => panic!("Arithmetic fixture unexpectedly blocked"),
            }
            v.detach_execution(execution).unwrap();
            assert!(v.callers.is_empty());
            assert_eq!(v.depth, 0);
        }
        if results.iter().all(Option::is_some) {
            break;
        }
    }
    assert_eq!(results, [Some(1760), Some(283)]);
    assert_eq!(
        call(
            &mut v,
            "Ljava/util/concurrent/atomic/AtomicInteger;->get()I",
            &[atomic]
        ),
        52
    );
    // Plain calls++ can lose updates under real instruction-level interleaving.
    assert!((37..=52).contains(&v.statics[&calls]));
    drop(a);
    drop(b);
    assert!(v.execution_roots.borrow().is_empty());
}
#[test]
fn paused_java_stack_roots_locals_and_return_values_until_context_drop() {
    let mut v = fixture_runtime("rift-concurrency-demo.apk");
    let index = v
        .dex
        .find(
            "Lorg/kyvex/extra/ExecutionChecks;",
            "carry",
            "(I)Ljava/lang/Object;",
        )
        .unwrap();
    let mut execution = v.begin_execution(index, &[11], false).unwrap();
    let object = loop {
        let state = v.execution_slice(&mut execution, 1).unwrap();
        v.detach_execution(&mut execution).unwrap();
        v.collect().unwrap();
        if let execution::Status::Return(value) = state {
            break value as u32;
        }
        v.attach_execution(&mut execution).unwrap();
    };
    assert_eq!(v.object(object).unwrap().class, "Ljava/lang/Object;");
    drop(execution);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&object));
    let mut execution = v.begin_execution(index, &[1000], false).unwrap();
    v.execution_slice(&mut execution, 1).unwrap();
    v.cancel_execution(&mut execution).unwrap();
    assert!(v.callers.is_empty());
    assert_eq!(v.depth, 0);
    drop(execution);
    assert!(v.execution_roots.borrow().is_empty());
}
#[test]
fn suspended_java_slices_preserve_pc_call_results_and_exception_handlers() {
    for quantum in [1, 2, 7, 64] {
        let mut v = fixture_runtime("rift-concurrency-demo.apk");
        let class = "Lorg/kyvex/extra/ExecutionChecks;";
        let method = v.dex.find(class, "sequence", "(I)I").unwrap();
        let calls_field = v
            .dex
            .fields
            .iter()
            .enumerate()
            .find(|(_, f)| v.dex.ty(f.class) == class && v.dex.strings[f.name] == "calls")
            .unwrap()
            .0;
        v.statics.insert(calls_field, 0);
        let body = v.dex.bodies[&method].clone();
        let mut regs = vec![0; body.registers];
        regs[body.registers - body.incoming] = 37;
        let mut cursor = interpreter::Cursor::default();
        let mut yields = 0;
        let mut calls = 0;
        let value = loop {
            match v
                .interpret_slice(&body, &mut regs, &mut cursor, quantum)
                .unwrap()
            {
                interpreter::Slice::Return(value) => break value,
                interpreter::Slice::Yield => yields += 1,
                interpreter::Slice::Blocked(_) => panic!("Arithmetic fixture unexpectedly blocked"),
                interpreter::Slice::Initialize(_) => {
                    panic!("Arithmetic fixture unexpectedly requested deferred initialization")
                }
                interpreter::Slice::Invoke(call) => {
                    calls += 1;
                    assert!(
                        v.interpret_slice(&body, &mut regs, &mut cursor, 1).is_err(),
                        "an outstanding call must be resolved before the caller can run"
                    );
                    let result = v.invoke(call.index, &call.args, call.virtual_call);
                    v.resume_interpreter_call(&body, &mut cursor, result)
                        .unwrap();
                }
            }
        };
        assert_eq!(value, 1760, "quantum {quantum}");
        assert_eq!(v.statics[&calls_field], 37, "a paused call must not replay");
        assert_eq!(calls, 37);
        if quantum == 1 {
            assert!(yields > 37);
        }
        assert!(
            v.interpret_slice(&body, &mut regs, &mut cursor, 1).is_err(),
            "returned frames cannot execute twice"
        );
    }
}
#[test]
fn runtime_identity_is_rooted_and_gc_request_is_processed_at_a_safe_point() {
    let mut v = runtime();
    let rt = call(
        &mut v,
        "Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;",
        &[],
    ) as u32;
    let limit = v.heap_limit as u64;
    assert_eq!(
        call(&mut v, "Ljava/lang/Runtime;->maxMemory()J", &[rt]),
        limit
    );
    assert_eq!(
        call(&mut v, "Ljava/lang/Runtime;->availableProcessors()I", &[rt]),
        1
    );
    call(&mut v, "Ljava/lang/Runtime;->gc()V", &[rt]);
    assert!(v.gc_requested);
    v.collect().unwrap();
    assert!(!v.gc_requested && v.heap.contains_key(&rt));
    assert_eq!(
        call(
            &mut v,
            "Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;",
            &[]
        ),
        rt as u64
    );
}
#[test]
fn field_updater_values_follow_real_object_fields_through_collection() {
    let mut v = fixture_runtime("rift-concurrency-demo.apk");
    let owner = v
        .class_object("Lorg/kyvex/extra/AtomicFieldChecks$Node;")
        .unwrap();
    let value_class = v.class_object("Ljava/lang/String;").unwrap();
    let name = v.string("label").unwrap();
    let updater = call(
        &mut v,
        "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;",
        &[owner, value_class, name],
    ) as u32;
    let node = v
        .instantiate("Lorg/kyvex/extra/AtomicFieldChecks$Node;")
        .unwrap();
    let value = v.string("field-owned").unwrap();
    call(
        &mut v,
        "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->set(Ljava/lang/Object;Ljava/lang/Object;)V",
        &[updater, node, value],
    );
    v.globals.insert(node, 1);
    v.globals.insert(updater, 1);
    v.collect().unwrap();
    assert!(v.heap.contains_key(&value));
    assert_eq!(
        call(
            &mut v,
            "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;",
            &[updater, node]
        ),
        value as u64
    );
    call(
        &mut v,
        "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->set(Ljava/lang/Object;Ljava/lang/Object;)V",
        &[updater, node, 0],
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&value));
}
#[test]
fn xml_input_survives_collection_and_set_input_null_releases_reader() {
    let mut v = runtime();
    let string = v.string("<root value='real'/>").unwrap();
    let reader = v.instantiate("Ljava/io/StringReader;").unwrap();
    call(
        &mut v,
        "Ljava/io/StringReader;-><init>(Ljava/lang/String;)V",
        &[reader, string],
    );
    let parser = call(
        &mut v,
        "Landroid/util/Xml;->newPullParser()Lorg/xmlpull/v1/XmlPullParser;",
        &[],
    ) as u32;
    call(
        &mut v,
        "Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/Reader;)V",
        &[parser, reader],
    );
    v.globals.insert(parser, 1);
    v.collect().unwrap();
    assert!(v.heap.contains_key(&reader) && v.heap.contains_key(&string));
    assert_eq!(
        call(
            &mut v,
            "Lorg/xmlpull/v1/XmlPullParser;->nextTag()I",
            &[parser]
        ),
        2
    );
    let value = call(
        &mut v,
        "Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(I)Ljava/lang/String;",
        &[parser, 0],
    ) as u32;
    assert_eq!(v.text(value).unwrap(), "real");
    call(
        &mut v,
        "Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/Reader;)V",
        &[parser, 0],
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&reader) && !v.heap.contains_key(&string));
}
#[test]
fn array_backed_list_keeps_actual_array_and_elements_alive() {
    let mut v = runtime();
    let text = v.string("retained").unwrap();
    let array = v
        .allocate("[Ljava/lang/String;", Payload::Array(vec![text as u64]))
        .unwrap();
    let list = call(
        &mut v,
        "Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;",
        &[array],
    ) as u32;
    v.globals.insert(list, 1);
    v.collect().unwrap();
    assert!(v.heap.contains_key(&array) && v.heap.contains_key(&text));
    assert_eq!(
        call(
            &mut v,
            "Ljava/util/List;->get(I)Ljava/lang/Object;",
            &[list, 0]
        ),
        text as u64
    );
    v.globals.remove(&list);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&array) && !v.heap.contains_key(&text));
}
#[test]
fn user_service_is_rooted_and_unattached_context_class_lookup_throws() {
    let mut v = runtime();
    let context = v.activity;
    let class = v.class_object("Landroid/os/UserManager;").unwrap();
    let manager = call(
        &mut v,
        "Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;",
        &[context, class],
    ) as u32;
    v.collect().unwrap();
    assert!(v.heap.contains_key(&manager));
    assert_eq!(
        call(
            &mut v,
            "Landroid/os/UserManager;->isUserUnlocked()Z",
            &[manager]
        ),
        1
    );
    let wrapper = v.instantiate("Landroid/app/Application;").unwrap();
    let unknown = v.class_object("Ljava/lang/String;").unwrap();
    let error = v
        .hle(
            "Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;",
            &[wrapper, unknown],
        )
        .unwrap_err();
    assert_eq!(
        error.downcast_ref::<JavaFault>().unwrap().class,
        "Ljava/lang/NullPointerException;"
    );
}
#[test]
fn reader_wrappers_keep_the_source_string_alive_and_release_it_when_closed() {
    let mut v = fixture_runtime("rift-reader-demo.apk");
    let string = v.string("reader owned source").unwrap();
    let text = v.instantiate("Ljava/io/StringReader;").unwrap();
    call(
        &mut v,
        "Ljava/io/StringReader;-><init>(Ljava/lang/String;)V",
        &[text, string],
    );
    let buffered = v.instantiate("Ljava/io/BufferedReader;").unwrap();
    call(
        &mut v,
        "Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V",
        &[buffered, text],
    );
    v.globals.insert(buffered, 1);
    v.collect().unwrap();
    assert!(v.heap.contains_key(&text) && v.heap.contains_key(&string));
    assert_eq!(
        call(&mut v, "Ljava/io/Reader;->read()I", &[buffered]),
        'r' as u64
    );
    call(&mut v, "Ljava/io/Reader;->close()V", &[buffered]);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&string));
    assert!(v.heap.contains_key(&text));
}
#[test]
fn bundle_key_iterator_roots_backing_entries_and_removes_them_after_gc() {
    let mut v = runtime();
    let bundle = v.instantiate("Landroid/os/Bundle;").unwrap();
    let key = v.string("retained").unwrap();
    let value = v.string("value").unwrap();
    call(
        &mut v,
        "Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V",
        &[bundle, key, value],
    );
    let keys = call(
        &mut v,
        "Landroid/os/Bundle;->keySet()Ljava/util/Set;",
        &[bundle],
    ) as u32;
    let iterator = call(
        &mut v,
        "Ljava/util/Set;->iterator()Ljava/util/Iterator;",
        &[keys],
    ) as u32;
    v.globals.insert(iterator, 1);
    v.collect().unwrap();
    assert!(
        v.heap.contains_key(&bundle) && v.heap.contains_key(&keys) && v.heap.contains_key(&value)
    );
    let next = call(
        &mut v,
        "Ljava/util/Iterator;->next()Ljava/lang/Object;",
        &[iterator],
    ) as u32;
    assert_eq!(v.text(next).unwrap(), "retained");
    call(&mut v, "Ljava/util/Iterator;->remove()V", &[iterator]);
    assert_eq!(call(&mut v, "Landroid/os/Bundle;->size()I", &[bundle]), 0);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&value));
}
#[test]
fn service_metadata_keeps_its_bundle_strings_and_component_info_across_gc() {
    let mut v = fixture_runtime("rift-provider-demo.apk");
    let context = v.application;
    let pm = call(
        &mut v,
        "Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;",
        &[context],
    ) as u32;
    let component = v.instantiate("Landroid/content/ComponentName;").unwrap();
    let package = v.string("org.kyvex.nativehello").unwrap();
    let name = v
        .string("org.kyvex.extra.ProviderChecks$MetadataService")
        .unwrap();
    call(
        &mut v,
        "Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V",
        &[component, package, name],
    );
    let info = call(
        &mut v,
        "Landroid/content/pm/PackageManager;->getServiceInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ServiceInfo;",
        &[pm, component, 128],
    ) as u32;
    v.globals.insert(info, 1);
    v.collect().unwrap();
    let Payload::Record(values) = &v.object(info).unwrap().payload else {
        panic!("service info");
    };
    assert_eq!(
        v.text(*values.get("processName").unwrap() as u32).unwrap(),
        "org.kyvex.nativehello:metadata"
    );
    assert!(
        v.heap
            .contains_key(&(*values.get("applicationInfo").unwrap() as u32))
    );
    let bundle = *values.get("metaData").unwrap() as u32;
    let key = v.string("fixture.registrar").unwrap();
    let value = call(
        &mut v,
        "Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;",
        &[bundle, key],
    ) as u32;
    assert_eq!(v.text(value).unwrap(), "org.kyvex.extra.RealRegistrar");
}
fn runtime() -> Runtime {
    fixture_runtime("rift-native-demo.apk")
}
fn fixture_runtime(name: &str) -> Runtime {
    let p = crate::package::Package::open(
        &std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built")
            .join(name),
        "auto",
    )
    .unwrap();
    let mut v = Runtime::new(
        p.dex,
        Machine::new(64, 32, 8).unwrap(),
        p.libraries,
        4 * 1024 * 1024,
    );
    v.configure_package(&p.info).unwrap();
    v.start_application(&p.info.package, &p.info.application)
        .unwrap();
    v.start(&p.info.launcher).unwrap();
    v
}
fn call(v: &mut Runtime, sig: &str, args: &[u32]) -> u64 {
    v.hle(sig, args).unwrap()
}
#[test]
fn activity_intent_has_launcher_identity_and_independent_extras_copies() {
    let mut v = runtime();
    let a = v.activity;
    let intent = call(
        &mut v,
        "Landroid/app/Activity;->getIntent()Landroid/content/Intent;",
        &[a],
    ) as u32;
    assert_eq!(
        call(
            &mut v,
            "Landroid/app/Activity;->getIntent()Landroid/content/Intent;",
            &[a]
        ),
        intent as u64
    );
    let action = call(
        &mut v,
        "Landroid/content/Intent;->getAction()Ljava/lang/String;",
        &[intent],
    ) as u32;
    assert_eq!(v.text(action).unwrap(), "android.intent.action.MAIN");
    let component = call(
        &mut v,
        "Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;",
        &[intent],
    ) as u32;
    let name = call(
        &mut v,
        "Landroid/content/ComponentName;->getClassName()Ljava/lang/String;",
        &[component],
    ) as u32;
    assert_eq!(v.text(name).unwrap(), "org.kyvex.nativehello.MainActivity");
    let key = v.string("number").unwrap();
    call(
        &mut v,
        "Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;",
        &[intent, key, 42],
    );
    let copy = call(
        &mut v,
        "Landroid/content/Intent;->getExtras()Landroid/os/Bundle;",
        &[intent],
    ) as u32;
    call(
        &mut v,
        "Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V",
        &[copy, key, 99],
    );
    assert_eq!(
        call(
            &mut v,
            "Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I",
            &[intent, key, 7]
        ),
        42
    );
    call(
        &mut v,
        "Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V",
        &[a, 0],
    );
    assert_eq!(
        call(
            &mut v,
            "Landroid/app/Activity;->getIntent()Landroid/content/Intent;",
            &[a]
        ),
        0
    );
}
#[test]
fn preferences_editor_is_transactional_typed_and_survives_runtime_restart() {
    let path = std::env::temp_dir().join(format!("kyvex-api-prefs-{}.journal", std::process::id()));
    let mut v = runtime();
    v.preferences_file(&path).unwrap();
    let context = v.application;
    let name = v.string("../../settings").unwrap();
    let key = v.string("value").unwrap();
    let p = call(
        &mut v,
        "Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;",
        &[context, name, 0],
    ) as u32;
    let editor = call(
        &mut v,
        "Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;",
        &[p],
    ) as u32;
    let wide = 0xfedcba9876543210u64;
    call(
        &mut v,
        "Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;",
        &[editor, key, wide as u32, (wide >> 32) as u32],
    );
    assert_eq!(
        call(
            &mut v,
            "Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J",
            &[p, key, 7, 0]
        ),
        7
    );
    assert_eq!(
        call(
            &mut v,
            "Landroid/content/SharedPreferences$Editor;->commit()Z",
            &[editor]
        ),
        1
    );
    assert!(
        v.hle(
            "Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I",
            &[p, key, 0]
        )
        .unwrap_err()
        .is::<JavaFault>()
    );
    drop(v);
    let mut v = runtime();
    v.preferences_file(&path).unwrap();
    let context = v.application;
    let name = v.string("../../settings").unwrap();
    let key = v.string("value").unwrap();
    let p = call(
        &mut v,
        "Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;",
        &[context, name, 0],
    ) as u32;
    assert_eq!(
        call(
            &mut v,
            "Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J",
            &[p, key, 0, 0]
        ),
        wide
    );
    drop(v);
    std::fs::remove_file(path).unwrap();
}
#[test]
fn weak_reference_queue_tracks_collection_and_dequeue() {
    let mut v = runtime();
    let target = v.string("temporary").unwrap();
    let q = v.instantiate("Ljava/lang/ref/ReferenceQueue;").unwrap();
    let r = v.instantiate("Ljava/lang/ref/WeakReference;").unwrap();
    call(
        &mut v,
        "Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;Ljava/lang/ref/ReferenceQueue;)V",
        &[r, target, q],
    );
    v.statics.insert(usize::MAX, r as u64);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&target));
    assert_eq!(
        call(
            &mut v,
            "Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",
            &[r]
        ),
        0
    );
    assert_eq!(
        call(&mut v, "Ljava/lang/ref/Reference;->isEnqueued()Z", &[r]),
        1
    );
    assert_eq!(
        call(
            &mut v,
            "Ljava/lang/ref/ReferenceQueue;->poll()Ljava/lang/ref/Reference;",
            &[q]
        ),
        r as u64
    );
    assert_eq!(
        call(&mut v, "Ljava/lang/ref/Reference;->isEnqueued()Z", &[r]),
        0
    );
    assert_eq!(
        call(&mut v, "Ljava/lang/ref/Reference;->enqueue()Z", &[r]),
        0
    );
}
#[test]
fn synchronized_set_wrapper_shares_contents_and_queue_keeps_fifo_order() {
    let mut v = runtime();
    let set = v.instantiate("Ljava/util/HashSet;").unwrap();
    let wrapper = call(
        &mut v,
        "Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;",
        &[set],
    ) as u32;
    assert_ne!(set, wrapper);
    let a = v.string("a").unwrap();
    let b = v.string("b").unwrap();
    call(
        &mut v,
        "Ljava/util/Set;->add(Ljava/lang/Object;)Z",
        &[wrapper, a],
    );
    assert_eq!(
        call(
            &mut v,
            "Ljava/util/Set;->contains(Ljava/lang/Object;)Z",
            &[set, a]
        ),
        1
    );
    let q = v
        .instantiate("Ljava/util/concurrent/ConcurrentLinkedQueue;")
        .unwrap();
    for value in [a, b] {
        assert_eq!(
            call(
                &mut v,
                "Ljava/util/Queue;->offer(Ljava/lang/Object;)Z",
                &[q, value]
            ),
            1
        );
    }
    for value in [a, b, 0] {
        assert_eq!(
            call(&mut v, "Ljava/util/Queue;->poll()Ljava/lang/Object;", &[q]),
            value as u64
        );
    }
    assert!(
        v.hle("Ljava/util/Queue;->offer(Ljava/lang/Object;)Z", &[q, 0])
            .unwrap_err()
            .is::<JavaFault>()
    );
}
#[test]
fn executor_factories_keep_configuration_and_single_executor_is_wrapped() {
    let mut v = runtime();
    let pool = call(
        &mut v,
        "Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;",
        &[4],
    ) as u32;
    assert_eq!(
        call(
            &mut v,
            "Ljava/util/concurrent/ThreadPoolExecutor;->getCorePoolSize()I",
            &[pool]
        ),
        4
    );
    let single = call(
        &mut v,
        "Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;",
        &[],
    ) as u32;
    assert!(
        !v.subclass(
            &v.object(single).unwrap().class,
            "Ljava/util/concurrent/ThreadPoolExecutor;"
        )
        .unwrap()
    );
    assert!(
        v.subclass(
            &v.object(single).unwrap().class,
            "Ljava/util/concurrent/ExecutorService;"
        )
        .unwrap()
    );
    call(
        &mut v,
        "Ljava/util/concurrent/ExecutorService;->shutdown()V",
        &[single],
    );
    assert_eq!(
        call(
            &mut v,
            "Ljava/util/concurrent/ExecutorService;->isShutdown()Z",
            &[single]
        ),
        1
    );
    assert!(
        v.hle(
            "Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V",
            &[pool, 0]
        )
        .is_err()
    );
}
#[test]
fn looper_reports_the_actual_main_event_thread_and_remains_gc_rooted() {
    let mut v = runtime();
    let looper = call(
        &mut v,
        "Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;",
        &[],
    ) as u32;
    let thread = call(
        &mut v,
        "Landroid/os/Looper;->getThread()Ljava/lang/Thread;",
        &[looper],
    );
    assert_eq!(
        thread,
        call(
            &mut v,
            "Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;",
            &[]
        )
    );
    v.collect().unwrap();
    assert_eq!(
        call(
            &mut v,
            "Landroid/os/Looper;->myLooper()Landroid/os/Looper;",
            &[]
        ),
        looper as u64
    );
    assert_eq!(
        call(&mut v, "Landroid/os/Looper;->isCurrentThread()Z", &[looper]),
        1
    );
    assert!(
        v.hle("Landroid/os/Looper;->quit()V", &[looper])
            .unwrap_err()
            .is::<JavaFault>()
    );
}
#[test]
fn frame_constructor_keeps_context_and_detached_views_are_reclaimed() {
    let mut v = runtime();
    let context = v.application;
    let frame = v.instantiate("Landroid/widget/FrameLayout;").unwrap();
    call(
        &mut v,
        "Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V",
        &[frame, context],
    );
    assert_eq!(
        call(
            &mut v,
            "Landroid/view/View;->getContext()Landroid/content/Context;",
            &[frame]
        ),
        context as u64
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&frame));
    assert!(!v.widgets.contains_key(&frame));
    let frame = v.instantiate("Landroid/widget/FrameLayout;").unwrap();
    v.scene.root = frame;
    assert!(
        v.finish_scene()
            .err()
            .unwrap()
            .to_string()
            .contains("graphics bridge")
    );
}
#[test]
fn handler_queue_owns_pending_objects_and_cancellation_releases_them() {
    let mut v = runtime();
    let handler = v.instantiate("Landroid/os/Handler;").unwrap();
    call(&mut v, "Landroid/os/Handler;-><init>()V", &[handler]);
    let payload = v.instantiate("Ljava/lang/Object;").unwrap();
    let message = call(
        &mut v,
        "Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;",
        &[handler, 42, payload],
    ) as u32;
    call(
        &mut v,
        "Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z",
        &[handler, message, 60000, 0],
    );
    assert!(
        v.hle(
            "Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z",
            &[handler, message]
        )
        .unwrap_err()
        .is::<JavaFault>()
    );
    v.collect().unwrap();
    assert!(v.heap.contains_key(&payload));
    assert!(v.heap.contains_key(&message));
    assert!(v.heap.contains_key(&handler));
    call(
        &mut v,
        "Landroid/os/Handler;->removeMessages(I)V",
        &[handler, 42],
    );
    assert_eq!(v.pending_events(), 0);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&payload));
    assert!(!v.heap.contains_key(&message));
    assert!(!v.heap.contains_key(&handler));
}
#[test]
fn message_copies_bundle_and_recycled_messages_remain_in_use() {
    let mut v = runtime();
    let handler = v.instantiate("Landroid/os/Handler;").unwrap();
    call(&mut v, "Landroid/os/Handler;-><init>()V", &[handler]);
    let message = call(
        &mut v,
        "Landroid/os/Message;->obtain()Landroid/os/Message;",
        &[],
    ) as u32;
    let bundle = call(
        &mut v,
        "Landroid/os/Message;->getData()Landroid/os/Bundle;",
        &[message],
    );
    let copy = call(
        &mut v,
        "Landroid/os/Message;->obtain(Landroid/os/Message;)Landroid/os/Message;",
        &[message],
    ) as u32;
    assert_ne!(
        bundle,
        call(
            &mut v,
            "Landroid/os/Message;->getData()Landroid/os/Bundle;",
            &[copy]
        )
    );
    call(&mut v, "Landroid/os/Message;->recycle()V", &[message]);
    assert!(
        v.hle(
            "Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z",
            &[handler, message]
        )
        .is_err()
    );
    assert!(
        v.hle(
            "Landroid/os/Handler;->obtainMessage(J)Landroid/os/Message;",
            &[handler, 0, 0]
        )
        .is_err()
    );
}
#[test]
fn abandoned_file_streams_are_closed_by_gc_and_file_state_is_private() {
    let mut v = runtime();
    let path = crate::vfs::join(&v.files.cwd, &crate::vfs::units("orphan.bin"));
    let inode = v.files.open(&path, true, false).unwrap();
    v.files.write(inode, 0, false, b"private data").unwrap();
    let id = v
        .allocate(
            "Ljava/io/FileOutputStream;",
            Payload::FileStream(Some(filesystem::Stream {
                inode,
                position: 12,
                output: true,
                append: false,
                closed: false,
                io: Some(strict_mode::IoTracker::default()),
            })),
        )
        .unwrap();
    v.files.delete(&path).unwrap();
    assert_eq!(v.files.length(inode).unwrap(), 12);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&id));
    assert!(v.files.length(inode).is_err());
    let other = runtime();
    assert!(other.files.stat(&path).is_none());
}
#[test]
fn application_info_fields_survive_gc_without_changing_filesystem_authority() {
    let mut v = runtime();
    let activity = v.activity;
    let info = call(
        &mut v,
        "Landroid/app/Activity;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;",
        &[activity],
    ) as u32;
    let class = v
        .class_object("Landroid/content/pm/ApplicationInfo;")
        .unwrap();
    let name = v.string("dataDir").unwrap();
    let field = call(
        &mut v,
        "Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;",
        &[class, name],
    ) as u32;
    let value = v.string("/etc/passwd").unwrap();
    call(
        &mut v,
        "Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V",
        &[field, info, value],
    );
    v.collect().unwrap();
    assert_eq!(v.text(value).unwrap(), "/etc/passwd");
    let dir = call(
        &mut v,
        "Landroid/content/Context;->getFilesDir()Ljava/io/File;",
        &[activity],
    ) as u32;
    assert!(
        matches!(&v.object(dir).unwrap().payload,Payload::File(path) if path.starts_with(&v.files.cwd))
    );
    assert!(v.files.stat(&crate::vfs::units("/etc/passwd")).is_none());
    assert_eq!(
        call(
            &mut v,
            "Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;",
            &[activity]
        ),
        info as u64
    );
}
#[test]
fn package_manager_is_rooted_and_reports_only_the_current_guest_package() {
    let mut v = runtime();
    let activity = v.activity;
    let manager = call(
        &mut v,
        "Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;",
        &[activity],
    ) as u32;
    v.collect().unwrap();
    assert_eq!(
        call(
            &mut v,
            "Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;",
            &[activity]
        ),
        manager as u64
    );
    let name = v.string("org.kyvex.nativehello").unwrap();
    let info = call(
        &mut v,
        "Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;",
        &[manager, name, 0],
    ) as u32;
    assert_eq!(
        call(
            &mut v,
            "Landroid/content/pm/PackageInfo;->getLongVersionCode()J",
            &[info]
        ),
        2
    );
    let missing = v.string("org.kyvex.missing").unwrap();
    let error=v.hle("Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;",&[manager,missing,0]).unwrap_err();
    assert_eq!(
        error.downcast_ref::<JavaFault>().unwrap().class,
        "Landroid/content/pm/PackageManager$NameNotFoundException;"
    );
}
#[test]
fn thread_constructor_has_distinct_unstarted_identity_and_inherits_priority() {
    let mut v = runtime();
    let main = call(
        &mut v,
        "Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;",
        &[],
    ) as u32;
    call(&mut v, "Ljava/lang/Thread;->setPriority(I)V", &[main, 8]);
    let child = v.instantiate("Ljava/lang/Thread;").unwrap();
    call(&mut v, "Ljava/lang/Thread;-><init>()V", &[child]);
    assert_eq!(
        call(&mut v, "Ljava/lang/Thread;->getPriority()I", &[child]),
        8
    );
    assert_eq!(call(&mut v, "Ljava/lang/Thread;->getId()J", &[child]), 2);
    assert_eq!(call(&mut v, "Ljava/lang/Thread;->isAlive()Z", &[child]), 0);
    call(&mut v, "Ljava/lang/Thread;->start()V", &[child]);
    assert_eq!(call(&mut v, "Ljava/lang/Thread;->isAlive()Z", &[child]), 1);
    v.collect().unwrap();
    assert!(
        v.heap.contains_key(&child),
        "Started threads remain rooted until they terminate"
    );
    v.pump_guest_workers(1).unwrap();
    assert_eq!(call(&mut v, "Ljava/lang/Thread;->isAlive()Z", &[child]), 0);
    assert!(
        v.hle("Ljava/lang/Thread;->start()V", &[child])
            .unwrap_err()
            .is::<JavaFault>()
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&child));
    assert!(v.heap.contains_key(&main));
}
#[test]
fn latch_waiting_does_not_report_success_before_the_counter_reaches_zero() {
    let mut v = runtime();
    let latch = v
        .instantiate("Ljava/util/concurrent/CountDownLatch;")
        .unwrap();
    call(
        &mut v,
        "Ljava/util/concurrent/CountDownLatch;-><init>(I)V",
        &[latch, 2],
    );
    assert!(
        v.hle("Ljava/util/concurrent/CountDownLatch;->await()V", &[latch])
            .is_err()
    );
    call(
        &mut v,
        "Ljava/util/concurrent/CountDownLatch;->countDown()V",
        &[latch],
    );
    assert_eq!(
        call(
            &mut v,
            "Ljava/util/concurrent/CountDownLatch;->getCount()J",
            &[latch]
        ),
        1
    );
    call(
        &mut v,
        "Ljava/util/concurrent/CountDownLatch;->countDown()V",
        &[latch],
    );
    call(
        &mut v,
        "Ljava/util/concurrent/CountDownLatch;->countDown()V",
        &[latch],
    );
    assert_eq!(
        call(
            &mut v,
            "Ljava/util/concurrent/CountDownLatch;->await()V",
            &[latch]
        ),
        0
    );
}
#[test]
fn custom_synchronized_constructor_mutex_stays_alive_with_its_wrapper() {
    let mut v = runtime();
    let target = v.instantiate("Ljava/util/ArrayList;").unwrap();
    let mutex = v.instantiate("Ljava/lang/Object;").unwrap();
    let wrapper = v
        .allocate(
            "Ljava/util/Collections$SynchronizedCollection;",
            Payload::CollectionWrapper {
                target,
                readonly: false,
                mutex,
            },
        )
        .unwrap();
    v.globals.insert(wrapper, 1);
    v.collect().unwrap();
    assert!(v.heap.contains_key(&target));
    assert!(v.heap.contains_key(&mutex));
    v.globals.clear();
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&mutex));
    assert!(!v.heap.contains_key(&target));
}

#[test]
fn apk_resource_configuration_metrics_and_typed_strings_survive_collection() {
    let mut v = fixture_runtime("rift-resource-demo.apk");
    let resources = v.resources;
    let config = v.resource_config;
    let metrics = v.display_metrics;
    let key = v.string("greeting").unwrap();
    let kind = v.string("string").unwrap();
    let package = v.string("org.kyvex.nativehello").unwrap();
    let id = call(
        &mut v,
        "Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I",
        &[resources, key, kind, package],
    ) as u32;
    let target = v.instantiate("Landroid/util/TypedValue;").unwrap();
    call(
        &mut v,
        "Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V",
        &[resources, id, target, 1],
    );
    v.globals.insert(target, 1);
    v.collect().unwrap();
    for handle in [resources, config, metrics, target] {
        assert!(v.heap.contains_key(&handle));
    }
    let Payload::Record(values) = &v.object(config).unwrap().payload else {
        panic!("config");
    };
    let locale = *values.get("locale").unwrap() as u32;
    let language = call(
        &mut v,
        "Ljava/util/Locale;->getLanguage()Ljava/lang/String;",
        &[locale],
    ) as u32;
    assert_eq!(v.text(language).unwrap(), "en");
    let Payload::Record(values) = &v.object(target).unwrap().payload else {
        panic!("value");
    };
    assert_eq!(
        v.text(*values.get("string").unwrap() as u32).unwrap(),
        "Hello from APK resources 🌍"
    );
    let context = v.application;
    assert_eq!(
        call(
            &mut v,
            "Landroid/content/Context;->getResources()Landroid/content/res/Resources;",
            &[context]
        ),
        resources as u64
    );
    assert!(v.heap_bytes() < v.heap_limit);
}

#[test]
fn thread_local_values_are_thread_owned_with_weak_keys_and_stale_entry_cleanup() {
    let mut v = runtime();
    let local = v.instantiate("Ljava/lang/ThreadLocal;").unwrap();
    let value = v.instantiate("Ljava/lang/Object;").unwrap();
    call(
        &mut v,
        "Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V",
        &[local, value],
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&local));
    assert!(v.heap.contains_key(&value));
    let next = v.instantiate("Ljava/lang/ThreadLocal;").unwrap();
    call(
        &mut v,
        "Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;",
        &[next],
    );
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&value));
    assert!(!v.thread_local_values.contains_key(&local));
}

#[test]
fn initialized_providers_retain_their_context_and_info_across_collection() {
    let mut v = fixture_runtime("rift-provider-demo.apk");
    assert_eq!(v.providers.len(), 2);
    v.collect().unwrap();
    for provider in v.providers.clone() {
        let context = call(
            &mut v,
            "Landroid/content/ContentProvider;->getContext()Landroid/content/Context;",
            &[provider],
        ) as u32;
        assert!(v.heap.contains_key(&context));
        let info = *v
            .object(provider)
            .unwrap()
            .fields
            .get(&(usize::MAX - 81))
            .unwrap() as u32;
        let Payload::Record(values) = &v.object(info).unwrap().payload else {
            panic!("ProviderInfo");
        };
        let name = *values.get("name").unwrap() as u32;
        assert!(
            v.text(name)
                .unwrap()
                .starts_with("org.kyvex.extra.ProviderChecks$")
        );
    }
}

#[test]
fn unreferenced_asset_streams_release_archive_handles_without_exposing_host_paths() {
    let mut v = fixture_runtime("rift-resource-demo.apk");
    let context = v.application;
    let assets = call(
        &mut v,
        "Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;",
        &[context],
    ) as u32;
    let path = v.string("payload.txt").unwrap();
    v.collect().unwrap();
    let before = v.files.bytes();
    // Allocate a fresh name after collection; ordinary Java local references
    // do not remain roots across the external event boundary tested here.
    let path = if v.heap.contains_key(&path) {
        path
    } else {
        v.string("payload.txt").unwrap()
    };
    let stream = call(
        &mut v,
        "Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;",
        &[assets, path],
    ) as u32;
    let Payload::FileStream(Some(handle)) = v.object(stream).unwrap().payload else {
        panic!("asset stream");
    };
    assert!(v.files.bytes() > before);
    v.collect().unwrap();
    assert!(!v.heap.contains_key(&stream));
    assert!(v.files.length(handle.inode).is_err());
    assert_eq!(v.files.bytes(), before);
    assert!(v.heap.contains_key(&assets));
}

#[test]
fn activity_callbacks_survive_gc_and_receive_actual_start_and_close_transitions() {
    let mut v = fixture_runtime("rift-provider-demo.apk");
    assert_eq!(v.activity_stage, 3);
    assert_eq!(v.activity_callbacks.len(), 1);
    assert_eq!(v.component_callbacks.len(), 1);
    v.collect().unwrap();
    let callback = v.activity_callbacks[0];
    assert!(v.heap.contains_key(&callback));
    assert!(
        v.subclass(
            &v.object(callback).unwrap().class,
            "Landroid/content/ComponentCallbacks;"
        )
        .unwrap()
    );
    v.close_activity().unwrap();
    assert_eq!(v.activity_stage, 6);
    let index = v
        .dex
        .find("Lorg/kyvex/extra/ProviderChecks;", "verifyClosed", "()I")
        .unwrap();
    assert_eq!(v.invoke(index, &[], false).unwrap(), 6);
    v.close_activity().unwrap();
    assert_eq!(v.invoke(index, &[], false).unwrap(), 6);
}

#[test]
fn activity_manager_and_process_snapshot_references_survive_collection() {
    let mut v = runtime();
    let context = v.activity;
    let name = v.string("activity").unwrap();
    let manager = call(
        &mut v,
        "Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;",
        &[context, name],
    ) as u32;
    let list = call(
        &mut v,
        "Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;",
        &[manager],
    ) as u32;
    let Payload::List(list) = &v.object(list).unwrap().payload else {
        panic!("list");
    };
    let info = list[0];
    v.globals.insert(info, 1);
    v.collect().unwrap();
    assert!(v.heap.contains_key(&manager));
    let Payload::Record(values) = &v.object(info).unwrap().payload else {
        panic!("process info");
    };
    assert_eq!(
        v.text(*values.get("processName").unwrap() as u32).unwrap(),
        "org.kyvex.nativehello"
    );
    let Payload::Array(packages) = &v
        .object(*values.get("pkgList").unwrap() as u32)
        .unwrap()
        .payload
    else {
        panic!("packages");
    };
    assert_eq!(v.text(packages[0] as u32).unwrap(), "org.kyvex.nativehello");
    assert_eq!(
        call(
            &mut v,
            "Landroid/app/ActivityManager;->getMemoryClass()I",
            &[manager]
        ),
        (v.heap_limit / (1024 * 1024)) as u64
    );
}
