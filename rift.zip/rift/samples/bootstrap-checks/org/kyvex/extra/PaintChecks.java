package org.kyvex.extra;

import android.graphics.Paint;
import android.text.TextPaint;
import java.util.Locale;
import java.util.regex.Pattern;

public final class PaintChecks {
    private static int checks;

    private static void check(boolean condition, String name) {
        if (!condition) throw new IllegalStateException(name);
        checks++;
    }

    public static int verify() {
        checks = 0;
        Paint paint = new TextPaint();
        paint.setTextSize(10.0f);
        check(paint.getTextSize() == 10.0f, "TextPaint state through Paint");
        paint.setTextSize(-1.0f);
        check(paint.getTextSize() == 10.0f, "Negative size leaves state intact");
        paint.setAntiAlias(true);
        Paint copy = new TextPaint(paint);
        paint.reset();
        check(copy.getTextSize() == 10.0f && copy.isAntiAlias() && !paint.isAntiAlias(), "Independent copy and reset");
        check(paint.hasGlyph("A") && paint.hasGlyph("Ж"), "Real Latin and Cyrillic glyphs");
        check(paint.hasGlyph("fi"), "Font ligature");
        check(!paint.hasGlyph("ab") && !paint.hasGlyph("\u0378") && !paint.hasGlyph(""), "No single glyph");
        check(paint.hasGlyph("🇺🇦") && !paint.hasGlyph("🇿🇿"), "Flag and invalid regional indicator pair");
        check(paint.hasGlyph("👩‍💻"), "Joined emoji");
        check(paint.hasGlyph("\u2764\uFE0F") && !paint.hasGlyph("A\uFE0F"), "Variation selector coverage");
        check(!paint.hasGlyph(new String(new char[]{'\uD800'})), "Unpaired UTF-16");
        boolean nullRejected = false;
        try { paint.hasGlyph(null); }
        catch (NullPointerException expected) { nullRejected = true; }
        check(nullRejected, "Null glyph input");
        check("aж١漢".equals(Pattern.compile("[^\\p{Alnum}]").matcher(" AЖ²١漢-")
                .replaceAll("").toLowerCase(Locale.US)), "Android Unicode POSIX default and ID cleanup");
        return checks;
    }
}
