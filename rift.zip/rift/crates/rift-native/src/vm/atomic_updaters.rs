//! Field updaters operate on actual checked volatile instance fields.
//! The interpreter serializes each operation; no native pointer is exposed.
use super::*;
#[derive(Clone)]
pub(super) struct Updater {
    pub field: reflection::Field,
    receiver: String,
    kind: char,
}
impl Updater {
    pub fn bytes(&self) -> usize {
        self.field.owner.len()
            + self.field.name.len()
            + self.field.descriptor.len()
            + self.receiver.len()
    }
}
fn base(class: &str) -> Option<char> {
    Some(match class {
        "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;"
        | "Lorg/kyvex/rift/ReferenceFieldUpdater;" => 'R',
        "Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;"
        | "Lorg/kyvex/rift/IntegerFieldUpdater;" => 'I',
        "Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;"
        | "Lorg/kyvex/rift/LongFieldUpdater;" => 'J',
        _ => return None,
    })
}
fn package(class: &str) -> &str {
    class.rsplit_once('/').map_or("", |(p, _)| p)
}
impl Runtime {
    fn updater_failure(
        &mut self,
        class: &str,
        message: &str,
    ) -> Result<Box<dyn std::error::Error + Send + Sync>> {
        let cause = self.materialize_fault(&JavaFault {
            class: class.into(),
            object: 0,
            message: message.into(),
        })?;
        let exception = self.materialize_fault(&JavaFault {
            class: "Ljava/lang/RuntimeException;".into(),
            object: 0,
            message: message.into(),
        })?;
        self.object_mut(exception)?
            .fields
            .insert(throwable::CAUSE, cause as u64);
        Ok(Box::new(JavaFault {
            class: "Ljava/lang/RuntimeException;".into(),
            object: exception,
            message: message.into(),
        }))
    }
    pub(super) fn updater_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Updater signature")?;
        let Some(kind) = base(class) else {
            return Ok(None);
        };
        let arg = |i: usize| a.get(i).copied().ok_or("Updater argument count");
        let factory = match kind {
            'R' => {
                "newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;"
            }
            'I' => {
                "newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;"
            }
            _ => {
                "newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;"
            }
        };
        if method == factory {
            let Payload::Class(owner) = &self.object(arg(0)?)?.payload else {
                return Err("Updater target Class type".into());
            };
            let owner = owner.clone();
            let descriptor = if kind == 'R' {
                let Payload::Class(value) = &self.object(arg(1)?)?.payload else {
                    return Err("Updater value Class type".into());
                };
                value.clone()
            } else {
                kind.to_string()
            };
            let name = String::from_utf16(&self.units(arg(if kind == 'R' { 2 } else { 1 })?)?)?;
            let field = match self.declared_field(&owner, &name) {
                Ok(field) => field,
                Err(error) => {
                    if let Some(fault) = error.downcast_ref::<JavaFault>() {
                        return Err(self.updater_failure(&fault.class, &fault.message)?);
                    }
                    return Err(error);
                }
            };
            // The immediate Java caller precedes this static factory on the call stack.
            let caller = self
                .callers
                .iter()
                .rev()
                .nth(1)
                .map(|i| self.dex.ty(self.dex.methods[*i].class).to_owned());
            let same_class = caller.as_deref() == Some(owner.as_str());
            let same_package = caller
                .as_ref()
                .is_some_and(|c| package(c) == package(&owner));
            let public_owner = self
                .dex
                .type_id(&owner)
                .and_then(|ty| self.dex.classes.get(&ty))
                .is_some_and(|class| class.access & 1 != 0);
            if !public_owner && !same_package && !same_class {
                return Err(self.updater_failure(
                    "Ljava/lang/IllegalAccessException;",
                    "Updater declaring class is inaccessible to the caller",
                )?);
            }
            let protected_subclass = field.access & 4 != 0
                && if let Some(caller) = &caller {
                    self.subclass(caller, &owner)?
                } else {
                    false
                };
            let allowed = if field.access & 1 != 0 {
                true
            } else if field.access & 2 != 0 {
                same_class
            } else {
                same_package || protected_subclass
            };
            if !allowed {
                return Err(self.updater_failure(
                    "Ljava/lang/IllegalAccessException;",
                    "Updater field is inaccessible to the caller",
                )?);
            }
            if field.descriptor != descriptor
                || (kind == 'R' && !descriptor.starts_with(['L', '[']))
            {
                return Err(fault(
                    if kind == 'R' {
                        "Ljava/lang/ClassCastException;"
                    } else {
                        "Ljava/lang/IllegalArgumentException;"
                    },
                    "Updater field type does not match",
                ));
            }
            if field.access & 64 == 0 || field.access & 8 != 0 {
                return Err(fault(
                    "Ljava/lang/IllegalArgumentException;",
                    "Updater requires a volatile instance field",
                ));
            }
            if field.index.is_none() {
                return Err("Native field updater storage is unsupported".into());
            }
            let receiver = if protected_subclass && !same_package {
                caller.unwrap()
            } else {
                owner
            };
            let class = match kind {
                'R' => "Lorg/kyvex/rift/ReferenceFieldUpdater;",
                'I' => "Lorg/kyvex/rift/IntegerFieldUpdater;",
                _ => "Lorg/kyvex/rift/LongFieldUpdater;",
            };
            return Ok(Some(self.allocate(
                class,
                Payload::FieldUpdater(Updater {
                    field,
                    receiver,
                    kind,
                }),
            )? as u64));
        }
        if method == "<init>()V" && class.starts_with("Ljava/") {
            self.object(arg(0)?)?;
            return Ok(Some(0));
        }
        let Payload::FieldUpdater(updater) = &self.object(arg(0)?)?.payload else {
            return Ok(None);
        };
        let updater = updater.clone();
        let method_name = method.split('(').next().ok_or("Updater method name")?;
        if !matches!(
            method_name,
            "get"
                | "set"
                | "lazySet"
                | "compareAndSet"
                | "weakCompareAndSet"
                | "getAndSet"
                | "getAndAdd"
                | "addAndGet"
                | "getAndIncrement"
                | "incrementAndGet"
                | "getAndDecrement"
                | "decrementAndGet"
        ) {
            return Ok(None);
        }
        let target = arg(1)?;
        if target == 0 || !self.subclass(&self.object(target)?.class, &updater.field.owner)? {
            return Err(fault(
                "Ljava/lang/ClassCastException;",
                "Updater receiver is not an instance of the declaring class",
            ));
        }
        if !self.subclass(&self.object(target)?.class, &updater.receiver)? {
            return Err(self.updater_failure(
                "Ljava/lang/IllegalAccessException;",
                "Protected updater receiver is outside caller type",
            )?);
        }
        let index = updater.field.index.ok_or("Updater field index")?;
        let old = self.load_field(target, index)?;
        let wide = updater.kind == 'J';
        let input = |i: usize| -> Result<u64> {
            Ok(arg(i)? as u64 | if wide { (arg(i + 1)? as u64) << 32 } else { 0 })
        };
        if method_name == "get" {
            return Ok(Some(old));
        }
        let mut compare = None;
        let mut returns = 0;
        let value = match method_name {
            "set" | "lazySet" => input(2)?,
            "getAndSet" => {
                returns = old;
                input(2)?
            }
            "compareAndSet" | "weakCompareAndSet" => {
                compare = Some(input(2)?);
                input(if wide { 4 } else { 3 })?
            }
            _ if updater.kind != 'R' => {
                let delta = match method_name {
                    "getAndIncrement" | "incrementAndGet" => 1,
                    "getAndDecrement" | "decrementAndGet" => u64::MAX,
                    _ => input(2)?,
                };
                let value = old.wrapping_add(delta);
                let value = if wide { value } else { value as u32 as u64 };
                returns = if method_name.starts_with("getAnd") {
                    old
                } else {
                    value
                };
                value
            }
            _ => return Ok(None),
        };
        if updater.kind == 'R'
            && value != 0
            && !self
                .class_assignable(&updater.field.descriptor, &self.object(value as u32)?.class)?
        {
            return Err(fault(
                "Ljava/lang/ClassCastException;",
                "Updater value has wrong reference type",
            ));
        }
        if let Some(expected) = compare {
            if old != expected {
                return Ok(Some(0));
            }
            returns = 1;
        }
        self.store_field(target, index, value)?;
        Ok(Some(returns))
    }
}
