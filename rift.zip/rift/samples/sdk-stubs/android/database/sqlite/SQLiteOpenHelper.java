package android.database.sqlite;
import android.content.Context;
public abstract class SQLiteOpenHelper implements AutoCloseable {
 public SQLiteOpenHelper(Context context,String name,SQLiteDatabase.CursorFactory factory,int version){}
 public SQLiteOpenHelper(Context context,String name,SQLiteDatabase.CursorFactory factory,int version,android.database.DatabaseErrorHandler handler){}
 public native String getDatabaseName();public native SQLiteDatabase getWritableDatabase();public native SQLiteDatabase getReadableDatabase();public native void close();
 public void onConfigure(SQLiteDatabase db){}public void onOpen(SQLiteDatabase db){}public void onDowngrade(SQLiteDatabase db,int oldVersion,int newVersion){}
 public abstract void onCreate(SQLiteDatabase db);public abstract void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion);
}
