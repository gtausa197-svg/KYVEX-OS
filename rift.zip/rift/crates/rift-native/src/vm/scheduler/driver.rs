use super::*;
impl Runtime {
    fn wake_guest_threads(&mut self) -> Result<()> {
        let mut waits: Vec<_> = self
            .scheduler
            .records
            .iter()
            .filter_map(|(id, r)| {
                if let State::Waiting(wait) = &r.state {
                    Some((*id, wait.clone(), r.interrupted, r.permit))
                } else {
                    None
                }
            })
            .collect();
        waits.sort_by_key(|(id, _, _, _)| self.scheduler.records[id].wait_order);
        for (id, mut wait, interrupted, permit) in waits {
            let expired = |until: Option<Instant>| until.is_some_and(|t| t <= Instant::now());
            let mut clear_interrupt = false;
            let completion = match &mut wait {
                Wait::Yield => Some(Completion::Value(0)),
                Wait::Sleep(until) => {
                    if interrupted {
                        clear_interrupt = true;
                        Some(Completion::Interrupted)
                    } else if expired(*until) {
                        Some(Completion::Value(0))
                    } else {
                        None
                    }
                }
                Wait::Join { target, until } => {
                    if interrupted {
                        clear_interrupt = true;
                        Some(Completion::Interrupted)
                    } else if !self
                        .scheduler
                        .records
                        .get(target)
                        .is_some_and(Record::alive)
                        || expired(*until)
                    {
                        Some(Completion::Value(0))
                    } else {
                        None
                    }
                }
                Wait::Monitor(object) => {
                    if self.monitor_available(*object, id) {
                        Some(Completion::Retry)
                    } else {
                        None
                    }
                }
                Wait::Initialization(ty) => {
                    if !self.initialization_pending(*ty) {
                        Some(Completion::Retry)
                    } else {
                        None
                    }
                }
                Wait::Object {
                    object,
                    holds,
                    until,
                    notified,
                    interrupted: was_interrupted,
                } => {
                    if interrupted {
                        *was_interrupted = true;
                    }
                    if (*notified || *was_interrupted || expired(*until))
                        && self.monitor_available(*object, id)
                    {
                        self.monitors.insert(
                            *object,
                            Monitor {
                                owner: id,
                                holds: *holds,
                            },
                        );
                        if *was_interrupted {
                            clear_interrupt = true;
                            Some(Completion::Interrupted)
                        } else {
                            Some(Completion::Value(0))
                        }
                    } else {
                        None
                    }
                }
                Wait::Lock {
                    object,
                    until,
                    interruptible,
                    boolean,
                } => {
                    if *interruptible && interrupted {
                        clear_interrupt = true;
                        Some(Completion::Interrupted)
                    } else if self.acquire_lock_for(*object, id, true)? {
                        Some(Completion::Value(*boolean as u64))
                    } else if expired(*until) {
                        Some(Completion::Value(0))
                    } else {
                        None
                    }
                }
                Wait::Latch {
                    object,
                    until,
                    boolean,
                } => {
                    if interrupted {
                        clear_interrupt = true;
                        Some(Completion::Interrupted)
                    } else if matches!(self.object(*object)?.payload, Payload::Latch(Some(0))) {
                        Some(Completion::Value(*boolean as u64))
                    } else if expired(*until) {
                        Some(Completion::Value(0))
                    } else {
                        None
                    }
                }
                Wait::Park { until, .. } => {
                    if permit || interrupted || expired(*until) {
                        if permit {
                            self.scheduler.records.get_mut(&id).unwrap().permit = false;
                        }
                        Some(Completion::Value(0))
                    } else {
                        None
                    }
                }
                Wait::Executor { worker, until } => {
                    if interrupted || self.pool_worker_ready(*worker, *until)? {
                        Some(Completion::Retry)
                    } else {
                        None
                    }
                }
                Wait::ExecutorTermination { pool, until } => {
                    if self.pool_terminated(*pool)? {
                        Some(Completion::Value(1))
                    } else if interrupted {
                        clear_interrupt = true;
                        Some(Completion::Interrupted)
                    } else if expired(*until) {
                        Some(Completion::Value(0))
                    } else {
                        None
                    }
                }
                Wait::Future { task, until } => {
                    if interrupted {
                        clear_interrupt = true;
                        Some(Completion::Interrupted)
                    } else if self.scheduled_task_done(*task)? {
                        Some(Completion::Retry)
                    } else if expired(*until) {
                        Some(Completion::FutureTimeout)
                    } else {
                        None
                    }
                }
                Wait::Handoff { until, .. } => {
                    if interrupted {
                        clear_interrupt = true;
                        Some(Completion::Interrupted)
                    } else if expired(*until) {
                        Some(Completion::Value(0))
                    } else {
                        None
                    }
                }
            };
            let record = self.scheduler.records.get_mut(&id).unwrap();
            if clear_interrupt {
                record.interrupted = false;
            }
            if let Some(completion) = completion {
                self.ready_guest_thread(id, completion)?;
            } else {
                record.state = State::Waiting(wait);
            }
        }
        Ok(())
    }
    pub(in crate::vm) fn completion_result(completion: Completion) -> Result<u64> {
        match completion {
            Completion::Value(value) => Ok(value),
            Completion::Reference(reference) => Ok(reference as u64),
            Completion::Interrupted => Err(fault(
                "Ljava/lang/InterruptedException;",
                "Guest thread interrupted while waiting",
            )),
            Completion::FutureTimeout => Err(fault(
                "Ljava/util/concurrent/TimeoutException;",
                "Scheduled task did not complete in time",
            )),
            Completion::Retry => Err("Retry completion must be applied to its execution".into()),
        }
    }
    fn run_one_guest_worker(&mut self) -> Result<bool> {
        self.wake_guest_threads()?;
        let Some(id) = self.scheduler.queue.pop_front() else {
            return Ok(false);
        };
        if !self
            .scheduler
            .records
            .get(&id)
            .is_some_and(|r| matches!(r.state, State::Runnable))
        {
            return Ok(true);
        }
        let previous = self.current_thread;
        self.switch_guest_thread(id)?;
        let result = (|| -> Result<()> {
            let (entry, stored) = {
                let r = self.scheduler.records.get_mut(&id).unwrap();
                (r.entry.take(), r.execution.take())
            };
            let mut execution = if let Some(mut execution) = stored {
                self.attach_execution(&mut execution)?;
                execution
            } else if let Some((method, args)) = entry {
                match self.begin_execution(method, &args, true) {
                    Ok(execution) => execution,
                    Err(error) => return self.fail_guest_thread(id, error),
                }
            } else {
                return self.finish_guest_thread(id);
            };
            let step = if let Some(completion) = self.take_completion(id)? {
                self.resume_execution_wait(&mut execution, completion)
                    .and_then(|()| self.execution_slice(&mut execution, 512))
            } else {
                self.execution_slice(&mut execution, 512)
            };
            match step {
                Ok(execution::Status::Return(_)) => {
                    self.detach_execution(&mut execution)?;
                    self.finish_guest_thread(id)?;
                }
                Ok(execution::Status::Yield) => {
                    self.detach_execution(&mut execution)?;
                    self.scheduler.records.get_mut(&id).unwrap().execution = Some(execution);
                    self.scheduler.queue.push_back(id);
                }
                Ok(execution::Status::Blocked(wait)) => {
                    self.detach_execution(&mut execution)?;
                    self.scheduler.records.get_mut(&id).unwrap().execution = Some(execution);
                    self.mark_guest_waiting(id, wait)?;
                }
                Err(error) => {
                    self.cancel_execution(&mut execution)?;
                    self.fail_guest_thread(id, error)?;
                }
            }
            Ok(())
        })();
        // All worker stacks are detached or unwound before restoring the caller.
        let restored = self.switch_guest_thread(previous);
        if self
            .scheduler
            .records
            .get(&id)
            .is_some_and(|r| matches!(r.state, State::Terminated))
        {
            self.machine
                .release_thread(self.object(id)?.fields[&threads::ID] as u32)?;
        }
        restored?;
        result?;
        Ok(true)
    }
    fn fail_guest_thread(
        &mut self,
        id: u32,
        error: Box<dyn std::error::Error + Send + Sync>,
    ) -> Result<()> {
        let result = (|| -> Result<bool> {
            let Some(exception) = error.downcast_ref::<JavaFault>() else {
                return Err(error);
            };
            if self.scheduler.records[&id].uncaught_handler {
                self.log_guest_thread_fault(format!(
                    "Exception from guest uncaught handler: {exception}"
                ));
                return Ok(false);
            }
            let throwable = self.materialize_fault(exception)?;
            let handler = self.thread_handler(id)?;
            if let Some(entry) = self.uncaught_target(handler, id, throwable, false)? {
                let record = self.scheduler.records.get_mut(&id).unwrap();
                record.uncaught_handler = true;
                record.entry = Some(entry);
                record.state = State::Runnable;
                self.scheduler.queue.push_back(id);
                Ok(true)
            } else {
                self.log_unhandled_thread(id, throwable)?;
                Ok(false)
            }
        })();
        if !matches!(result, Ok(true)) {
            self.finish_guest_thread(id)?;
        }
        result.map(|_| ())
    }
    pub(in crate::vm) fn log_guest_thread_fault(&mut self, message: String) {
        self.append_guest_log(message);
    }
    pub(in crate::vm) fn pump_guest_workers(&mut self, limit: usize) -> Result<()> {
        if !self.callers.is_empty() {
            return Err("Guest worker pump requires detached Java frames".into());
        }
        for _ in 0..limit.min(64) {
            if !self.run_one_guest_worker()? {
                break;
            }
        }
        let result = self.machine.pump_native_threads(limit.min(8));
        self.flush_native_logs();
        result
    }
    pub(in crate::vm) fn drive_guest_execution(
        &mut self,
        execution: &mut execution::Execution,
    ) -> Result<u64> {
        let thread = self.current_thread;
        loop {
            let pump = execution.top_level() && thread == self.main_thread;
            match self.execution_slice(execution, 512) {
                Ok(execution::Status::Return(value)) => {
                    if pump {
                        self.detach_execution(execution)?;
                        self.pump_guest_workers(1)?;
                    }
                    return Ok(value);
                }
                Ok(execution::Status::Yield) => {
                    self.detach_execution(execution)?;
                    if pump {
                        if self.gc_requested {
                            self.collect()?;
                        }
                        self.pump_guest_workers(1)?;
                    }
                    self.attach_execution(execution)?;
                }
                Ok(execution::Status::Blocked(wait)) => {
                    self.detach_execution(execution)?;
                    let yielding = matches!(wait, Wait::Yield);
                    self.mark_guest_waiting(thread, wait)?;
                    if yielding {
                        self.run_one_guest_worker()?;
                    }
                    loop {
                        self.wake_guest_threads()?;
                        if let Some(completion) = self.take_completion(thread)? {
                            self.attach_execution(execution)?;
                            self.resume_execution_wait(execution, completion)?;
                            break;
                        }
                        if !self.run_one_guest_worker()? {
                            if !self
                                .scheduler
                                .records
                                .values()
                                .any(|r| matches!(&r.state, State::Waiting(wait) if wait.timed()))
                            {
                                return Err("Guest Java threads are deadlocked: no runnable thread or timed wakeup".into());
                            }
                            // Polling has no descriptors and opens no host capability.
                            unsafe {
                                libc::poll(std::ptr::null_mut(), 0, 1);
                            }
                        }
                    }
                }
                Err(error) => {
                    self.cancel_execution(execution)?;
                    return Err(error);
                }
            }
        }
    }
    pub(in crate::vm) fn shutdown_guest_threads(&mut self) -> Result<()> {
        let ids: Vec<_> = self
            .scheduler
            .records
            .keys()
            .copied()
            .filter(|id| *id != self.main_thread)
            .collect();
        for id in ids {
            if let Some(mut execution) = self
                .scheduler
                .records
                .get_mut(&id)
                .unwrap()
                .execution
                .take()
            {
                self.cancel_execution(&mut execution)?;
            }
            self.finish_guest_thread(id)?;
            let tid = self.object(id)?.fields[&threads::ID] as u32;
            self.machine.release_thread(tid)?;
        }
        self.scheduler.queue.clear();
        Ok(())
    }
}
