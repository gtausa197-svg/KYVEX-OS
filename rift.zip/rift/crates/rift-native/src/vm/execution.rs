//! Owned Java, invocation and initialization continuations; no borrowed Rust stack is suspended.
use super::*;
use std::{cell::RefCell, rc::Rc};
pub(super) const MAX_CALL_DEPTH: usize = 128;
const MAX_CONTINUATIONS: usize = MAX_CALL_DEPTH * 2 + 64;
pub(super) type Roots = Rc<RefCell<BTreeMap<u64, Vec<u32>>>>;
pub(super) struct RootLease {
    id: u64,
    roots: Roots,
    traces: stack_trace::Registry,
}
impl RootLease {
    pub(super) fn keep(&mut self, object: u32) -> Result<()> {
        if object == 0 {
            return Ok(());
        }
        let mut roots = self.roots.borrow_mut();
        let values = roots.get_mut(&self.id).ok_or("Expired library roots")?;
        if values.len() >= 4112 {
            return Err("Library reference quota".into());
        }
        values.push(object);
        Ok(())
    }
}
impl Drop for RootLease {
    fn drop(&mut self) {
        self.roots.borrow_mut().remove(&self.id);
        self.traces.borrow_mut().remove(&self.id);
    }
}
struct JavaFrame {
    index: usize,
    body: Body,
    registers: Vec<u32>,
    cursor: interpreter::Cursor,
}
enum Frame {
    Java(JavaFrame),
    Call(interpreter::Call),
    Initialize(initialization::Task),
}
impl Frame {
    fn index(&self) -> Option<usize> {
        if let Self::Java(frame) = self {
            Some(frame.index)
        } else {
            None
        }
    }
    fn bytes(&self) -> usize {
        match self {
            Self::Java(frame) => frame.registers.capacity() * 4 + frame.body.code.capacity() * 2,
            Self::Call(call) => 64 + call.args.capacity() * 4,
            Self::Initialize(task) => 64 + task.dependencies.capacity() * 8,
        }
    }
}
enum Entered {
    Frame(JavaFrame),
    Value(u64),
}
pub(super) struct Execution {
    frames: Vec<Frame>,
    result: Option<u64>,
    baseline: usize,
    detached: bool,
    lease: RootLease,
    suspended: Option<Suspended>,
    thread: u32,
}
enum Suspended {
    Call,
    Instruction,
    Initialization,
}
pub(super) enum Status {
    Yield,
    Return(u64),
    Blocked(scheduler::Wait),
}
impl Execution {
    pub(super) fn top_level(&self) -> bool {
        self.baseline == 0
    }
    fn java_depth(&self) -> usize {
        self.frames.iter().filter_map(Frame::index).count()
    }
}
impl Runtime {
    pub(super) fn scoped_library_roots(&mut self, values: &[u32]) -> Result<RootLease> {
        if self.execution_roots.borrow().len() >= 64 || values.len() > 4112 {
            return Err("Library execution roots quota".into());
        }
        let id = self.next_execution;
        self.next_execution = id
            .checked_add(1)
            .ok_or("Java execution sequence exhausted")?;
        self.execution_roots
            .borrow_mut()
            .insert(id, values.to_vec());
        Ok(RootLease {
            id,
            roots: Rc::clone(&self.execution_roots),
            traces: Rc::clone(&self.trace_contexts),
        })
    }
    fn leave_java_frame(&mut self, index: usize) -> Result<()> {
        if self.callers.pop() != Some(index) {
            return Err("Java caller stack is inconsistent".into());
        }
        self.depth = self
            .depth
            .checked_sub(1)
            .ok_or("Java frame depth underflow")?;
        Ok(())
    }
    fn new_execution(&mut self, frame: Frame) -> Result<Execution> {
        self.ensure_main_thread()?;
        if self.execution_roots.borrow().len() >= 64 {
            return Err("Java execution context quota".into());
        }
        let id = self.next_execution;
        self.next_execution = id
            .checked_add(1)
            .ok_or("Java execution sequence exhausted")?;
        let execution = Execution {
            frames: vec![frame],
            result: None,
            baseline: self.callers.len(),
            detached: false,
            lease: RootLease {
                id,
                roots: Rc::clone(&self.execution_roots),
                traces: Rc::clone(&self.trace_contexts),
            },
            suspended: None,
            thread: self.current_thread,
        };
        self.refresh_execution_roots(&execution);
        Ok(execution)
    }
    pub(super) fn begin_execution(
        &mut self,
        index: usize,
        args: &[u32],
        virtual_call: bool,
    ) -> Result<Execution> {
        self.new_execution(Frame::Call(interpreter::Call {
            index,
            args: args.to_vec(),
            virtual_call,
        }))
    }
    pub(super) fn begin_initialization(&mut self, ty: usize) -> Result<Execution> {
        self.new_execution(Frame::Initialize(initialization::Task::new(ty)))
    }
    fn refresh_execution_roots(&self, execution: &Execution) {
        let mut methods: Vec<_> = execution.frames.iter().filter_map(Frame::index).collect();
        if matches!(execution.suspended, Some(Suspended::Call))
            && let Some(Frame::Call(call)) = execution.frames.last()
        {
            methods.push(call.index);
        }
        execution.lease.traces.borrow_mut().insert(
            execution.lease.id,
            stack_trace::Context {
                thread: execution.thread,
                baseline: execution.baseline,
                methods,
            },
        );
        let mut roots = Vec::new();
        for frame in &execution.frames {
            match frame {
                Frame::Java(frame) => {
                    roots.extend(&frame.registers);
                    roots.push(frame.cursor.pending_exception);
                    if let Ok(value) = u32::try_from(frame.cursor.result) {
                        roots.push(value);
                    }
                }
                Frame::Call(call) => roots.extend(&call.args),
                Frame::Initialize(_) => {}
            }
        }
        if let Some(value) = execution.result.and_then(|value| u32::try_from(value).ok()) {
            roots.push(value);
        }
        execution
            .lease
            .roots
            .borrow_mut()
            .insert(execution.lease.id, roots);
    }
    fn execution_attached(&self, execution: &Execution) -> bool {
        self.callers.len() == execution.baseline + execution.java_depth()
            && self.callers[execution.baseline..]
                .iter()
                .copied()
                .eq(execution.frames.iter().filter_map(Frame::index))
    }
    pub(super) fn detach_execution(&mut self, execution: &mut Execution) -> Result<()> {
        if execution.detached {
            return Err("Java execution is already detached".into());
        }
        if !self.execution_attached(execution) {
            return Err("Cannot detach a different Java caller context".into());
        }
        self.callers.truncate(execution.baseline);
        self.depth -= execution.java_depth();
        execution.detached = true;
        Ok(())
    }
    pub(super) fn attach_execution(&mut self, execution: &mut Execution) -> Result<()> {
        if !execution.detached {
            return Err("Java execution is already attached".into());
        }
        if self.depth + execution.java_depth() > MAX_CALL_DEPTH {
            return Err("DEX call stack limit".into());
        }
        execution.baseline = self.callers.len();
        self.callers
            .extend(execution.frames.iter().filter_map(Frame::index));
        self.depth += execution.java_depth();
        execution.detached = false;
        Ok(())
    }
    pub(super) fn cancel_execution(&mut self, execution: &mut Execution) -> Result<()> {
        if !execution.detached {
            self.detach_execution(execution)?;
        }
        self.abandon_initialization(execution.lease.id);
        execution.frames.clear();
        execution.result = None;
        execution.suspended = None;
        self.refresh_execution_roots(execution);
        Ok(())
    }
    fn execution_error(
        &mut self,
        execution: &mut Execution,
        mut error: Box<dyn std::error::Error + Send + Sync>,
    ) -> Result<()> {
        error = self.pin_fault(error);
        while let Some(frame) = execution.frames.pop() {
            match frame {
                Frame::Java(frame) => {
                    self.leave_java_frame(frame.index)?;
                    if !error.is::<JavaFault>() {
                        error = format!("{}: {error}", self.dex.signature(frame.index)).into();
                    }
                }
                Frame::Call(_) => {
                    if let Some(Frame::Java(parent)) = execution.frames.last_mut() {
                        match self.resume_interpreter_call(
                            &parent.body,
                            &mut parent.cursor,
                            Err(error),
                        ) {
                            Ok(()) => return Ok(()),
                            Err(next) => error = next,
                        }
                    }
                }
                Frame::Initialize(task) => {
                    error = self.fail_initialization(
                        task.ty,
                        execution.lease.id,
                        task.stage == initialization::Stage::Clinit,
                        error,
                    )?;
                    if let Some(Frame::Java(parent)) = execution.frames.last_mut() {
                        match self.resume_interpreter_instruction(
                            &parent.body,
                            &mut parent.cursor,
                            error,
                        ) {
                            Ok(()) => return Ok(()),
                            Err(next) => error = next,
                        }
                    }
                }
            }
        }
        Err(error)
    }
    fn execution_call_result(
        &mut self,
        execution: &mut Execution,
        outcome: Result<u64>,
    ) -> Result<()> {
        let value = match outcome {
            Ok(value) => value,
            Err(error) => return self.execution_error(execution, error),
        };
        if !matches!(execution.frames.pop(), Some(Frame::Call(_))) {
            return Err("Missing Java invocation continuation".into());
        }
        match execution.frames.last_mut() {
            Some(Frame::Java(parent)) => {
                match self.resume_interpreter_call(&parent.body, &mut parent.cursor, Ok(value)) {
                    Ok(()) => Ok(()),
                    Err(error) => self.execution_error(execution, error),
                }
            }
            Some(Frame::Initialize(task)) if task.stage == initialization::Stage::Clinit => {
                task.stage = initialization::Stage::Complete;
                Ok(())
            }
            None => {
                execution.result = Some(value);
                Ok(())
            }
            _ => Err("Unexpected Java invocation return target".into()),
        }
    }
    pub(super) fn execution_slice(
        &mut self,
        execution: &mut Execution,
        quantum: usize,
    ) -> Result<Status> {
        if execution.detached {
            return Err("Attach the Java execution before resuming it".into());
        }
        self.ensure_main_thread()?;
        if execution.suspended.is_some() {
            return Err("Execution is still waiting for a completion".into());
        }
        let previous_suspend =
            std::mem::replace(&mut self.suspension_allowed, execution.top_level());
        let previous_init = std::mem::replace(&mut self.defer_initialization, true);
        let result = self.run_execution_slice(execution, quantum);
        self.suspension_allowed = previous_suspend;
        self.defer_initialization = previous_init;
        self.refresh_execution_roots(execution);
        result
    }
    pub(super) fn resume_execution_wait(
        &mut self,
        execution: &mut Execution,
        completion: scheduler::Completion,
    ) -> Result<()> {
        if execution.detached {
            return Err("Waiting execution must be attached".into());
        }
        let suspended = execution
            .suspended
            .take()
            .ok_or("Execution has no outstanding wait")?;
        match (suspended, completion) {
            (_, scheduler::Completion::Retry) => {}
            (Suspended::Call, completion) => {
                self.execution_call_result(execution, Self::completion_result(completion))?
            }
            _ => {
                return Err(
                    "Waiting instruction or initialization requires retry completion".into(),
                );
            }
        }
        self.refresh_execution_roots(execution);
        Ok(())
    }
    fn push_initialization(execution: &mut Execution, ty: usize) -> Result<()> {
        if execution
            .frames
            .iter()
            .filter(|frame| matches!(frame, Frame::Initialize(_)))
            .count()
            >= 64
        {
            return Err("Class initialization continuation quota".into());
        }
        execution
            .frames
            .push(Frame::Initialize(initialization::Task::new(ty)));
        Ok(())
    }
    fn step_initialization(
        &mut self,
        execution: &mut Execution,
    ) -> Result<Option<scheduler::Wait>> {
        let Some(Frame::Initialize(task)) = execution.frames.last_mut() else {
            return Err("Missing initialization continuation".into());
        };
        match task.stage {
            initialization::Stage::Acquire => match self.check_initialization(task.ty)? {
                initialization::Check::Ready => task.stage = initialization::Stage::Complete,
                initialization::Check::Wait => {
                    if !self.can_suspend() {
                        return Err("Blocking class initialization inside synchronous library callback is not implemented".into());
                    }
                    return Ok(Some(scheduler::Wait::Initialization(task.ty)));
                }
                initialization::Check::Begin => {
                    task.dependencies = self.claim_initialization(task.ty, execution.lease.id)?;
                    task.stage = initialization::Stage::Dependencies;
                }
            },
            initialization::Stage::Dependencies => {
                if let Some(dependency) = task.dependencies.pop_front() {
                    Self::push_initialization(execution, dependency)?;
                } else if let Some(method) = self.dex.find(self.dex.ty(task.ty), "<clinit>", "()V")
                {
                    task.stage = initialization::Stage::Clinit;
                    execution.frames.push(Frame::Call(interpreter::Call {
                        index: method,
                        args: Vec::new(),
                        virtual_call: false,
                    }));
                } else {
                    task.stage = initialization::Stage::Complete;
                }
            }
            initialization::Stage::Complete => {
                let ty = task.ty;
                if matches!(self.initialization_states.get(&ty),Some(initialization::State::Running{execution:owner,..})if *owner==execution.lease.id)
                {
                    self.initialization_states
                        .insert(ty, initialization::State::Complete);
                }
                execution.frames.pop();
                if execution.frames.is_empty() {
                    execution.result = Some(0);
                }
            }
            initialization::Stage::Clinit => {
                return Err("Initializer is missing its clinit call continuation".into());
            }
        }
        Ok(None)
    }
    fn run_execution_slice(
        &mut self,
        execution: &mut Execution,
        mut quantum: usize,
    ) -> Result<Status> {
        if !self.execution_attached(execution) {
            return Err("Java execution is attached to a different caller context".into());
        }
        loop {
            if let Some(value) = execution.result {
                return Ok(Status::Return(value));
            }
            if quantum == 0 {
                return Ok(Status::Yield);
            }
            let before = self.instructions;
            let step = match execution
                .frames
                .last_mut()
                .ok_or("Empty Java execution stack")?
            {
                Frame::Call(call) => {
                    let index = call.index;
                    let args = call.args.clone();
                    let virtual_call = call.virtual_call;
                    match self.enter_invocation(index, &args, virtual_call) {
                        Ok(Entered::Frame(frame)) => execution.frames.push(Frame::Java(frame)),
                        Ok(Entered::Value(value)) => {
                            self.execution_call_result(execution, Ok(value))?
                        }
                        Err(error) => {
                            if let Some(request) = error.downcast_ref::<initialization::Request>() {
                                Self::push_initialization(execution, request.0)?;
                            } else if let Some(signal) = error.downcast_ref::<scheduler::Signal>() {
                                execution.suspended = Some(Suspended::Call);
                                return Ok(Status::Blocked(signal.0.clone()));
                            } else {
                                self.execution_error(execution, error)?;
                            }
                        }
                    }
                    Ok(None)
                }
                Frame::Initialize(_) => {
                    match self.step_initialization(execution) {
                        Ok(Some(wait)) => {
                            execution.suspended = Some(Suspended::Initialization);
                            return Ok(Status::Blocked(wait));
                        }
                        Ok(None) => {}
                        Err(error) => self.execution_error(execution, error)?,
                    }
                    Ok(None)
                }
                Frame::Java(frame) => self
                    .interpret_slice(
                        &frame.body,
                        &mut frame.registers,
                        &mut frame.cursor,
                        quantum,
                    )
                    .map(Some),
            };
            match step {
                Ok(Some(interpreter::Slice::Yield)) => return Ok(Status::Yield),
                Ok(Some(interpreter::Slice::Blocked(wait))) => {
                    execution.suspended = Some(Suspended::Instruction);
                    return Ok(Status::Blocked(wait));
                }
                Ok(Some(interpreter::Slice::Initialize(ty))) => {
                    Self::push_initialization(execution, ty)?
                }
                Ok(Some(interpreter::Slice::Invoke(call))) => {
                    execution.frames.push(Frame::Call(call))
                }
                Ok(Some(interpreter::Slice::Return(value))) => {
                    let Some(Frame::Java(frame)) = execution.frames.pop() else {
                        return Err("Missing returning Java frame".into());
                    };
                    self.leave_java_frame(frame.index)?;
                    self.execution_call_result(execution, Ok(value))?;
                }
                Ok(None) => {}
                Err(error) => self.execution_error(execution, error)?,
            }
            if execution.frames.len() > MAX_CONTINUATIONS
                || execution.frames.iter().map(Frame::bytes).sum::<usize>() > self.heap_limit / 2
            {
                return Err("Java stack memory/continuation quota".into());
            }
            quantum = quantum.saturating_sub(((self.instructions - before) as usize).max(1));
        }
    }
    fn enter_invocation(
        &mut self,
        mut index: usize,
        args: &[u32],
        virtual_call: bool,
    ) -> Result<Entered> {
        let method = self
            .dex
            .methods
            .get(index)
            .ok_or("DEX invocation method index")?
            .clone();
        let name = self.dex.strings[method.name].clone();
        let descriptor = self.descriptor(index);
        let declared = self.dex.ty(method.class).to_owned();
        self.ensure_class(&declared)?;
        if let Some(resolved) = self.dex.find(&declared, &name, &descriptor) {
            index = resolved;
        }
        // ART resolves direct/static references through the superclass chain too.
        // Optimized APKs may omit an empty constructor and reference its superclass.
        let (mut hle_class, forwarded) = if virtual_call {
            let receiver =
                self.object(*args.first().ok_or("Virtual invocation has no receiver")?)?;
            if let Some(target) = self.executor_receiver(receiver, &name, &descriptor)? {
                let mut words = args.to_vec();
                words[0] = target;
                (self.object(target)?.class.clone(), Some(words))
            } else {
                (receiver.class.clone(), None)
            }
        } else {
            (declared, None)
        };
        let args = forwarded.as_deref().unwrap_or(args);
        let receiver_class = hle_class.clone();
        let mut class_method = false;
        for depth in 0..64 {
            self.ensure_class(&hle_class)?;
            if let Some(i) = self.dex.find(&hle_class, &name, &descriptor)
                && self.dex.bodies.contains_key(&i)
            {
                index = i;
                class_method = true;
                break;
            }
            if name == "<clinit>" {
                break;
            }
            let Some(ty) = self.dex.type_id(&hle_class) else {
                break;
            };
            let Some(parent) = self.dex.classes.get(&ty).and_then(|c| c.parent) else {
                break;
            };
            hle_class = self.dex.ty(parent).to_owned();
            if depth == 63 {
                return Err("DEX method hierarchy budget".into());
            }
        }
        if virtual_call
            && !class_method
            && name != "<init>"
            && name != "<clinit>"
            && let Some(method) = self.default_method(&receiver_class, &name, &descriptor)?
        {
            index = method;
        }
        let method = self.dex.methods[index].clone();
        let body = self.dex.bodies.get(&index).cloned();
        let signature = self.dex.signature(index);
        self.trace_startup_call(index);
        // A library Thread.run forwards into the target's owned Java frame.
        // Keeping this out of a Rust callback lets the Runnable really suspend.
        if body.is_none()
            && hle_class == "Ljava/lang/Thread;"
            && name == "run"
            && descriptor == "()V"
        {
            let receiver = *args.first().ok_or("Thread.run receiver")?;
            let target = self
                .object(receiver)?
                .fields
                .get(&threads::TARGET)
                .copied()
                .unwrap_or(0) as u32;
            if target != 0 {
                let run = self
                    .callback_method(target, "run", "()V")?
                    .ok_or("Runnable.run implementation absent")?;
                return self.enter_invocation(run, &[target], true);
            }
        }
        // Native group delegation also forwards into an owned Java frame. A
        // parent's/default handler may really wait, including after super calls.
        if body.is_none()
            && hle_class == "Ljava/lang/ThreadGroup;"
            && name == "uncaughtException"
            && descriptor == thread_groups::UNCAUGHT
        {
            let receiver = *args.first().ok_or("ThreadGroup handler receiver")?;
            let thread = *args.get(1).ok_or("Uncaught Thread")?;
            let throwable = *args.get(2).ok_or("Uncaught Throwable")?;
            if let Some((target, args)) = self.uncaught_target(receiver, thread, throwable, true)? {
                return self.enter_invocation(target, &args, true);
            }
            self.log_unhandled_thread(thread, throwable)?;
            return Ok(Entered::Value(0));
        }
        if self.depth >= MAX_CALL_DEPTH {
            return Err("DEX call stack limit".into());
        }
        self.depth += 1;
        self.callers.push(index);
        let result = (|| -> Result<Entered> {
            if let Some(body) = body {
                if body.access & 8 != 0 && name != "<clinit>" {
                    self.initialize(method.class)?;
                }
                if body.access & 0x100 != 0 {
                    if body.access & 0x20 != 0 {
                        let monitor = if body.access & 8 != 0 {
                            self.class_object(self.dex.ty(method.class).to_owned().as_str())?
                        } else {
                            *args.first().ok_or("Synchronized native receiver")?
                        };
                        self.enter_monitor(monitor)?;
                        let result = self.native(index, args);
                        self.exit_monitor(monitor)?;
                        return result.map(Entered::Value);
                    }
                    return self.native(index, args).map(Entered::Value);
                }
                if body.access & 0x400 != 0 {
                    return Err(fault(
                        "Ljava/lang/AbstractMethodError;",
                        "Cannot invoke an abstract DEX method",
                    ));
                }
                if body.incoming != args.len() {
                    return Err(format!("DEX argument/register mismatch: {signature}").into());
                }
                let mut regs = vec![0; body.registers];
                let start = body.registers - body.incoming;
                regs[start..].copy_from_slice(args);
                Ok(Entered::Frame(JavaFrame {
                    index,
                    body,
                    registers: regs,
                    cursor: interpreter::Cursor::default(),
                }))
            } else {
                self.hle(&format!("{hle_class}->{name}{descriptor}"), args)
                    .map(Entered::Value)
            }
        })();
        let result = result.map_err(|error| self.pin_fault(error));
        if !matches!(&result, Ok(Entered::Frame(_))) {
            self.leave_java_frame(index)?;
        }
        result.map_err(|e| {
            if e.is::<JavaFault>()
                || e.is::<scheduler::Signal>()
                || e.is::<initialization::Request>()
            {
                e
            } else {
                format!("{signature}: {e}").into()
            }
        })
    }
}
