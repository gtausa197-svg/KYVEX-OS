#!/usr/bin/env python3
"""Exercise the real per-user daemon, its APK importer and input IPC."""
import argparse,json,os,pathlib,socket,struct,tempfile,time,zipfile
p=argparse.ArgumentParser();p.add_argument('apk');a=p.parse_args()
path=f'/run/user/{os.getuid()}/kyvex-rift.sock'
def call(method,params=None,version=1):
    with socket.socket(socket.AF_UNIX) as s:
        s.connect(path);s.sendall((json.dumps(dict(version=version,method=method,params=params or {}))+'\n').encode());s.settimeout(60)
        data=b''
        while b'\n' not in data:data+=s.recv(65536)
        return json.loads(data)
def ok(method,params=None):
    result=call(method,params);assert result['ok'],result;return result['data']
assert not call('status',version=99)['ok']
assert not call('arbitrary-shell',{'command':'echo forbidden'})['ok']
info=ok('inspect',{'path':str(pathlib.Path(a.apk).resolve())})
assert info['package']=='com.kiloo.subwaysurf' and set(info['abis'])=={'armeabi-v7a','arm64-v8a'}
assert info['dex_files']>=2 and info['native_libraries']>=2
print('PASS real Subway APK metadata / DEX / native ABI inspection',flush=True)
item=ok('import',{'path':a.apk});assert item['sha256']==info['sha256']
assert any(v['package']==info['package'] for v in ok('list'))
profile=ok('profile',{'package':info['package']});assert len(profile['controls'])==5
ok('save-profile',profile);assert ok('profile',{'package':info['package']})==profile
bad={**profile,'schema_version':9};assert not call('save-profile',bad)['ok']
bad={**profile,'controls':[dict(profile['controls'][0],x=1.1)]};assert not call('save-profile',bad)['ok']
ok('session',{'package':'org.kyvex.test','android':False});ok('input',{'key':'W','down':True});ok('input',{'key':'Space','down':True})
state=ok('heartbeat');assert len(state['contacts'])==2 and len({v['pointer'] for v in state['contacts']})==2
ok('input',{'key':'W','down':False});assert len(ok('heartbeat')['contacts'])==1
ok('release');assert not ok('heartbeat')['contacts']
ok('touch',{'pointer':90,'action':'down','x':0.4,'y':0.5});assert len(ok('heartbeat')['contacts'])==1;time.sleep(2.05)
assert not ok('heartbeat')['contacts']
ok('input',{'key':'Space','down':True});time.sleep(2.05);assert not ok('heartbeat')['contacts']
print('PASS concurrent pointers / release / lost-client watchdog',flush=True)
ok('session',{'package':info['package'],'android':False});ok('input',{'key':'Up','down':True});time.sleep(.2)
state=ok('heartbeat');assert not state['contacts'];assert any(t['action']=='up' and abs(t['y']-.2)<1e-6 for t in state['trace'])
assert ok('native-test')['result']==42
print('PASS Subway swipe scheduler / bounded native DEX arithmetic',flush=True)
with tempfile.TemporaryDirectory() as d:
    manifest=zipfile.ZipFile(a.apk).read('AndroidManifest.xml')
    for name,entries in [('traversal',[('AndroidManifest.xml',manifest),('../outside',b'x')]),('truncated',[('AndroidManifest.xml',b'\x03\x00')]),('dex',[('AndroidManifest.xml',manifest),('classes.dex',b'bad')])]:
        file=pathlib.Path(d)/(name+'.apk')
        with zipfile.ZipFile(file,'w') as z:
            for n,b in entries:z.writestr(n,b)
        assert not call('inspect',{'path':str(file)})['ok']
print('PASS malicious ZIP path / truncated manifest / malformed DEX rejection',flush=True)
ok('disconnect')
print(json.dumps(info,indent=2))
