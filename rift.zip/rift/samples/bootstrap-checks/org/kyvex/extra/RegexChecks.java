package org.kyvex.extra;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class RegexChecks {
    private static int checks;

    private static void check(boolean condition, String description) {
        if (!condition) throw new IllegalStateException(description);
        checks++;
    }

    public static int verify() {
        checks = 0;
        check("a_b_.c".equals("a-b_.c".replaceAll("[^a-zA-Z0-9.]", "_")), "Crashlytics filename");
        check("0,456".equals("123,456".replaceFirst("[0-9]+", "0")), "First replacement only");
        check("AB9:AB:AB:9".equals("AB9".replaceAll("(?<tag>[A-Z]+)([0-9]+)?",
                "$0:${tag}:$1:$2")), "Whole, named and numbered captures");
        check("AB0!".equals("AB".replaceAll("([A-Z]+)([0-9]+)?", "$10$2!")), "Greedy valid group and unmatched capture");
        check("$\\x".equals("a".replaceAll("a", "\\$\\\\\\x")), "Escaped dollar, slash and literal");
        check("-a-b-".equals("ab".replaceAll("", "-")), "Empty matches make progress");
        check("a-b".equals("ab".replaceAll("(?=b)", "-")), "Zero-width lookahead");
        String emoji = "\uD83D\uDE00";
        check(("[" + emoji + "]").equals(emoji.replaceAll("(.)", "[$1]")), "Supplementary group");
        check(new String(new char[]{'-', '\uD83D', '-', '\uDE00', '-'}).equals(emoji.replaceAll("", "-")),
                "Empty pattern uses UTF-16 boundaries");

        String unchanged = new String(new char[]{'a', 'b'});
        check(unchanged.replaceAll("x", "$") == unchanged, "Skip invalid replacement on no match");
        check(unchanged.replaceAll("x", null) == unchanged, "Lazy null check in replaceAll");
        try {
            unchanged.replaceFirst("x", null);
            throw new IllegalStateException("Null replacement accepted");
        } catch (NullPointerException expected) {
            checks++;
        }
        try {
            "a".replaceAll("(a)", "$2");
            throw new IllegalStateException("Invalid capture accepted");
        } catch (IndexOutOfBoundsException expected) {
            checks++;
        }
        try {
            "a".replaceAll("(a)", "${unknown}");
            throw new IllegalStateException("Unknown name accepted");
        } catch (IllegalArgumentException expected) {
            checks++;
        }
        try {
            "a".replaceAll("(a)", "\\");
            throw new IllegalStateException("Dangling escape accepted");
        } catch (IllegalArgumentException expected) {
            checks++;
        }

        Matcher matcher = Pattern.compile("(a)").matcher(new StringBuilder("aba"));
        check(matcher.find() && matcher.find(), "Matcher positions before replacement");
        check("Aba".equals(matcher.replaceFirst("A")) && "a".equals(matcher.group())
                && matcher.start() == 0 && matcher.find() && matcher.start() == 2, "ReplaceFirst resets the matcher");
        check("[a]b[a]".equals(matcher.replaceAll("[$1]")), "ReplaceAll resets the matcher");
        boolean exhausted = false;
        try { matcher.group(); }
        catch (IllegalStateException expected) { exhausted = true; }
        check(exhausted, "Exhausted matcher");
        return checks;
    }

    public static void main(String[] args) {
        System.out.println("Regex replacement checks: " + verify());
    }
}
