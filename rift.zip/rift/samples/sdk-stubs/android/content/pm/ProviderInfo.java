package android.content.pm;
public class ProviderInfo extends ComponentInfo {
 public String authority,readPermission,writePermission;
 public int initOrder,flags;
 public boolean grantUriPermissions;
}
