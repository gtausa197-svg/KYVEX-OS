package org.kyvex.rift.internal;

/** Compile-time signatures only. Never included in the runtime DEX. */
final class PoolAccess {
 static native Runnable next(PoolWorker worker);
 static native void before(PoolWorker worker,Runnable task);
 static native void after(PoolWorker worker,Runnable task,Throwable failure);
 static native void done(PoolWorker worker);
 static native void exit(PoolWorker worker,boolean abrupt);
 static native Object startTask(ScheduledTask task);
 static native boolean isCallable(ScheduledTask task);
 static native void finishTask(ScheduledTask task,Object value,Throwable failure);
}
