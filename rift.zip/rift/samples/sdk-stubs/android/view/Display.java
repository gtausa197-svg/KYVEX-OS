package android.view;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.DisplayMetrics;
public final class Display {
    public int getDisplayId() { return 0; }
    public int getRotation() { return 0; }
    public void getSize(Point outSize) {}
    public void getRealSize(Point outSize) {}
    public void getRectSize(Rect outSize) {}
    public void getMetrics(DisplayMetrics outMetrics) {}
    public void getRealMetrics(DisplayMetrics outMetrics) {}
    public float getRefreshRate() { return 0; }
    public float[] getSupportedRefreshRates() { return null; }
    public Mode getMode() { return null; }
    public boolean isHdr() { return false; }
    public HdrCapabilities getHdrCapabilities() { return null; }
    public static final class Mode {
        public int getModeId() { return 0; }
        public int getPhysicalWidth() { return 0; }
        public int getPhysicalHeight() { return 0; }
        public float getRefreshRate() { return 0; }
    }
    public static final class HdrCapabilities {
        public int[] getSupportedHdrTypes() { return null; }
        public float getDesiredMaxLuminance() { return 0; }
    }
}
