package android.database;
public interface Cursor extends java.io.Closeable {
 int FIELD_TYPE_NULL=0,FIELD_TYPE_INTEGER=1,FIELD_TYPE_FLOAT=2,FIELD_TYPE_STRING=3,FIELD_TYPE_BLOB=4;
 int getCount();int getPosition();int getColumnCount();String[] getColumnNames();String getColumnName(int column);
 int getColumnIndex(String name);int getColumnIndexOrThrow(String name);
 boolean moveToFirst();boolean moveToLast();boolean moveToNext();boolean moveToPrevious();boolean moveToPosition(int position);boolean move(int offset);
 boolean isFirst();boolean isLast();boolean isBeforeFirst();boolean isAfterLast();boolean isClosed();void close();
 int getType(int column);boolean isNull(int column);String getString(int column);byte[] getBlob(int column);
 int getInt(int column);short getShort(int column);long getLong(int column);float getFloat(int column);double getDouble(int column);
}
