//! Executor configuration, guest latches and saturated TimeUnit conversions.
use super::*;

pub(super) const ABORT_POLICY: &str = "Ljava/util/concurrent/ThreadPoolExecutor$AbortPolicy;";
pub(super) const DISCARD_POLICY: &str = "Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;";

const FACTORS: [i128; 7] = [
    1,
    1000,
    1_000_000,
    1_000_000_000,
    60_000_000_000,
    3_600_000_000_000,
    86_400_000_000_000,
];
const NAMES: [&str; 7] = [
    "NANOSECONDS",
    "MICROSECONDS",
    "MILLISECONDS",
    "SECONDS",
    "MINUTES",
    "HOURS",
    "DAYS",
];
#[derive(Default, Clone)]
pub(super) struct Executor {
    pub core: u32,
    pub maximum: u32,
    pub keep_alive: i64,
    pub queue: u32,
    pub factory: u32,
    pub handler: u32,
    pub timeout: bool,
    pub shutdown: bool,
    pub stopping: bool,
    pub terminating: bool,
    pub terminated: bool,
    pub workers: Vec<u32>,
    pub largest: usize,
    pub completed: u64,
}
pub(super) fn payload(class: &str) -> Option<Payload> {
    match class {
        "Ljava/util/concurrent/CountDownLatch;" => Some(Payload::Latch(None)),
        scheduler::HANDOFF_QUEUE => Some(Payload::HandoffQueue(None)),
        "Ljava/util/concurrent/ThreadPoolExecutor;" | executors::scheduled::POOL => {
            Some(Payload::Executor(Executor::default()))
        }
        ABORT_POLICY | DISCARD_POLICY => Some(Payload::Instance),
        _ => None,
    }
}
pub(super) fn inherits(class: &str, base: &str) -> bool {
    if executors::scheduled::inherits(class, base) || rwlock::inherits(class, base) {
        return true;
    }
    if matches!(class, ABORT_POLICY | DISCARD_POLICY)
        && base == "Ljava/util/concurrent/RejectedExecutionHandler;"
    {
        return true;
    }
    if class == scheduler::HANDOFF_QUEUE {
        return matches!(
            base,
            "Ljava/util/concurrent/BlockingQueue;"
                | "Ljava/util/Queue;"
                | "Ljava/util/Collection;"
                | "Ljava/lang/Iterable;"
                | "Ljava/io/Serializable;"
        );
    }
    if class == "Ljava/util/concurrent/AbstractExecutorService;" {
        return matches!(
            base,
            "Ljava/util/concurrent/Executor;" | "Ljava/util/concurrent/ExecutorService;"
        );
    }
    if matches!(
        class,
        executors::DELEGATED | executors::FINALIZABLE_DELEGATED
    ) && matches!(
        base,
        "Ljava/util/concurrent/Executor;" | "Ljava/util/concurrent/ExecutorService;"
    ) {
        return true;
    }
    class == "Ljava/util/concurrent/ThreadPoolExecutor;"
        && matches!(
            base,
            "Ljava/util/concurrent/Executor;"
                | "Ljava/util/concurrent/ExecutorService;"
                | "Ljava/util/concurrent/AbstractExecutorService;"
        )
}
fn convert(value: i64, from: usize, to: usize) -> i64 {
    (value as i128 * FACTORS[from] / FACTORS[to]).clamp(i64::MIN as i128, i64::MAX as i128) as i64
}
impl Runtime {
    pub(super) fn timeout_nanos(&self, time: i64, unit: u32) -> Result<i64> {
        Ok(convert(time, self.unit_ordinal(unit)?, 0))
    }
    pub(super) fn nanos_to_unit(&self, nanos: i64, unit: u32) -> Result<i64> {
        Ok(convert(nanos, 0, self.unit_ordinal(unit)?))
    }
    pub(super) fn time_unit(&mut self, ordinal: u32) -> Result<u32> {
        if ordinal >= 7 {
            return Err("TimeUnit ordinal".into());
        }
        if let Some(id) = self.time_units.get(&ordinal) {
            return Ok(*id);
        }
        let name = self.literal(NAMES[ordinal as usize].encode_utf16().collect())?;
        let id = self.allocate(
            "Ljava/util/concurrent/TimeUnit;",
            Payload::Enum { name, ordinal },
        )?;
        self.time_units.insert(ordinal, id);
        Ok(id)
    }
    fn unit_ordinal(&self, id: u32) -> Result<usize> {
        let object = self.object(id)?;
        if object.class != "Ljava/util/concurrent/TimeUnit;" {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "TimeUnit type",
            ));
        }
        let Payload::Enum { ordinal, .. } = object.payload else {
            return Err("TimeUnit payload".into());
        };
        if ordinal >= 7 {
            return Err("TimeUnit ordinal".into());
        }
        Ok(ordinal as usize)
    }
    fn default_factory(&mut self) -> Result<u32> {
        self.executor_default_factory()
    }
    pub(super) fn default_rejection(&mut self) -> Result<u32> {
        self.allocate(ABORT_POLICY, Payload::Instance)
    }
    pub(super) fn concurrency_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        if sig.starts_with("Ljava/util/concurrent/CountDownLatch;->") {
            let method = sig.split_once("->").ok_or("Latch signature")?.1;
            let id = *a.first().ok_or("Latch receiver")?;
            if method == "<init>(I)V" {
                let count = *a.get(1).ok_or("Latch count")? as i32;
                if count < 0 {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Negative latch count",
                    ));
                }
                self.object_mut(id)?.payload = Payload::Latch(Some(count as u32));
                return Ok(Some(0));
            }
            let Payload::Latch(Some(count)) = self.object(id)?.payload else {
                return Err("Uninitialized CountDownLatch".into());
            };
            return Ok(Some(match method {
                "getCount()J" => count as u64,
                "countDown()V" => {
                    self.object_mut(id)?.payload = Payload::Latch(Some(count.saturating_sub(1)));
                    0
                }
                "await()V" => {
                    self.check_interrupted()?;
                    if count != 0 {
                        return self
                            .suspend(scheduler::Wait::Latch {
                                object: id,
                                until: None,
                                boolean: false,
                            })
                            .map(Some);
                    }
                    0
                }
                "await(JLjava/util/concurrent/TimeUnit;)Z" => {
                    let time = *a.get(1).ok_or("Latch time")? as u64
                        | ((*a.get(2).ok_or("Latch time")? as u64) << 32);
                    let nanos =
                        self.timeout_nanos(time as i64, *a.get(3).ok_or("Latch TimeUnit")?)?;
                    self.check_interrupted()?;
                    if count == 0 {
                        1
                    } else if nanos <= 0 {
                        0
                    } else {
                        return self
                            .suspend(scheduler::Wait::Latch {
                                object: id,
                                until: Self::deadline(nanos as u64),
                                boolean: true,
                            })
                            .map(Some);
                    }
                }
                "toString()Ljava/lang/String;" => self.string(&format!(
                    "java.util.concurrent.CountDownLatch@{id:x}[Count = {count}]"
                ))? as u64,
                _ => return Ok(None),
            }));
        }
        let (class, method) = sig.split_once("->").ok_or("Concurrency signature")?;
        if !class.starts_with("Ljava/util/concurrent/") {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Concurrency argument count");
        if class == "Ljava/util/concurrent/Executors;" {
            if method == "defaultThreadFactory()Ljava/util/concurrent/ThreadFactory;" {
                return Ok(Some(self.default_factory()? as u64));
            }
            if matches!(
                method,
                "newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;"
                    | "newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;"
                    | "newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;"
                    | "newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;"
                    | "newCachedThreadPool()Ljava/util/concurrent/ExecutorService;"
                    | "newCachedThreadPool(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;"
            ) {
                let single = method.starts_with("newSingle");
                let cached = method.starts_with("newCached");
                let size = if single {
                    1
                } else if cached {
                    0
                } else {
                    arg(0)?
                };
                if !cached && (size == 0 || size > i32::MAX as u32) {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "executor size must be positive",
                    ));
                }
                let factory = if method.contains("ThreadFactory;") {
                    let id = arg(usize::from(!single && !cached))?;
                    self.object(id)?;
                    id
                } else {
                    self.default_factory()?
                };
                let mut roots = self.scoped_library_roots(&[factory])?;
                let queue = if cached {
                    self.allocate(scheduler::HANDOFF_QUEUE, Payload::HandoffQueue(Some(false)))?
                } else {
                    self.allocate(
                        "Ljava/util/concurrent/LinkedBlockingQueue;",
                        Payload::List(Vec::new()),
                    )?
                };
                roots.keep(queue)?;
                let handler = self.default_rejection()?;
                roots.keep(handler)?;
                let pool = self.allocate(
                    "Ljava/util/concurrent/ThreadPoolExecutor;",
                    Payload::Executor(Executor {
                        core: size,
                        maximum: if cached { i32::MAX as u32 } else { size },
                        keep_alive: if cached { 60_000_000_000 } else { 0 },
                        queue,
                        factory,
                        handler,
                        ..Executor::default()
                    }),
                )?;
                roots.keep(pool)?;
                let id = if single {
                    self.allocate(
                        executors::FINALIZABLE_DELEGATED,
                        Payload::ExecutorWrapper(pool),
                    )?
                } else {
                    pool
                };
                return Ok(Some(id as u64));
            }
            return Err(format!("Unsupported executor factory {sig}").into());
        }
        if class == "Ljava/util/concurrent/TimeUnit;" {
            if method == "valueOf(Ljava/lang/String;)Ljava/util/concurrent/TimeUnit;" {
                let name = self.text(arg(0)?)?;
                let index = NAMES.iter().position(|s| *s == name).ok_or_else(|| {
                    fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "unknown TimeUnit name",
                    )
                })?;
                return Ok(Some(self.time_unit(index as u32)? as u64));
            }
            if method == "values()[Ljava/util/concurrent/TimeUnit;" {
                let mut values = Vec::new();
                for i in 0..7 {
                    values.push(self.time_unit(i)? as u64);
                }
                return Ok(Some(
                    self.allocate("[Ljava/util/concurrent/TimeUnit;", Payload::Array(values))?
                        as u64,
                ));
            }
            let id = arg(0)?;
            let from = self.unit_ordinal(id)?;
            let to = match method {
                "toNanos(J)J" => Some(0),
                "toMicros(J)J" => Some(1),
                "toMillis(J)J" => Some(2),
                "toSeconds(J)J" => Some(3),
                "toMinutes(J)J" => Some(4),
                "toHours(J)J" => Some(5),
                "toDays(J)J" => Some(6),
                _ => None,
            };
            if let Some(to) = to {
                let duration = (arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64;
                return Ok(Some(convert(duration, from, to) as u64));
            }
            if method == "convert(JLjava/util/concurrent/TimeUnit;)J" {
                let duration = (arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64;
                return Ok(Some(
                    convert(duration, self.unit_ordinal(arg(3)?)?, from) as u64
                ));
            }
            return self.lang_api(&format!("Ljava/lang/Enum;->{method}"), a);
        }
        if matches!(class, ABORT_POLICY | DISCARD_POLICY) && method == "<init>()V" {
            self.object(arg(0)?)?;
            return Ok(Some(0));
        }
        let Some(&id) = a.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        let mut e = if let Payload::Executor(executor) = &object.payload {
            executor.clone()
        } else if class == "Ljava/util/concurrent/ThreadPoolExecutor;"
            && matches!(
                method,
                "<init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;)V"
                    | "<init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V"
                    | "<init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/RejectedExecutionHandler;)V"
                    | "<init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V"
            )
            && self.subclass(&object.class, "Ljava/util/concurrent/ThreadPoolExecutor;")?
        {
            // The base constructor initializes a real DEX subclass while its
            // ordinary subclass fields retain their original identity/storage.
            Executor::default()
        } else {
            return Ok(None);
        };
        let result = match method {
            "<init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;)V"
            | "<init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V"
            | "<init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/RejectedExecutionHandler;)V"
            | "<init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V" =>
            {
                let core = arg(1)?;
                let maximum = arg(2)?;
                let duration = (arg(3)? as u64 | ((arg(4)? as u64) << 32)) as i64;
                if core > i32::MAX as u32
                    || maximum == 0
                    || maximum > i32::MAX as u32
                    || maximum < core
                    || duration < 0
                {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "executor size/keepalive",
                    ));
                }
                let unit = self.unit_ordinal(arg(5)?)?;
                let queue = arg(6)?;
                if !matches!(self.object(queue)?.payload, Payload::HandoffQueue(Some(_))) {
                    self.collection_values(queue)?;
                }
                let has_factory = method.contains("ThreadFactory;");
                let has_handler = method.contains("RejectedExecutionHandler;");
                let factory = if has_factory {
                    let f = arg(7)?;
                    self.object(f)?;
                    f
                } else {
                    self.default_factory()?
                };
                let handler = if has_handler {
                    let h = arg(if has_factory { 8 } else { 7 })?;
                    self.object(h)?;
                    h
                } else {
                    self.default_rejection()?
                };
                e = Executor {
                    core,
                    maximum,
                    keep_alive: convert(duration, unit, 0),
                    queue,
                    factory,
                    handler,
                    ..Executor::default()
                };
                0
            }
            "getCorePoolSize()I" => e.core as u64,
            "getMaximumPoolSize()I" => e.maximum as u64,
            "getQueue()Ljava/util/concurrent/BlockingQueue;" => e.queue as u64,
            "getThreadFactory()Ljava/util/concurrent/ThreadFactory;" => e.factory as u64,
            "getRejectedExecutionHandler()Ljava/util/concurrent/RejectedExecutionHandler;" => {
                e.handler as u64
            }
            "getKeepAliveTime(Ljava/util/concurrent/TimeUnit;)J" => {
                convert(e.keep_alive, 0, self.unit_ordinal(arg(1)?)?) as u64
            }
            "allowsCoreThreadTimeOut()Z" => e.timeout as u64,
            "setThreadFactory(Ljava/util/concurrent/ThreadFactory;)V" => {
                let f = arg(1)?;
                self.object(f)?;
                e.factory = f;
                0
            }
            "setRejectedExecutionHandler(Ljava/util/concurrent/RejectedExecutionHandler;)V" => {
                let h = arg(1)?;
                self.object(h)?;
                e.handler = h;
                0
            }
            "submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;"
            | "submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;" => {
                if e.shutdown {
                    return Err(fault(
                        "Ljava/util/concurrent/RejectedExecutionException;",
                        "executor is shut down",
                    ));
                }
                return Err("Executor Future/submit is not implemented".into());
            }
            _ => return Ok(None),
        };
        self.object_mut(id)?.payload = Payload::Executor(e);
        Ok(Some(result))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn time_units_saturate_overflow_and_truncate_toward_zero() {
        assert_eq!(convert(i64::MAX, 6, 0), i64::MAX);
        assert_eq!(convert(i64::MIN, 3, 0), i64::MIN);
        assert_eq!(convert(-1500, 2, 3), -1);
        assert_eq!(convert(7, 3, 2), 7000);
    }
}
