//! Resources of the current APK; no invented framework strings or layouts.
use super::*;
use crate::resources::{Content, DENSITY, HEIGHT_DP, Table, Value, WIDTH_DP};

pub(super) fn declared_field(class: &str, name: &str) -> Option<(&'static str, u32)> {
    Some((
        match (class, name) {
            ("Landroid/content/res/Configuration;", "fontScale") => "F",
            ("Landroid/content/res/Configuration;", "locale") => "Ljava/util/Locale;",
            (
                "Landroid/content/res/Configuration;",
                "mcc"
                | "mnc"
                | "orientation"
                | "touchscreen"
                | "keyboard"
                | "keyboardHidden"
                | "hardKeyboardHidden"
                | "navigation"
                | "navigationHidden"
                | "screenLayout"
                | "uiMode"
                | "screenWidthDp"
                | "screenHeightDp"
                | "smallestScreenWidthDp"
                | "densityDpi"
                | "colorMode",
            ) => "I",
            ("Landroid/util/DisplayMetrics;", "widthPixels" | "heightPixels" | "densityDpi") => "I",
            ("Landroid/util/DisplayMetrics;", "density" | "scaledDensity" | "xdpi" | "ydpi") => "F",
            (
                "Landroid/util/TypedValue;",
                "type"
                | "data"
                | "assetCookie"
                | "resourceId"
                | "changingConfigurations"
                | "density",
            ) => "I",
            ("Landroid/util/TypedValue;", "string") => "Ljava/lang/CharSequence;",
            _ => return None,
        },
        1,
    ))
}
fn not_found(message: impl std::fmt::Display) -> Box<dyn std::error::Error + Send + Sync> {
    fault(
        "Landroid/content/res/Resources$NotFoundException;",
        &message.to_string(),
    )
}
pub(super) fn complex(data: u32) -> f32 {
    let radix = [
        1.0 / 256.0,
        1.0 / 32768.0,
        1.0 / 8388608.0,
        1.0 / 2147483648.0,
    ];
    ((data & 0xffffff00) as i32 as f32) * radix[((data >> 4) & 3) as usize]
}
fn dimension(data: u32, density: f32, scaled: f32, dpi: f32) -> Result<f32> {
    let value = complex(data);
    Ok(value
        * match data & 15 {
            0 => 1.0,
            1 => density,
            2 => scaled,
            3 => dpi / 72.0,
            4 => dpi,
            5 => dpi / 25.4,
            _ => return Err(not_found("Unsupported dimension unit")),
        })
}
impl Runtime {
    pub(super) fn apk_resources(&mut self) -> Result<u32> {
        if self.resources != 0 {
            return Ok(self.resources);
        }
        let limit = self.heap_limit.saturating_sub(self.heap_bytes());
        let table = if let Some(bytes) = self
            .libraries
            .resource_table(limit.min(64 * 1024 * 1024) as u64)?
        {
            Table::parse(bytes, limit)?
        } else {
            Table::empty()
        };
        self.resource_table = Some(table);
        self.resources = self.allocate("Landroid/content/res/Resources;", Payload::Instance)?;
        Ok(self.resources)
    }
    pub(super) fn resource_value(&self, id: u32) -> Result<(u32, Value)> {
        self.resource_table
            .as_ref()
            .ok_or("APK resources not initialized")?
            .resolve(id)
            .map_err(not_found)
    }
    pub(super) fn apk_xml(&mut self, id: u32) -> Result<u32> {
        self.apk_resources()?;
        let (_, value) = self.resource_value(id)?;
        if value.kind != 3 {
            return Err(not_found(format!("Resource 0x{id:08x} is not an XML file")));
        }
        let path = String::from_utf16(&self.resource_text_value(value)?).map_err(not_found)?;
        let limit = self.compiled_xml_input_limit();
        let bytes = self
            .libraries
            .resource(&path, limit as u64)
            .map_err(not_found)?;
        self.allocate_compiled_xml(bytes).map_err(not_found)
    }
    fn resource_text_value(&self, value: Value) -> Result<Vec<u16>> {
        Ok(match value.kind {
            3 => self
                .resource_table
                .as_ref()
                .ok_or("Resource table")?
                .string(value.data)
                .map_err(not_found)?,
            0x10 => (value.data as i32).to_string().encode_utf16().collect(),
            0x11 => format!("0x{:x}", value.data).encode_utf16().collect(),
            0x12 => if value.data == 0 { "false" } else { "true" }
                .encode_utf16()
                .collect(),
            0x1c..=0x1f => format!("#{:08x}", value.data).encode_utf16().collect(),
            _ => return Err(not_found("Resource cannot be converted to text")),
        })
    }
    fn resource_text(&mut self, id: u32) -> Result<u32> {
        let (_, value) = self.resource_value(id)?;
        let units = self.resource_text_value(value)?;
        self.string_units(units)
    }
    fn resource_configuration(&mut self) -> Result<u32> {
        if self.resource_config != 0 {
            return Ok(self.resource_config);
        }
        let locale = self.default_locale()?;
        self.resource_config = self.allocate(
            "Landroid/content/res/Configuration;",
            Payload::Record(BTreeMap::from([
                (
                    "fontScale".into(),
                    u64::from(content_resolver::FONT_SCALE.to_bits()),
                ),
                ("locale".into(), locale as u64),
                ("orientation".into(), 1),
                ("touchscreen".into(), 3),
                ("keyboard".into(), 1),
                ("keyboardHidden".into(), 2),
                ("hardKeyboardHidden".into(), 2),
                ("navigation".into(), 1),
                ("navigationHidden".into(), 2),
                ("screenLayout".into(), 2 | 0x20 | 0x40),
                ("uiMode".into(), 1 | 0x10),
                ("colorMode".into(), 1 | 4),
                ("screenWidthDp".into(), WIDTH_DP as u64),
                ("screenHeightDp".into(), HEIGHT_DP as u64),
                ("smallestScreenWidthDp".into(), WIDTH_DP as u64),
                ("densityDpi".into(), DENSITY as u64),
            ])),
        )?;
        Ok(self.resource_config)
    }
    fn resource_metrics(&mut self) -> Result<u32> {
        if self.display_metrics != 0 {
            return Ok(self.display_metrics);
        }
        self.display_metrics = self.allocate(
            "Landroid/util/DisplayMetrics;",
            Payload::Record(display_api::profile_metrics()),
        )?;
        Ok(self.display_metrics)
    }
    fn resource_array(&self, id: u32) -> Result<Vec<Value>> {
        let table = self.resource_table.as_ref().ok_or("Resource table")?;
        if table.entry(id).is_none_or(|e| e.kind.as_ref() != "array") {
            return Err(not_found("Resource is not an array"));
        }
        let Content::Bag { parent, items } = table.content(id).map_err(not_found)? else {
            return Err(not_found("Resource is not an array"));
        };
        if *parent != 0 {
            return Err(not_found("Inherited resource arrays are unsupported"));
        }
        let mut values = Vec::with_capacity(items.len());
        for (i, (name, value)) in items.iter().enumerate() {
            if *name != 0x01000001 + i as u32 {
                return Err(not_found("Resource bag is not an ordered array"));
            }
            values.push(if value.kind == 1 {
                table.resolve(value.data).map_err(not_found)?.1
            } else {
                *value
            });
        }
        Ok(values)
    }
    pub(super) fn resources_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Resource API signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Resource argument count");
        if matches!(
            method,
            "getResources()Landroid/content/res/Resources;"
                | "getString(I)Ljava/lang/String;"
                | "getText(I)Ljava/lang/CharSequence;"
        ) && self.subclass(&self.object(arg(0)?)?.class, "Landroid/content/Context;")?
        {
            let id = self.apk_resources()?;
            return Ok(Some(if method.starts_with("getResources") {
                id
            } else {
                self.resource_text(arg(1)?)?
            } as u64));
        }
        if class == "Ljava/util/Locale;"
            && matches!(
                method,
                "getLanguage()Ljava/lang/String;"
                    | "getCountry()Ljava/lang/String;"
                    | "toString()Ljava/lang/String;"
                    | "toLanguageTag()Ljava/lang/String;"
            )
        {
            let Payload::Record(values) = &self.object(arg(0)?)?.payload else {
                return Ok(None);
            };
            let language = *values.get("language").ok_or("Locale language")? as u32;
            let country = *values.get("country").ok_or("Locale country")? as u32;
            return Ok(Some(match method {
                "getLanguage()Ljava/lang/String;" => language as u64,
                "getCountry()Ljava/lang/String;" => country as u64,
                _ => self.string(&format!(
                    "{}{}{}",
                    self.text(language)?,
                    if method.starts_with("toLanguageTag") {
                        "-"
                    } else {
                        "_"
                    },
                    self.text(country)?
                ))? as u64,
            }));
        }
        if matches!(
            class,
            "Landroid/util/TypedValue;"
                | "Landroid/util/DisplayMetrics;"
                | "Landroid/content/res/Configuration;"
        ) {
            if method == "<init>()V" {
                self.object_mut(arg(0)?)?.payload = Payload::Record(BTreeMap::new());
                return Ok(Some(0));
            }
            if class == "Landroid/content/res/Configuration;" && method == "getLayoutDirection()I" {
                let Payload::Record(values) = &self.object(arg(0)?)?.payload else {
                    return Err("Configuration payload".into());
                };
                return Ok(Some(
                    ((values.get("screenLayout").copied().unwrap_or(0) >> 6) & 3).saturating_sub(1),
                ));
            }
        }
        if class != "Landroid/content/res/Resources;" {
            return Ok(None);
        }
        let resource = arg(0)?;
        self.object(resource)?;
        if resource != self.resources || resource == 0 {
            return Err("Unknown APK Resources handle".into());
        }
        match method {
            "getXml(I)Landroid/content/res/XmlResourceParser;" => {
                return Ok(Some(self.apk_xml(arg(1)?)? as u64));
            }
            "getConfiguration()Landroid/content/res/Configuration;" => {
                return Ok(Some(self.resource_configuration()? as u64));
            }
            "getDisplayMetrics()Landroid/util/DisplayMetrics;" => {
                return Ok(Some(self.resource_metrics()? as u64));
            }
            "getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I" => {
                let name = self.text(arg(1)?)?;
                let kind = if arg(2)? == 0 {
                    String::new()
                } else {
                    self.text(arg(2)?)?
                };
                let package = if arg(3)? == 0 {
                    String::new()
                } else {
                    self.text(arg(3)?)?
                };
                return Ok(Some(
                    self.resource_table
                        .as_ref()
                        .ok_or("Resource table")?
                        .identifier(&name, &kind, &package) as u64,
                ));
            }
            "getResourceName(I)Ljava/lang/String;"
            | "getResourcePackageName(I)Ljava/lang/String;"
            | "getResourceTypeName(I)Ljava/lang/String;"
            | "getResourceEntryName(I)Ljava/lang/String;" => {
                let e = self
                    .resource_table
                    .as_ref()
                    .ok_or("Resource table")?
                    .entry(arg(1)?)
                    .ok_or_else(|| not_found("Unknown resource name"))?;
                let name = match method {
                    "getResourcePackageName(I)Ljava/lang/String;" => e.package.to_string(),
                    "getResourceTypeName(I)Ljava/lang/String;" => e.kind.to_string(),
                    "getResourceEntryName(I)Ljava/lang/String;" => e.name.clone(),
                    _ => format!("{}:{}/{}", e.package, e.kind, e.name),
                };
                return Ok(Some(self.string(&name)? as u64));
            }
            "getString(I)Ljava/lang/String;" | "getText(I)Ljava/lang/CharSequence;" => {
                return Ok(Some(self.resource_text(arg(1)?)? as u64));
            }
            "getText(ILjava/lang/CharSequence;)Ljava/lang/CharSequence;" => {
                let default = arg(2)?;
                if default != 0 {
                    self.object(default)?;
                }
                return Ok(Some(match self.resource_text(arg(1)?) {
                    Ok(id) => id as u64,
                    Err(e) if e.is::<JavaFault>() => default as u64,
                    Err(e) => return Err(e),
                }));
            }
            "getStringArray(I)[Ljava/lang/String;"
            | "getTextArray(I)[Ljava/lang/CharSequence;"
            | "getIntArray(I)[I" => {
                let array = self.resource_array(arg(1)?)?;
                let mut values = Vec::with_capacity(array.len());
                for value in array {
                    values.push(if method.ends_with("[I") {
                        if !(0x10..=0x1f).contains(&value.kind) {
                            return Err(not_found("Array item is not an integer"));
                        }
                        value.data as u64
                    } else {
                        let units = self.resource_text_value(value)?;
                        self.string_units(units)? as u64
                    });
                }
                let class = if method.ends_with("[I") {
                    "[I"
                } else if method.starts_with("getTextArray") {
                    "[Ljava/lang/CharSequence;"
                } else {
                    "[Ljava/lang/String;"
                };
                return Ok(Some(self.allocate(class, Payload::Array(values))? as u64));
            }
            "getValue(ILandroid/util/TypedValue;Z)V" => {
                let id = arg(1)?;
                let target = arg(2)?;
                if !self.subclass(&self.object(target)?.class, "Landroid/util/TypedValue;")? {
                    return Err("getValue target is not TypedValue".into());
                }
                let (resolved, value) = if arg(3)? != 0 {
                    self.resource_value(id)?
                } else {
                    let Content::Simple(value) = self
                        .resource_table
                        .as_ref()
                        .ok_or("Resource table")?
                        .content(id)
                        .map_err(not_found)?
                    else {
                        return Err(not_found("Resource is a bag"));
                    };
                    (id, *value)
                };
                let string = if value.kind == 3 {
                    let units = self.resource_text_value(value)?;
                    self.string_units(units)?
                } else {
                    0
                };
                self.object_mut(target)?.payload = Payload::Record(BTreeMap::from([
                    ("type".into(), value.kind as u64),
                    ("data".into(), value.data as u64),
                    ("resourceId".into(), resolved as u64),
                    ("assetCookie".into(), 1),
                    ("string".into(), string as u64),
                    ("changingConfigurations".into(), 0),
                    ("density".into(), 0),
                ]));
                return Ok(Some(0));
            }
            "getBoolean(I)Z"
            | "getInteger(I)I"
            | "getColor(I)I"
            | "getDimension(I)F"
            | "getDimensionPixelOffset(I)I"
            | "getDimensionPixelSize(I)I" => {
                let (_, value) = self.resource_value(arg(1)?)?;
                return Ok(Some(match method {
                    "getBoolean(I)Z" if (0x10..=0x1f).contains(&value.kind) => {
                        u64::from(value.data != 0)
                    }
                    "getInteger(I)I" if (0x10..=0x1f).contains(&value.kind) => value.data as u64,
                    "getColor(I)I" if (0x1c..=0x1f).contains(&value.kind) => value.data as u64,
                    _ if method.starts_with("getDimension") && value.kind == 5 => {
                        let result = dimension(value.data, 2.0, 2.0, DENSITY as f32)?;
                        if method == "getDimension(I)F" {
                            result.to_bits() as u64
                        } else if method == "getDimensionPixelOffset(I)I" {
                            result as i32 as u32 as u64
                        } else {
                            let rounded = (result + if result >= 0.0 { 0.5 } else { -0.5 }) as i32;
                            (if rounded != 0 || result == 0.0 {
                                rounded
                            } else if result > 0.0 {
                                1
                            } else {
                                -1
                            }) as u32 as u64
                        }
                    }
                    _ => {
                        return Err(not_found(
                            "Resource value type does not match requested API",
                        ));
                    }
                }));
            }
            _ => {}
        }
        Ok(None)
    }
}
