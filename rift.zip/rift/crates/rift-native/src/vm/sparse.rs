//! Bounded, sorted integer map with Android's key/index distinction.
use super::*;
impl Runtime {
    pub(super) fn sparse_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Sparse signature")?;
        if class != "Landroid/util/SparseIntArray;" {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Sparse argument count");
        let id = arg(0)?;
        if matches!(method, "<init>()V" | "<init>(I)V") {
            let capacity = if a.len() == 2 { arg(1)? as i32 } else { 10 };
            if capacity < 0 {
                return Err(fault(
                    "Ljava/lang/NegativeArraySizeException;",
                    "Negative SparseIntArray capacity",
                ));
            }
            if capacity > 4096 {
                return Err("SparseIntArray capacity quota".into());
            }
            self.object_mut(id)?.payload =
                Payload::SparseInt(Vec::with_capacity(capacity as usize));
            return Ok(Some(0));
        }
        let Payload::SparseInt(values) = &self.object(id)?.payload else {
            return Err("SparseIntArray payload".into());
        };
        Ok(Some(match method {
            "size()I" => values.len() as u64,
            "get(I)I" | "get(II)I" => {
                let key = arg(1)? as i32;
                let fallback = a.get(2).copied().unwrap_or(0);
                values
                    .binary_search_by_key(&key, |p| p.0)
                    .ok()
                    .map_or(fallback, |i| values[i].1 as u32) as u64
            }
            "keyAt(I)I" | "valueAt(I)I" => {
                let item = values.get(arg(1)? as usize).ok_or_else(|| {
                    fault(
                        "Ljava/lang/ArrayIndexOutOfBoundsException;",
                        "SparseIntArray index",
                    )
                })?;
                if method.starts_with("keyAt") {
                    item.0 as u32 as u64
                } else {
                    item.1 as u32 as u64
                }
            }
            "indexOfKey(I)I" => {
                let key = arg(1)? as i32;
                match values.binary_search_by_key(&key, |p| p.0) {
                    Ok(i) => i as u32 as u64,
                    Err(i) => (!(i as i32)) as u32 as u64,
                }
            }
            "indexOfValue(I)I" => {
                let value = arg(1)? as i32;
                values
                    .iter()
                    .position(|p| p.1 == value)
                    .map_or(u32::MAX, |i| i as u32) as u64
            }
            "put(II)V" | "append(II)V" => {
                let key = arg(1)? as i32;
                let value = arg(2)? as i32;
                let position = values.binary_search_by_key(&key, |p| p.0);
                if position.is_err() && values.len() >= 4096 {
                    return Err("SparseIntArray entry quota".into());
                }
                let Payload::SparseInt(values) = &mut self.object_mut(id)?.payload else {
                    unreachable!()
                };
                match position {
                    Ok(i) => values[i].1 = value,
                    Err(i) => values.insert(i, (key, value)),
                };
                0
            }
            "delete(I)V" => {
                let position = values.binary_search_by_key(&(arg(1)? as i32), |p| p.0);
                if let Ok(i) = position {
                    let Payload::SparseInt(values) = &mut self.object_mut(id)?.payload else {
                        unreachable!()
                    };
                    values.remove(i);
                }
                0
            }
            "removeAt(I)V" | "setValueAt(II)V" => {
                let index = arg(1)? as usize;
                if index >= values.len() {
                    return Err(fault(
                        "Ljava/lang/ArrayIndexOutOfBoundsException;",
                        "SparseIntArray index",
                    ));
                }
                let Payload::SparseInt(values) = &mut self.object_mut(id)?.payload else {
                    unreachable!()
                };
                if method.starts_with("removeAt") {
                    values.remove(index);
                } else {
                    values[index].1 = arg(2)? as i32;
                }
                0
            }
            "clear()V" => {
                let Payload::SparseInt(values) = &mut self.object_mut(id)?.payload else {
                    unreachable!()
                };
                values.clear();
                0
            }
            "clone()Landroid/util/SparseIntArray;" | "clone()Ljava/lang/Object;" => {
                let copy = values.clone();
                self.allocate(class, Payload::SparseInt(copy))? as u64
            }
            "toString()Ljava/lang/String;" => {
                let text = format!(
                    "{{{}}}",
                    values
                        .iter()
                        .map(|(k, v)| format!("{k}={v}"))
                        .collect::<Vec<_>>()
                        .join(", ")
                );
                self.string(&text)? as u64
            }
            _ => return Ok(None),
        }))
    }
}
