package org.kyvex.extra;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.LockSupport;
import java.util.concurrent.locks.ReentrantLock;
/** The same code runs on a stock JDK and in the guest; assertions verify actual work. */
public final class ThreadChecks {
 private static int checks;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 public static int verify() throws InterruptedException {
  checks=0;final Thread main=Thread.currentThread();final AtomicInteger outcome=new AtomicInteger();
  final ThreadLocal<Integer> local=new ThreadLocal<Integer>();local.set(7);
  final InheritableThreadLocal<Integer> inherited=new InheritableThreadLocal<Integer>(){protected Integer childValue(Integer parent){return parent+1;}};inherited.set(10);
  final CountDownLatch ready=new CountDownLatch(1),gate=new CountDownLatch(1);
  Thread child=new Thread(new Runnable(){public void run(){
   if(Thread.currentThread()==main||Thread.currentThread().getId()==main.getId()||!Thread.currentThread().getName().equals("guest-work"))throw new IllegalStateException("Worker identity");
   if(local.get()!=null||inherited.get()!=11)throw new IllegalStateException("ThreadLocal isolation/inheritance");
   local.set(99);Object keep=new Object();ready.countDown();
   try{gate.await();}catch(InterruptedException e){throw new IllegalStateException(e);}
   if(local.get()!=99||keep.getClass()!=Object.class)throw new IllegalStateException("Lost waiting frame or local map");outcome.set(41);
  }},"guest-work");
  check(child.getState()==Thread.State.NEW&&!child.isAlive(),"New thread state");child.start();ready.await();
  check(child.isAlive(),"Waiting child alive");check(local.get()==7&&inherited.get()==10,"Parent locals");
  System.gc();gate.countDown();child.join();check(outcome.get()==41,"Runnable actually executed after latch");
  check(child.getState()==Thread.State.TERMINATED&&!child.isAlive(),"Terminated state");
  check(Thread.currentThread()==main,"Main identity restored");
  try{child.start();throw new IllegalStateException("Thread restarted");}catch(IllegalThreadStateException expected){checks++;}
  final CountDownLatch sleepy=new CountDownLatch(1);
  Thread interrupted=new Thread(new Runnable(){public void run(){sleepy.countDown();try{Thread.sleep(10000);outcome.set(-1);}catch(InterruptedException expected){outcome.set(Thread.currentThread().isInterrupted()?-2:42);}}});
  interrupted.start();sleepy.await();interrupted.interrupt();interrupted.join();check(outcome.get()==42,"Sleep interrupted and flag cleared");
  final Object monitor=new Object();final int[] phase={0};
  Thread waiter=new Thread(new Runnable(){public void run(){synchronized(monitor){synchronized(monitor){
   phase[0]=1;monitor.notifyAll();try{while(phase[0]!=2)monitor.wait();}catch(InterruptedException e){throw new IllegalStateException(e);}
   if(!Thread.holdsLock(monitor))throw new IllegalStateException("Wait did not restore monitor ownership");phase[0]=3;
  }}phase[0]=4;}});
  waiter.start();synchronized(monitor){while(phase[0]!=1)monitor.wait();check(Thread.holdsLock(monitor),"Released all reentrant holds during wait");phase[0]=2;monitor.notifyAll();}
  waiter.join();check(phase[0]==4,"Wait/notify resumed child and restored both monitor holds");check(!Thread.holdsLock(monitor),"Monitor released");
  try{monitor.notify();throw new IllegalStateException("Foreign notify accepted");}catch(IllegalMonitorStateException expected){checks++;}
  final ReentrantLock lock=new ReentrantLock(true);final CountDownLatch lockReady=new CountDownLatch(1);lock.lock();lock.lock();
  Thread locker=new Thread(new Runnable(){public void run(){
   if(lock.tryLock()||lock.getHoldCount()!=0||lock.isHeldByCurrentThread())throw new IllegalStateException("Foreign reentrant ownership");
   try{lock.unlock();throw new IllegalStateException("Foreign unlock accepted");}catch(IllegalMonitorStateException expected){}
   lockReady.countDown();try{lock.lockInterruptibly();}catch(InterruptedException e){throw new IllegalStateException(e);}
   try{if(lock.getHoldCount()!=1)throw new IllegalStateException("Acquired lock depth");outcome.set(43);}finally{lock.unlock();}
  }});locker.start();lockReady.await();check(lock.getHoldCount()==2&&lock.isFair(),"Main reentrant ownership");lock.unlock();lock.unlock();locker.join();
  check(outcome.get()==43&&!lock.isLocked(),"Lock handoff");
  check(!new CountDownLatch(1).await(1,TimeUnit.MILLISECONDS),"Timed latch must expire");
  check(new CountDownLatch(0).await(1,TimeUnit.NANOSECONDS),"Open latch returns true");
  synchronized(monitor){monitor.wait(1);check(Thread.holdsLock(monitor),"Timed wait reacquires monitor");}
  LockSupport.unpark(main);LockSupport.unpark(main);LockSupport.park();LockSupport.parkNanos(1);
  check(!main.isInterrupted(),"Parking permit and timeout");
  final Object blocker=new Object();final CountDownLatch parked=new CountDownLatch(1);
  Thread parker=new Thread(new Runnable(){public void run(){parked.countDown();LockSupport.park(blocker);outcome.set(Thread.currentThread().isInterrupted()?44:-4);if(!Thread.interrupted()||Thread.interrupted())outcome.set(-5);}});
  parker.start();parked.await();int spins=0;while(LockSupport.getBlocker(parker)==null&&spins++<1000)Thread.yield();
  check(LockSupport.getBlocker(parker)==blocker,"Park blocker belongs to waiting worker");parker.interrupt();parker.join();check(outcome.get()==44,"Park preserves interrupt then interrupted clears it");
  Thread bad=new Thread(new Runnable(){public void run(){throw new IllegalArgumentException("expected-worker-fault");}});
  bad.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){public void uncaughtException(Thread thread,Throwable e){if(thread!=Thread.currentThread()||!(e instanceof IllegalArgumentException))throw new IllegalStateException("Wrong uncaught thread/fault");outcome.set(45);}});
  bad.start();bad.join();check(outcome.get()==45,"Uncaught handler actually invoked");
  Thread empty=new Thread();empty.start();empty.join();check(!empty.isAlive(),"Empty Thread finishes");
  Thread.currentThread().interrupt();try{Thread.sleep(0);throw new IllegalStateException("Interrupted sleep succeeded");}catch(InterruptedException expected){checks++;}
  check(!Thread.interrupted(),"Sleep cleared interrupt");
  final CountDownLatch monitorReady=new CountDownLatch(1);
  Thread contender=new Thread(new Runnable(){public void run(){monitorReady.countDown();synchronized(monitor){outcome.set(Thread.interrupted()?46:-6);}}});
  synchronized(monitor){contender.start();monitorReady.await();waitState(contender,Thread.State.BLOCKED);contender.interrupt();Thread.yield();check(contender.isAlive(),"Interrupt does not abort monitor enter");}
  contender.join();check(outcome.get()==46,"Blocked monitor instruction resumes once and retains interrupt");
  final CountDownLatch waitReady=new CountDownLatch(1);
  Thread interruptedWait=new Thread(new Runnable(){public void run(){synchronized(monitor){waitReady.countDown();try{monitor.wait();outcome.set(-7);}catch(InterruptedException expected){outcome.set(Thread.holdsLock(monitor)&&!Thread.currentThread().isInterrupted()?47:-8);}}}});
  interruptedWait.start();waitReady.await();synchronized(monitor){interruptedWait.interrupt();Thread.yield();check(interruptedWait.isAlive(),"Interrupted wait must reacquire occupied monitor before throwing");}
  interruptedWait.join();check(outcome.get()==47,"Interrupted wait restores ownership and clears interrupt");
  final int[] order={0,0};final ReentrantLock fifo=new ReentrantLock(true);
  Thread older=new Thread(new Runnable(){public void run(){fifo.lock();try{order[1]=++order[0];}finally{fifo.unlock();}}});
  Thread younger=new Thread(new Runnable(){public void run(){fifo.lock();try{order[0]=1;}finally{fifo.unlock();}}});
  fifo.lock();younger.start();waitState(younger,Thread.State.WAITING);older.start();waitState(older,Thread.State.WAITING);check(fifo.getQueueLength()==2,"Two threads really queued for fair lock");fifo.unlock();younger.join();older.join();check(order[0]==2&&order[1]==2,"Fairness follows wait order, not creation id");
  Thread handlerFault=new Thread(new Runnable(){public void run(){throw new IllegalArgumentException("expected");}});handlerFault.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){public void uncaughtException(Thread thread,Throwable fault){outcome.set(48);throw new IllegalStateException("expected-handler-fault");}});handlerFault.start();handlerFault.join();check(outcome.get()==48,"Fault in uncaught handler still terminates worker");
  Thread forwarding=new Thread(new Runnable(){public void run(){try{Thread.sleep(1);}catch(InterruptedException e){throw new IllegalStateException(e);}outcome.set(49);}}){public void run(){super.run();outcome.set(outcome.get()+1);}};forwarding.start();forwarding.join();check(outcome.get()==50,"super.run forwards a genuinely suspendable Runnable");
  local.remove();inherited.remove();return checks;
 }
 private static void waitState(Thread thread,Thread.State state)throws InterruptedException{for(int i=0;i<1000;i++){if(thread.getState()==state)return;Thread.sleep(1);}throw new IllegalStateException("Thread did not reach expected wait state");}
 public static void deadlockJoin()throws InterruptedException{
  final Thread[] tasks=new Thread[2];final CountDownLatch gate=new CountDownLatch(1);
  tasks[0]=new Thread(new Runnable(){public void run(){try{gate.await();tasks[1].join();}catch(InterruptedException e){throw new IllegalStateException(e);}}});
  tasks[1]=new Thread(new Runnable(){public void run(){try{tasks[0].join();}catch(InterruptedException e){throw new IllegalStateException(e);}}});
  tasks[0].start();tasks[1].start();gate.countDown();tasks[0].join();
 }
 public static int report(){try{return verify();}catch(InterruptedException e){throw new IllegalStateException(e);}}
 public static void main(String[] args)throws Exception{System.out.println("Thread checks: "+verify());}
}
