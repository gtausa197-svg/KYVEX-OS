//! Bounded API 28 date formatting, multibyte state and floating conversions.
use super::{Machine, READ, Result, State, TLS, c_format, c_scan::NumericLocale};
use crate::{identity::MAIN_TID, memory::PAGE};

const C_STRING_LIMIT: usize = 16 * 1024;
const MAX_TIME_OUTPUT: u64 = 16 * 1024;
const MAX_ZONE_NAME: usize = 256;
const MBRLEN_STATE: u64 = 136;
const MBRTOWC_STATE: u64 = 144;

const MONTHS: [&[u8]; 12] = [
    b"January",
    b"February",
    b"March",
    b"April",
    b"May",
    b"June",
    b"July",
    b"August",
    b"September",
    b"October",
    b"November",
    b"December",
];
const WEEKDAYS: [&[u8]; 7] = [
    b"Sunday",
    b"Monday",
    b"Tuesday",
    b"Wednesday",
    b"Thursday",
    b"Friday",
    b"Saturday",
];

fn add_text(output: &mut Vec<u8>, text: &[u8], modifier: u8) {
    output.extend(text.iter().copied().map(|byte| match modifier {
        b'^' => byte.to_ascii_uppercase(),
        b'#' if byte.is_ascii_uppercase() => byte.to_ascii_lowercase(),
        b'#' => byte.to_ascii_uppercase(),
        _ => byte,
    }));
}

fn add_number(output: &mut Vec<u8>, value: i64, width: usize, zero: bool, modifier: u8) {
    let rendered = match modifier {
        b'-' => value.to_string(),
        b'0' => format!("{value:0width$}"),
        b'_' => format!("{value:width$}"),
        _ if zero => format!("{value:0width$}"),
        _ => format!("{value:width$}"),
    };
    output.extend(rendered.bytes());
}

fn add_year(output: &mut Vec<u8>, year: i64, specifier: u8, modifier: u8) {
    if matches!(specifier, b'Y' | b'G' | b'C') {
        if (-99..0).contains(&year) {
            output.extend(b"-0");
        } else {
            add_number(output, year / 100, 2, true, modifier);
        }
    }
    if specifier != b'C' {
        add_number(output, (year % 100).abs(), 2, true, modifier);
    }
}

fn year_days(year: i64) -> i64 {
    let leap = year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    365 + i64::from(leap)
}

fn iso_week(year: i64, weekday: i64, ordinal: i64) -> (i64, i64) {
    // The ISO week and its year are selected by the Thursday in that week.
    let thursday = ordinal + 3 - (weekday + 6).rem_euclid(7);
    if thursday < 0 {
        (year - 1, (thursday + year_days(year - 1)) / 7 + 1)
    } else if thursday >= year_days(year) {
        (year + 1, 1)
    } else {
        (year, thursday / 7 + 1)
    }
}

fn expanded_time_format(specifier: u8) -> Option<&'static [u8]> {
    Some(match specifier {
        b'c' => b"%a %b %e %T %Y",
        b'D' | b'x' => b"%m/%d/%y",
        b'F' => b"%Y-%m-%d",
        b'R' => b"%H:%M",
        b'r' => b"%I:%M:%S %p",
        b'T' | b'X' => b"%H:%M:%S",
        b'v' => b"%e-%b-%Y",
        b'+' => b"%a %b %e %H:%M:%S %Z %Y",
        _ => return None,
    })
}

struct TimeFormat<'a> {
    machine: &'a Machine,
    fields: libc::tm,
    zone_pointer: u64,
    zone: Option<Vec<u8>>,
    epoch: Option<i64>,
}

impl<'a> TimeFormat<'a> {
    fn read(machine: &'a Machine, pointer: u64) -> Result<Self> {
        let width = (machine.arch / 8) as usize;
        let offset = 36usize.next_multiple_of(width);
        let mut raw = [0; 56];
        machine
            .cpu
            .memory()
            .read(pointer, &mut raw[..offset + 2 * width], READ)?;
        let (integers, _) = raw[..36].as_chunks::<4>();
        let field = |index: usize| i32::from_le_bytes(integers[index]);
        let word = |start: usize| {
            let mut data = [0; 8];
            data[..width].copy_from_slice(&raw[start..start + width]);
            u64::from_le_bytes(data)
        };
        let offset_word = word(offset);
        let offset_seconds = if width == 4 {
            i64::from(offset_word as i32)
        } else {
            offset_word as i64
        };
        Ok(Self {
            machine,
            fields: libc::tm {
                tm_sec: field(0),
                tm_min: field(1),
                tm_hour: field(2),
                tm_mday: field(3),
                tm_mon: field(4),
                tm_year: field(5),
                tm_wday: field(6),
                tm_yday: field(7),
                tm_isdst: field(8),
                tm_gmtoff: offset_seconds,
                tm_zone: std::ptr::null(),
            },
            zone_pointer: word(offset + width),
            zone: None,
            epoch: None,
        })
    }

    fn zone(&mut self) -> Result<&[u8]> {
        if self.zone.is_none() {
            let mut zone = if self.zone_pointer == 0 {
                Vec::new()
            } else {
                self.machine.cbytes(self.zone_pointer, MAX_ZONE_NAME)?
            };
            if zone.is_empty() && self.fields.tm_isdst >= 0 {
                zone.extend_from_slice(b"UTC");
            }
            self.zone = Some(zone);
        }
        Ok(self.zone.as_deref().unwrap_or_default())
    }

    fn write(&mut self, format: &[u8], output: &mut Vec<u8>, capacity: usize) -> Result<bool> {
        let mut bytes = format.iter().copied();
        while let Some(byte) = bytes.next() {
            if byte != b'%' {
                output.push(byte);
            } else {
                let mut modifier = 0;
                let mut final_byte = b'%';
                let specifier = loop {
                    match bytes.next() {
                        Some(flag @ (b'_' | b'-' | b'0' | b'^' | b'#')) => {
                            modifier = flag;
                            final_byte = flag;
                        }
                        Some(flag @ (b'E' | b'O')) => final_byte = flag,
                        Some(value) => break value,
                        None => break final_byte,
                    }
                };
                if let Some(expanded) = expanded_time_format(specifier) {
                    if !self.write(expanded, output, capacity)? {
                        return Ok(false);
                    }
                } else {
                    self.conversion(output, specifier, modifier)?;
                }
            }
            if output.len() > capacity {
                return Ok(false);
            }
        }
        Ok(true)
    }

    fn conversion(&mut self, output: &mut Vec<u8>, specifier: u8, modifier: u8) -> Result<()> {
        let time = &self.fields;
        let year = i64::from(time.tm_year) + 1900;
        let weekday = i64::from(time.tm_wday);
        let ordinal = i64::from(time.tm_yday);
        let hour = i64::from(time.tm_hour);
        let hour12 = if hour % 12 == 0 { 12 } else { hour % 12 };
        let day = i64::from(time.tm_mday);
        let number = match specifier {
            b'd' => (day, 2, true),
            b'e' => (day, 2, false),
            b'H' => (hour, 2, true),
            b'I' => (hour12, 2, true),
            b'j' => (ordinal + 1, 3, true),
            b'k' => (hour, 2, false),
            b'l' => (hour12, 2, false),
            b'M' => (i64::from(time.tm_min), 2, true),
            b'm' => (i64::from(time.tm_mon) + 1, 2, true),
            b'S' => (i64::from(time.tm_sec), 2, true),
            b'U' => ((ordinal + 7 - weekday) / 7, 2, true),
            b'W' => ((ordinal + 7 - (weekday + 6) % 7) / 7, 2, true),
            b'V' => (iso_week(year, weekday, ordinal).1, 2, true),
            b'w' => (weekday, 0, false),
            b'u' => (if weekday == 0 { 7 } else { weekday }, 0, false),
            _ => {
                match specifier {
                    b'C' | b'Y' | b'y' => add_year(output, year, specifier, modifier),
                    b'G' | b'g' => {
                        add_year(
                            output,
                            iso_week(year, weekday, ordinal).0,
                            specifier,
                            modifier,
                        );
                    }
                    b'A' | b'a' | b'B' | b'b' | b'h' => {
                        let name = if matches!(specifier, b'A' | b'a') {
                            WEEKDAYS.get(weekday as usize)
                        } else {
                            MONTHS.get(time.tm_mon as usize)
                        }
                        .copied()
                        .unwrap_or(b"?");
                        let length = if matches!(specifier, b'A' | b'B') {
                            name.len()
                        } else {
                            name.len().min(3)
                        };
                        add_text(output, &name[..length], modifier);
                    }
                    b'P' => output.extend(if hour >= 12 { b"pm" } else { b"am" }),
                    b'p' => add_text(output, if hour >= 12 { b"PM" } else { b"AM" }, modifier),
                    b'Z' => add_text(output, self.zone()?, modifier),
                    b'z' if time.tm_isdst >= 0 => {
                        let seconds = time.tm_gmtoff;
                        let minutes = seconds.unsigned_abs() / 60;
                        output.push(if seconds < 0 { b'-' } else { b'+' });
                        add_number(
                            output,
                            ((minutes / 60) * 100 + minutes % 60) as i64,
                            4,
                            true,
                            modifier,
                        );
                    }
                    b'z' => {}
                    b's' => {
                        // Rift's process timezone is UTC. timegm normalizes a local copy
                        // without consulting the host timezone or reading host files.
                        let epoch = self.epoch.get_or_insert_with(|| {
                            let mut normalized = self.fields;
                            unsafe { libc::timegm(&mut normalized) }
                        });
                        output.extend(epoch.to_string().bytes());
                    }
                    b'n' => output.push(b'\n'),
                    b't' => output.push(b'\t'),
                    other => output.push(other),
                }
                return Ok(());
            }
        };
        add_number(output, number.0, number.1, number.2, modifier);
        Ok(())
    }
}

enum Multibyte {
    NoInput,
    Incomplete,
    Complete { code: u32, consumed: usize },
    Error(i32),
}

fn decode_multibyte(
    sequence: &mut [u8; 4],
    count: u64,
    mut input: impl FnMut(usize) -> Result<u8>,
) -> Result<Multibyte> {
    let stored = sequence
        .iter()
        .rposition(|&byte| byte != 0)
        .map_or(0, |index| index + 1);
    if stored == 4 {
        return Ok(Multibyte::Error(libc::EINVAL));
    }
    if count == 0 {
        return Ok(Multibyte::NoInput);
    }
    let lead = if stored == 0 { input(0)? } else { sequence[0] };
    let (width, mask, minimum) = match lead {
        0x00..=0x7f => (1, 0x7f, 0),
        0xc0..=0xdf => (2, 0x1f, 0x80),
        0xe0..=0xef => (3, 0x0f, 0x800),
        0xf0..=0xf7 => (4, 0x07, 0x10000),
        _ => return Ok(Multibyte::Error(libc::EILSEQ)),
    };
    if stored >= width
        || sequence[1..stored.max(1)]
            .iter()
            .any(|byte| byte & 0xc0 != 0x80)
    {
        return Ok(Multibyte::Error(libc::EINVAL));
    }
    let consumed = ((width - stored) as u64).min(count) as usize;
    for (index, byte) in sequence[stored..stored + consumed].iter_mut().enumerate() {
        let next = if index + stored == 0 {
            lead
        } else {
            input(index)?
        };
        if index + stored > 0 && next & 0xc0 != 0x80 {
            return Ok(Multibyte::Error(libc::EILSEQ));
        }
        *byte = next;
    }
    if stored + consumed < width {
        return Ok(Multibyte::Incomplete);
    }
    let code = sequence[1..width]
        .iter()
        .fold(u32::from(lead & mask), |code, &byte| {
            (code << 6) | u32::from(byte & 0x3f)
        });
    if code < minimum || matches!(code, 0xd800..=0xdfff | 0xfffe | 0xffff) {
        return Ok(Multibyte::Error(libc::EILSEQ));
    }
    Ok(Multibyte::Complete { code, consumed })
}

impl Machine {
    pub(super) fn c_locale_function(&mut self, function: &str, state: &mut State) -> Result<u64> {
        let [first, second, third, fourth, ..] = state.regs;
        match function {
            "strftime" => self.strftime_guest(first, second, third, fourth),
            "mbrlen" => self.multibyte_guest(0, first, second, third, MBRLEN_STATE),
            "mbrtowc" => self.multibyte_guest(first, second, third, fourth, MBRTOWC_STATE),
            "strtod" | "strtof" => self.floating_guest(function == "strtod", state),
            _ => Err(format!("Unsupported Bionic C conversion {function}").into()),
        }
    }

    fn strftime_guest(&mut self, output: u64, size: u64, format: u64, time: u64) -> Result<u64> {
        if size == 0 {
            return Ok(0);
        }
        let format = if format == 0 {
            b"%c".to_vec()
        } else {
            self.cbytes(format, C_STRING_LIMIT)?
        };
        let mut formatter = TimeFormat::read(self, time)?;
        let mut rendered = Vec::new();
        if !formatter.write(
            &format,
            &mut rendered,
            (size - 1).min(MAX_TIME_OUTPUT) as usize,
        )? {
            return Ok(0);
        }
        let written = rendered.len() as u64;
        rendered.push(0);
        self.cpu.memory_mut().write(output, &rendered)?;
        Ok(written)
    }

    fn multibyte_guest(
        &mut self,
        output: u64,
        input: u64,
        count: u64,
        state: u64,
        private_offset: u64,
    ) -> Result<u64> {
        let tls = if self.current_tid == MAIN_TID {
            TLS
        } else {
            self.jni_env + PAGE
        };
        let state = if state == 0 {
            tls + private_offset
        } else {
            state
        };
        let mut sequence = [0; 4];
        self.cpu.memory().read(state, &mut sequence, READ)?;
        let outcome =
            decode_multibyte(&mut sequence, if input == 0 { 1 } else { count }, |index| {
                if input == 0 {
                    return Ok(0);
                }
                let address = input
                    .checked_add(index as u64)
                    .ok_or("Guest multibyte input overflow")?;
                Ok(c_format::read_word(self.cpu.memory(), address, 1)? as u8)
            })?;
        match outcome {
            Multibyte::NoInput => Ok(0),
            Multibyte::Incomplete => {
                self.cpu.memory_mut().write(state, &sequence)?;
                Ok(u64::MAX - 1)
            }
            Multibyte::Complete { code, consumed } => {
                if input != 0 && output != 0 {
                    self.cpu.memory_mut().write(output, &code.to_le_bytes())?;
                }
                self.cpu.memory_mut().write(state, &[0; 4])?;
                Ok(if code == 0 { 0 } else { consumed as u64 })
            }
            Multibyte::Error(error) => {
                self.cpu.memory_mut().write(state, &[0; 4])?;
                self.set_guest_errno(error)?;
                Ok(u64::MAX)
            }
        }
    }

    fn floating_guest(&mut self, double: bool, state: &mut State) -> Result<u64> {
        let [input, end_pointer, ..] = state.regs;
        let text = self.cbytes(input, C_STRING_LIMIT)?;
        let (consumed, bytes, error) = NumericLocale::open()?.parse(&text, double);
        let mut bits = [0; 8];
        bits[..bytes.len()].copy_from_slice(&bytes);
        let bits = u64::from_le_bytes(bits);
        if end_pointer != 0 {
            let end = input
                .checked_add(consumed as u64)
                .ok_or("Guest strto* end overflow")?;
            self.cpu
                .memory_mut()
                .write(end_pointer, &end.to_le_bytes()[..(self.arch / 8) as usize])?;
        }
        if let Some(error) = error {
            self.set_guest_errno(error)?;
        }
        if self.arch == 64 {
            state.vectors[0] = bits;
            state.vectors[1] = 0;
        } else if double {
            state.regs[1] = bits >> 32;
        }
        Ok(bits)
    }
}
