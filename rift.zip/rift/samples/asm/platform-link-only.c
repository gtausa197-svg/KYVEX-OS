/* Link-time signature fixtures. None of these objects enter the APK. */
#if defined(LINK_LOG)
int __android_log_write(int priority, const char *tag, const char *text) {
    (void)priority;
    (void)tag;
    (void)text;
    return -1;
}
int __android_log_print(int priority, const char *tag, const char *format, ...) {
    (void)priority;
    (void)tag;
    (void)format;
    return -1;
}
#elif defined(LINK_Z)
unsigned long adler32(unsigned long sum, const unsigned char *buffer, unsigned int length) {
    (void)sum;
    (void)buffer;
    (void)length;
    return 0;
}
#else
void link_namespace_marker(void) {}
#endif
