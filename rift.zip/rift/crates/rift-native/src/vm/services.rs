//! Desktop guest service registry. Process information describes this VM only.
use super::*;
fn service_name(class: &str) -> Option<&'static str> {
    Some(match class {
        "Landroid/app/ActivityManager;" => "activity",
        "Landroid/telephony/TelephonyManager;" => "phone",
        "Landroid/hardware/SensorManager;" => "sensor",
        "Landroid/bluetooth/BluetoothManager;" => "bluetooth",
        "Landroid/nfc/NfcManager;" => "nfc",
        "Landroid/net/wifi/WifiManager;" => "wifi",
        "Landroid/location/LocationManager;" => "location",
        "Landroid/view/WindowManager;" => "window",
        "Landroid/view/LayoutInflater;" => "layout_inflater",
        "Landroid/net/ConnectivityManager;" => "connectivity",
        "Landroid/os/PowerManager;" => "power",
        "Landroid/media/AudioManager;" => "audio",
        "Landroid/view/inputmethod/InputMethodManager;" => "input_method",
        "Landroid/app/NotificationManager;" => "notification",
        "Landroid/app/AlarmManager;" => "alarm",
        "Landroid/app/job/JobScheduler;" => "jobscheduler",
        "Landroid/os/UserManager;" => "user",
        _ => return None,
    })
}
pub(super) fn declared_field(class: &str, name: &str) -> Option<(&'static str, u32)> {
    if class != "Landroid/app/ActivityManager$RunningAppProcessInfo;" {
        return None;
    }
    Some((
        match name {
            "processName" => "Ljava/lang/String;",
            "pkgList" => "[Ljava/lang/String;",
            "pid"
            | "uid"
            | "importance"
            | "lru"
            | "lastTrimLevel"
            | "importanceReasonCode"
            | "importanceReasonPid"
            | "flags" => "I",
            _ => return None,
        },
        1,
    ))
}
impl Runtime {
    pub(super) fn context_device_storage(&self, mut context: u32) -> Result<bool> {
        for _ in 0..128 {
            let object = self.object(context)?;
            if matches!(object.payload, Payload::DeviceStorageContext) {
                return Ok(true);
            }
            if !self.subclass(&object.class, "Landroid/content/ContextWrapper;")? {
                return Ok(false);
            }
            context = object.fields.get(&(usize::MAX - 1)).copied().unwrap_or(0) as u32;
        }
        Err("ContextWrapper delegation depth exceeded".into())
    }

    fn check_service_context(&self, id: u32) -> Result<()> {
        let object = self.object(id)?;
        if self.subclass(&object.class, "Landroid/content/ContextWrapper;")?
            && object.fields.get(&(usize::MAX - 1)).copied().unwrap_or(0) == 0
        {
            return Err(fault(
                "Ljava/lang/NullPointerException;",
                "ContextWrapper base is not attached yet",
            ));
        }
        Ok(())
    }
    fn process_information(&mut self) -> Result<BTreeMap<String, u64>> {
        let name = self.string(&self.guest_process_name())?;
        let package = self.string(&self.package_name.clone())?;
        let packages =
            self.allocate("[Ljava/lang/String;", Payload::Array(vec![package as u64]))?;
        Ok(BTreeMap::from([
            ("processName".into(), name as u64),
            ("pkgList".into(), packages as u64),
            ("pid".into(), crate::identity::PID as u64),
            ("uid".into(), crate::identity::UID as u64),
            (
                "importance".into(),
                match self.activity_stage {
                    2 | 4 => 200,
                    5 | 6 => 400,
                    _ => 100,
                },
            ),
        ]))
    }
    pub(super) fn services_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Service signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Service argument count");
        if matches!(
            method,
            "createDeviceProtectedStorageContext()Landroid/content/Context;"
                | "createCredentialProtectedStorageContext()Landroid/content/Context;"
                | "isDeviceProtectedStorage()Z"
                | "isCredentialProtectedStorage()Z"
        ) && self.subclass(class, "Landroid/content/Context;")?
        {
            let device = self.context_device_storage(arg(0)?)?;
            return Ok(Some(match method {
                "isDeviceProtectedStorage()Z" => device as u64,
                "isCredentialProtectedStorage()Z" => (!device) as u64,
                _ => self.allocate(
                    "Landroid/app/ContextImpl;",
                    if method.starts_with("createDevice") {
                        Payload::DeviceStorageContext
                    } else {
                        Payload::Instance
                    },
                )? as u64,
            }));
        }
        if method == "getBaseContext()Landroid/content/Context;"
            && self.subclass(class, "Landroid/content/ContextWrapper;")?
        {
            return Ok(Some(
                self.object(arg(0)?)?
                    .fields
                    .get(&(usize::MAX - 1))
                    .copied()
                    .unwrap_or(0),
            ));
        }
        if sig == "Landroid/content/ContextWrapper;-><init>(Landroid/content/Context;)V" {
            let context = arg(1)?;
            if context != 0
                && !self.subclass(&self.object(context)?.class, "Landroid/content/Context;")?
            {
                return Err("ContextWrapper base type".into());
            }
            self.object_mut(arg(0)?)?
                .fields
                .insert(usize::MAX - 1, context as u64);
            return Ok(Some(0));
        }
        if matches!(
            method,
            "getSystemService(Ljava/lang/Class;)Ljava/lang/Object;"
                | "getSystemServiceName(Ljava/lang/Class;)Ljava/lang/String;"
        ) && self.subclass(class, "Landroid/content/Context;")?
        {
            self.check_service_context(arg(0)?)?;
            let Payload::Class(service) = &self.object(arg(1)?)?.payload else {
                return Err("System service Class argument type".into());
            };
            let name = service_name(service);
            if method.starts_with("getSystemServiceName") {
                return Ok(Some(if let Some(name) = name {
                    self.string(name)? as u64
                } else {
                    0
                }));
            }
            let Some(name) = name else {
                return Ok(Some(0));
            };
            let name = self.string(name)?;
            return self.services_api(
                &format!("{class}->getSystemService(Ljava/lang/String;)Ljava/lang/Object;"),
                &[arg(0)?, name],
            );
        }
        if method == "getSystemService(Ljava/lang/String;)Ljava/lang/Object;"
            && self.subclass(class, "Landroid/content/Context;")?
        {
            let id = arg(0)?;
            self.check_service_context(id)?;
            let name = self.text(arg(1)?)?;
            if name == "activity" {
                if self.activity_manager == 0 {
                    self.activity_manager =
                        self.allocate("Landroid/app/ActivityManager;", Payload::Instance)?;
                }
                return Ok(Some(self.activity_manager as u64));
            }
            if name == "user" {
                if self.user_manager == 0 {
                    self.user_manager =
                        self.allocate("Landroid/os/UserManager;", Payload::Instance)?;
                }
                return Ok(Some(self.user_manager as u64));
            }
            if name == "window" {
                return Ok(Some(u64::from(self.guest_window_manager()?)));
            }
            // These devices do not exist in the current desktop profile.
            if matches!(
                name.as_str(),
                "phone" | "sensor" | "bluetooth" | "nfc" | "wifi" | "location"
            ) {
                return Ok(Some(0));
            }
            if matches!(
                name.as_str(),
                "layout_inflater"
                    | "connectivity"
                    | "power"
                    | "audio"
                    | "input_method"
                    | "notification"
                    | "alarm"
                    | "jobscheduler"
            ) {
                return Err(format!("Unsupported desktop guest service: {name}").into());
            }
            return Ok(Some(0));
        }
        if class == "Landroid/os/UserManager;" && method == "isUserUnlocked()Z" {
            let id = arg(0)?;
            self.object(id)?;
            if id != self.user_manager || id == 0 {
                return Err("Unknown guest UserManager".into());
            }
            return Ok(Some(crate::identity::CREDENTIAL_STORAGE_UNLOCKED as u64));
        }
        if class == "Landroid/app/ActivityManager$RunningAppProcessInfo;" && method == "<init>()V" {
            self.object_mut(arg(0)?)?.payload = Payload::Record(BTreeMap::new());
            return Ok(Some(0));
        }
        if class != "Landroid/app/ActivityManager;" {
            return Ok(None);
        }
        if method == "getMyMemoryState(Landroid/app/ActivityManager$RunningAppProcessInfo;)V" {
            let target = arg(0)?;
            if self.object(target)?.class != "Landroid/app/ActivityManager$RunningAppProcessInfo;" {
                return Err("RunningAppProcessInfo target type".into());
            }
            let values = self.process_information()?;
            self.object_mut(target)?.payload = Payload::Record(values);
            return Ok(Some(0));
        }
        if method == "isUserAMonkey()Z" {
            return Ok(Some(0));
        }
        let manager = arg(0)?;
        self.object(manager)?;
        if manager != self.activity_manager || manager == 0 {
            return Err("Unknown guest ActivityManager".into());
        }
        match method {
            "getRunningAppProcesses()Ljava/util/List;" => {
                let values = self.process_information()?;
                let info = self.allocate(
                    "Landroid/app/ActivityManager$RunningAppProcessInfo;",
                    Payload::Record(values),
                )?;
                return Ok(Some(
                    self.allocate("Ljava/util/ArrayList;", Payload::List(vec![info]))? as u64,
                ));
            }
            "getMemoryClass()I" | "getLargeMemoryClass()I" => {
                return Ok(Some((self.heap_limit / (1024 * 1024)) as u64));
            }
            _ => {}
        }
        Ok(None)
    }
}
