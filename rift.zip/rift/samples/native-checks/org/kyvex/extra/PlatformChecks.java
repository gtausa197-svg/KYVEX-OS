package org.kyvex.extra;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.*;

/** Plain Android/Java source. Assertions run before the Activity provides a UI. */
public final class PlatformChecks {
    enum Color {RED,GREEN}
    public static String result;
    private static int checks;
    private static void check(boolean condition,String label) {if(!condition)throw new IllegalStateException(label);checks++;}
    public static void verify(Activity activity) {
        checks=0;
        Intent launch=activity.getIntent();
        check(launch!=null&&"android.intent.action.MAIN".equals(launch.getAction()),"launcher intent");
        check("org.kyvex.nativehello.MainActivity".equals(launch.getComponent().getClassName()),"launcher component");
        Intent custom=new Intent().putExtra("number",42);check(custom.getIntExtra("number",0)==42,"typed intent extras");
        SharedPreferences prefs=activity.getSharedPreferences("platform-fixture",0);
        int previous=prefs.getInt("launch_count",0);
        check(prefs.edit().putInt("launch_count",previous+1).putString("text","persisted").commit(),"durable preferences commit");
        check(prefs.getInt("launch_count",0)==previous+1&&"persisted".equals(prefs.getString("text",null)),"preferences readback");
        HashSet<String> original=new HashSet<String>();original.add("alpha");prefs.edit().putStringSet("set",original).apply();original.add("later");
        check(prefs.getStringSet("set",null).size()==1,"preference set copy");
        ConcurrentHashMap<String,String> map=new ConcurrentHashMap<String,String>();check(map.putIfAbsent("key","one")==null&&"one".equals(map.putIfAbsent("key","two")),"conditional map updates");
        check(map.replace("key","one","two")&&"two".equals(map.get("key")),"conditional map replace");
        CopyOnWriteArrayList<String> list=new CopyOnWriteArrayList<String>();list.add("before");Iterator<String> snapshot=list.iterator();list.set(0,"after");check("before".equals(snapshot.next())&&!snapshot.hasNext(),"snapshot iterator");
        ConcurrentLinkedQueue<String> queue=new ConcurrentLinkedQueue<String>();queue.offer("first");queue.offer("second");check("first".equals(queue.poll())&&"second".equals(queue.poll())&&queue.poll()==null,"FIFO queue");
        Set<String> set=Collections.synchronizedSet(new HashSet<String>());set.add("shared");check(set.contains("shared"),"synchronized collection wrapper");
        Object referent=new Object();WeakReference<Object> ref=new WeakReference<Object>(referent);check(ref.get()==referent,"weak reference read");ref.clear();check(ref.get()==null,"weak reference clear");
        check(Integer.valueOf(42)==Integer.valueOf(42)&&Long.valueOf(0x1000000000000080L).byteValue()==(byte)-128,"boxed scalar semantics");
        check(Boolean.FALSE==Boolean.valueOf(false)&&Boolean.TRUE==Boolean.valueOf(true),"Boolean singleton fields");
        check(Integer.TYPE.isPrimitive()&&"int".equals(Integer.TYPE.getName()),"primitive Class metadata");
        check(Color.GREEN.ordinal()==1&&"RED".equals(Color.RED.name())&&Color.values().length==2,"enum metadata");
        check("main".equals(Thread.currentThread().getName()),"main thread identity");
        String built=new StringBuilder().append(true).append('/').append(0x1122334455667788L).toString();check("true/1234605616436508552".equals(built),"builder primitive overloads");
        result=checks+" / launch_count: "+(previous+1);
    }
}
