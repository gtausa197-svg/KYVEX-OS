import java.util.*;
/** Independent stock JDK results. Does not load any KYVEX classes. */
public final class StringSearchOracle {
 static String hex(String s){StringBuilder b=new StringBuilder();for(int i=0;i<s.length();i++)b.append(String.format("%04x",(int)s.charAt(i)));return b.toString();}
 static String text(Random r,int length){char[] a=new char[length];char[] alphabet={'a','b','c',0,'\u00e9','\u041a','\ud800','\ud83d','\ude00','\udfff'};for(int i=0;i<a.length;i++)a[i]=alphabet[r.nextInt(alphabet.length)];return new String(a);}
 public static void main(String[] args){
  Random r=new Random(0x4b59564558L);StringBuilder out=new StringBuilder("{\"jdk_version\":\"").append(System.getProperty("java.runtime.version")).append("\",\"cases\":[");
  String[] fixed={"","a","aaaaaaa","ababa","A\ud83d\ude00B\ud83d\ude00C","\ud800A\udfff","a\u0000b","\u00e9\u041a"};int[] offsets={Integer.MIN_VALUE,-1,0,1,2,3,7,100,Integer.MAX_VALUE};int[] points={-1,0,97,0xd800,0xd83d,0xde00,0x1f600,0x10ffff,0x110000};
  for(int i=0;i<1024;i++){
   String s=i<576?fixed[(i/72)%8]:text(r,r.nextInt(65));String n;
   if(i<576)n=fixed[(i/9)%8];else if(r.nextBoolean()&&s.length()>0){int p=r.nextInt(s.length()+1);n=s.substring(p,p+r.nextInt(s.length()-p+1));}else n=text(r,r.nextInt(17));
   int from=i<576?offsets[i%9]:(r.nextBoolean()?r.nextInt(s.length()+10)-5:offsets[r.nextInt(offsets.length)]);int cp=points[i%points.length];
   String replacement=i%3==0?"$1\ud83d\ude00":(i%3==1?"":n);
   if(i>0)out.append(',');out.append("[\"").append(hex(s)).append("\",\"").append(hex(n)).append("\",").append(from).append(',').append(s.indexOf(n,from)).append(',').append(s.lastIndexOf(n,from)).append(',').append(cp).append(',').append(s.indexOf(cp,from)).append(',').append(s.lastIndexOf(cp,from)).append(',').append(s.startsWith(n,from)?1:0).append(",\"").append(hex(replacement)).append("\",\"").append(hex(s.replace(n,replacement))).append("\"]");
  }System.out.println(out.append("]}"));
 }
}
