//! Experimental register interpreter; no Android Framework or JNI is claimed.
use crate::Result;
pub fn execute(code: &[u16], count: usize, fuel: usize) -> Result<i32> {
    if count == 0 || count > 256 || code.len() > 65536 {
        return Err("DEX method limits".into());
    }
    let mut r = vec![0i32; count];
    let mut pc = 0usize;
    for _ in 0..fuel.min(100000) {
        let ins = *code.get(pc).ok_or("DEX pc outside method")?;
        let op = ins as u8;
        let a = (ins >> 8) as usize;
        let mut next = pc + 1;
        let reg = |r: &Vec<i32>, i: usize| r.get(i).copied().ok_or("DEX register outside frame");
        let mut put = |i: usize, v: i32| -> Result<()> {
            *r.get_mut(i).ok_or("DEX register outside frame")? = v;
            Ok(())
        };
        match op{
            0x00=>{},0x12=>{let dst=a&15;let val=(ins as i16)>>12;put(dst,val as i32)?;},
            0x13=>{put(a,*code.get(pc+1).ok_or("Truncated const")? as i16 as i32)?;next+=1;},
            0x14=>{let lo=*code.get(pc+1).ok_or("Truncated const")? as u32;let hi=*code.get(pc+2).ok_or("Truncated const")? as u32;put(a,(lo|(hi<<16))as i32)?;next+=2;},
            0x01=>{let v=reg(&r,a>>4)?;*r.get_mut(a&15).ok_or("DEX register")?=v;},
            0x0f=>return Ok(reg(&r,a)?),
            0x90..=0x93=>{let pair=*code.get(pc+1).ok_or("Truncated arithmetic")?;let x=reg(&r,(pair&255)as usize)?;let y=reg(&r,(pair>>8)as usize)?;let v=match op{0x90=>x.wrapping_add(y),0x91=>x.wrapping_sub(y),0x92=>x.wrapping_mul(y),_=>if y==0{return Err("DEX divide by zero".into())}else{x.wrapping_div(y)}};*r.get_mut(a).ok_or("DEX register")?=v;next+=1;},
            0x28=>{let offset=(ins as i16>>8)as isize;next=pc.checked_add_signed(offset).ok_or("DEX branch bounds")?;},
            _=>return Err(format!("Unsupported experimental DEX opcode 0x{op:02x}; use the Android compatibility backend").into())
        }
        pc = next;
    }
    Err("DEX instruction budget exhausted".into())
}
pub fn self_test() -> Result<i32> {
    execute(&[0x0013, 6, 0x0113, 7, 0x0292, 0x0100, 0x020f], 3, 100)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn arithmetic() {
        assert_eq!(self_test().unwrap(), 42);
        assert_eq!(execute(&[0xf012, 0x000f], 1, 4).unwrap(), -1)
    }
    #[test]
    fn fuel_and_bounds() {
        assert!(execute(&[0x0028], 1, 9).is_err());
        assert!(execute(&[0xff0f], 1, 2).is_err());
        assert!(execute(&[0x0014], 1, 2).is_err());
    }
    #[test]
    fn no_fake_framework_support() {
        assert!(
            execute(&[0x006e], 1, 1)
                .unwrap_err()
                .to_string()
                .contains("Unsupported")
        );
    }
}
