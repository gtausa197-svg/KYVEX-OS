.text
.global Java_org_kyvex_nativehello_MainActivity_timesSeven
.type Java_org_kyvex_nativehello_MainActivity_timesSeven,%function
Java_org_kyvex_nativehello_MainActivity_timesSeven:
    mov w3,#7
    mul w0,w2,w3
    ret
.global Java_org_kyvex_nativehello_MainActivity_nativeMessage
.type Java_org_kyvex_nativehello_MainActivity_nativeMessage,%function
Java_org_kyvex_nativehello_MainActivity_nativeMessage:
    ldr x3,[x0]
    ldr x4,[x3,#(167*8)]
    adrp x1,message
    add x1,x1,:lo12:message
    br x4
.section .rodata
message: .asciz "Rust + Dynarmic / ARM64"
