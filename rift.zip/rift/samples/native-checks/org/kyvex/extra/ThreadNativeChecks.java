package org.kyvex.extra;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.widget.TextView;
public final class ThreadNativeChecks {
 private static synchronized native long probe(int tid,int previous,int next);
 public static int verify(){
  final long mainEnv=probe(Process.myTid(),0,71);if(mainEnv==0)throw new IllegalStateException("Main native context");
  final long[] data={0,0};final Thread main=Thread.currentThread();
  Thread task=new Thread(new Runnable(){public void run(){
   if(Looper.myLooper()!=null||Looper.getMainLooper().getThread()!=main)throw new IllegalStateException("Wrong worker main Looper");
   try{new Handler();throw new IllegalStateException("Worker falsely received main Looper");}catch(RuntimeException expected){if(expected instanceof IllegalStateException)throw expected;}
   if(Process.myTid()!=Thread.currentThread().getId())throw new IllegalStateException("Java/native thread ids diverged");
   data[0]=probe(Process.myTid(),0,92);Thread.yield();data[1]=probe(Process.myTid(),92,93);
  }});
  synchronized(ThreadNativeChecks.class){task.start();Thread.yield();if(task.getState()!=Thread.State.BLOCKED)throw new IllegalStateException("Synchronized native method did not acquire its class monitor");}
  try{task.join();}catch(InterruptedException e){throw new IllegalStateException(e);}
  if(data[0]==0||data[0]==mainEnv||data[1]!=data[0])throw new IllegalStateException("JNIEnv/TLS not thread owned");
  if(probe(Process.myTid(),71,72)!=mainEnv)throw new IllegalStateException("Main JNIEnv/TLS not restored");
  return 7;
 }
 public static void schedule(final TextView status){
  final Handler main=new Handler(Looper.getMainLooper(),null);
  Thread worker=new Thread(new Runnable(){public void run(){
   try{Thread.sleep(650);}catch(InterruptedException e){throw new IllegalStateException(e);}
   main.post(new Runnable(){public void run(){status.setText("Worker timer: delivered");}});
  }},"deferred-worker");worker.setDaemon(true);worker.start();
 }
}
