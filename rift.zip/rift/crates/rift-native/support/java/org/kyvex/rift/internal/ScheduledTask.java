package org.kyvex.rift.internal;

import java.util.concurrent.Callable;

/** Runs the actual command in an owned DEX frame, including guest thread waits. */
public final class ScheduledTask implements Runnable {
    public void run() {
        Object command = PoolAccess.startTask(this);
        if (command == null) return;

        Object result = null;
        Throwable failure = null;
        try {
            if (PoolAccess.isCallable(this)) {
                result = ((Callable<?>) command).call();
            } else {
                ((Runnable) command).run();
            }
        } catch (Throwable thrown) {
            failure = thrown;
        }
        PoolAccess.finishTask(this, result, failure);
    }
}
