//! Guest-owned selected java.util.logging APIs and a bounded diagnostic sink.
//! Named lookups are weak; live children retain their actual parent and level.
use super::*;
const LOGGER: &str = "Ljava/util/logging/Logger;";
const LEVEL: &str = "Ljava/util/logging/Level;";
const LEVELS: [(&str, i32); 9] = [
    ("OFF", i32::MAX),
    ("SEVERE", 1000),
    ("WARNING", 900),
    ("INFO", 800),
    ("CONFIG", 700),
    ("FINE", 500),
    ("FINER", 400),
    ("FINEST", 300),
    ("ALL", i32::MIN),
];
const MAX_NAMES: usize = 256;
#[derive(Default)]
pub(super) struct State {
    pub named: BTreeMap<Vec<u16>, u32>,
    root: u32,
    global: u32,
    levels: [u32; 9],
}
impl State {
    pub fn bytes(&self) -> usize {
        self.named.keys().map(|key| 64 + key.capacity() * 2).sum()
    }
    pub fn roots(&self) -> impl Iterator<Item = u32> + '_ {
        self.levels.iter().copied().chain([self.root, self.global])
    }
}
#[derive(Clone, Copy)]
pub(super) struct Logger {
    pub name: u32,
    pub level: u32,
    pub parent: u32,
}
#[derive(Clone, Copy)]
pub(super) struct Level {
    pub name: u32,
    pub value: i32,
}
fn descendant(name: &[u16], parent: &[u16]) -> bool {
    name.len() > parent.len() && name.starts_with(parent) && name[parent.len()] == b'.' as u16
}
impl Runtime {
    /// Bound JSON expansion as well as message count; diagnostics must leave room
    /// for the actual scene and metrics in the worker's 64-KiB protocol packet.
    pub(super) fn append_guest_log(&mut self, message: String) {
        fn json_bytes(message: &str) -> usize {
            3 + message
                .chars()
                .map(|c| match c {
                    '\0'..='\x1f' => 6,
                    '"' | '\\' => 2,
                    _ => c.len_utf8(),
                })
                .sum::<usize>()
        }
        let message = message.chars().take(2048).collect::<String>();
        let needed = json_bytes(&message);
        while !self.logs.is_empty()
            && (self.logs.len() >= 32
                || self.logs.iter().map(|s| json_bytes(s)).sum::<usize>() + needed > 16384)
        {
            self.logs.remove(0);
        }
        self.logs.push(message);
    }
    pub(super) fn logging_level_constant(&mut self, name: &str) -> Result<u32> {
        let index = LEVELS
            .iter()
            .position(|(key, _)| *key == name)
            .ok_or("Unknown logging Level constant")?;
        if self.logging.levels[index] == 0 {
            let name = self.string(LEVELS[index].0)?;
            let id = self.allocate(
                LEVEL,
                Payload::LogLevel(Level {
                    name,
                    value: LEVELS[index].1,
                }),
            )?;
            self.logging.levels[index] = id;
        }
        Ok(self.logging.levels[index])
    }
    fn ensure_logger_roots(&mut self) -> Result<()> {
        if self.logging.root == 0 {
            let level = self.logging_level_constant("INFO")?;
            let name = self.string("")?;
            let id = self.allocate(
                LOGGER,
                Payload::Logger(Logger {
                    name,
                    level,
                    parent: 0,
                }),
            )?;
            self.logging.root = id;
            self.logging.named.insert(Vec::new(), id);
        }
        if self.logging.global == 0 {
            let name = self.string("global")?;
            let id = self.allocate(
                LOGGER,
                Payload::Logger(Logger {
                    name,
                    level: 0,
                    parent: self.logging.root,
                }),
            )?;
            self.logging.global = id;
            self.logging
                .named
                .insert("global".encode_utf16().collect(), id);
        }
        Ok(())
    }
    fn logger(&self, id: u32) -> Result<Logger> {
        match self.object(id)?.payload {
            Payload::Logger(logger) => Ok(logger),
            _ => Err("Expected initialized guest Logger".into()),
        }
    }
    fn log_level(&self, id: u32) -> Result<Level> {
        match self.object(id)?.payload {
            Payload::LogLevel(level) => Ok(level),
            _ => Err("Expected initialized guest logging Level".into()),
        }
    }
    fn named_logger(&mut self, name: u32) -> Result<u32> {
        let units = self.units(name)?;
        if units.len() > 1024 {
            return Err("Logger name quota".into());
        }
        self.ensure_logger_roots()?;
        if let Some(id) = self.logging.named.get(&units) {
            return Ok(*id);
        }
        if self.logging.named.len() >= MAX_NAMES {
            return Err("Logger namespace quota".into());
        }
        if self.heap_bytes().saturating_add(64 + units.capacity() * 2) > self.heap_limit {
            return Err("Logger namespace memory quota".into());
        }
        let parent = self
            .logging
            .named
            .iter()
            .filter(|(key, _)| !key.is_empty() && descendant(&units, key))
            .max_by_key(|(key, _)| key.len())
            .map_or(self.logging.root, |(_, id)| *id);
        let id = self.allocate(
            LOGGER,
            Payload::Logger(Logger {
                name,
                level: 0,
                parent,
            }),
        )?;
        // A newly registered ancestor becomes the parent of existing descendants
        // that do not already have a nearer registered parent.
        let children = self
            .logging
            .named
            .iter()
            .filter(|(key, _)| descendant(key, &units))
            .map(|(_, id)| *id)
            .collect::<Vec<_>>();
        for child in children {
            let previous = self.logger(child)?.parent;
            let previous_name = self.logger(previous)?.name;
            if self.units(previous_name)?.len() < units.len() {
                let Payload::Logger(logger) = &mut self.object_mut(child)?.payload else {
                    unreachable!()
                };
                logger.parent = id;
            }
        }
        self.logging.named.insert(units, id);
        Ok(id)
    }
    fn logger_enabled(&self, id: u32, level: i32) -> Result<bool> {
        let mut current = id;
        for _ in 0..=MAX_NAMES {
            let logger = self.logger(current)?;
            if logger.level != 0 {
                let minimum = self.log_level(logger.level)?.value;
                return Ok(minimum != i32::MAX && level >= minimum);
            }
            if logger.parent == 0 {
                return Ok(level >= 800);
            }
            current = logger.parent;
        }
        Err("Logger parent hierarchy quota/cycle".into())
    }
    fn emit_logger_message(
        &mut self,
        id: u32,
        level_name: &str,
        message: u32,
        thrown: u32,
    ) -> Result<()> {
        let logger = self.logger(id)?;
        let name = if logger.name == 0 {
            String::new()
        } else {
            self.text(logger.name)?
        };
        let message = if message == 0 {
            "null".into()
        } else {
            self.text(message)?
        };
        let mut line = format!("{level_name} {name}: {message}");
        if thrown != 0 {
            let object = self.object(thrown)?;
            if !self.subclass(&object.class, "Ljava/lang/Throwable;")? {
                return Err("Logging Throwable type".into());
            }
            let class = object
                .class
                .trim_start_matches('L')
                .trim_end_matches(';')
                .replace('/', ".");
            let detail = object.fields.get(&throwable::MESSAGE).copied().unwrap_or(0) as u32;
            line.push_str(" | ");
            line.push_str(&class);
            if detail != 0 {
                line.push_str(": ");
                line.push_str(&self.text(detail)?);
            }
        }
        self.append_guest_log(line);
        Ok(())
    }
    pub(super) fn logging_global(&mut self) -> Result<u32> {
        self.ensure_logger_roots()?;
        Ok(self.logging.global)
    }
    pub(super) fn logging_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Logging signature")?;
        let arg = |index: usize| a.get(index).copied().ok_or("Logging argument count");
        if class == LOGGER {
            match method {
                "getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;" => {
                    return Ok(Some(self.named_logger(arg(0)?)? as u64));
                }
                "getGlobal()Ljava/util/logging/Logger;" => {
                    return Ok(Some(self.logging_global()? as u64));
                }
                "getAnonymousLogger()Ljava/util/logging/Logger;" => {
                    self.ensure_logger_roots()?;
                    return Ok(Some(self.allocate(
                        LOGGER,
                        Payload::Logger(Logger {
                            name: 0,
                            level: 0,
                            parent: self.logging.root,
                        }),
                    )? as u64));
                }
                _ => {}
            }
        }
        if class == LEVEL && method == "<init>(Ljava/lang/String;I)V" {
            let id = arg(0)?;
            let name = arg(1)?;
            self.units(name)?;
            if !self.subclass(&self.object(id)?.class, LEVEL)? {
                return Err("Level constructor receiver".into());
            }
            self.object_mut(id)?.payload = Payload::LogLevel(Level {
                name,
                value: arg(2)? as i32,
            });
            return Ok(Some(0));
        }
        let Some(id) = a.first().copied() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        if let Payload::LogLevel(level) = object.payload {
            return Ok(match method {
                "getName()Ljava/lang/String;" | "toString()Ljava/lang/String;" => {
                    Some(level.name as u64)
                }
                "intValue()I" | "hashCode()I" => Some(level.value as u32 as u64),
                "equals(Ljava/lang/Object;)Z" => Some(self.heap.get(&arg(1)?).is_some_and(
                    |o| matches!(o.payload,Payload::LogLevel(other) if other.value==level.value),
                ) as u64),
                _ => None,
            });
        }
        let Payload::Logger(logger) = object.payload else {
            return Ok(None);
        };
        Ok(Some(match method {
            "getName()Ljava/lang/String;" => logger.name as u64,
            "getParent()Ljava/util/logging/Logger;" => logger.parent as u64,
            "getLevel()Ljava/util/logging/Level;" => logger.level as u64,
            "getResourceBundleName()Ljava/lang/String;" => 0,
            "setLevel(Ljava/util/logging/Level;)V" => {
                let level = arg(1)?;
                if level != 0 {
                    self.log_level(level)?;
                }
                let Payload::Logger(logger) = &mut self.object_mut(id)?.payload else {
                    unreachable!()
                };
                logger.level = level;
                0
            }
            "isLoggable(Ljava/util/logging/Level;)Z" => {
                self.logger_enabled(id, self.log_level(arg(1)?)?.value)? as u64
            }
            "log(Ljava/util/logging/Level;Ljava/lang/String;)V"
            | "log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V" => {
                let level = self.log_level(arg(1)?)?;
                if self.logger_enabled(id, level.value)? {
                    let name = self.text(level.name)?;
                    self.emit_logger_message(
                        id,
                        &name,
                        arg(2)?,
                        if a.len() == 4 { arg(3)? } else { 0 },
                    )?;
                }
                0
            }
            "severe(Ljava/lang/String;)V"
            | "warning(Ljava/lang/String;)V"
            | "info(Ljava/lang/String;)V"
            | "config(Ljava/lang/String;)V"
            | "fine(Ljava/lang/String;)V"
            | "finer(Ljava/lang/String;)V"
            | "finest(Ljava/lang/String;)V" => {
                let name = method.split('(').next().unwrap().to_ascii_uppercase();
                let value = LEVELS
                    .iter()
                    .find(|(key, _)| *key == name)
                    .ok_or("Logging convenience level")?
                    .1;
                if self.logger_enabled(id, value)? {
                    self.emit_logger_message(id, &name, arg(1)?, 0)?;
                }
                0
            }
            _ => return Ok(None),
        }))
    }
}
