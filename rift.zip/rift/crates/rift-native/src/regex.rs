//! Bounded UTF-16 regular expressions using the same ICU engine family as Android.
use crate::Result;
use std::{ffi::c_void, ptr::NonNull};
pub type Captures = Vec<Option<(usize, usize)>>;
/// Java split limits, including trailing empties and UTF-16 empty-pattern splits.
pub fn split(input: &[u16], source: &[u16], flags: u32, limit: i32) -> Result<Vec<Vec<u16>>> {
    if input.len() > 65536 {
        return Err("Split input quota".into());
    }
    let literal = if flags == 0
        && source.len() == 1
        && source[0] < 128
        && !b".$|()[]{}^?*+\\".contains(&(source[0] as u8))
    {
        Some(source[0])
    } else if flags == 0
        && source.len() == 2
        && source[0] == 92
        && source[1] < 128
        && !(source[1] as u8).is_ascii_alphanumeric()
    {
        Some(source[1])
    } else {
        None
    };
    let empty = source.is_empty() && flags == 0;
    let pattern = if literal.is_none() && !empty {
        Some(Regex::compile(source.to_vec(), flags)?)
    } else {
        None
    };
    if limit == 1 {
        return Ok(vec![input.to_vec()]);
    }
    let subject = pattern.as_ref().map(|p| p.subject(input)).transpose()?;
    let mut pieces = Vec::new();
    let mut next = 0usize;
    let mut cut = 0usize;
    let mut matched = false;
    while next <= input.len() && (limit <= 0 || pieces.len() < (limit as usize).saturating_sub(1)) {
        let found = if empty {
            Some((next, next))
        } else if let Some(c) = literal {
            input[next..]
                .iter()
                .position(|v| *v == c)
                .map(|i| (next + i, next + i + 1))
        } else {
            subject
                .as_ref()
                .ok_or("Split pattern")?
                .search(next, false)?
                .and_then(|g| g[0])
        };
        let Some((start, end)) = found else { break };
        if start != 0 || end != 0 {
            if pieces.len() >= 4095 {
                return Err("Split result quota".into());
            }
            pieces.push(input[cut..start].to_vec());
            cut = end;
            matched = true;
        }
        next = match &subject {
            Some(subject) => subject.after_match(start, end),
            None => end + usize::from(start == end),
        };
    }
    if !matched {
        return Ok(vec![input.to_vec()]);
    }
    pieces.push(input[cut..].to_vec());
    if limit == 0 {
        while pieces.last().is_some_and(|p| p.is_empty()) {
            pieces.pop();
        }
    }
    Ok(pieces)
}
unsafe extern "C" {
    fn rift_regex_compile(
        source: *const u16,
        length: i32,
        flags: u32,
        groups: *mut i32,
        offset: *mut i32,
        error: *mut i32,
    ) -> *mut c_void;
    fn rift_regex_bind(
        code: *const c_void,
        input: *const u16,
        length: i32,
        error: *mut i32,
    ) -> *mut c_void;
    fn rift_regex_close(regex: *mut c_void);
    fn rift_regex_search(
        regex: *mut c_void,
        start: i32,
        full: i32,
        groups: i32,
        ranges: *mut i32,
    ) -> i32;
    fn rift_regex_group(regex: *mut c_void, name: *const u16, length: i32) -> i32;
}

struct Code(NonNull<c_void>);

impl Drop for Code {
    fn drop(&mut self) {
        unsafe { rift_regex_close(self.0.as_ptr()) }
    }
}

pub struct Regex {
    code: Option<Code>,
    pub source: Vec<u16>,
    pub flags: u32,
    pub bytes: usize,
    pub groups: usize,
}

pub struct Subject<'a> {
    // ICU borrows the input for this handle. Closing it releases that borrow.
    code: Option<Code>,
    input: &'a [u16],
    groups: usize,
}

impl Subject<'_> {
    pub fn search(&self, start: usize, full: bool) -> Result<Option<Captures>> {
        if start > self.input.len() {
            return Err("Regex start quota".into());
        }
        let Some(code) = &self.code else {
            return Ok((!full || self.input.is_empty()).then(|| vec![Some((start, start))]));
        };
        let mut ranges = vec![-1; self.groups * 2];
        let result = unsafe {
            rift_regex_search(
                code.0.as_ptr(),
                start as i32,
                i32::from(full),
                self.groups as i32,
                ranges.as_mut_ptr(),
            )
        };
        match result {
            0 => Ok(None),
            1 => {
                let captures = ranges
                    .as_chunks::<2>()
                    .0
                    .iter()
                    .map(|&[begin, end]| {
                        if begin == -1 && end == -1 {
                            Ok(None)
                        } else if begin >= 0 && end >= begin && end as usize <= self.input.len() {
                            Ok(Some((begin as usize, end as usize)))
                        } else {
                            Err("ICU returned an invalid capture range")
                        }
                    })
                    .collect::<std::result::Result<Captures, _>>()?;
                Ok(Some(captures))
            }
            status => Err(format!("Regex match capability/budget error (ICU {})", -status).into()),
        }
    }

    pub fn after_match(&self, start: usize, end: usize) -> usize {
        if start != end {
            return end;
        }
        // A literal empty Java pattern can match between the two UTF-16 units.
        if self.code.is_some()
            && matches!(
                self.input.get(end..end + 2),
                Some([0xd800..=0xdbff, 0xdc00..=0xdfff])
            )
        {
            end + 2
        } else {
            end + 1
        }
    }
}

impl Regex {
    pub fn compile(source: Vec<u16>, flags: u32) -> Result<Self> {
        if source.len() > 16384 || flags & !0x17f != 0 {
            return Err("Unsupported Java regex flags or pattern size".into());
        }
        let mut groups = 0;
        let code = if source.is_empty() {
            None
        } else {
            let mut error = 0;
            let mut offset = 0;
            let code = unsafe {
                rift_regex_compile(
                    source.as_ptr(),
                    source.len() as i32,
                    flags,
                    &mut groups,
                    &mut offset,
                    &mut error,
                )
            };
            let code = NonNull::new(code).ok_or_else(|| {
                format!("Unsupported/invalid regex (ICU {error}, UTF-16 offset {offset})")
            })?;
            Some(Code(code))
        };
        if !(0..=511).contains(&groups) {
            return Err("Regex capture count quota".into());
        }
        // Account for ICU's opaque compiled representation against the Java heap budget.
        let bytes = if code.is_some() {
            16384 + source.len() * 32
        } else {
            0
        };
        Ok(Self {
            code,
            source,
            flags,
            groups: groups as usize,
            bytes,
        })
    }

    pub fn search(&self, input: &[u16], start: usize, full: bool) -> Result<Option<Captures>> {
        self.subject(input)?.search(start, full)
    }

    pub fn subject<'a>(&self, input: &'a [u16]) -> Result<Subject<'a>> {
        if input.len() > 65536 {
            return Err("Regex input quota".into());
        }
        let code = if let Some(pattern) = &self.code {
            let mut error = 0;
            let handle = unsafe {
                rift_regex_bind(
                    pattern.0.as_ptr(),
                    input.as_ptr(),
                    input.len() as i32,
                    &mut error,
                )
            };
            Some(Code(
                NonNull::new(handle).ok_or_else(|| format!("ICU regex input error {error}"))?,
            ))
        } else {
            None
        };
        Ok(Subject {
            code,
            input,
            groups: self.groups + 1,
        })
    }

    pub fn group_index(&self, name: &[u16]) -> Option<usize> {
        let code = self.code.as_ref()?;
        let length = i32::try_from(name.len()).ok()?;
        let index = unsafe { rift_regex_group(code.0.as_ptr(), name.as_ptr(), length) };
        (index > 0).then_some(index as usize)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn units(s: &str) -> Vec<u16> {
        s.encode_utf16().collect()
    }
    #[test]
    fn utf16_captures_and_lookbehind() {
        let p = Regex::compile(units("(?<=id=)([0-9]+)"), 0).unwrap();
        let m = p.search(&units("🦀 id=42"), 0, false).unwrap().unwrap();
        assert_eq!(m[0], Some((6, 8)));
        assert_eq!(m[1], Some((6, 8)));
    }
    #[test]
    fn anchors_and_backreferences() {
        let p = Regex::compile(units("([a-z]+)-\\1"), 0).unwrap();
        assert!(p.search(&units("word-word"), 0, true).unwrap().is_some());
        assert!(p.search(&units("xword-word!"), 0, true).unwrap().is_none());
        let intersect = Regex::compile(units("[a-z&&[^aeiou]]"), 0).unwrap();
        assert!(intersect.search(&units("b"), 0, true).unwrap().is_some());
        assert!(intersect.search(&units("a"), 0, true).unwrap().is_none());
        assert!(Regex::compile(units("a"), 128).is_err());
    }
    #[test]
    fn bounded_pathological_patterns_and_literal() {
        let p = Regex::compile(units("(a+)+$"), 0).unwrap();
        assert!(
            p.search(&units(&("a".repeat(3000) + "!")), 0, false)
                .is_err()
        );
        let p = Regex::compile(units("a[b]"), 16).unwrap();
        assert!(p.search(&units("a[b]"), 0, true).unwrap().is_some());
    }
    #[test]
    fn split_limits_and_utf16_boundaries_match_the_stock_java_oracle() {
        assert_eq!(
            split(&units("a,,b,,"), &units(","), 0, 0).unwrap(),
            vec![units("a"), units(""), units("b")]
        );
        assert_eq!(
            split(&units("a,,b,,"), &units(","), 0, -1).unwrap().len(),
            5
        );
        assert_eq!(
            split(&units("a,,b,,"), &units(","), 0, 2).unwrap(),
            vec![units("a"), units(",b,,")]
        );
        assert_eq!(
            split(&units("abc"), &units("(?=b)"), 0, 0).unwrap(),
            vec![units("a"), units("bc")]
        );
        assert_eq!(
            split(&units(""), &units(","), 0, 0).unwrap(),
            vec![Vec::<u16>::new()]
        );
        assert_eq!(
            split(&units("😀x"), &[], 0, 0).unwrap(),
            vec![vec![0xd83d], vec![0xde00], vec![120]]
        );
        assert_eq!(
            split(&units("😀x"), &[], 0, 2).unwrap(),
            vec![vec![0xd83d], vec![0xde00, 120]]
        );
        assert_eq!(
            split(&[0xd800, 44, 97], &units(","), 0, 0).unwrap(),
            vec![vec![0xd800], vec![97]]
        );
        assert!(split(&units(&"a,".repeat(5000)), &units(","), 0, -1).is_err());
    }
}
