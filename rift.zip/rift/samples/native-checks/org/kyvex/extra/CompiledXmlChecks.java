package org.kyvex.extra;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Environment;
import android.util.AttributeSet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/** Parses the resource compiled by AAPT2 from the real provider metadata. */
public final class CompiledXmlChecks {
    private static final String NS = "http://schemas.android.com/apk/res-auto";
    private static int checks;

    private static void check(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
        checks++;
    }

    public static int result() { return checks; }

    public static void verify(Context context, ProviderInfo info) {
        checks = 0;
        try { readPaths(context, info); }
        catch (Exception error) { throw new IllegalStateException(error); }
    }

    private static void readPaths(Context context, ProviderInfo info) throws Exception {
        Resources resources = context.getResources();
        PackageManager manager = context.getPackageManager();
        String pkg = context.getPackageName();
        int id = resources.getIdentifier("kyvex_paths", "xml", pkg);
        check(id != 0 && info.metaData.getInt("provider.paths") == id, "Provider manifest contains the actual resource ID");
        check(info.loadXmlMetaData(manager, "provider.absent") == null, "Absent metadata returns null");
        ProviderInfo without = manager.resolveContentProvider(info.authority, 0);
        check(without.metaData == null && without.loadXmlMetaData(manager, "provider.paths") == null,
                "Resource access follows the PackageManager metadata flag");
        check(manager.getXml("org.kyvex.foreign", id, null) == null, "Foreign APK resources are unavailable");
        check(manager.getXml(pkg, 0x7f7f1234, null) == null, "Missing package XML has the PackageManager null result");
        int raw = resources.getIdentifier("payload", "raw", pkg);
        try { resources.getXml(raw); throw new IllegalStateException("Expected a compiled resource"); }
        catch (Resources.NotFoundException expected) { checks++; }

        XmlResourceParser parser = info.loadXmlMetaData(manager, "provider.paths");
        check(parser != null, "Provider opened its compiled path resource");
        try {
            AttributeSet attrs = parser;
            check(parser instanceof AutoCloseable && parser.getEventType() == XmlPullParser.START_DOCUMENT,
                    "Resource cursor starts before its first tag");
            check(parser.nextTag() == XmlPullParser.START_TAG && "paths".equals(parser.getName())
                    && parser.getDepth() == 1 && "".equals(parser.getNamespace()), "Root path element");
            check(parser.getLineNumber() > 0 && parser.getColumnNumber() == -1 && attrs.getAttributeCount() == 6,
                    "Line and attribute count from the compiled node");
            check(attrs.getAttributeIntValue(NS, "path_count", -1) == 7, "Typed namespace integer");
            check(attrs.getAttributeBooleanValue(NS, "path_enabled", false), "Typed boolean");
            check(attrs.getAttributeFloatValue(NS, "path_ratio", -1) == 1.5f, "Typed float");
            check(attrs.getAttributeResourceValue(NS, "path_link", 0)
                    == resources.getIdentifier("greeting", "string", pkg), "Reference to the actual resource table");
            int countIndex = -1;
            for (int i = 0; i < attrs.getAttributeCount(); i++) {
                if ("path_count".equals(attrs.getAttributeName(i))) countIndex = i;
            }
            check(countIndex >= 0 && NS.equals(parser.getAttributeNamespace(countIndex))
                    && attrs.getAttributeNameResource(countIndex)
                    == resources.getIdentifier("path_count", "attr", pkg), "Attribute name resource ID");
            check(attrs.getAttributeIntValue(null, "path_count", 99) == 99
                    && attrs.getAttributeValue(null, "path_count") == null, "Namespace matching is exact");
            check("7".equals(attrs.getAttributeValue(countIndex))
                    && "true".equals(attrs.getAttributeValue(NS, "path_enabled")), "Typed attributes coerce to text");
            try { attrs.getAttributeFloatValue(countIndex, 0); throw new IllegalStateException("Expected float type error"); }
            catch (RuntimeException expected) { check(expected.getClass() == RuntimeException.class, "Wrong typed getter"); }
            check(attrs.getStyleAttribute() == resources.getIdentifier("KyvexPathStyle", "style", pkg),
                    "Compiled style attribute");
            check("fixture".equals(attrs.getClassAttribute()), "Compiled class attribute");
            try { attrs.getAttributeName(1000); throw new IllegalStateException("Expected index error"); }
            catch (IndexOutOfBoundsException expected) { checks++; }
            try { parser.getNamespaceCount(1); throw new IllegalStateException("Expected binary namespace limit"); }
            catch (XmlPullParserException expected) { checks++; }

            check(parser.nextToken() == XmlPullParser.START_TAG && "files-path".equals(parser.getName())
                    && parser.getDepth() == 2 && !parser.isEmptyElementTag(), "Compiled child start node");
            check("shared🌍".equals(attrs.getAttributeValue(null, "name"))
                    && "shared/".equals(attrs.getAttributeValue(null, "path")), "Actual Unicode path metadata");
            check(attrs.getAttributeListValue(null, "path", new String[]{"other", "shared/"}, -1) == 1,
                    "Attribute option lookup");
            check(parser.nextTag() == XmlPullParser.END_TAG && parser.getDepth() == 2
                    && parser.getAttributeCount() == -1, "Child end event preserves depth");
            check(parser.nextTag() == XmlPullParser.START_TAG && "cache-path".equals(parser.getName())
                    && "cache/".equals(attrs.getAttributeValue(null, "path"))
                    && parser.nextTag() == XmlPullParser.END_TAG, "Independent cache path");
            check(parser.nextTag() == XmlPullParser.START_TAG && "external-path".equals(parser.getName()),
                    "External path resource");
            verifyStorage(context, attrs.getAttributeValue(null, "path"));
            check(parser.nextTag() == XmlPullParser.END_TAG, "End of the external path");
            check(parser.nextTag() == XmlPullParser.START_TAG && "note".equals(parser.getName())
                    && "urn:kyvex:fixture".equals(parser.getNamespace()), "Nested namespace from the string pool");
            check("ready & secure".equals(parser.nextText())
                    && parser.getEventType() == XmlPullParser.END_TAG, "Real compiled text and end event");
            check(parser.nextTag() == XmlPullParser.END_TAG && "paths".equals(parser.getName())
                    && parser.next() == XmlPullParser.END_DOCUMENT && parser.next() == XmlPullParser.END_DOCUMENT,
                    "End of document and repeated next");
        } finally {
            parser.close();
        }
        int alias = resources.getIdentifier("kyvex_paths_alias", "xml", pkg);
        XmlResourceParser other = resources.getXml(alias);
        check(other.getEventType() == XmlPullParser.START_DOCUMENT
                && other.next() == XmlPullParser.START_TAG && "paths".equals(other.getName()), "Resource alias has a fresh cursor");
        other.close();
        other.close();
        check(other.next() == XmlPullParser.END_DOCUMENT, "Closing early releases the cursor");
    }

    private static void verifyStorage(Context context, String relative) throws Exception {
        File root = Environment.getExternalStorageDirectory();
        check(root.isDirectory() && root.canWrite() && "/storage/emulated/0".equals(root.getPath()),
                "A writable guest storage volume");
        check(Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())
                && Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState(root))
                && "unknown".equals(Environment.getExternalStorageState(new File("/storage/emulated/0x")))
                && Environment.isExternalStorageEmulated() && !Environment.isExternalStorageRemovable(),
                "Mounted emulated volume and path boundary");
        check(new File(root, "Download").getPath().equals(
                Environment.getExternalStoragePublicDirectory("Download").getPath()), "Public directory resolution");
        File[] files = context.getExternalFilesDirs(null);
        String base = new File(root, "Android/data/" + context.getPackageName()).getPath();
        check(files.length == 1 && files[0].isDirectory() && (base + "/files").equals(files[0].getPath()),
                "Application files directory on the single volume");
        File pictures = context.getExternalFilesDir("Pictures");
        check(pictures.isDirectory() && (base + "/files/Pictures").equals(pictures.getPath()),
                "Application-specific directory type");
        File[] caches = context.getExternalCacheDirs();
        check(caches.length == 1 && caches[0].isDirectory() && (base + "/cache").equals(caches[0].getPath())
                && caches[0].getPath().equals(context.getExternalCacheDir().getPath()), "Cache directory");
        File[] media = context.getExternalMediaDirs();
        check(media.length == 1 && media[0].isDirectory()
                && new File(root, "Android/media/" + context.getPackageName()).getPath().equals(media[0].getPath()),
                "Application media directory");
        File share = new File(root, relative);
        check("KyvexShare/".equals(relative) && share.mkdirs() && share.isDirectory(),
                "A real provider path can be created on the guest volume");
        File file = new File(share, "sample.bin");
        FileOutputStream out = new FileOutputStream(file);
        out.write(195);
        out.close();
        FileInputStream in = new FileInputStream(file);
        int value = in.read();
        int end = in.read();
        in.close();
        check(value == 195 && end == -1 && file.length() == 1, "Actual I/O on the emulated volume");
        try { context.getExternalFilesDir("../escape"); throw new IllegalStateException("Invalid directory type"); }
        catch (IllegalArgumentException expected) { checks++; }
    }
}
