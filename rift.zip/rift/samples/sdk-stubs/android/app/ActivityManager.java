package android.app;
public class ActivityManager {
 public static class RunningAppProcessInfo {
  public String processName;
  public String[] pkgList;
  public int pid,uid,importance,lru,lastTrimLevel,flags;
 }
 public java.util.List<RunningAppProcessInfo> getRunningAppProcesses(){return null;}
 public int getMemoryClass(){return 0;}
 public int getLargeMemoryClass(){return 0;}
 public static void getMyMemoryState(RunningAppProcessInfo info){}
}
