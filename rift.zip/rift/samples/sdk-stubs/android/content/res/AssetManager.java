package android.content.res;
public final class AssetManager {
 public java.io.InputStream open(String name) throws java.io.IOException{return null;}
 public java.io.InputStream open(String name,int mode) throws java.io.IOException{return null;}
}
