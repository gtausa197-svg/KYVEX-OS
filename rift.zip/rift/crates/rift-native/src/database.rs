//! Actual SQLite over isolated memory connections and bounded SQLite images.
//! Guest SQL never names a host database, attaches files or loads extensions.
use crate::Result;
use rusqlite::{
    Connection, DatabaseName,
    backup::{Backup, StepResult},
    config::DbConfig,
    hooks::{AuthAction, AuthContext, Authorization},
    limits::Limit,
    types::{ToSql, ToSqlOutput, ValueRef},
};
use std::sync::{
    Arc,
    atomic::{AtomicUsize, Ordering},
};

#[derive(Clone, Debug, PartialEq)]
pub enum Cell {
    Null,
    Integer(i64),
    Real(f64),
    Text(Vec<u8>),
    Blob(Vec<u8>),
}
impl Cell {
    pub fn bytes(&self) -> usize {
        32 + match self {
            Self::Text(v) | Self::Blob(v) => v.capacity(),
            _ => 0,
        }
    }
}
impl ToSql for Cell {
    fn to_sql(&self) -> rusqlite::Result<ToSqlOutput<'_>> {
        Ok(ToSqlOutput::Borrowed(match self {
            Self::Null => ValueRef::Null,
            Self::Integer(v) => ValueRef::Integer(*v),
            Self::Real(v) => ValueRef::Real(*v),
            Self::Text(v) => ValueRef::Text(v),
            Self::Blob(v) => ValueRef::Blob(v),
        }))
    }
}
pub struct Rows {
    pub columns: Vec<String>,
    pub values: Vec<Vec<Cell>>,
    pub writable: bool,
}
impl Rows {
    pub fn bytes(&self) -> usize {
        64 + self.columns.capacity() * std::mem::size_of::<String>()
            + self.values.capacity() * std::mem::size_of::<Vec<Cell>>()
            + self
                .columns
                .iter()
                .map(|v| 32 + v.capacity())
                .sum::<usize>()
            + self
                .values
                .iter()
                .map(|row| 32 + row.iter().map(Cell::bytes).sum::<usize>())
                .sum::<usize>()
    }
}
pub struct Database {
    connection: Connection,
    max_bytes: usize,
    steps: Arc<AtomicUsize>,
}
const PAGE: usize = 4096;
const STEP_TICKS: usize = 2000;
fn authorize(context: AuthContext<'_>) -> Authorization {
    use Authorization::{Allow, Deny};
    match context.action {
        AuthAction::Attach { .. }
        | AuthAction::Detach { .. }
        | AuthAction::Unknown { .. }
        | AuthAction::CreateVtable { .. }
        | AuthAction::DropVtable { .. } => Deny,
        AuthAction::Function { function_name }
            if ["load_extension", "readfile", "writefile", "fts3_tokenizer"]
                .iter()
                .any(|name| function_name.eq_ignore_ascii_case(name)) =>
        {
            Deny
        }
        AuthAction::Pragma {
            pragma_name,
            pragma_value,
        } => {
            let name = pragma_name.to_ascii_lowercase();
            if matches!(
                name.as_str(),
                "user_version" | "application_id" | "foreign_keys"
            ) || pragma_value.is_none()
                && matches!(
                    name.as_str(),
                    "table_info"
                        | "table_xinfo"
                        | "index_list"
                        | "index_info"
                        | "index_xinfo"
                        | "foreign_key_list"
                        | "database_list"
                        | "page_count"
                        | "page_size"
                        | "encoding"
                        | "schema_version"
                        | "quick_check"
                        | "integrity_check"
                        | "journal_mode"
                        | "busy_timeout"
                )
                || matches!(
                    name.as_str(),
                    "table_info"
                        | "table_xinfo"
                        | "index_list"
                        | "index_info"
                        | "index_xinfo"
                        | "foreign_key_list"
                )
                || name == "busy_timeout" && pragma_value.is_some_and(|v| v == "0")
            {
                Allow
            } else {
                Deny
            }
        }
        _ => Allow,
    }
}
impl Database {
    pub fn new(image: Option<&[u8]>, max_bytes: usize) -> Result<Self> {
        if !(65536..=16 * 1024 * 1024).contains(&max_bytes) {
            return Err("SQLite memory budget".into());
        }
        let mut connection = Connection::open_in_memory()?;
        connection.set_db_config(DbConfig::SQLITE_DBCONFIG_DEFENSIVE, true)?;
        connection.set_db_config(DbConfig::SQLITE_DBCONFIG_TRUSTED_SCHEMA, false)?;
        for (limit, value) in [
            (Limit::SQLITE_LIMIT_LENGTH, 65536),
            (Limit::SQLITE_LIMIT_SQL_LENGTH, 32768),
            (Limit::SQLITE_LIMIT_COLUMN, 128),
            (Limit::SQLITE_LIMIT_EXPR_DEPTH, 64),
            (Limit::SQLITE_LIMIT_COMPOUND_SELECT, 64),
            (Limit::SQLITE_LIMIT_VDBE_OP, 100000),
            (Limit::SQLITE_LIMIT_VARIABLE_NUMBER, 999),
            (Limit::SQLITE_LIMIT_ATTACHED, 0),
            (Limit::SQLITE_LIMIT_TRIGGER_DEPTH, 32),
            (Limit::SQLITE_LIMIT_WORKER_THREADS, 0),
        ] {
            connection.set_limit(limit, value);
        }
        connection.execute_batch(&format!("PRAGMA page_size={PAGE}; PRAGMA max_page_count={}; PRAGMA temp_store=MEMORY; PRAGMA journal_mode=MEMORY; PRAGMA user_version=0;",max_bytes/PAGE))?;
        if let Some(image) = image {
            validate_image(image, max_bytes)?;
            let imported = Connection::open_in_memory()?;
            // READONLY without FREEONCLOSE: SQLite borrows image only until imported
            // is dropped below. Backup copies pages into our own isolated connection.
            let rc = unsafe {
                rusqlite::ffi::sqlite3_deserialize(
                    imported.handle(),
                    c"main".as_ptr(),
                    image.as_ptr().cast_mut(),
                    image.len() as i64,
                    image.len() as i64,
                    rusqlite::ffi::SQLITE_DESERIALIZE_READONLY,
                )
            };
            if rc != rusqlite::ffi::SQLITE_OK {
                return Err("SQLite image import failed".into());
            }
            let backup = Backup::new(&imported, &mut connection)?;
            let mut complete = false;
            for _ in 0..=max_bytes / 512 {
                match backup.step(16)? {
                    StepResult::Done => {
                        complete = true;
                        break;
                    }
                    StepResult::More => {}
                    _ => return Err("SQLite image backup busy".into()),
                }
            }
            if !complete {
                return Err("SQLite image backup quota".into());
            }
            drop(backup);
        }
        // A restored image can carry a different page size; bound its pager again
        // before accepting any guest SQL. These are constant driver operations.
        let page_size: i64 = connection.query_row("PRAGMA page_size", [], |row| row.get(0))?;
        connection.execute_batch(&format!(
            "PRAGMA max_page_count={}; PRAGMA temp_store=MEMORY; PRAGMA journal_mode=MEMORY;",
            max_bytes / page_size as usize
        ))?;
        let steps = Arc::new(AtomicUsize::new(0));
        let progress = Arc::clone(&steps);
        connection.progress_handler(
            100,
            Some(move || progress.fetch_add(1, Ordering::Relaxed) >= STEP_TICKS),
        );
        connection.authorizer(Some(authorize));
        Ok(Self {
            connection,
            max_bytes,
            steps,
        })
    }
    fn reset_budget(&self) {
        self.steps.store(0, Ordering::Relaxed);
    }
    pub fn reserved_bytes(&self) -> usize {
        self.max_bytes + 65536
    }
    pub fn autocommit(&self) -> bool {
        self.connection.is_autocommit()
    }
    pub fn last_insert_id(&self) -> i64 {
        self.connection.last_insert_rowid()
    }
    pub fn exec(&self, sql: &str, args: &[Cell]) -> Result<usize> {
        self.reset_budget();
        self.single_statement(sql)?;
        if self.connection.prepare(sql)?.column_count() != 0 {
            return Err("SQLite exec requires a non-query statement".into());
        }
        Ok(self
            .connection
            .execute(sql, rusqlite::params_from_iter(args))?)
    }
    pub fn query(&self, sql: &str, args: &[Cell], byte_limit: usize) -> Result<Rows> {
        self.reset_budget();
        self.single_statement(sql)?;
        let mut statement = self.connection.prepare(sql)?;
        let columns = statement
            .column_names()
            .iter()
            .map(|s| s.to_string())
            .collect::<Vec<_>>();
        let writable = !statement.readonly();
        let mut result = Rows {
            columns,
            values: Vec::new(),
            writable,
        };
        let mut used = result.bytes();
        if used > byte_limit {
            return Err("SQLite result memory quota".into());
        }
        let count = statement.column_count();
        let mut rows = statement.query(rusqlite::params_from_iter(args))?;
        while let Some(row) = rows.next()? {
            if result.values.len() >= 4096 {
                return Err("SQLite result row quota".into());
            }
            let mut values = Vec::with_capacity(count);
            for i in 0..count {
                let value = match row.get_ref(i)? {
                    ValueRef::Null => Cell::Null,
                    ValueRef::Integer(v) => Cell::Integer(v),
                    ValueRef::Real(v) => Cell::Real(v),
                    ValueRef::Text(v) => Cell::Text(v.to_vec()),
                    ValueRef::Blob(v) => Cell::Blob(v.to_vec()),
                };
                used = used
                    .checked_add(value.bytes() + 8)
                    .ok_or("SQLite result memory overflow")?;
                if used > byte_limit {
                    return Err("SQLite result memory quota".into());
                }
                values.push(value);
            }
            used += 64;
            result.values.push(values);
        }
        Ok(result)
    }
    pub fn image(&self) -> Result<Vec<u8>> {
        if !self.autocommit() {
            return Err("Cannot save SQLite before transaction completion".into());
        }
        let data = self.connection.serialize(DatabaseName::Main)?;
        if data.len() > self.max_bytes {
            return Err("SQLite database image quota".into());
        }
        Ok(data.to_vec())
    }
    fn single_statement(&self, sql: &str) -> Result<()> {
        if sql.len() > 32768 {
            return Err("SQLite SQL length quota".into());
        }
        let length = sql.len();
        let mut sql = std::ffi::CString::new(sql)?.into_bytes_with_nul();
        let start = sql_trivia_end(&sql[..length], 0);
        if start == length {
            return Err("Invalid SQLite statement".into());
        }
        // Some PRAGMAs mutate connection state during prepare, even without a
        // step. Detect extra SQL BEFORE any prepare on this connection. SQLite's
        // completeness parser handles quoted semicolons and trigger BEGIN/END;
        // it does not compile or execute the supplied SQL.
        for index in start..length {
            if sql[index] != b';' {
                continue;
            }
            let saved = sql[index + 1];
            sql[index + 1] = 0;
            // The buffer remains allocated and NUL-terminated during this call.
            let complete =
                unsafe { rusqlite::ffi::sqlite3_complete(sql.as_ptr().add(start).cast()) };
            sql[index + 1] = saved;
            if complete != 0 && complete != 1 {
                return Err("SQLite SQL completeness check failed".into());
            }
            if complete != 0 {
                if sql_trivia_end(&sql[..length], index + 1) != length {
                    return Err("SQLite requires a single statement".into());
                }
                break;
            }
        }
        Ok(())
    }
}
fn sql_trivia_end(sql: &[u8], mut index: usize) -> usize {
    while index < sql.len() {
        match sql[index] {
            b' ' | b'\t' | b'\n' | b'\r' | b'\x0c' | b';' => index += 1,
            b'-' if sql.get(index + 1) == Some(&b'-') => {
                index += 2;
                while index < sql.len() && sql[index] != b'\n' {
                    index += 1;
                }
            }
            b'/' if sql.get(index + 1) == Some(&b'*') => {
                index += 2;
                index = sql[index..]
                    .windows(2)
                    .position(|pair| pair == b"*/")
                    .map_or(sql.len(), |offset| index + offset + 2);
            }
            _ => break,
        }
    }
    index
}
fn validate_image(image: &[u8], limit: usize) -> Result<()> {
    if image.len() < 100 || image.len() > limit || &image[..16] != b"SQLite format 3\0" {
        return Err("Invalid SQLite image or quota".into());
    }
    let raw = u16::from_be_bytes([image[16], image[17]]);
    let size = if raw == 1 { 65536 } else { raw as usize };
    if !(512..=65536).contains(&size)
        || !size.is_power_of_two()
        || !image.len().is_multiple_of(size)
    {
        return Err("Invalid SQLite image pages".into());
    }
    let pages = u32::from_be_bytes(image[28..32].try_into()?) as usize;
    if pages > image.len() / size {
        return Err("Truncated SQLite image pages".into());
    }
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn actual_sql_preserves_types_bindings_transactions_and_images() {
        let db = Database::new(None, 262144).unwrap();
        db.exec("CREATE TABLE events(id INTEGER PRIMARY KEY, number INTEGER, fraction REAL, text TEXT, bytes BLOB, missing)",&[]).unwrap();
        db.exec(
            "INSERT INTO events VALUES(?,?,?,?,?,?)",
            &[
                Cell::Null,
                Cell::Integer(i64::MAX),
                Cell::Real(1.25),
                Cell::Text(b"a\0b".to_vec()),
                Cell::Blob(vec![0, 255]),
                Cell::Null,
            ],
        )
        .unwrap();
        assert_eq!(db.last_insert_id(), 1);
        db.exec("BEGIN EXCLUSIVE", &[]).unwrap();
        db.exec("DELETE FROM events", &[]).unwrap();
        assert!(db.image().is_err());
        db.exec("ROLLBACK", &[]).unwrap();
        let rows = db.query("SELECT * FROM events", &[], 65536).unwrap();
        assert_eq!(
            rows.values[0],
            vec![
                Cell::Integer(1),
                Cell::Integer(i64::MAX),
                Cell::Real(1.25),
                Cell::Text(b"a\0b".to_vec()),
                Cell::Blob(vec![0, 255]),
                Cell::Null
            ]
        );
        db.exec("PRAGMA user_version=5", &[]).unwrap();
        let image = db.image().unwrap();
        let restored = Database::new(Some(&image), 262144).unwrap();
        assert_eq!(
            restored
                .query("SELECT * FROM events", &[], 65536)
                .unwrap()
                .values,
            rows.values
        );
        assert_eq!(
            restored
                .query("PRAGMA user_version", &[], 1024)
                .unwrap()
                .values[0][0],
            Cell::Integer(5)
        );
    }
    #[test]
    fn guest_sql_cannot_escape_to_host_files_extensions_or_change_limits() {
        let db = Database::new(None, 65536).unwrap();
        assert!(db.exec("CREATE TABLE forbidden(x); SELECT 1", &[]).is_err());
        assert!(db.query("SELECT 1; SELECT 2", &[], 4096).is_err());
        assert!(db.query("SELECT * FROM forbidden", &[], 4096).is_err());
        for sql in [
            "ATTACH DATABASE '/tmp/rift-escape.db' AS escape",
            "SELECT load_extension('/tmp/escape')",
            "SELECT writefile('/tmp/escape','payload')",
            "PRAGMA temp_store=FILE",
            "PRAGMA max_page_count=999999",
            "PRAGMA writable_schema=ON",
            "VACUUM INTO '/tmp/escape.db'",
        ] {
            assert!(db.exec(sql, &[]).is_err(), "Guest escape: {sql}");
        }
        assert!(
            db.query("SELECT load_extension('/tmp/escape')", &[], 4096)
                .is_err()
        );
        assert!(db.query("ATTACH ':memory:' AS other", &[], 4096).is_err());
    }
    #[test]
    fn rejecting_extra_sql_preserves_prepare_time_state_and_valid_trigger_syntax() {
        let db = Database::new(None, 65536).unwrap();
        db.exec("PRAGMA foreign_keys=ON", &[]).unwrap();
        for sql in [
            "PRAGMA foreign_keys=OFF; SELECT 1",
            "SELECT 1; PRAGMA foreign_keys=OFF",
            "/* leading ; */ PRAGMA foreign_keys=OFF; -- separator\nSELECT 1",
        ] {
            assert!(db.exec(sql, &[]).is_err());
            assert_eq!(
                db.query("PRAGMA foreign_keys", &[], 1024).unwrap().values[0][0],
                Cell::Integer(1),
                "Rejected exec changed connection state: {sql}"
            );
            assert!(db.query(sql, &[], 4096).is_err());
            assert_eq!(
                db.query("PRAGMA foreign_keys", &[], 1024).unwrap().values[0][0],
                Cell::Integer(1),
                "Rejected query changed connection state: {sql}"
            );
        }
        let quoted = db.query(
            "; /* leading ; */ SELECT 'one;two'';three' AS \"quoted;column\", 1 AS [bracket;name], 2 AS `tick;name`; /* trailing ; */ ; -- ;",
            &[],
            4096,
        ).unwrap();
        assert_eq!(
            quoted.columns,
            ["quoted;column", "bracket;name", "tick;name"]
        );
        assert_eq!(quoted.values[0][0], Cell::Text(b"one;two';three".to_vec()));
        db.exec("CREATE TABLE events(value TEXT)", &[]).unwrap();
        db.exec("CREATE TABLE audit(value TEXT)", &[]).unwrap();
        db.exec(
            "CREATE TRIGGER audit_insert AFTER INSERT ON events BEGIN INSERT INTO audit VALUES('trigger;first'); INSERT INTO audit VALUES(CASE WHEN new.value='' THEN 'end;' ELSE new.value END); END; -- tail ;",
            &[],
        ).unwrap();
        db.exec("INSERT INTO events VALUES('kept;value')", &[])
            .unwrap();
        assert_eq!(
            db.query("SELECT value FROM audit ORDER BY rowid", &[], 4096)
                .unwrap()
                .values,
            vec![
                vec![Cell::Text(b"trigger;first".to_vec())],
                vec![Cell::Text(b"kept;value".to_vec())]
            ]
        );
        // An unterminated block comment at EOF is SQLite trivia as well.
        assert!(db.query("SELECT 42; /* ;", &[], 1024).is_ok());
        db.exec("PRAGMA foreign_keys=OFF; -- valid single statement", &[])
            .unwrap();
        assert_eq!(
            db.query("PRAGMA foreign_keys", &[], 1024).unwrap().values[0][0],
            Cell::Integer(0)
        );
    }
    #[test]
    fn enormous_queries_and_results_fail_without_truncating_success() {
        let db = Database::new(None, 65536).unwrap();
        assert!(
            db.query(
                "WITH RECURSIVE n(x) AS(SELECT 1 UNION ALL SELECT x+1 FROM n) SELECT sum(x) FROM n",
                &[],
                65536
            )
            .is_err()
        );
        assert!(db.query("SELECT zeroblob(65536)", &[], 1024).is_err());
        assert!(db.query("WITH RECURSIVE n(x) AS(SELECT 1 UNION ALL SELECT x+1 FROM n WHERE x<5000) SELECT x FROM n",&[],1024*1024).is_err());
        assert_eq!(
            db.query("SELECT 42", &[], 1024).unwrap().values[0][0],
            Cell::Integer(42)
        );
    }
    #[test]
    fn invalid_and_exaggerated_database_images_are_rejected() {
        for bytes in [vec![], vec![0; 4096], b"SQLite format 3\0".to_vec()] {
            assert!(Database::new(Some(&bytes), 65536).is_err());
        }
        let db = Database::new(None, 65536).unwrap();
        let mut image = db.image().unwrap();
        image[28..32].copy_from_slice(&u32::MAX.to_be_bytes());
        assert!(Database::new(Some(&image), 65536).is_err());
    }
}
