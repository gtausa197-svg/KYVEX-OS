//! Java string searches operate on UTF-16 units, including unpaired surrogates.
use super::*;

fn fold_case(unit: u16) -> u16 {
    let pairs = include_bytes!("../../support/java8-case-fold.bin")
        .as_chunks::<4>()
        .0;
    let found = pairs.binary_search_by_key(&unit, |row| u16::from_le_bytes([row[0], row[1]]));
    found.map_or(unit, |i| u16::from_le_bytes([pairs[i][2], pairs[i][3]]))
}

fn find(text: &[u16], needle: &[u16], from: i32, reverse: bool) -> i32 {
    if reverse && from < 0 {
        return -1;
    }
    if needle.is_empty() {
        return (from.max(0) as usize).min(text.len()) as i32;
    }
    if needle.len() > text.len() {
        return -1;
    }
    let last_start = text.len() - needle.len();
    let (begin, end) = if reverse {
        (0, (from as usize).min(last_start) + needle.len())
    } else {
        let begin = from.max(0) as usize;
        if begin > last_start {
            return -1;
        }
        (begin, text.len())
    };
    // KMP bounds work to O(text + needle), even on repeated malicious input.
    let mut prefix = vec![0; needle.len()];
    let mut matched = 0;
    for i in 1..needle.len() {
        while matched > 0 && needle[i] != needle[matched] {
            matched = prefix[matched - 1];
        }
        if needle[i] == needle[matched] {
            matched += 1;
        }
        prefix[i] = matched;
    }
    let mut result = -1;
    matched = 0;
    for (offset, unit) in text[begin..end].iter().enumerate() {
        while matched > 0 && *unit != needle[matched] {
            matched = prefix[matched - 1];
        }
        if *unit == needle[matched] {
            matched += 1;
        }
        if matched == needle.len() {
            result = (begin + offset + 1 - needle.len()) as i32;
            if !reverse {
                return result;
            }
            matched = prefix[matched - 1];
        }
    }
    result
}

fn code_point(text: &[u16], value: i32, from: i32, reverse: bool) -> i32 {
    if !(0..=0x10ffff).contains(&value) {
        return -1;
    }
    if value <= 0xffff {
        find(text, &[value as u16], from, reverse)
    } else {
        let value = value as u32 - 0x10000;
        find(
            text,
            &[
                0xd800 + (value >> 10) as u16,
                0xdc00 + (value & 1023) as u16,
            ],
            from,
            reverse,
        )
    }
}

fn starts_at(text: &[u16], needle: &[u16], offset: i32) -> bool {
    offset >= 0 && (offset as usize) <= text.len() && text[offset as usize..].starts_with(needle)
}

fn replace(text: &[u16], target: &[u16], replacement: &[u16]) -> Result<Option<Vec<u16>>> {
    let mut offsets = Vec::new();
    if target.is_empty() {
        offsets.extend(0..=text.len());
    } else {
        let mut from = 0;
        loop {
            let at = find(text, target, from as i32, false);
            if at < 0 {
                break;
            }
            offsets.push(at as usize);
            from = at as usize + target.len();
        }
    }
    if offsets.is_empty() || target == replacement {
        return Ok(None);
    }
    let length = text.len() - offsets.len() * target.len() + offsets.len() * replacement.len();
    if length > 16384 {
        return Err("Java string replacement quota (16384 UTF-16 units)".into());
    }
    let mut output = Vec::with_capacity(length);
    let mut start = 0;
    for at in offsets {
        output.extend_from_slice(&text[start..at]);
        output.extend_from_slice(replacement);
        start = at + target.len();
    }
    output.extend_from_slice(&text[start..]);
    Ok(Some(output))
}

impl Runtime {
    pub(super) fn string_search_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let Some(method) = sig.strip_prefix("Ljava/lang/String;->") else {
            return Ok(None);
        };
        if !matches!(
            method,
            "indexOf(Ljava/lang/String;)I"
                | "indexOf(Ljava/lang/String;I)I"
                | "lastIndexOf(Ljava/lang/String;)I"
                | "lastIndexOf(Ljava/lang/String;I)I"
                | "indexOf(I)I"
                | "indexOf(II)I"
                | "lastIndexOf(I)I"
                | "lastIndexOf(II)I"
                | "contains(Ljava/lang/CharSequence;)Z"
                | "equalsIgnoreCase(Ljava/lang/String;)Z"
                | "startsWith(Ljava/lang/String;I)Z"
                | "replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;"
                | "replace(CC)Ljava/lang/String;"
        ) {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("String search argument count");
        let text = self.units(arg(0)?)?;
        if method == "equalsIgnoreCase(Ljava/lang/String;)Z" {
            if arg(1)? == 0 {
                return Ok(Some(0));
            }
            let other = self.units(arg(1)?)?;
            let equal = text.len() == other.len()
                && text.iter().zip(&other).all(|(&first, &second)| {
                    first == second || fold_case(first) == fold_case(second)
                });
            return Ok(Some(equal as u64));
        }
        if method.starts_with("replace(") {
            let (target, replacement) = if method.starts_with("replace(CC)") {
                (vec![arg(1)? as u16], vec![arg(2)? as u16])
            } else {
                (self.sequence_units(arg(1)?)?, self.sequence_units(arg(2)?)?)
            };
            return Ok(Some(
                if let Some(output) = replace(&text, &target, &replacement)? {
                    self.string_units(output)?
                } else {
                    arg(0)?
                } as u64,
            ));
        }
        let reverse = method.starts_with("lastIndexOf");
        let from = if method.contains(";I)") || method.contains("(II)") {
            arg(2)? as i32
        } else if reverse {
            text.len() as i32
        } else {
            0
        };
        let result = if method.contains("(I") {
            code_point(&text, arg(1)? as i32, from, reverse)
        } else {
            let needle = if method.starts_with("contains") {
                self.sequence_units(arg(1)?)?
            } else {
                self.units(arg(1)?)?
            };
            if method.starts_with("startsWith") {
                starts_at(&text, &needle, from) as i32
            } else {
                let result = find(&text, &needle, from, reverse);
                if method.starts_with("contains") {
                    (result >= 0) as i32
                } else {
                    result
                }
            }
        };
        Ok(Some(result as u32 as u64))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn replacement_limit_is_checked_before_allocating_output() {
        let text = vec![97; 16384];
        assert!(replace(&text, &[], &[98]).is_err());
        assert!(replace(&text, &[97], &text).is_err());
        assert!(replace(&text, &[97], &[97]).unwrap().is_none());
    }
    #[test]
    fn searches_match_independent_stock_jdk_results() {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/string-search-oracle.json");
        let data: serde_json::Value =
            serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
        fn units(value: &serde_json::Value) -> Vec<u16> {
            value
                .as_str()
                .unwrap()
                .as_bytes()
                .as_chunks::<4>()
                .0
                .iter()
                .map(|s| u16::from_str_radix(std::str::from_utf8(s).unwrap(), 16).unwrap())
                .collect()
        }
        for case in data["cases"].as_array().unwrap() {
            let text = units(&case[0]);
            let needle = units(&case[1]);
            let from = case[2].as_i64().unwrap() as i32;
            let cp = case[5].as_i64().unwrap() as i32;
            for (actual, expected) in [
                (find(&text, &needle, from, false), &case[3]),
                (find(&text, &needle, from, true), &case[4]),
                (code_point(&text, cp, from, false), &case[6]),
                (code_point(&text, cp, from, true), &case[7]),
                (starts_at(&text, &needle, from) as i32, &case[8]),
            ] {
                assert_eq!(actual as i64, expected.as_i64().unwrap(), "{case}");
            }
            let replacement = units(&case[9]);
            let actual = replace(&text, &needle, &replacement)
                .unwrap()
                .unwrap_or_else(|| text.clone());
            assert_eq!(actual, units(&case[10]), "replacement {case}");
        }
    }
}
