package org.kyvex.other;
public class UpdaterBase { protected volatile String value="protected"; }
