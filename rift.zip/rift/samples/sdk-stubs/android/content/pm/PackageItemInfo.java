package android.content.pm;
/** Compile-only SDK signature; never packaged into the APK. */
public class PackageItemInfo {
    public String name, packageName;
    public android.os.Bundle metaData;
    public android.content.res.XmlResourceParser loadXmlMetaData(PackageManager manager, String name) { return null; }
}
