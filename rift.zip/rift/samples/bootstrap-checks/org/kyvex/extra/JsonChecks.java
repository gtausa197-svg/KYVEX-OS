package org.kyvex.extra;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;
import org.json.JSONTokener;

public final class JsonChecks {
    private static int checks;

    private static void check(boolean ok, String label) {
        if (!ok) throw new IllegalStateException(label);
        checks++;
    }

    private static void verifyNumbers() {
        String[] values = {
            " -0.0\u0000", "+1.25F", "1e999999", "-1e-999999", "-NaN", "+Infinity",
            "0x1.00000000000008p0", "0x1.00000000000008000000001p0", "0x1.fffffffffffffp1023",
            "0x1.fffffffffffff8p1023", "0x1p-1075", "-0x1.00000000000001p-1075",
            "0x0.fffffffffffff8p-1022", "0X.2P+3d", "-0x0p99999999"
        };
        long[] bits = {
            0x8000000000000000L, 0x3ff4000000000000L, 0x7ff0000000000000L,
            0x8000000000000000L, 0x7ff8000000000000L, 0x7ff0000000000000L,
            0x3ff0000000000000L, 0x3ff0000000000001L, 0x7fefffffffffffffL,
            0x7ff0000000000000L, 0L, 0x8000000000000001L, 0x0010000000000000L,
            0x3ff0000000000000L, 0x8000000000000000L
        };
        for (int index = 0; index < values.length; index++) {
            check(Double.doubleToLongBits(Double.parseDouble(values[index])) == bits[index], values[index]);
        }
        for (String invalid : new String[]{"inf", "nan", "1_0", "0x.p1", "0x1p", "Infinityf", "1.0 2", "++1"}) {
            boolean rejected = false;
            try { Double.parseDouble(invalid); } catch (NumberFormatException expected) { rejected = true; }
            check(rejected, "Rejected floating-point input " + invalid);
        }
        boolean rejectedNull = false;
        try { Double.valueOf((String) null); } catch (NullPointerException expected) { rejectedNull = true; }
        check(rejectedNull, "Null number throws NullPointerException");
    }

    public static int verify() {
        checks = 0;
        verifyNumbers();
        try {
            JSONObject object = new JSONObject("\ufeff{ /* comment */ x:1, x:2, 'n':null, y:TrUe, text:'A\\u0000\u041a', data:[1, 2.5, {n:9223372036854775807}]} ");
            check(object.length() == 5 && object.getInt("x") == 2, "Object, comments and last duplicate value");
            check(object.has("n") && object.isNull("n") && object.isNull("missing"), "Null and missing lookup");
            check(object.get("n") == JSONObject.NULL && JSONObject.NULL.equals(null), "Real JSON null singleton");
            check("null".equals(object.optString("n")), "Null coerces to text");
            check(object.getBoolean("y") && "A\u0000\u041a".equals(object.getString("text")), "Boolean and UTF16 parse");
            JSONArray data = object.getJSONArray("data");
            check(data.length() == 3 && data.getDouble(1) == 2.5, "Nested array and real number");
            check(data.getJSONObject(2).getLong("n") == Long.MAX_VALUE, "64-bit integer exact");
            check(object.optInt("text", 63) == 63 && object.optBoolean("missing", true), "Defaults on missing or incompatible value");
            object.put("encoded", " 0x1.8p1 ");
            check(object.getInt("encoded") == 3 && object.getDouble("encoded") == 3.0, "String number coercion");
            object.put("coerced", "fAlSe");
            check(!object.getBoolean("coerced"), "Case-insensitive boolean coercion");
            String bmp = new String(new char[]{'\u0130', '\u03c2', '\ud800'});
            String supplementary = new String(new char[]{'\ud801', '\udc00'});
            check(bmp.equalsIgnoreCase("i\u03a3\ud800"), "Java 8 char case folding and surrogate preservation");
            check(!supplementary.equalsIgnoreCase("\ud801\udc28"), "Java 8 compares surrogate code units");
            object.put("n", (Object)null);
            check(!object.has("n"), "Java null removes a key");
            object.accumulate("tags", "one").accumulate("tags", "two");
            check("two".equals(object.getJSONArray("tags").getString(1)), "Accumulated values use a real array");
            data.put(4, 9);
            check(data.length() == 5 && data.isNull(3) && data.getInt(4) == 9, "Array extension and null hole");
            check(data.remove(0).equals(1) && data.length() == 4 && data.optInt(-1, 82) == 82, "Array removal and fallback");
            Iterator<String> keys = object.keys();
            check("x".equals(keys.next()), "Object insertion order");
            keys.remove();
            check(!object.has("x"), "Key iterator is a live view");
            Map<String,Object> map = new LinkedHashMap<String,Object>();
            map.put("left", 24);
            map.put("right", JSONObject.NULL);
            JSONObject copied = new JSONObject(map);
            map.clear();
            check(copied.getInt("left") == 24 && copied.has("right"), "Copy map into independent object");
            check("[\"left\",\"right\"]".equals(copied.names().toString()), "Object names as a JSON array");
            check("{\"left\":24,\"right\":null}".equals(copied.toString()), "Compact JSON serialization");
            check("{\n  \"left\": 24,\n  \"right\": null\n}".equals(copied.toString(2)), "Indented JSON serialization");
            check("\"A\\u0000\\n\\/\"".equals(JSONObject.quote("A\u0000\n/")), "Quoted control characters and slash");
            check("[true,{\"k\":-0}]".equals(new JSONStringer().array().value(true).object().key("k").value(-0.0).endObject().endArray().toString()), "Streaming writer and negative zero");
            check("abc\nXYZ".equals(new JSONTokener("'abc\\nXYZ'").nextValue()), "Escaped string slices");
            check("a\ud800".equals(new JSONTokener("'a\\ud800'").nextValue()), "Lone surrogate preserved");
            boolean rejected = false;
            try { object.put("bad", Double.POSITIVE_INFINITY); } catch (JSONException expected) { rejected = true; }
            check(rejected && !object.has("bad"), "Nonfinite value rejected without mutation");
            rejected = false;
            try { new JSONArray("[1,{]"); } catch (JSONException expected) { rejected = expected.getMessage() != null; }
            check(rejected, "Malformed array raises typed parse exception");
            rejected = false;
            try { data.get(50); } catch (JSONException expected) { rejected = expected.getCause() instanceof IndexOutOfBoundsException; }
            check(rejected, "Array bounds cause is retained");
            System.gc();
            check(copied.has("right") && data.getJSONObject(1).getLong("n") == Long.MAX_VALUE, "Guest references survive collection");
        } catch (JSONException error) {
            throw new IllegalStateException("Unexpected JSON exception", error);
        }
        return checks;
    }

    public static void main(String[] args) {
        System.out.println("JSON checks: " + verify());
    }
}
