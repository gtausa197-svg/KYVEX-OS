//! One virtual app process; these are never desktop process/account identifiers.
pub const PID: u32 = 1;
pub const MAIN_TID: u32 = 1;
pub const UID: u32 = 10000;
pub const GID: u32 = 10000;
// This VM has one guest user and no credential-encrypted storage or lock state.
pub const CREDENTIAL_STORAGE_UNLOCKED: bool = true;
