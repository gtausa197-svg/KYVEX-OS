/* Small ABI-only fixture. It has no Android SDK or host library dependency. */
typedef struct {const void **functions;} Env;
typedef struct {const void **functions;} VM;
typedef void *Object;
typedef struct {const char *name;const char *signature;const void *function;} Method;
__attribute__((visibility("default"))) void Java_org_kyvex_extra_StackChecks_nativeFault(Env *env,Object type){
    (void)type;Object (*find)(Env*,const char*)=(void*)env->functions[6];
    int (*throw_new)(Env*,Object,const char*)=(void*)env->functions[14];
    Object exception=find(env,"java/lang/IllegalStateException");
    if(exception)throw_new(env,exception,"native-stack");
}
__attribute__((visibility("default"))) long long Java_org_kyvex_extra_ThreadNativeChecks_probe(Env *env,Object type,int expected_tid,int previous,int next){
    (void)type;unsigned long tls;long tid;
#ifdef __aarch64__
    __asm__ volatile("mrs %0,tpidr_el0":"=r"(tls));
    register long x8 __asm__("x8")=178;register long x0 __asm__("x0");
    __asm__ volatile("svc #0":"=r"(x0):"r"(x8):"memory");tid=x0;
#else
    __asm__ volatile("mrc p15,0,%0,c13,c0,3":"=r"(tls));
    register long r7 __asm__("r7")=224;register long r0 __asm__("r0");
    __asm__ volatile("svc #0":"=r"(r0):"r"(r7):"memory");tid=r0;
#endif
    VM *vm=0;Env *actual=0;
    int (*get_vm)(Env*,VM**)=(void*)env->functions[219];
    if(tid!=expected_tid||!tls||*(unsigned long*)tls!=tls||*(int*)(tls+64)!=previous||get_vm(env,&vm)!=0||!vm)return 0;
    int (*get_env)(VM*,Env**,int)=(void*)vm->functions[6];
    if(get_env(vm,&actual,0x10006)!=0||actual!=env)return 0;
    *(int*)(tls+64)=next;return (unsigned long)env;
}
static int multiply(Env *env,Object type,int value){(void)env;(void)type;return value*7;}
static double mixed(Env *e,Object t,long long marker,float f,double d,int a,int b,int c,int x,int y,int z,int q,int r){
    (void)e;(void)t;if(marker!=0x1122334455667788LL)return -999.0;return f+d+a+b+c+x+y+z+q+r;
}
static long long aligned(Env *e,Object t,int pad,long long wide,int tail){(void)e;(void)t;return wide+pad+tail;}
static float floating(Env *e,Object t,float value){(void)e;(void)t;return value*1.5f;}
static double fp_stack(Env *e,Object t,double a,double b,double c,double d,double f,double g,double h,double i,double j,double k){(void)e;(void)t;return a+b+c+d+f+g+h+i+j+k;}
static Object message(Env *env,Object type){
    (void)type;
    Object (*new_string)(Env*,const char*)=(void*)env->functions[167];
    int (*length)(Env*,Object)=(void*)env->functions[164];
    const char *(*get_utf)(Env*,Object,void*)=(void*)env->functions[169];
    void (*release_utf)(Env*,Object,const char*)=(void*)env->functions[170];
    Object (*global)(Env*,Object)=(void*)env->functions[21];
    void (*drop_global)(Env*,Object)=(void*)env->functions[22];
    int (*ref_type)(Env*,Object)=(void*)env->functions[232];
    Object (*array)(Env*,int)=(void*)env->functions[176];
    void (*set_region)(Env*,Object,int,int,const char*)=(void*)env->functions[208];
    void (*get_region)(Env*,Object,int,int,char*)=(void*)env->functions[200];
    int (*get_vm)(Env*,VM**)=(void*)env->functions[219];
    VM *vm=0;
    if(get_vm(env,&vm)!=0 || !vm)return 0;
    Object a=array(env,3);char data[3]={2,3,7};char output[3]={0,0,0};
    set_region(env,a,0,3,data);get_region(env,a,0,3,output);
    if(output[0]!=2||output[1]!=3||output[2]!=7)return 0;
#ifdef __aarch64__
    Object text=new_string(env,"Registered JNI / ARM64");
#else
    Object text=new_string(env,"Registered JNI / ARM32");
#endif
    Object g=global(env,text);
    if(ref_type(env,g)!=2 || length(env,g)!=22)return 0;
    const char *chars=get_utf(env,g,0);
    if(!chars || chars[0]!='R')return 0;
    release_utf(env,g,chars);drop_global(env,g);return text;
}
__attribute__((visibility("default"))) int JNI_OnLoad(VM *vm,void *reserved){
    (void)reserved;Env *env=0;
    int (*get_env)(VM*,Env**,int)=(void*)vm->functions[6];
    if(get_env(vm,&env,0x10006)!=0)return -1;
    Object (*find)(Env*,const char*)=(void*)env->functions[6];
    int (*register_methods)(Env*,Object,const Method*,int)=(void*)env->functions[215];
    static const Method methods[]={{"timesSeven","(I)I",multiply},{"nativeMessage","()Ljava/lang/String;",message},
        {"mixedNative","(JFDIIIIIIII)D",mixed},{"alignedNative","(IJI)J",aligned},{"floatingNative","(F)F",floating},{"fpStackNative","(DDDDDDDDDD)D",fp_stack}};
    Object type=find(env,"org/kyvex/nativehello/MainActivity");
    if(!type||register_methods(env,type,methods,6)!=0)return -1;
    return 0x10006;
}
