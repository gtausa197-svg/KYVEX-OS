//! Read-only Android resource tables. Bytes come only from the preopened APK.
//! Selection currently targets a fixed en-US, API 28, 360x640 dp virtual display.
use crate::Result;
use std::{cmp::Ordering, collections::BTreeMap, rc::Rc};

const MAX_TABLE: usize = 64 * 1024 * 1024;
const MAX_ENTRIES: usize = 262144;
const MAX_VISITS: usize = 2_000_000;
pub const WIDTH_DP: u16 = 360;
pub const HEIGHT_DP: u16 = 640;
pub const DENSITY: u16 = 320;

pub(crate) fn u16le(b: &[u8], at: usize) -> Result<u16> {
    Ok(u16::from_le_bytes(
        b.get(at..at + 2).ok_or("Resource u16 bounds")?.try_into()?,
    ))
}
pub(crate) fn u32le(b: &[u8], at: usize) -> Result<u32> {
    Ok(u32::from_le_bytes(
        b.get(at..at + 4).ok_or("Resource u32 bounds")?.try_into()?,
    ))
}
pub(crate) fn chunk(b: &[u8], at: usize) -> Result<(u16, usize, &[u8])> {
    let rest = b.get(at..).ok_or("Resource chunk bounds")?;
    let head = u16le(rest, 2)? as usize;
    let size = u32le(rest, 4)? as usize;
    if head < 8 || size < head || !size.is_multiple_of(4) {
        return Err("Invalid resource chunk header".into());
    }
    Ok((
        u16le(rest, 0)?,
        head,
        rest.get(..size).ok_or("Truncated resource chunk")?,
    ))
}
#[derive(Clone)]
pub(crate) struct Pool {
    start: usize,
    end: usize,
    utf8: bool,
    offsets: Vec<u32>,
}
impl Pool {
    pub(crate) fn parse(b: &[u8], at: usize) -> Result<Self> {
        let (kind, head, c) = chunk(b, at)?;
        if kind != 1 || head < 28 {
            return Err("Resource string pool header".into());
        }
        let count = u32le(c, 8)? as usize;
        let styles = u32le(c, 12)? as usize;
        let start = u32le(c, 20)? as usize;
        let style_start = u32le(c, 24)? as usize;
        if count > 500000
            || styles > count
            || head + (count + styles) * 4 > start
            || start > c.len()
            || (styles != 0 && (style_start < start || style_start > c.len()))
        {
            return Err("Resource string pool bounds/quota".into());
        }
        let end = if style_start == 0 {
            c.len()
        } else {
            style_start
        };
        if end < start || end > c.len() {
            return Err("Resource string data bounds".into());
        }
        let mut offsets = Vec::with_capacity(count);
        for i in 0..count {
            let offset = u32le(c, head + i * 4)?;
            if offset as usize >= end - start {
                return Err("Resource string offset".into());
            }
            offsets.push(offset);
        }
        Ok(Self {
            start: at + start,
            end: at + end,
            utf8: u32le(c, 16)? & 256 != 0,
            offsets,
        })
    }
    fn units(&self, bytes: &[u8], index: u32) -> Result<Vec<u16>> {
        self.bounded_units(bytes, index, 1_000_000)
    }
    pub(crate) fn count(&self) -> usize {
        self.offsets.len()
    }
    pub(crate) fn bounded_units(&self, bytes: &[u8], index: u32, limit: usize) -> Result<Vec<u16>> {
        let offset = *self
            .offsets
            .get(index as usize)
            .ok_or("Resource string index")? as usize;
        let b = bytes
            .get(self.start + offset..self.end)
            .ok_or("Resource string data")?;
        let mut at = 0;
        let mut len = |wide: bool| -> Result<usize> {
            let (first, mask, shift) = if wide {
                let v = u16le(b, at)? as usize;
                at += 2;
                (v, 0x8000, 16)
            } else {
                let v = *b.get(at).ok_or("Resource string length")? as usize;
                at += 1;
                (v, 0x80, 8)
            };
            Ok(if first & mask == 0 {
                first
            } else {
                let tail = if wide {
                    let v = u16le(b, at)? as usize;
                    at += 2;
                    v
                } else {
                    let v = *b.get(at).ok_or("Resource string length")? as usize;
                    at += 1;
                    v
                };
                ((first & !mask) << shift) | tail
            })
        };
        let length = len(!self.utf8)?;
        let encoded = if self.utf8 { len(false)? } else { length * 2 };
        if length > limit {
            return Err("Resource string length quota".into());
        }
        let data = b.get(at..at + encoded).ok_or("Resource string bounds")?;
        let value = if self.utf8 {
            if b.get(at + encoded) != Some(&0) {
                return Err("Unterminated resource UTF8".into());
            }
            match std::str::from_utf8(data) {
                Ok(s) => s.encode_utf16().collect::<Vec<_>>(),
                // AAPT2 also emits the surrogate-pair form used by Android's
                // modified UTF8 helpers. Preserve the UTF16 units exactly.
                Err(_) => crate::dexfile::mutf8_units(data)?,
            }
        } else {
            if u16le(b, at + encoded)? != 0 {
                return Err("Unterminated resource UTF16".into());
            }
            data.as_chunks::<2>()
                .0
                .iter()
                .map(|c| u16::from_le_bytes(*c))
                .collect()
        };
        if value.len() != length {
            return Err("Resource UTF16 length mismatch".into());
        }
        Ok(value)
    }
    fn text(&self, bytes: &[u8], index: u32) -> Result<String> {
        Ok(String::from_utf16(&self.units(bytes, index)?)?)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Value {
    pub kind: u8,
    pub data: u32,
}
impl Value {
    pub(crate) fn parse(b: &[u8], at: usize) -> Result<Self> {
        if u16le(b, at)? != 8 || b.get(at + 2) != Some(&0) {
            return Err("Resource typed value header".into());
        }
        Ok(Self {
            kind: *b.get(at + 3).ok_or("Resource value type")?,
            data: u32le(b, at + 4)?,
        })
    }
}
#[derive(Clone, Debug)]
pub enum Content {
    Simple(Value),
    Bag {
        parent: u32,
        items: Vec<(u32, Value)>,
    },
}
#[derive(Clone, Eq, PartialEq)]
struct Rank {
    qualifiers: [u16; 14],
    density: u16,
    sdk: u16,
}
impl Ord for Rank {
    fn cmp(&self, other: &Self) -> Ordering {
        self.qualifiers
            .cmp(&other.qualifiers)
            .then_with(|| density_cmp(self.density, other.density))
            .then(self.sdk.cmp(&other.sdk))
    }
}
impl PartialOrd for Rank {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}
fn density_cmp(a: u16, b: u16) -> Ordering {
    if a == b {
        return Ordering::Equal;
    }
    if a == 0xfffe {
        return Ordering::Greater;
    }
    if b == 0xfffe {
        return Ordering::Less;
    }
    let x = if a == 0 { 160 } else { a as u32 };
    let y = if b == 0 { 160 } else { b as u32 };
    if x == y {
        return Ordering::Equal;
    }
    let (low, high) = (x.min(y), x.max(y));
    let target = DENSITY as u32;
    let prefer_low = if target >= high {
        false
    } else if low >= target {
        true
    } else {
        (2 * low).saturating_sub(target) * high > target * target
    };
    if (x == low) == prefer_low {
        Ordering::Greater
    } else {
        Ordering::Less
    }
}
fn configuration(c: &[u8]) -> Result<Option<Rank>> {
    let size = u32le(c, 0)? as usize;
    if !(28..=128).contains(&size) || size > c.len() {
        return Err("Resource configuration bounds".into());
    }
    let c = &c[..size];
    let byte = |i: usize| c.get(i).copied().unwrap_or(0);
    let word = |i: usize| u16::from_le_bytes([byte(i), byte(i + 1)]);
    let field =
        |at: usize, mask: u8, expected: u8| byte(at) & mask == 0 || byte(at) & mask == expected;
    // No SIM, en-US, portrait touch display, no physical keyboard/navigation,
    // normal non-round sRGB/LDR screen, day mode. Other configurations stay unavailable.
    if word(4) != 0
        || word(6) != 0
        || (word(8) != 0 && [byte(8), byte(9)] != *b"en")
        || (word(10) != 0 && [byte(10), byte(11)] != *b"US")
        || !field(12, 0xff, 1)
        || !field(13, 0xff, 3)
        || !field(16, 0xff, 1)
        || !field(17, 0xff, 1)
        || !field(18, 3, 2)
        || !field(18, 12, 8)
        || byte(19) != 0
        || word(20) > WIDTH_DP * 2
        || word(22) > HEIGHT_DP * 2
        || word(24) > 28
        || word(26) != 0
        || byte(28) & 15 > 2
        || !field(28, 0x30, 0x20)
        || !field(28, 0xc0, 0x40)
        || !field(29, 15, 1)
        || !field(29, 0x30, 0x10)
        || word(30) > WIDTH_DP
        || word(32) > WIDTH_DP
        || word(34) > HEIGHT_DP
        || (c
            .get(36..40)
            .is_some_and(|s| s.iter().any(|v| *v != 0) && s != b"Latn"))
        || c.get(40..48).is_some_and(|s| s.iter().any(|v| *v != 0))
        || !field(48, 3, 1)
        || !field(49, 3, 1)
        || !field(49, 12, 4)
        || c.get(50..).is_some_and(|s| s.iter().any(|v| *v != 0))
    {
        return Ok(None);
    }
    Ok(Some(Rank {
        qualifiers: [
            u16::from(word(8) != 0),
            u16::from(word(10) != 0),
            (byte(28) & 0xc0) as u16,
            word(30),
            word(32),
            word(34),
            (byte(28) & 15) as u16,
            (byte(28) & 0x30) as u16,
            (byte(48) & 3) as u16,
            byte(49) as u16,
            byte(12) as u16,
            (byte(29) & 15) as u16,
            (byte(29) & 0x30) as u16,
            word(20),
        ],
        density: word(14),
        sdk: word(24),
    }))
}
pub struct Entry {
    pub package: Rc<str>,
    pub kind: Rc<str>,
    pub name: String,
    selected: Option<(Rank, Content)>,
}
pub struct Table {
    bytes: Vec<u8>,
    strings: Option<Pool>,
    entries: BTreeMap<u32, Entry>,
    allocated: usize,
}
impl Table {
    pub fn empty() -> Self {
        Self {
            bytes: Vec::new(),
            strings: None,
            entries: BTreeMap::new(),
            allocated: 0,
        }
    }
    pub fn bytes(&self) -> usize {
        self.allocated
            + self.bytes.len()
            + self
                .strings
                .as_ref()
                .map_or(0, |s| s.offsets.capacity() * 4)
    }
    pub fn parse(bytes: Vec<u8>, limit: usize) -> Result<Self> {
        if bytes.len() > MAX_TABLE || bytes.len() > limit {
            return Err("APK resource table memory quota".into());
        }
        let (kind, head, root) = chunk(&bytes, 0)?;
        if kind != 2 || head < 12 || root.len() != bytes.len() {
            return Err("Resource table header".into());
        }
        let expected = u32le(root, 8)? as usize;
        if expected > 32 {
            return Err("Resource package count quota".into());
        }
        let mut result = Self::empty();
        let (mut at, mut packages, mut visits) = (head, 0, 0);
        while at < bytes.len() {
            let (kind, _, c) = chunk(&bytes, at)?;
            if kind == 1 {
                if result.strings.is_some() {
                    return Err("Duplicate global resource string pool".into());
                }
                result.strings = Some(Pool::parse(&bytes, at)?);
            } else if kind == 0x200 {
                result.package(c, &mut visits, limit.saturating_sub(bytes.len()))?;
                packages += 1;
            }
            at += c.len();
        }
        if packages != expected || result.strings.is_none() {
            return Err("Resource package/string table count".into());
        }
        result.bytes = bytes;
        if result.bytes() > limit {
            return Err("Resource index memory quota".into());
        }
        Ok(result)
    }
    fn package(&mut self, b: &[u8], visits: &mut usize, limit: usize) -> Result<()> {
        let (_, head, _) = chunk(b, 0)?;
        if head < 284 {
            return Err("Resource package header".into());
        }
        let package_id = u32le(b, 8)?;
        if !(1..=255).contains(&package_id) {
            return Err("Unsupported shared/dynamic resource package".into());
        }
        let raw = b.get(12..268).ok_or("Resource package name")?;
        let name: Vec<u16> = raw
            .as_chunks::<2>()
            .0
            .iter()
            .map(|v| u16::from_le_bytes(*v))
            .take_while(|v| *v != 0)
            .collect();
        let package: Rc<str> = String::from_utf16(&name)?.into();
        let types = Pool::parse(b, u32le(b, 268)? as usize)?;
        let keys = Pool::parse(b, u32le(b, 276)? as usize)?;
        let offset = if head >= 288 { u32le(b, 284)? } else { 0 };
        self.allocated += package.len() + types.offsets.len() * 16;
        let mut names = BTreeMap::<u8, Rc<str>>::new();
        let mut at = head;
        while at < b.len() {
            let (kind, h, c) = chunk(b, at)?;
            if kind == 0x201 {
                if h < 48 || h < 20 + u32le(c, 20)? as usize {
                    return Err("Resource type/config header".into());
                }
                let type_id = c[8];
                let id = type_id as u32 + offset;
                if type_id == 0 || id > 255 || c[9] & !3 != 0 || c[9] == 3 || u16le(c, 10)? != 0 {
                    return Err("Resource type ID/flags".into());
                }
                let count = u32le(c, 12)? as usize;
                let start = u32le(c, 16)? as usize;
                let stride = if c[9] & 2 != 0 { 2 } else { 4 };
                if count > 65536 || h + count * stride > start || start > c.len() {
                    return Err("Resource entry offsets bounds".into());
                }
                let rank = configuration(&c[20..h])?;
                let ty = if let Some(name) = names.get(&type_id) {
                    name.clone()
                } else {
                    let value: Rc<str> = types.text(b, type_id as u32 - 1)?.into();
                    names.insert(type_id, value.clone());
                    value
                };
                let mut previous = None;
                for i in 0..count {
                    *visits += 1;
                    if *visits > MAX_VISITS {
                        return Err("Resource variant visit quota".into());
                    }
                    let (entry_id, entry_offset) = if c[9] & 1 != 0 {
                        let entry = u16le(c, h + i * 4)? as u32;
                        if previous.is_some_and(|last| last >= entry) {
                            return Err("Unsorted sparse resource entries".into());
                        }
                        previous = Some(entry);
                        (entry, u16le(c, h + i * 4 + 2)? as u32 * 4)
                    } else if stride == 2 {
                        let off = u16le(c, h + i * 2)?;
                        (
                            i as u32,
                            if off == 0xffff {
                                u32::MAX
                            } else {
                                off as u32 * 4
                            },
                        )
                    } else {
                        (i as u32, u32le(c, h + i * 4)?)
                    };
                    if entry_offset == u32::MAX {
                        continue;
                    }
                    let e = start
                        .checked_add(entry_offset as usize)
                        .ok_or("Resource entry offset overflow")?;
                    let flags = u16le(c, e + 2)?;
                    let key = if flags & 8 != 0 {
                        u16le(c, e)? as u32
                    } else {
                        u32le(c, e + 4)?
                    };
                    let key = keys.text(b, key)?;
                    let resource_id = (package_id << 24) | (id << 16) | entry_id;
                    if !self.entries.contains_key(&resource_id) && self.entries.len() >= MAX_ENTRIES
                    {
                        return Err("Resource entry count quota".into());
                    }
                    let record = self.entries.entry(resource_id).or_insert_with(|| {
                        self.allocated += 128 + key.len();
                        Entry {
                            package: package.clone(),
                            kind: ty.clone(),
                            name: key.clone(),
                            selected: None,
                        }
                    });
                    if record.package != package || record.kind != ty || record.name != key {
                        return Err("Resource ID has conflicting names".into());
                    }
                    if let Some(rank) = &rank
                        && record.selected.as_ref().is_none_or(|(old, _)| rank > old)
                    {
                        let content = if flags & 8 != 0 {
                            if flags & 1 != 0 {
                                return Err("Invalid compact complex resource".into());
                            }
                            Content::Simple(Value {
                                kind: (flags >> 8) as u8,
                                data: u32le(c, e + 4)?,
                            })
                        } else {
                            let size = u16le(c, e)? as usize;
                            if size < 8 || e + size > c.len() {
                                return Err("Resource entry size".into());
                            }
                            if flags & 1 == 0 {
                                Content::Simple(Value::parse(c, e + size)?)
                            } else {
                                if size < 16 {
                                    return Err("Complex resource header".into());
                                }
                                let n = u32le(c, e + 12)? as usize;
                                if n > 65536 || e + size + n * 12 > c.len() {
                                    return Err("Complex resource bounds/quota".into());
                                }
                                let mut items = Vec::with_capacity(n);
                                for j in 0..n {
                                    let at = e + size + j * 12;
                                    items.push((u32le(c, at)?, Value::parse(c, at + 4)?));
                                }
                                Content::Bag {
                                    parent: u32le(c, e + 8)?,
                                    items,
                                }
                            }
                        };
                        let bag_bytes = |c: &Content| match c {
                            Content::Bag { items, .. } => items.capacity() * 12,
                            _ => 0,
                        };
                        self.allocated -= record.selected.as_ref().map_or(0, |(_, c)| bag_bytes(c));
                        self.allocated += bag_bytes(&content);
                        record.selected = Some((rank.clone(), content));
                    }
                    if self.allocated > limit {
                        return Err("Resource index allocation quota".into());
                    }
                }
            }
            at += c.len();
        }
        Ok(())
    }
    pub fn entry(&self, id: u32) -> Option<&Entry> {
        self.entries.get(&id)
    }
    pub fn content(&self, id: u32) -> Result<&Content> {
        self.entries
            .get(&id)
            .and_then(|e| e.selected.as_ref())
            .map(|(_, c)| c)
            .ok_or_else(|| {
                format!("Resource 0x{id:08x} unavailable for virtual display/configuration").into()
            })
    }
    pub fn resolve(&self, id: u32) -> Result<(u32, Value)> {
        let mut id = id;
        let mut seen = Vec::new();
        loop {
            if seen.len() >= 32 || seen.contains(&id) {
                return Err("Resource reference cycle/depth quota".into());
            }
            seen.push(id);
            let Content::Simple(value) = self.content(id)? else {
                return Err("Resource is a complex bag".into());
            };
            if value.kind != 1 {
                return Ok((id, *value));
            }
            id = value.data;
        }
    }
    pub fn string(&self, index: u32) -> Result<Vec<u16>> {
        self.strings
            .as_ref()
            .ok_or("No global resource strings")?
            .units(&self.bytes, index)
    }
    pub fn identifier(&self, name: &str, kind: &str, package: &str) -> u32 {
        if let Ok(id) = name.parse::<u32>() {
            return id;
        }
        let (package, name) = name.split_once(':').unwrap_or((package, name));
        let (kind, name) = name.split_once('/').unwrap_or((kind, name));
        self.entries
            .iter()
            .find_map(|(id, e)| {
                (e.package.as_ref() == package && e.kind.as_ref() == kind && e.name == name)
                    .then_some(*id)
            })
            .unwrap_or(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture() -> Vec<u8> {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/rift-resource-demo.apk");
        let mut zip = zip::ZipArchive::new(std::fs::File::open(path).unwrap()).unwrap();
        crate::assets::member(&mut zip, "resources.arsc", MAX_TABLE as u64).unwrap()
    }
    #[test]
    fn aapt2_table_selects_locale_orientation_sdk_and_resolves_real_values() {
        let t = Table::parse(fixture(), 4 * 1024 * 1024).unwrap();
        let id = |kind, name| t.identifier(name, kind, "org.kyvex.nativehello");
        let text = |name| {
            let (_, value) = t.resolve(id("string", name)).unwrap();
            assert_eq!(value.kind, 3);
            String::from_utf16(&t.string(value.data).unwrap()).unwrap()
        };
        assert_eq!(text("greeting_alias"), "Hello from APK resources 🌍");
        assert_eq!(text("locale_choice"), "US locale");
        assert_eq!(text("orientation_choice"), "portrait default");
        assert_eq!(text("sdk_choice"), "API 28 fallback");
        assert_eq!(
            t.resolve(id("integer", "answer")).unwrap().1,
            Value {
                kind: 0x10,
                data: 42
            }
        );
        assert_eq!(t.resolve(id("color", "accent")).unwrap().1.data, 0xff345678);
        let Content::Bag { parent, items } = t.content(id("array", "numbers")).unwrap() else {
            panic!("not an array");
        };
        assert_eq!((*parent, items.len(), items[1].1.data as i32), (0, 3, -3));
        assert_eq!(
            items.iter().map(|v| v.0).collect::<Vec<_>>(),
            [0x01000001, 0x01000002, 0x01000003]
        );
        assert_eq!(
            t.identifier("org.kyvex.nativehello:string/greeting", "", ""),
            id("string", "greeting")
        );
        assert_eq!(t.identifier("greeting", "string", "other.package"), 0);
    }
    #[test]
    fn malformed_and_over_budget_resource_tables_are_rejected_without_panics() {
        let bytes = fixture();
        assert!(Table::parse(bytes.clone(), bytes.len()).is_err());
        for len in [0, 7, 8, 11, bytes.len() - 1] {
            assert!(Table::parse(bytes[..len].to_vec(), MAX_TABLE).is_err());
        }
        for offset in [2, 4, 8, 12 + 4, 12 + 8, 12 + 20] {
            let mut damaged = bytes.clone();
            damaged[offset..offset + 4].fill(0xff);
            assert!(Table::parse(damaged, MAX_TABLE).is_err(), "offset {offset}");
        }
    }
    #[test]
    fn cyclic_resource_references_and_incorrect_string_terminators_fail() {
        let mut t = Table::parse(fixture(), MAX_TABLE).unwrap();
        let a = t.identifier("greeting", "string", "org.kyvex.nativehello");
        let b = t.identifier("greeting_alias", "string", "org.kyvex.nativehello");
        let rank = t.entries[&a].selected.as_ref().unwrap().0.clone();
        for (id, target) in [(a, b), (b, a)] {
            t.entries.get_mut(&id).unwrap().selected = Some((
                rank.clone(),
                Content::Simple(Value {
                    kind: 1,
                    data: target,
                }),
            ));
        }
        assert!(t.resolve(a).unwrap_err().to_string().contains("cycle"));
        let mut t = Table::parse(fixture(), MAX_TABLE).unwrap();
        let (_, v) = t.resolve(a).unwrap();
        let p = t.strings.as_ref().unwrap();
        let offset = p.start + p.offsets[v.data as usize] as usize;
        let terminator = t.bytes[offset..p.end].iter().position(|c| *c == 0).unwrap() + offset;
        t.bytes[terminator] = 1;
        assert!(t.string(v.data).is_err());
    }
    #[test]
    fn density_choice_is_order_independent_and_preserves_android_scaling_preference() {
        for (a, b, winner) in [
            (160, 320, 320),
            (240, 480, 480),
            (480, 640, 480),
            (120, 160, 160),
            (0, 320, 320),
            (0xfffe, 320, 0xfffe),
        ] {
            assert_eq!(
                density_cmp(a, b),
                if winner == a {
                    Ordering::Greater
                } else {
                    Ordering::Less
                }
            );
            assert_eq!(density_cmp(b, a), density_cmp(a, b).reverse());
        }
    }
}
