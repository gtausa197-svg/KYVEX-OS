/* A real ARM library whose JNI_OnLoad deliberately rejects initialization. */
int JNI_OnLoad(void *vm, void *reserved) { (void)vm; (void)reserved; return 0; }
