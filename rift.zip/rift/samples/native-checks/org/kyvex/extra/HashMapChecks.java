package org.kyvex.extra;

import java.util.Date;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/** Hash and equality callbacks run on the same Java code in both engines. */
public final class HashMapChecks {
    private static int checks;
    private static int hashes;
    private static int comparisons;

    private static void check(boolean ok, String description) {
        if (!ok) throw new IllegalStateException(description);
        checks++;
    }

    private static class Key {
        final int id;
        int hash;
        Key(int id, int hash) { this.id = id; this.hash = hash; }
        public int hashCode() { hashes++; return hash; }
        public boolean equals(Object other) {
            comparisons++;
            return other instanceof Key && ((Key) other).id == id;
        }
    }

    private static void largeMap() {
        Map<Key, Object> map = new HashMap<Key, Object>();
        Object marker = new Object();
        hashes = comparisons = 0;
        for (int i = 0; i < 256; i++) map.put(new Key(i, 31 * i + 5), marker);
        check(map.size() == 256 && hashes == 256 && comparisons == 0,
                "Distinct hashes avoid equality scans during insertion");
        hashes = comparisons = 0;
        for (int i = 0; i < 256; i++) {
            if (map.get(new Key(i, 31 * i + 5)) != marker) throw new IllegalStateException("Lookup lost a key");
        }
        check(hashes == 256 && comparisons == 256, "One hash and one equality test per matching key");
        hashes = comparisons = 0;
        check(!map.containsKey(new Key(200, -1)) && hashes == 1 && comparisons == 0,
                "A hash miss never runs a guest equals callback");
        HashMap<Key, Object> copy = new HashMap<Key, Object>(map);
        check(copy.size() == 256 && copy.get(new Key(255, 31 * 255 + 5)) == marker, "Copy constructor builds independent entries");
        map.clear();
        check(map.isEmpty() && !map.containsKey(new Key(255, 31 * 255 + 5)) && copy.size() == 256,
                "Clearing clears only this map's index");
    }

    private static void collisionsAndViews() {
        Map<Key, Object> map = new LinkedHashMap<Key, Object>();
        Key first = new Key(1, 6);
        Key second = new Key(2, 6);
        Object a = new Object();
        Object b = new Object();
        Object c = new Object();
        map.put(first, a);
        map.put(second, b);
        hashes = comparisons = 0;
        check(map.get(new Key(2, 6)) == b && hashes == 1 && comparisons == 2,
                "True collisions dispatch real equality in bucket order");
        check(map.put(new Key(1, 6), c) == a && map.size() == 2,
                "An equal key updates its existing value");
        Iterator<Map.Entry<Key, Object>> entries = map.entrySet().iterator();
        Map.Entry<Key, Object> firstEntry = entries.next();
        check(firstEntry.getKey() == first && firstEntry.getValue() == c, "Updates preserve the key object and linked order");
        first.hash = 9;
        check(!map.containsKey(first) && map.get(new Key(1, 6)) == c,
                "The key retains its insertion hash after mutation");
        check(firstEntry.setValue(a) == c && firstEntry.getValue() == a && map.get(new Key(1, 6)) == a,
                "A live entry can update the original cached key slot");
        first.hash = 6;
        entries.remove();
        check(!map.containsKey(first) && map.get(second) == b && entries.next().getKey() == second,
                "Iterator removal maintains the other collision entries");
        check(map.remove(new Key(2, 6), b) && map.isEmpty(), "Conditional removal uses the same bucket");
    }

    private static void libraryKeys() {
        Map<Object, Object> map = new HashMap<Object, Object>();
        Object marker = new Object();
        map.put(null, null);
        check(map.containsKey(null) && map.getOrDefault(null, marker) == null,
                "A present null mapping differs from an absent key");
        check(map.putIfAbsent(null, marker) == null && map.get(null) == marker, "Put-if-absent replaces a null value");
        map.put("Aa", "one");
        map.put("BB", "two");
        check("one".equals(map.get("Aa")) && "two".equals(map.get("BB")), "Real Java String hash collision");
        map.put(new Date(1234567890123L), "date");
        check("date".equals(map.get(new Date(1234567890123L))), "Date hash matches its value equality");
        map.put(Integer.valueOf(137), "integer");
        check("integer".equals(map.get(Integer.valueOf(137))), "Boxed keys use numeric hash and equality");
        map.put(new java.io.File("/data/sample"), "file");
        check("file".equals(map.get(new java.io.File("/data/sample"))), "File hashes follow pathname equality");
        HashMap<Object, Object> other = new HashMap<Object, Object>();
        other.putAll(map);
        check(other.size() == map.size() && other.get(null) == marker, "Bulk copy preserves the null and library keys");
    }

    private static void callbackFailures() {
        final RuntimeException failure = new IllegalStateException("guest hash failure");
        Map<Key, Object> map = new HashMap<Key, Object>();
        Key present = new Key(12, 20);
        Object value = new Object();
        map.put(present, value);
        try {
            map.put(new Key(13, 20) {
                public int hashCode() { throw failure; }
            }, new Object());
            throw new IllegalStateException("Hash error was discarded");
        } catch (RuntimeException actual) {
            check(actual == failure && map.size() == 1 && map.get(present) == value, "Hash errors propagate without inserting");
        }
        try {
            map.get(new Key(13, 20) {
                public boolean equals(Object other) { throw failure; }
            });
            throw new IllegalStateException("Equality error was discarded");
        } catch (RuntimeException actual) {
            check(actual == failure && map.size() == 1 && map.get(present) == value,
                    "Collisions use the lookup key's real equals callback");
        }
        Key collected = new Key(14, 21) {
            public int hashCode() { System.gc(); return super.hashCode(); }
        };
        map.put(collected, value);
        check(map.get(new Key(14, 21)) == value, "Guest GC preserves the pending key and stored value");
    }

    private static void arrayCopies() {
        int[] original = new int[]{11, -7, 25};
        int[] longer = Arrays.copyOf(original, 5);
        check(longer != original && longer.length == 5 && longer[0] == 11 && longer[1] == -7
                && longer[2] == 25 && longer[3] == 0 && longer[4] == 0, "Integer copies pad with zeros");
        int[] shorter = Arrays.copyOf(original, 1);
        shorter[0] = 77;
        check(shorter.length == 1 && original[0] == 11, "Truncated copies are independent");
        int[] range = Arrays.copyOfRange(original, 1, 5);
        check(range.length == 4 && range[0] == -7 && range[1] == 25 && range[3] == 0,
                "Range copies preserve order and pad beyond the end");
        check(Arrays.copyOfRange(original, 3, 4)[0] == 0, "The source end is a valid start");
        check(Arrays.copyOf(new boolean[]{true}, 2)[0] && !Arrays.copyOf(new boolean[]{true}, 2)[1]
                && Arrays.copyOf(new byte[]{-99}, 1)[0] == -99, "Boolean and byte arrays");
        check(Arrays.copyOfRange(new char[]{'x', '\uffff'}, 1, 3)[0] == '\uffff'
                && Arrays.copyOf(new short[]{-30000}, 1)[0] == -30000, "Character and short arrays");
        check(Arrays.copyOf(new long[]{0x12345678abcdef12L}, 2)[0] == 0x12345678abcdef12L,
                "A copied long retains both DEX words");
        check(1.0f / Arrays.copyOf(new float[]{-0.0f}, 1)[0] == Float.NEGATIVE_INFINITY
                && Arrays.copyOfRange(new double[]{3.5, -9.25}, 1, 2)[0] == -9.25,
                "Floating array words retain their bits");

        Object[] strings = new String[]{"value"};
        Object[] sameType = Arrays.copyOf(strings, 2);
        check(sameType.getClass() == String[].class && sameType[0] == strings[0] && sameType[1] == null,
                "Reference copies preserve the source's runtime array class");
        Object[] widened = Arrays.copyOf(strings, 2, Object[].class);
        check(widened.getClass() == Object[].class && widened[0] == strings[0], "Explicit widened target class");
        String[] narrowed = Arrays.copyOfRange(new Object[]{null, "typed"}, 1, 3, String[].class);
        check(narrowed.length == 2 && "typed".equals(narrowed[0]) && narrowed[1] == null,
                "Checked narrowing copies the actual reference");
        int[][] nested = new int[][]{original};
        check(Arrays.copyOf(nested, 1)[0] == original, "Multidimensional copies retain their inner arrays");
        try {
            Arrays.copyOf(new Object[]{new Object()}, 1, String[].class);
            throw new IllegalStateException("Expected array element type failure");
        } catch (ArrayStoreException expected) { checks++; }
        try { Arrays.copyOf((int[]) null, -1); throw new IllegalStateException("Expected negative length"); }
        catch (NegativeArraySizeException expected) { checks++; }
        try { Arrays.copyOf((Object[]) null, -1); throw new IllegalStateException("Expected null array"); }
        catch (NullPointerException expected) { checks++; }
        try { Arrays.copyOfRange(original, 2, 1); throw new IllegalStateException("Expected reversed range"); }
        catch (IllegalArgumentException expected) { checks++; }
        try { Arrays.copyOfRange(original, 4, 4); throw new IllegalStateException("Expected bounds failure"); }
        catch (ArrayIndexOutOfBoundsException expected) { checks++; }
    }

    public static int verify() {
        checks = 0;
        largeMap();
        collisionsAndViews();
        libraryKeys();
        callbackFailures();
        arrayCopies();
        return checks;
    }

    public static void main(String[] args) {
        System.out.println("HashMap checks: " + verify());
    }
}
