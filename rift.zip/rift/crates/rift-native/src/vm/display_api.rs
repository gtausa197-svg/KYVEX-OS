//! One window-backed virtual display with the same profile as Android resources.
use super::*;
use crate::resources::{DENSITY, HEIGHT_DP, WIDTH_DP};

pub(super) const WINDOW_MANAGER: &str = "Landroid/view/WindowManager;";
pub(super) const VIEW_MANAGER: &str = "Landroid/view/ViewManager;";
const WINDOW_MANAGER_IMPL: &str = "Landroid/view/WindowManagerImpl;";
const DISPLAY: &str = "Landroid/view/Display;";
const MODE: &str = "Landroid/view/Display$Mode;";
const HDR_CAPABILITIES: &str = "Landroid/view/Display$HdrCapabilities;";
const METRICS: &str = "Landroid/util/DisplayMetrics;";
const DISPLAY_REF: usize = usize::MAX - 131;
const MODE_REF: usize = usize::MAX - 132;
const HDR_REF: usize = usize::MAX - 133;
const BASE_DPI: u32 = 160;
const WIDTH: u32 = WIDTH_DP as u32 * DENSITY as u32 / BASE_DPI;
const HEIGHT: u32 = HEIGHT_DP as u32 * DENSITY as u32 / BASE_DPI;
const REFRESH_RATE: f32 = 60.0;

pub(super) fn parent(class: &str) -> Option<&'static str> {
    matches!(
        class,
        WINDOW_MANAGER | VIEW_MANAGER | WINDOW_MANAGER_IMPL | DISPLAY | MODE | HDR_CAPABILITIES
    )
    .then_some("Ljava/lang/Object;")
}

pub(super) fn inherits(class: &str, base: &str) -> bool {
    (class == WINDOW_MANAGER_IMPL && matches!(base, WINDOW_MANAGER | VIEW_MANAGER))
        || (class == WINDOW_MANAGER && base == VIEW_MANAGER)
}

pub(super) fn profile_metrics() -> BTreeMap<String, u64> {
    let density = f32::from(DENSITY) / BASE_DPI as f32;
    BTreeMap::from([
        ("widthPixels".into(), u64::from(WIDTH)),
        ("heightPixels".into(), u64::from(HEIGHT)),
        ("densityDpi".into(), u64::from(DENSITY)),
        ("density".into(), u64::from(density.to_bits())),
        ("scaledDensity".into(), u64::from(density.to_bits())),
        ("xdpi".into(), u64::from(f32::from(DENSITY).to_bits())),
        ("ydpi".into(), u64::from(f32::from(DENSITY).to_bits())),
    ])
}

impl Runtime {
    pub(super) fn guest_window_manager(&mut self) -> Result<u32> {
        if self.window_manager == 0 {
            self.window_manager = self.allocate(WINDOW_MANAGER_IMPL, Payload::Instance)?;
        }
        Ok(self.window_manager)
    }

    fn display_member(&mut self, owner: u32, key: usize, class: &str) -> Result<u64> {
        if let Some(&id) = self.object(owner)?.fields.get(&key) {
            return Ok(id);
        }
        let id = u64::from(self.allocate(class, Payload::Instance)?);
        self.object_mut(owner)?.fields.insert(key, id);
        Ok(id)
    }

    pub(super) fn display_api(&mut self, sig: &str, args: &[u32]) -> Result<Option<u64>> {
        let Some((class, method)) = sig.split_once("->") else {
            return Ok(None);
        };
        let arg = |i: usize| args.get(i).copied().ok_or("Display argument");
        if matches!(class, WINDOW_MANAGER | WINDOW_MANAGER_IMPL)
            && method == "getDefaultDisplay()Landroid/view/Display;"
        {
            let manager = arg(0)?;
            self.object(manager)?;
            if manager != self.window_manager {
                return Err("Unknown guest WindowManager".into());
            }
            return Ok(Some(self.display_member(manager, DISPLAY_REF, DISPLAY)?));
        }
        let value = match class {
            DISPLAY => match method {
                "getSize(Landroid/graphics/Point;)V" | "getRealSize(Landroid/graphics/Point;)V" => {
                    self.point_api(
                        "Landroid/graphics/Point;->set(II)V",
                        &[arg(1)?, WIDTH, HEIGHT],
                    )?;
                    0
                }
                "getRectSize(Landroid/graphics/Rect;)V" => {
                    self.rect_api(
                        "Landroid/graphics/Rect;->set(IIII)V",
                        &[arg(1)?, 0, 0, WIDTH, HEIGHT],
                    )?;
                    0
                }
                "getMetrics(Landroid/util/DisplayMetrics;)V"
                | "getRealMetrics(Landroid/util/DisplayMetrics;)V" => {
                    let output = self.object_mut(arg(1)?)?;
                    if output.class != METRICS {
                        return Err(fault(
                            "Ljava/lang/ClassCastException;",
                            "Expected DisplayMetrics output",
                        ));
                    }
                    output.payload = Payload::Record(profile_metrics());
                    0
                }
                "getDisplayId()I" | "getRotation()I" | "getOrientation()I" | "isHdr()Z" => 0,
                "isValid()Z" => 1,
                "getWidth()I" => u64::from(WIDTH),
                "getHeight()I" => u64::from(HEIGHT),
                "getRefreshRate()F" => u64::from(REFRESH_RATE.to_bits()),
                "getSupportedRefreshRates()[F" => u64::from(self.allocate(
                    "[F",
                    Payload::Array(vec![u64::from(REFRESH_RATE.to_bits())]),
                )?),
                "getMode()Landroid/view/Display$Mode;" => {
                    self.display_member(arg(0)?, MODE_REF, MODE)?
                }
                "getHdrCapabilities()Landroid/view/Display$HdrCapabilities;" => {
                    self.display_member(arg(0)?, HDR_REF, HDR_CAPABILITIES)?
                }
                _ => return Ok(None),
            },
            MODE => match method {
                "getModeId()I" => 1,
                "getPhysicalWidth()I" => u64::from(WIDTH),
                "getPhysicalHeight()I" => u64::from(HEIGHT),
                "getRefreshRate()F" => u64::from(REFRESH_RATE.to_bits()),
                _ => return Ok(None),
            },
            HDR_CAPABILITIES => match method {
                "getSupportedHdrTypes()[I" => {
                    u64::from(self.allocate("[I", Payload::Array(Vec::new()))?)
                }
                "getDesiredMaxLuminance()F"
                | "getDesiredMaxAverageLuminance()F"
                | "getDesiredMinLuminance()F" => u64::from((-1.0f32).to_bits()),
                _ => return Ok(None),
            },
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}
