//! Timing curves for guest Android animations.
use super::*;

pub(super) const INTERPOLATOR: &str = "Landroid/view/animation/Interpolator;";
pub(super) const TIME_INTERPOLATOR: &str = "Landroid/animation/TimeInterpolator;";
const BASE: &str = "Landroid/view/animation/BaseInterpolator;";
const ACCELERATE: &str = "Landroid/view/animation/AccelerateInterpolator;";
const DECELERATE: &str = "Landroid/view/animation/DecelerateInterpolator;";
const OVERSHOOT: &str = "Landroid/view/animation/OvershootInterpolator;";
const AMOUNT: usize = usize::MAX - 130;

pub(super) fn parent(class: &str) -> Option<&'static str> {
    Some(match class {
        ACCELERATE | DECELERATE | OVERSHOOT => BASE,
        BASE | INTERPOLATOR | TIME_INTERPOLATOR => "Ljava/lang/Object;",
        _ => return None,
    })
}

pub(super) fn inherits(class: &str, base: &str) -> bool {
    (class == BASE && matches!(base, INTERPOLATOR | TIME_INTERPOLATOR))
        || (class == INTERPOLATOR && base == TIME_INTERPOLATOR)
}

pub(super) fn payload(class: &str) -> Option<Payload> {
    matches!(class, ACCELERATE | DECELERATE | OVERSHOOT).then_some(Payload::Instance)
}

fn pow(base: f32, exponent: f32) -> f64 {
    // Java Math.pow specifies NaN for either unit base and an infinite exponent.
    if (base.abs() == 1.0 && exponent.is_infinite()) || exponent.is_nan() {
        f64::NAN
    } else {
        f64::from(base).powf(f64::from(exponent))
    }
}

impl Runtime {
    pub(super) fn interpolator_api(&mut self, sig: &str, args: &[u32]) -> Result<Option<u64>> {
        let Some((class, method)) = sig.split_once("->") else {
            return Ok(None);
        };
        let default: f32 = match class {
            ACCELERATE | DECELERATE => 1.0,
            OVERSHOOT => 2.0,
            _ => return Ok(None),
        };
        let arg = |i: usize| args.get(i).copied().ok_or("Interpolator argument");
        let receiver = arg(0)?;
        if !self.subclass(&self.object(receiver)?.class, class)? {
            return Err("Interpolator receiver type".into());
        }
        let amount = match method {
            "<init>()V" => default.to_bits(),
            "<init>(F)V" => arg(1)?,
            "getInterpolation(F)F" => {
                let amount = self
                    .object(receiver)?
                    .fields
                    .get(&AMOUNT)
                    .copied()
                    .unwrap_or(0);
                let amount = f32::from_bits(amount as u32);
                let input = f32::from_bits(arg(1)?);
                let value = match class {
                    ACCELERATE if amount == 1.0 => input * input,
                    ACCELERATE => pow(input, 2.0 * amount) as f32,
                    DECELERATE if amount == 1.0 => {
                        let remaining = 1.0 - input;
                        1.0 - remaining * remaining
                    }
                    DECELERATE => (1.0 - pow(1.0 - input, 2.0 * amount)) as f32,
                    OVERSHOOT => {
                        let end = input - 1.0;
                        end * end * ((amount + 1.0) * end + amount) + 1.0
                    }
                    _ => unreachable!(),
                };
                return Ok(Some(u64::from(value.to_bits())));
            }
            _ => return Ok(None),
        };
        // The generic object field tracer scans 32-bit words as guest handles.
        self.object_mut(receiver)?
            .fields
            .insert(AMOUNT, (1u64 << 32) | u64::from(amount));
        Ok(Some(0))
    }
}
