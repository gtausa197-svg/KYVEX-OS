//! Declared constructor lookup invokes real DEX constructors or known native ones.
use super::throwable::CAUSE;
use super::*;
#[derive(Clone)]
pub(super) struct Constructor {
    pub owner: String,
    pub descriptor: String,
    pub parameters: Vec<String>,
    pub access: u32,
    pub index: Option<usize>,
    pub accessible: bool,
}
fn native_constructor(class: &str, descriptor: &str) -> Option<u32> {
    Some(match (class, descriptor) {
        (
            "Ljava/util/Collections$SynchronizedCollection;",
            "(Ljava/util/Collection;)V" | "(Ljava/util/Collection;Ljava/lang/Object;)V",
        )
        | (
            "Ljava/util/Collections$SynchronizedMap;",
            "(Ljava/util/Map;)V" | "(Ljava/util/Map;Ljava/lang/Object;)V",
        )
        | (
            "Ljava/util/Collections$SynchronizedList;",
            "(Ljava/util/List;)V" | "(Ljava/util/List;Ljava/lang/Object;)V",
        ) => 0,
        ("Landroid/content/pm/ApplicationInfo;" | "Landroid/content/pm/PackageInfo;", "()V")
        | (
            "Ljava/lang/Thread;",
            "()V"
            | "(Ljava/lang/String;)V"
            | "(Ljava/lang/Runnable;)V"
            | "(Ljava/lang/Runnable;Ljava/lang/String;)V"
            | "(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;)V"
            | "(Ljava/lang/ThreadGroup;Ljava/lang/String;)V"
            | "(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;)V"
            | "(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;J)V",
        )
        | (
            "Ljava/lang/ThreadGroup;",
            "(Ljava/lang/String;)V" | "(Ljava/lang/ThreadGroup;Ljava/lang/String;)V",
        )
        | (
            "Ljava/io/File;",
            "(Ljava/lang/String;)V"
            | "(Ljava/lang/String;Ljava/lang/String;)V"
            | "(Ljava/io/File;Ljava/lang/String;)V",
        )
        | ("Ljava/util/concurrent/CountDownLatch;", "(I)V") => 1,
        (
            "Ljava/lang/StackTraceElement;",
            "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V",
        ) => 1,
        (
            "Ljava/io/ObjectStreamField;",
            "(Ljava/lang/String;Ljava/lang/Class;)V" | "(Ljava/lang/String;Ljava/lang/Class;Z)V",
        ) => 1,
        _ => return None,
    })
}
impl Runtime {
    fn class_parameters(&self, array: u32) -> Result<Vec<String>> {
        if array == 0 {
            return Ok(Vec::new());
        }
        let Payload::Array(values) = &self.object(array)?.payload else {
            return Err("Constructor parameter types must be Class[]".into());
        };
        if values.len() > 255 {
            return Err("Constructor parameter quota".into());
        }
        values
            .iter()
            .map(|id| match &self.object(*id as u32)?.payload {
                Payload::Class(c) => Ok(c.clone()),
                _ => Err("Constructor parameter is not Class".into()),
            })
            .collect()
    }
    fn declared_constructor(
        &mut self,
        owner: String,
        parameters: Vec<String>,
    ) -> Result<Constructor> {
        self.ensure_class(&owner)?;
        let descriptor = format!("({})V", parameters.concat());
        if let Some(ty) = self.dex.type_id(&owner)
            && let Some(class) = self.dex.classes.get(&ty)
        {
            if let Some(index) = self
                .dex
                .find(&owner, "<init>", &descriptor)
                .filter(|i| class.methods.contains(i))
            {
                let access = self
                    .dex
                    .bodies
                    .get(&index)
                    .ok_or("Constructor access metadata")?
                    .access;
                return Ok(Constructor {
                    owner,
                    descriptor,
                    parameters,
                    access,
                    index: Some(index),
                    accessible: false,
                });
            }
        } else if let Some(access) = native_constructor(&owner, &descriptor) {
            return Ok(Constructor {
                owner,
                descriptor,
                parameters,
                access,
                index: None,
                accessible: false,
            });
        }
        Err(fault(
            "Ljava/lang/NoSuchMethodException;",
            &format!("{owner}->{descriptor}"),
        ))
    }
    fn constructor_arguments(&self, constructor: &Constructor, array: u32) -> Result<Vec<u32>> {
        let values = if array == 0 {
            Vec::new()
        } else {
            let Payload::Array(v) = &self.object(array)?.payload else {
                return Err(fault(
                    "Ljava/lang/IllegalArgumentException;",
                    "Constructor arguments must be Object[]",
                ));
            };
            v.clone()
        };
        if values.len() != constructor.parameters.len() {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Wrong constructor argument count",
            ));
        }
        let mut words = Vec::new();
        for (value, ty) in values.iter().zip(&constructor.parameters) {
            if ty.starts_with(['L', '[']) {
                let id = u32::try_from(*value)?;
                if id != 0 && !self.subclass(&self.object(id)?.class, ty)? {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Wrong constructor argument type",
                    ));
                }
                words.push(id);
            } else {
                if *value == 0 {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Null primitive constructor argument",
                    ));
                }
                let Payload::Boxed { kind, bits } = self.object(*value as u32)?.payload else {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Primitive constructor argument must be boxed",
                    ));
                };
                let to = ty.chars().next().ok_or("Constructor argument type")?;
                let bits = reflection::widen(bits, kind, to).ok_or_else(|| {
                    fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Wrong primitive constructor argument type",
                    )
                })?;
                words.push(bits as u32);
                if matches!(to, 'J' | 'D') {
                    words.push((bits >> 32) as u32);
                }
            }
        }
        Ok(words)
    }
    fn construct(&mut self, constructor: &Constructor, words: &[u32]) -> Result<u32> {
        if constructor.index.is_none()
            && constructor
                .owner
                .starts_with("Ljava/util/Collections$Synchronized")
        {
            let target = *words.first().ok_or("Synchronized target")?;
            self.object(target)?;
            let mutex = if words.len() == 2 {
                self.object(words[1])?;
                words[1]
            } else {
                0
            };
            return self.allocate(
                &constructor.owner,
                Payload::CollectionWrapper {
                    target,
                    readonly: false,
                    mutex,
                },
            );
        }
        let object = self.instantiate(&constructor.owner)?;
        let mut args = vec![object];
        args.extend(words);
        if let Some(index) = constructor.index {
            self.invoke(index, &args, false)?;
        } else {
            self.hle(
                &format!("{}-><init>{}", constructor.owner, constructor.descriptor),
                &args,
            )?;
        }
        Ok(object)
    }
    fn invocation_error(
        &mut self,
        error: Box<dyn std::error::Error + Send + Sync>,
    ) -> Box<dyn std::error::Error + Send + Sync> {
        let Some(original) = error.downcast_ref::<JavaFault>() else {
            return error;
        };
        let result = (|| -> Result<u32> {
            let cause = self.materialize_fault(original)?;
            let wrapper = self.instantiate("Ljava/lang/reflect/InvocationTargetException;")?;
            self.object_mut(wrapper)?.fields.insert(CAUSE, cause as u64);
            self.capture_throwable_stack(wrapper)?;
            Ok(wrapper)
        })();
        match result {
            Ok(object) => Box::new(JavaFault {
                class: "Ljava/lang/reflect/InvocationTargetException;".into(),
                object,
                message: original.message.clone(),
            }),
            Err(error) => error,
        }
    }
    pub(super) fn constructor_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Constructor signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Constructor argument count");
        if class == "Ljava/lang/Class;"
            && matches!(
                method,
                "getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;"
                    | "getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;"
            )
        {
            let Payload::Class(owner) = &self.object(arg(0)?)?.payload else {
                return Err("Expected Class object".into());
            };
            let owner = owner.clone();
            let parameters = self.class_parameters(arg(1)?)?;
            let constructor = self.declared_constructor(owner, parameters)?;
            if method.starts_with("getConstructor(") && constructor.access & 1 == 0 {
                return Err(fault(
                    "Ljava/lang/NoSuchMethodException;",
                    "No public constructor with these parameter types",
                ));
            }
            return Ok(Some(self.allocate(
                "Ljava/lang/reflect/Constructor;",
                Payload::ReflectedConstructor(constructor),
            )? as u64));
        }
        if matches!(
            method,
            "getCause()Ljava/lang/Throwable;" | "getTargetException()Ljava/lang/Throwable;"
        ) && self.object(arg(0)?)?.class == "Ljava/lang/reflect/InvocationTargetException;"
        {
            return Ok(Some(
                *self.object(arg(0)?)?.fields.get(&CAUSE).unwrap_or(&0),
            ));
        }
        if !matches!(
            class,
            "Ljava/lang/reflect/Constructor;" | "Ljava/lang/reflect/AccessibleObject;"
        ) {
            return Ok(None);
        }
        let id = arg(0)?;
        let Payload::ReflectedConstructor(constructor) = &self.object(id)?.payload else {
            return Ok(None);
        };
        let mut constructor = constructor.clone();
        let value = match method {
            "setAccessible(Z)V" => {
                constructor.accessible = arg(1)? != 0;
                self.object_mut(id)?.payload = Payload::ReflectedConstructor(constructor);
                0
            }
            "isAccessible()Z" => constructor.accessible as u64,
            "getDeclaringClass()Ljava/lang/Class;" => self.class_object(&constructor.owner)? as u64,
            "getModifiers()I" => constructor.access as u64,
            "getParameterTypes()[Ljava/lang/Class;" => {
                let mut values = Vec::new();
                for ty in &constructor.parameters {
                    values.push(self.class_object(ty)? as u64);
                }
                self.allocate("[Ljava/lang/Class;", Payload::Array(values))? as u64
            }
            "newInstance([Ljava/lang/Object;)Ljava/lang/Object;" => {
                if constructor.access & 1 == 0 && !constructor.accessible {
                    return Err(fault(
                        "Ljava/lang/IllegalAccessException;",
                        "Constructor is not accessible",
                    ));
                }
                if let Some(class) = self
                    .dex
                    .type_id(&constructor.owner)
                    .and_then(|ty| self.dex.classes.get(&ty))
                {
                    if class.access & 0x600 != 0 {
                        return Err(fault(
                            "Ljava/lang/InstantiationException;",
                            "Cannot instantiate an abstract class or interface",
                        ));
                    }
                    if class.access & 0x4000 != 0 {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "Cannot reflectively create an enum",
                        ));
                    }
                }
                let words = self.constructor_arguments(&constructor, arg(1)?)?;
                if let Some(ty) = self.dex.type_id(&constructor.owner) {
                    self.initialize(ty)?;
                }
                match self.construct(&constructor, &words) {
                    Ok(object) => object as u64,
                    Err(error) => return Err(self.invocation_error(error)),
                }
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}
