"""Original bounded-fixture binary Android XML generator."""
import struct

def manifest(with_metadata=False, with_providers=False, with_services=False, min_sdk=23, provider_xml=0):
    android='http://schemas.android.com/apk/res/android';strings=[]
    def s(value):
        if value not in strings:strings.append(value)
        return strings.index(value)
    s('android');s(android)
    nodes=[]
    def start(name,attrs=()):
        name=s(name);encoded=[]
        for ns,key,value,kind in attrs:
            ni=s(ns) if ns else 0xffffffff;ki=s(key)
            if kind==3:raw=s(value);data=raw
            else:raw=0xffffffff;data=int(value)
            encoded.append(struct.pack('<IIIHBBI',ni,ki,raw,8,0,kind,data))
        ext=struct.pack('<IIHHHHHH',0xffffffff,name,20,20,len(encoded),0,0,0)
        nodes.append(struct.pack('<HHIII',0x102,16,16+len(ext)+20*len(encoded),1,0xffffffff)+ext+b''.join(encoded))
    def end(name):nodes.append(struct.pack('<HHIIIII',0x103,16,24,1,0xffffffff,0xffffffff,s(name)))
    start('manifest',[(None,'package','org.kyvex.nativehello',3),(android,'versionCode',2,0x10),(android,'versionName','0.2',3)])
    start('uses-sdk',[(android,'minSdkVersion',min_sdk,0x10),(android,'targetSdkVersion',28,0x10)]);end('uses-sdk')
    app_attrs=[(android,'label','Rift Native Demo',3)]
    if with_providers:app_attrs.append((android,'name','org.kyvex.extra.ProviderChecks$App',3))
    start('application',app_attrs)
    if with_metadata:
        for key,value,kind in [('fixture.text','metadata',3),('fixture.number',17,0x10),('fixture.flag',1,0x12),('fixture.float',0x3fc00000,4)]:
            start('meta-data',[(android,'name',key,3),(android,'value',value,kind)]);end('meta-data')
        start('meta-data',[(android,'name','fixture.resource',3),(android,'resource',0x7f010001,1)]);end('meta-data')
    if with_providers:
        for name,order,enabled,process in [('Late',10,1,''),('Disabled',200,0,''),('Remote',300,1,':aux'),('Early',100,1,'')]:
            attrs=[(android,'name','org.kyvex.extra.ProviderChecks$'+name,3),(android,'authorities','org.kyvex.nativehello.'+name.lower(),3),(android,'initOrder',order,0x10),(android,'enabled',enabled,0x12),(android,'exported',0,0x12)]
            if process:attrs.append((android,'process',process,3))
            if name=='Early':attrs.extend([(android,'readPermission','org.kyvex.nativehello.READ',3),(android,'directBootAware',1,0x12),(android,'grantUriPermissions',1,0x12)])
            start('provider',attrs)
            if name=='Early':start('meta-data',[(android,'name','provider.marker',3),(android,'value',11,0x10)]);end('meta-data')
            if name=='Early' and provider_xml:
                start('meta-data',[(android,'name','provider.paths',3),(android,'resource',provider_xml,1)])
                end('meta-data')
            end('provider')
    if with_services:
        for name,enabled in [('MetadataService',1),('DisabledService',0)]:
            start('service',[(android,'name','org.kyvex.extra.ProviderChecks$'+name,3),(android,'enabled',enabled,0x12),(android,'exported',0,0x12),(android,'process',':metadata',3),(android,'permission','org.kyvex.nativehello.SERVICE',3)])
            start('meta-data',[(android,'name','service.marker',3),(android,'value',7,0x10)]);end('meta-data')
            start('meta-data',[(android,'name','fixture.registrar',3),(android,'value','org.kyvex.extra.RealRegistrar',3)]);end('meta-data')
            end('service')
    start('activity',[(android,'name','org.kyvex.nativehello.MainActivity',3),(android,'exported',1,0x12)])
    if with_metadata:
        start('meta-data',[(android,'name','activity.only',3),(android,'value','excluded',3)]);end('meta-data')
    start('intent-filter');start('action',[(android,'name','android.intent.action.MAIN',3)]);end('action');start('category',[(android,'name','android.intent.category.LAUNCHER',3)]);end('category');end('intent-filter');end('activity');end('application');end('manifest')
    data=bytearray();offsets=[]
    def length(n):return bytes([n]) if n<128 else bytes([0x80|(n>>8),n&255])
    for value in strings:
        b=value.encode();offsets.append(len(data));data+=length(len(value.encode('utf-16le'))//2)+length(len(b))+b+b'\0'
    while len(data)%4:data+=b'\0'
    pool=struct.pack('<HHIIIIII',1,28,28+len(offsets)*4+len(data),len(strings),0,256,28+len(offsets)*4,0)+struct.pack('<'+'I'*len(offsets),*offsets)+data
    ids={'versionCode':0x0101021b,'versionName':0x0101021c,'minSdkVersion':0x0101020c,'targetSdkVersion':0x01010270,'label':0x01010001,'name':0x01010003,'exported':0x01010010,'value':0x01010024,'resource':0x01010025,'authorities':0x01010018,'initOrder':0x0101001a,'enabled':0x0101000e,'process':0x01010011,'readPermission':0x01010007,'directBootAware':0x01010505}
    ids['permission']=0x01010006
    ids['grantUriPermissions']=0x0101001b
    resource_map=struct.pack('<HHI',0x180,8,8+len(strings)*4)+b''.join(struct.pack('<I',ids.get(v,0)) for v in strings)
    ns=struct.pack('<HHIIIII',0x100,16,24,1,0xffffffff,s('android'),s(android));ns_end=struct.pack('<HHIIIII',0x101,16,24,1,0xffffffff,s('android'),s(android))
    body=pool+resource_map+ns+b''.join(nodes)+ns_end
    return struct.pack('<HHI',3,8,len(body)+8)+body
