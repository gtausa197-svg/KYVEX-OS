package android.content;

/** Compile-only declaration, excluded from the guest DEX. */
public abstract class ContentResolver {}
