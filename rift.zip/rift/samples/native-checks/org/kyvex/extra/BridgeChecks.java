package org.kyvex.extra;
import android.content.Context;
import android.content.pm.*;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Pattern;

/** Four requested API gaps, verified by actual DEX reads, callbacks and reflection. */
public final class BridgeChecks {
    private static int checks,ran;
    private static class Parent {public int inherited;}
    private static final class Fields extends Parent {
        private int count=7;
        public String label="before";
        private static long marker=0x1122334455667788L;
    }
    private static final class ChildThread extends Thread {}
    public abstract static class AbstractTarget {public AbstractTarget(){}}
    private enum Choice {ONE}
    private static final class PhoneListener extends android.telephony.PhoneStateListener {
        int notifications;
        @Override public void onCallStateChanged(int state,String number){notifications++;}
    }
    private static final class Arguments {
        int number;String label;
        public Arguments(int number,String label){if(number<0)throw new IllegalArgumentException("negative");this.number=number;this.label=label;}
    }
    private static void check(boolean value,String label){if(!value)throw new IllegalStateException(label);checks++;}
    public static int verify(Context context) {
        checks=0;
        try {
            PackageManager manager=context.getPackageManager();
            check(manager!=null&&manager==context.getPackageManager(),"stable PackageManager");
            ApplicationInfo info=context.getApplicationInfo();
            check(info!=null&&info==context.getApplicationInfo(),"stable ApplicationInfo");
            check(info.dataDir.equals("/data/user/0/"+context.getPackageName())&&new File(info.dataDir).isDirectory(),"actual private dataDir");
            check(new File(info.dataDir,"files").getPath().equals(context.getFilesDir().getPath()),"Context and ApplicationInfo agree");
            PackageInfo pkg=manager.getPackageInfo(context.getPackageName(),0);
            check(pkg.packageName.equals(context.getPackageName())&&pkg.versionCode==2&&"0.2".equals(pkg.versionName),"real manifest version");
            check(pkg.getLongVersionCode()==2&&pkg.applicationInfo.dataDir.equals(info.dataDir),"PackageInfo metadata");
            check(manager.getApplicationInfo(context.getPackageName(),0).targetSdkVersion==28&&info.minSdkVersion==23,"manifest SDK values");
            boolean missing=false;try{manager.getPackageInfo("org.kyvex.not_installed",0);}catch(PackageManager.NameNotFoundException expected){missing=true;}check(missing,"unknown packages are not fabricated");
            ApplicationInfo blank=new ApplicationInfo();check(blank.dataDir==null,"ApplicationInfo constructor defaults");
            Field dataDir=ApplicationInfo.class.getDeclaredField("dataDir");
            check(dataDir.getType()==String.class&&Modifier.isPublic(dataDir.getModifiers())&&info.dataDir.equals(dataDir.get(info)),"public native field metadata and read");
            dataDir.set(blank,info.dataDir);check(info.dataDir.equals(blank.dataDir),"reflected write visible to DEX");
            Thread main=Thread.currentThread();Thread first=new Thread(),second=new ChildThread();
            check(!first.isAlive()&&!second.isAlive()&&first.getId()!=second.getId()&&first.getId()!=main.getId(),"unstarted Thread identities");
            check(first.getName().startsWith("Thread-")&&!first.getName().equals(second.getName()),"generated names and subclass constructor");
            first.setName("worker");first.setDaemon(true);first.setPriority(7);check("worker".equals(first.getName())&&first.isDaemon()&&first.getPriority()==7,"Thread metadata setters");
            check(new Thread().getPriority()==main.getPriority()&&first instanceof Runnable,"priority inheritance and Runnable type");
            Thread direct=new Thread(new Runnable(){public void run(){ran++;if(Thread.currentThread()!=main)throw new IllegalStateException("direct run changed current thread");}});
            check(ran==0&&!direct.isAlive(),"Thread constructor does not execute target");direct.run();check(ran==1&&!direct.isAlive(),"direct Runnable execution is synchronous");
            Fields value=new Fields();Field count=Fields.class.getDeclaredField("count");
            boolean denied=false;try{count.get(value);}catch(IllegalAccessException expected){denied=true;}check(denied,"private field access is checked");
            count.setAccessible(true);check(count.isAccessible()&&count.getInt(value)==7&&count.getDeclaringClass()==Fields.class,"private reflected field metadata");
            count.setInt(value,44);check(((Integer)count.get(value)).intValue()==44&&value.count==44,"actual private field storage");
            Field label=Fields.class.getDeclaredField("label");label.set(value,"after");check("after".equals(value.label),"reference field mutation");
            Field marker=Fields.class.getDeclaredField("marker");marker.setAccessible(true);check(Modifier.isStatic(marker.getModifiers())&&marker.getLong(null)==0x1122334455667788L,"static field flags after lazy DEX merge");
            missing=false;try{Fields.class.getDeclaredField("inherited");}catch(NoSuchFieldException expected){missing=true;}check(missing,"getDeclaredField does not search parents");
            Field mutex=Collections.synchronizedCollection(new ArrayList<Object>()).getClass().getDeclaredField("mutex");
            Collection<Object> wrapper=Collections.synchronizedCollection(new ArrayList<Object>());mutex.setAccessible(true);check(mutex.get(wrapper)==wrapper,"synchronized wrapper mutex is real");
            Field backing=wrapper.getClass().getDeclaredField("c");backing.setAccessible(true);check(backing.get(wrapper) instanceof Collection,"synchronized wrapper backing collection");
            String[] parts="a,,b,,".split(",");check(parts.length==3&&"".equals(parts[1])&&"b".equals(parts[2]),"split trailing empties");
            check("a,,b,,".split(",",-1).length==5,"split negative limit");
            parts="a,,b,,".split(",",2);check(parts.length==2&&",b,,".equals(parts[1]),"split positive limit");
            check(",a".split(",").length==2&&"".equals(",a".split(",")[0]),"split leading empty");
            parts="\ud83d\ude00x".split("");check(parts.length==3&&parts[0].length()==1&&parts[0].charAt(0)=='\ud83d'&&parts[1].charAt(0)=='\ude00',"split empty pattern uses UTF16 units");
            check(Pattern.compile("::").split("a::b::").length==2,"Pattern split shares limits");
            check("".split(",").length==1&&"abc".split("/")[0].equals("abc"),"split empty and no match");
            CountDownLatch latch=new CountDownLatch(2);check(latch.getCount()==2&&!latch.await(0,TimeUnit.MILLISECONDS),"latch initial count and zero timeout");
            latch.countDown();check(latch.getCount()==1,"latch countDown");latch.countDown();latch.countDown();latch.await();check(latch.getCount()==0&&latch.await(0,TimeUnit.MILLISECONDS),"latch terminal zero");
            boolean invalid=false;try{new CountDownLatch(-1);}catch(IllegalArgumentException expected){invalid=true;}check(invalid,"negative latch count rejected");
            android.os.Bundle meta=manager.getApplicationInfo(context.getPackageName(),128).metaData;
            check(meta!=null&&"metadata".equals(meta.getString("fixture.text")),"manifest string metadata");
            check(meta.getInt("fixture.number")==17,"manifest integer metadata");
            check(meta.getBoolean("fixture.flag"),"manifest boolean metadata");
            check(meta.getFloat("fixture.float")==1.5f,"manifest float metadata");
            check(meta.getInt("fixture.resource")==0x7f010001,"resource attribute is an identifier");
            check(!meta.containsKey("activity.only")&&manager.getApplicationInfo(context.getPackageName(),0).metaData==null&&manager.getPackageInfo(context.getPackageName(),0).applicationInfo.metaData==null,"metadata scope and GET_META_DATA flag");
            Constructor<Fields> zero=Fields.class.getDeclaredConstructor();zero.setAccessible(true);check(zero.newInstance().count==7&&zero.getDeclaringClass()==Fields.class,"real declared constructor invocation");
            Constructor<Arguments> args=Arguments.class.getDeclaredConstructor(Integer.TYPE,String.class);Arguments created=args.newInstance(Integer.valueOf(9),"created");check(created.number==9&&"created".equals(created.label)&&args.getParameterTypes()[0]==Integer.TYPE,"boxed constructor parameters");
            boolean wrapped=false;try{args.newInstance(Integer.valueOf(-1),"bad");}catch(InvocationTargetException expected){wrapped=expected.getCause() instanceof IllegalArgumentException;}check(wrapped,"constructor exceptions retain their cause");
            Constructor<?> factory=wrapper.getClass().getDeclaredConstructor(Collection.class,Object.class);factory.setAccessible(true);ArrayList<Object> real=new ArrayList<Object>();Object lock=new Object();Collection<?> custom=(Collection<?>)factory.newInstance(real,lock);real.add("shared");check(mutex.get(custom)==lock&&custom.size()==1,"native synchronized constructor retains target and mutex");
            boolean rejected=false;try{AbstractTarget.class.getDeclaredConstructor().newInstance();}catch(InstantiationException expected){rejected=true;}check(rejected,"abstract construction is rejected");
            Constructor<Choice> choice=Choice.class.getDeclaredConstructor(String.class,Integer.TYPE);choice.setAccessible(true);rejected=false;try{choice.newInstance("copy",Integer.valueOf(2));}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"enum construction is rejected");
            check("metadata".contentEquals(new StringBuilder("metadata"))&&!"metadata".contentEquals("other"),"contentEquals uses CharSequence units");
            UUID uuid=UUID.randomUUID();check(uuid.version()==4&&uuid.variant()==2,"OS-random UUID v4 layout");
            check(uuid.toString().length()==36&&uuid.toString().charAt(14)=='4'&&!uuid.equals(UUID.randomUUID()),"UUID representation and distinct entropy");
            UUID same=new UUID(uuid.getMostSignificantBits(),uuid.getLeastSignificantBits());check(same.equals(uuid)&&same.hashCode()==uuid.hashCode()&&UUID.fromString(uuid.toString()).equals(uuid),"UUID bits and parse round trip");
            HashMap<UUID,String> uuidMap=new HashMap<UUID,String>();uuidMap.put(uuid,"shared");check("shared".equals(uuidMap.get(same)),"UUID equality in collections");
            UUID timed=UUID.fromString("00000001-0002-1003-8004-000000000005");check(timed.version()==1&&timed.timestamp()==((3L<<48)|(2L<<32)|1)&&timed.clockSequence()==4&&timed.node()==5,"UUID time fields");
            android.util.SparseIntArray sparse=new android.util.SparseIntArray(0);sparse.put(8,80);sparse.put(-2,-20);sparse.append(3,30);check(sparse.size()==3&&sparse.keyAt(0)==-2&&sparse.keyAt(1)==3&&sparse.valueAt(2)==80,"sorted sparse integer keys");
            check(sparse.get(42,99)==99&&sparse.indexOfKey(4)==~2&&sparse.indexOfValue(30)==1,"sparse search and fallback");
            android.util.SparseIntArray copy=sparse.clone();copy.setValueAt(0,-21);copy.delete(8);check(copy.size()==2&&sparse.size()==3&&sparse.get(-2)==-20,"sparse clone isolation");
            copy.clear();check(copy.size()==0&&copy.get(8)==0,"sparse clear");
            check(android.os.Process.myPid()==1&&android.os.Process.myTid()==Thread.currentThread().getId()&&android.os.Process.myUid()==10000,"guest identity is consistent");
            PhoneListener phone=new PhoneListener();check(phone instanceof android.telephony.PhoneStateListener&&phone.notifications==0,"listener construction creates no fake phone events");
            ThreadLocal<Object> local=new ThreadLocal<Object>();check(local.get()==null,"ThreadLocal default initial value");
            Object stored=new Object();local.set(stored);check(local.get()==stored,"ThreadLocal stores actual object");
            local.remove();check(local.get()==null,"ThreadLocal remove resets value");
            final int[] initializations=new int[1];ThreadLocal<Object> initialized=new ThreadLocal<Object>(){protected Object initialValue(){initializations[0]++;return new Object();}};
            Object initial=initialized.get();check(initial==initialized.get()&&initializations[0]==1,"actual initialValue callback once");
            initialized.set(null);check(initialized.get()==null&&initializations[0]==1,"explicit null remains initialized");
            initialized.remove();check(initialized.get()!=initial&&initializations[0]==2,"remove invokes initialValue again");
            boolean caughtMessage=false;try{Class.forName("missing.rift.NoSuchClass");}catch(ClassNotFoundException expected){caughtMessage="missing.rift.NoSuchClass".equals(expected.getMessage());}check(caughtMessage,"caught VM fault retains message");
            IllegalArgumentException cause=new IllegalArgumentException("bad input");check("bad input".equals(cause.getMessage())&&"java.lang.IllegalArgumentException: bad input".equals(cause.toString()),"Throwable string and message");
            RuntimeException outer=new RuntimeException("outer",cause);check(outer.getCause()==cause&&"outer".equals(outer.getLocalizedMessage()),"constructor retains cause");
            Throwable chain=new Throwable();check(chain.initCause(cause)==chain&&chain.getCause()==cause,"initCause retains actual cause");
            rejected=false;try{chain.initCause(null);}catch(IllegalStateException expected){rejected=true;}check(rejected,"cause cannot be overwritten");
            Throwable self=new Throwable();rejected=false;try{self.initCause(self);}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"self cause rejected");
            String plain="plain";check("x".equals(" \t\r\nx\0 ".trim())&&plain.trim()==plain&&"\u00a0".equals("\u00a0".trim()),"trim follows Java UTF16 control-space rules");
            check(Boolean.parseBoolean("TrUe")&&!Boolean.parseBoolean(null)&&!Boolean.parseBoolean(" true")&&Boolean.valueOf("TRUE")==Boolean.TRUE,"Boolean string parsing");
            android.app.ActivityManager activity=(android.app.ActivityManager)context.getSystemService("activity");check(activity!=null&&activity==context.getSystemService("activity"),"guest ActivityManager identity");
            android.app.ActivityManager.RunningAppProcessInfo process=activity.getRunningAppProcesses().get(0);check(process.pid==android.os.Process.myPid()&&process.uid==android.os.Process.myUid()&&context.getPackageName().equals(process.processName)&&process.pkgList.length==1,"actual isolated guest process registry");
            process.processName="changed";check(context.getPackageName().equals(activity.getRunningAppProcesses().get(0).processName),"process snapshots do not mutate registry");
            android.app.ActivityManager.RunningAppProcessInfo current=new android.app.ActivityManager.RunningAppProcessInfo();android.app.ActivityManager.getMyMemoryState(current);check(current.pid==android.os.Process.myPid()&&current.importance==100,"current guest process state");
            check(context.getSystemService("not-a-service")==null&&context.getSystemService("phone")==null,"unavailable guest services do not fabricate hardware");
            android.content.ComponentName component=new android.content.ComponentName(context,Fields.class);check(context.getPackageName().equals(component.getPackageName())&&Fields.class.getName().equals(component.getClassName()),"ComponentName Context and Class constructor");
            android.os.Bundle bundle=new android.os.Bundle();bundle.putInt("first",1);Set<String> keys=bundle.keySet();bundle.putString("second","two");check(keys.size()==2&&keys.contains("second"),"Bundle keySet is backed by actual entries");
            Iterator<String> keyIterator=keys.iterator();String removed=keyIterator.next();keyIterator.remove();check(!bundle.containsKey(removed)&&bundle.size()==1,"Bundle key iterator removal changes Bundle");
            keys.clear();bundle.putString("second","two");
            rejected=false;try{keys.add("unsupported");}catch(UnsupportedOperationException expected){rejected=true;}check(rejected,"Bundle keySet cannot add valueless keys");
            keyIterator=keys.iterator();bundle.putInt("third",3);rejected=false;try{keyIterator.next();}catch(ConcurrentModificationException expected){rejected=true;}check(rejected,"Bundle structural edits invalidate old iterators");
            android.os.Bundle merged=new android.os.Bundle();merged.putAll(bundle);check(((Integer)merged.get("third")).intValue()==3&&"two".equals(merged.get("second")),"Bundle putAll preserves typed values and get boxes scalars");
            merged.keySet().clear();bundle.putString(null,"nullable");check(merged.size()==0&&bundle.size()==3&&keys.contains(null),"Bundle key view clear and null keys");
            HashSet<String> sourceSet=new HashSet<String>();check(Collections.addAll(sourceSet,"a","b","a")&&!Collections.addAll(sourceSet,"a")&&sourceSet.size()==2,"Collections.addAll executes every add and reports actual changes");
            Set<String> readOnlySet=Collections.unmodifiableSet(sourceSet);sourceSet.add("later");check(readOnlySet.size()==3&&readOnlySet.contains("later"),"unmodifiable set remains a live view");
            rejected=false;try{readOnlySet.add("blocked");}catch(UnsupportedOperationException expected){rejected=true;}check(rejected&&!sourceSet.contains("blocked"),"read-only set rejects mutation");
            Iterator<String> readOnlyIterator=readOnlySet.iterator();readOnlyIterator.next();rejected=false;try{readOnlyIterator.remove();}catch(UnsupportedOperationException expected){rejected=true;}check(rejected&&sourceSet.size()==3,"read-only iterator cannot mutate backing set");
            ArrayList<String> sourceList=new ArrayList<String>();sourceList.add("one");List<String> readOnlyList=Collections.unmodifiableList(sourceList);sourceList.add("two");rejected=false;try{readOnlyList.set(0,"blocked");}catch(UnsupportedOperationException expected){rejected=true;}check(rejected&&"two".equals(readOnlyList.get(1))&&"one".equals(sourceList.get(0)),"unmodifiable list reads live contents and blocks set");
            HashMap<String,String> sourceMap=new HashMap<String,String>();sourceMap.put("key","before");Map<String,String> readOnlyMap=Collections.unmodifiableMap(sourceMap);sourceMap.put("key","actual");rejected=false;try{readOnlyMap.entrySet().iterator().next().setValue("blocked");}catch(UnsupportedOperationException expected){rejected=true;}check(rejected&&"actual".equals(readOnlyMap.get("key")),"unmodifiable map protects entry setValue");
            int blocked=0;try{((Map.Entry<String,String>)readOnlyMap.entrySet().toArray()[0]).setValue("blocked");}catch(UnsupportedOperationException expected){blocked++;}try{readOnlyMap.keySet().clear();}catch(UnsupportedOperationException expected){blocked++;}Iterator<String> valueIterator=readOnlyMap.values().iterator();valueIterator.next();try{valueIterator.remove();}catch(UnsupportedOperationException expected){blocked++;}check(blocked==3&&sourceMap.size()==1&&"actual".equals(sourceMap.get("key")),"all map views preserve read-only boundary");
            Collections.unmodifiableSet(sourceMap.entrySet()).iterator().next().setValue("entry is mutable");check("entry is mutable".equals(sourceMap.get("key")),"unmodifiableSet does not freeze its element objects");
            Map.Entry<String,String>[] entryArray=new Map.Entry[3];entryArray[2]=sourceMap.entrySet().iterator().next();readOnlyMap.entrySet().toArray(entryArray);entryArray[2].setValue("tail remains mutable");check(entryArray[1]==null&&"tail remains mutable".equals(sourceMap.get("key")),"read-only toArray leaves unrelated tail elements untouched");
            String searched="A\ud83d\ude00B\ud83d\ude00C";check(searched.indexOf("\ud83d\ude00")==1&&searched.indexOf("\ud83d\ude00",2)==4&&searched.lastIndexOf("\ud83d\ude00")==4&&searched.lastIndexOf("\ud83d\ude00",3)==1,"string search reports UTF16 offsets");
            check(searched.indexOf(0x1f600)==1&&searched.indexOf(0x1f600,2)==4&&searched.lastIndexOf(0x1f600,3)==1&&searched.indexOf(0xde00)==2,"code point and surrogate searches");
            check(searched.indexOf("",Integer.MAX_VALUE)==7&&searched.indexOf("",Integer.MIN_VALUE)==0&&searched.lastIndexOf("",-1)==-1&&searched.lastIndexOf("",Integer.MAX_VALUE)==7,"empty search and extreme offsets");
            check("ababa".lastIndexOf("aba",1)==0&&"ababa".lastIndexOf("aba")==2&&searched.indexOf(-1)==-1&&searched.indexOf(0x110000)==-1,"overlapping search and invalid code points");
            check(searched.startsWith("B",3)&&!searched.startsWith("",8)&&!searched.startsWith("A",-1)&&searched.contains(new StringBuilder("\ud83d\ude00B")),"offset prefix and CharSequence contains");
            rejected=false;try{searched.indexOf((String)null,0);}catch(NullPointerException expected){rejected=true;}check(rejected,"null search needle throws Java exception");
            check(Parent.class.isAssignableFrom(Fields.class)&&!Fields.class.isAssignableFrom(Parent.class)&&Collection.class.isAssignableFrom(ArrayList.class),"class assignability uses actual superclass and interfaces");
            check(Object[].class.isAssignableFrom(String[].class)&&!Object[].class.isAssignableFrom(int[].class)&&Object[].class.isAssignableFrom(int[][].class)&&java.io.Serializable.class.isAssignableFrom(int[].class),"array covariance and primitive array rules");
            check(int.class.isAssignableFrom(int.class)&&!long.class.isAssignableFrom(int.class)&&!Object.class.isAssignableFrom(int.class)&&!int.class.isInstance(Integer.valueOf(1)),"primitive Class identity does not widen or box");
            check(CharSequence.class.isInstance("actual")&&!CharSequence.class.isInstance(Integer.valueOf(1))&&!Object.class.isInstance(null),"Class.isInstance reads actual object types");
            check(activity==context.getSystemService(android.app.ActivityManager.class)&&"activity".equals(context.getSystemServiceName(android.app.ActivityManager.class)),"class and string service lookups share one registry");
            check(context.getSystemService(String.class)==null&&context.getSystemServiceName(String.class)==null,"unknown service Class has no fabricated instance");
            rejected=false;try{context.getSystemService((Class<?>)null);}catch(NullPointerException expected){rejected=true;}check(rejected,"null service Class rejected");
            String[] arrayBacking={"one","two"};List<String> arrayList=Arrays.asList(arrayBacking);arrayBacking[0]="external";check("external".equals(arrayList.get(0))&&arrayList instanceof RandomAccess,"Arrays.asList is a live array view");
            check("two".equals(arrayList.set(1,"internal"))&&"internal".equals(arrayBacking[1]),"array list set updates original array");
            Iterator<String> arrayIterator=arrayList.iterator();arrayBacking[0]="visible";check("visible".equals(arrayIterator.next()),"array list iterator reads current backing array");
            blocked=0;try{arrayList.add("blocked");}catch(UnsupportedOperationException expected){blocked++;}try{arrayIterator.remove();}catch(UnsupportedOperationException expected){blocked++;}try{((List)arrayList).set(0,Integer.valueOf(1));}catch(ArrayStoreException expected){blocked++;}check(blocked==3&&arrayBacking.length==2&&"visible".equals(arrayBacking[0]),"array list rejects size changes and enforces array component type");
            check(!arrayList.remove("missing")&&!arrayList.addAll(Collections.<String>emptyList())&&Arrays.asList().isEmpty(),"fixed-size list permits operations which do not resize it");
            Object[] detached=arrayList.toArray();detached[0]="detached";check("visible".equals(arrayList.get(0)),"array view toArray returns an independent copy");
            android.os.UserManager user=context.getSystemService(android.os.UserManager.class);check(user!=null&&user==context.getSystemService("user")&&user.isUserUnlocked(),"guest user storage is accessible and has no credential lock");
            check("xx$1xx".equals("xx..xx".replace(new StringBuilder(".."),new StringBuilder("$1")))&&"bbbbb".equals("aaaaa".replace('a','b')),"literal replacement executes CharSequence inputs without regex substitution");
            check("-\ud83d-\ude00-".equals("\ud83d\ude00".replace("","-"))&&"bbba".equals("aaaaaaa".replace("aa","b")),"replacement handles UTF16 boundaries and non-overlapping matches");
            String unchangedText="unchanged";rejected=false;try{unchangedText.replace((CharSequence)null,"x");}catch(NullPointerException expected){rejected=true;}check(rejected&&unchangedText.replace("missing","value")==unchangedText,"null replacement input and unchanged result identity");
            check(Collections.EMPTY_LIST==Collections.emptyList()&&Collections.EMPTY_SET==Collections.emptySet()&&Collections.EMPTY_MAP==Collections.emptyMap(),"empty collection constants and factories share their instances");
            check(Fields.class.equals(Fields.class)&&!Fields.class.equals(Parent.class)&&!Fields.class.equals(null)&&Fields.class.hashCode()==System.identityHashCode(Fields.class),"Class inherits Object identity equality and hash code");
            check(Fields.class.getSuperclass()==Parent.class&&Parent.class.getSuperclass()==Object.class&&String[].class.getSuperclass()==Object.class&&int[].class.getSuperclass()==Object.class&&Context.class.getSuperclass()==Object.class,"Class superclass uses DEX declarations and native/array rules");
            check(Collection.class.isInterface()&&Collection.class.getSuperclass()==null&&!Fields.class.isInterface()&&int.class.getSuperclass()==null&&Object.class.getSuperclass()==null,"interfaces primitives and Object have no superclass");
            android.content.SharedPreferences hierarchyPrefs=context.getSharedPreferences("hierarchy",0);check(hierarchyPrefs.getClass().getSuperclass()==Object.class&&android.content.SharedPreferences.class.isInstance(hierarchyPrefs)&&android.content.SharedPreferences.Editor.class.isInstance(hierarchyPrefs.edit()),"native preferences implementation exposes its actual superclass and interfaces");
            return checks;
        } catch(Exception error){throw new IllegalStateException("Bridge check failed: "+error.getMessage());}
    }
}
