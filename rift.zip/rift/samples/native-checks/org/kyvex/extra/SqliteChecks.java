package org.kyvex.extra;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;
/** Actual callbacks, SQL, migrations, cursors and private SQLite images. */
public final class SqliteChecks {
 private static int checks,created,upgraded,configured,opened;
 private static boolean failUpgrade;
 private static StringBuilder order;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 public static final class Helper extends SQLiteOpenHelper {
  Helper(Context context,String name,int version){super(context,name,null,version);}
  public void onConfigure(SQLiteDatabase db){configured++;order.append('g');db.setForeignKeyConstraintsEnabled(true);Cursor c=db.rawQuery("PRAGMA busy_timeout=0",new String[0]);check(c.moveToFirst()&&c.getInt(0)==0,"Real connection configuration query");c.close();}
  public void onCreate(SQLiteDatabase db){created++;order.append('c');
   boolean recursive=false;try{getWritableDatabase();}catch(IllegalStateException expected){recursive=true;}check(recursive,"Recursive helper open rejected");
   db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY, number INTEGER, fraction REAL, text TEXT, bytes BLOB, missing)");
   db.execSQL("CREATE TABLE children(parent INTEGER REFERENCES events(id))");
   db.execSQL("INSERT INTO events VALUES(1,?,?,?,?,NULL)",new Object[]{Long.MAX_VALUE,1.25,"a\u0000\u043a\ud83d\ude00",new byte[]{0,(byte)255,3}});
   System.gc();
  }
  public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){upgraded++;order.append('u');if(newVersion==2)db.execSQL("ALTER TABLE events ADD COLUMN extra INTEGER DEFAULT 7");if(failUpgrade){db.execSQL("INSERT INTO children VALUES(1)");throw new IllegalStateException("Expected migration failure");}}
  public void onOpen(SQLiteDatabase db){opened++;order.append('o');}
 }
 private static long count(SQLiteDatabase db,String table){Cursor c=db.rawQuery("SELECT count(*) FROM "+table,null);if(!c.moveToFirst())throw new IllegalStateException("Missing count row");long result=c.getLong(0);c.close();return result;}
 public static int verify(Context context){checks=created=upgraded=configured=opened=0;failUpgrade=false;order=new StringBuilder();
  Helper helper=new Helper(context,"native-fixture.db",1);
  check(created==0&&configured==0&&!context.getDatabasePath("native-fixture.db").exists(),"Constructor does not open the database");
  check("native-fixture.db".equals(helper.getDatabaseName()),"Actual helper name");
  SQLiteDatabase db=helper.getWritableDatabase();
  check(db==helper.getReadableDatabase()&&db==helper.getWritableDatabase(),"Cached actual database object");
  check(created==1&&configured==1&&opened==1&&"gco".equals(order.toString()),"Configure-create-open order");
  check(db.isOpen()&&!db.isReadOnly()&&db.getVersion()==1,"Open state and stored version");
  Cursor clock=db.rawQuery("SELECT CAST(strftime('%s','now') AS INTEGER)",null);long now=System.currentTimeMillis()/1000;check(clock.moveToFirst()&&clock.getLong(0)>=now-10&&clock.getLong(0)<=now+10,"Real SQL clock under worker containment");clock.close();
  check(db.getPath().equals(context.getDatabasePath("native-fixture.db").getPath())&&context.getDatabasePath("native-fixture.db").length()>0,"Real SQLite private image");
  Cursor cursor=db.rawQuery("SELECT * FROM events WHERE id=?",new String[]{"1"});
  check(cursor.getCount()==1&&cursor.getColumnCount()==6&&cursor.isBeforeFirst()&&!cursor.isAfterLast(),"Query and initial cursor");
  boolean rejected=false;try{cursor.getString(0);}catch(IndexOutOfBoundsException expected){rejected=true;}check(rejected,"Getters require valid position");
  check(cursor.moveToFirst()&&cursor.isFirst()&&cursor.isLast()&&cursor.getPosition()==0,"First row movement");
  check(cursor.getType(1)==Cursor.FIELD_TYPE_INTEGER&&cursor.getLong(1)==Long.MAX_VALUE,"Exact 64-bit value");
  check(cursor.getType(2)==Cursor.FIELD_TYPE_FLOAT&&cursor.getDouble(2)==1.25&&cursor.getFloat(2)==1.25f,"Floating column");
  check(cursor.getType(3)==Cursor.FIELD_TYPE_STRING&&"a\u0000\u043a\ud83d\ude00".equals(cursor.getString(3)),"Text including NUL and Unicode");
  byte[] blob=cursor.getBlob(4);blob[0]=9;check(cursor.getType(4)==Cursor.FIELD_TYPE_BLOB&&blob[1]==(byte)255&&cursor.getBlob(4)[0]==0,"BLOB ownership");
  check(cursor.isNull(5)&&cursor.getType(5)==Cursor.FIELD_TYPE_NULL&&cursor.getString(5)==null&&cursor.getLong(5)==0,"Null getters");
  check(cursor.getColumnIndex("events.TEXT")==3&&cursor.getColumnIndex("missing-column")==-1&&"number".equals(cursor.getColumnName(1)),"Column lookup");
  rejected=false;try{cursor.getColumnIndexOrThrow("absent");}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"Missing column failure");
  String[] names=cursor.getColumnNames();names[0]="changed";check("id".equals(cursor.getColumnName(0)),"Column name copy");
  check(!cursor.moveToNext()&&cursor.isAfterLast()&&cursor.getPosition()==1&&cursor.moveToPrevious(),"End and reverse movement");
  cursor.close();check(cursor.isClosed()&&cursor.getClass()!=null,"Closed Object behavior");
  rejected=false;try{cursor.moveToFirst();}catch(IllegalStateException expected){rejected=true;}check(rejected,"Closed cursor rejects reads");
  rejected=false;try{db.execSQL("INSERT INTO children VALUES(999)");}catch(SQLiteConstraintException expected){rejected=true;}check(rejected&&count(db,"children")==0,"Foreign key failure");
  db.beginTransaction();db.execSQL("INSERT INTO children VALUES(1)");check(db.inTransaction()&&count(db,"children")==1,"Transaction sees writes");db.endTransaction();
  check(!db.inTransaction()&&count(db,"children")==0,"Actual rollback");
  db.beginTransactionNonExclusive();db.execSQL("INSERT INTO children VALUES(1)");db.setTransactionSuccessful();db.endTransaction();check(count(db,"children")==1,"Actual commit");
  db.beginTransaction();db.beginTransaction();db.execSQL("INSERT INTO children VALUES(1)");db.endTransaction();db.setTransactionSuccessful();db.endTransaction();check(count(db,"children")==1,"Failed child poisons parent");
  db.execSQL("CREATE TABLE deferred_child(parent INTEGER REFERENCES events(id) DEFERRABLE INITIALLY DEFERRED)");db.beginTransaction();db.execSQL("INSERT INTO deferred_child VALUES(999)");db.setTransactionSuccessful();rejected=false;try{db.endTransaction();}catch(SQLiteConstraintException expected){rejected=true;}check(rejected&&!db.inTransaction()&&count(db,"deferred_child")==0,"Commit failure rolls back and releases transaction state");
  rejected=false;try{db.setTransactionSuccessful();}catch(IllegalStateException expected){rejected=true;}check(rejected,"Transaction required for marker");
  rejected=false;try{db.execSQL("ATTACH DATABASE '/tmp/host.db' AS host");}catch(SQLiteException expected){rejected=true;}check(rejected,"Host files cannot be attached");
  rejected=false;try{db.execSQL("CREATE TABLE forbidden(x); INSERT INTO forbidden VALUES(1)");}catch(SQLiteException expected){rejected=true;}check(rejected,"Multiple SQL rejected before mutation");
  for(String sql:new String[]{"PRAGMA foreign_keys=OFF; SELECT 1","SELECT 1; PRAGMA foreign_keys=OFF"}){
   rejected=false;try{db.execSQL(sql);}catch(SQLiteException expected){rejected=true;}
   Cursor state=db.rawQuery("PRAGMA foreign_keys",null);check(rejected&&state.moveToFirst()&&state.getInt(0)==1,"Rejected exec preserves prepare-time connection state");state.close();
   rejected=false;try{db.rawQuery(sql,null);}catch(SQLiteException expected){rejected=true;}
   state=db.rawQuery("PRAGMA foreign_keys",null);check(rejected&&state.moveToFirst()&&state.getInt(0)==1,"Rejected query preserves prepare-time connection state");state.close();
  }
  helper.close();check(!db.isOpen()&&db.getClass()!=null,"Close retains Object identity");
  helper=new Helper(context,"native-fixture.db",2);db=helper.getWritableDatabase();
  check(upgraded==1&&created==1&&db.getVersion()==2&&count(db,"children")==1,"Existing image upgrade");
  cursor=db.rawQuery("SELECT extra FROM events",null);check(cursor.moveToFirst()&&cursor.getInt(0)==7,"Real schema migration");cursor.close();helper.close();
  failUpgrade=true;Helper failed=new Helper(context,"native-fixture.db",3);rejected=false;try{failed.getWritableDatabase();}catch(IllegalStateException expected){rejected=true;}check(rejected,"Migration exception reaches Java");failUpgrade=false;
  helper=new Helper(context,"native-fixture.db",2);db=helper.getReadableDatabase();check(db.getVersion()==2&&count(db,"children")==1,"Failed migration rolled back");helper.close();
  rejected=false;try{new Helper(context,"bad-version.db",0);}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"Invalid version rejected");
  Helper memory=new Helper(null,null,1);SQLiteDatabase anonymous=memory.getWritableDatabase();check(memory.getDatabaseName()==null&&":memory:".equals(anonymous.getPath())&&count(anonymous,"events")==1,"Actual anonymous database");memory.close();
  return checks;
 }
}
