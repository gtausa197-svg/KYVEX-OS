//! Guest-owned standard charsets and bounded String byte conversion.
//! No host locale, JVM objects or replacement-success fallback is involved.
use super::*;
#[derive(Clone, Copy, PartialEq, Eq)]
pub(super) enum Encoding {
    Utf8,
    Latin1,
    Ascii,
    Utf16Be,
    Utf16Le,
    Utf16,
}
impl Encoding {
    pub(super) const ALL: [Self; 6] = [
        Self::Utf8,
        Self::Latin1,
        Self::Ascii,
        Self::Utf16Be,
        Self::Utf16Le,
        Self::Utf16,
    ];
    pub(super) fn name(self) -> &'static str {
        match self {
            Self::Utf8 => "UTF-8",
            Self::Latin1 => "ISO-8859-1",
            Self::Ascii => "US-ASCII",
            Self::Utf16Be => "UTF-16BE",
            Self::Utf16Le => "UTF-16LE",
            Self::Utf16 => "UTF-16",
        }
    }
    fn aliases(self) -> &'static [&'static str] {
        match self {
            Self::Utf8 => &["UTF8", "unicode-1-1-utf-8"],
            Self::Latin1 => &[
                "819",
                "8859_1",
                "IBM-819",
                "IBM819",
                "ISO8859-1",
                "ISO8859_1",
                "ISO_8859-1",
                "ISO_8859-1:1987",
                "ISO_8859_1",
                "cp819",
                "csISOLatin1",
                "iso-ir-100",
                "l1",
                "latin1",
            ],
            Self::Ascii => &[
                "646",
                "ANSI_X3.4-1968",
                "ANSI_X3.4-1986",
                "ASCII",
                "IBM367",
                "ISO646-US",
                "ISO_646.irv:1991",
                "ascii7",
                "cp367",
                "csASCII",
                "default",
                "iso-ir-6",
                "iso_646.irv:1983",
                "us",
            ],
            Self::Utf16Be => &[
                "ISO-10646-UCS-2",
                "UTF_16BE",
                "UnicodeBigUnmarked",
                "X-UTF-16BE",
            ],
            Self::Utf16Le => &["UTF_16LE", "UnicodeLittleUnmarked", "X-UTF-16LE"],
            Self::Utf16 => &["UTF_16", "UnicodeBig", "unicode", "utf16"],
        }
    }
    fn parse(name: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|encoding| {
            encoding.name().eq_ignore_ascii_case(name)
                || encoding
                    .aliases()
                    .iter()
                    .any(|alias| alias.eq_ignore_ascii_case(name))
        })
    }
    pub(super) fn encode(self, units: &[u16]) -> Vec<u8> {
        let mut bytes = Vec::new();
        if self == Self::Utf16 && !units.is_empty() {
            bytes.extend([0xfe, 0xff]);
        }
        for scalar in char::decode_utf16(units.iter().copied()) {
            match self {
                Self::Utf8 => match scalar {
                    Ok(c) => {
                        bytes.extend_from_slice(c.encode_utf8(&mut [0; 4]).as_bytes());
                    }
                    Err(_) => bytes.push(b'?'),
                },
                Self::Latin1 | Self::Ascii => bytes.push(
                    scalar
                        .ok()
                        .filter(|c| (*c as u32) <= if self == Self::Ascii { 127 } else { 255 })
                        .map_or(b'?', |c| c as u8),
                ),
                Self::Utf16Be | Self::Utf16Le | Self::Utf16 => {
                    for word in scalar.unwrap_or('\u{fffd}').encode_utf16(&mut [0; 2]) {
                        bytes.extend(if self == Self::Utf16Le {
                            word.to_le_bytes()
                        } else {
                            word.to_be_bytes()
                        });
                    }
                }
            }
        }
        bytes
    }
    pub(super) fn decode(self, bytes: &[u8]) -> Vec<u16> {
        match self {
            Self::Utf8 => return readers::utf8_units(bytes, true).0,
            Self::Latin1 => return bytes.iter().map(|v| *v as u16).collect(),
            Self::Ascii => {
                return bytes
                    .iter()
                    .map(|v| if *v < 128 { *v as u16 } else { 0xfffd })
                    .collect();
            }
            _ => {}
        }
        let mut at = 0;
        let mut little = self == Self::Utf16Le;
        if self == Self::Utf16 && bytes.len() >= 2 {
            match &bytes[..2] {
                [0xfe, 0xff] => at = 2,
                [0xff, 0xfe] => {
                    at = 2;
                    little = true;
                }
                _ => {}
            }
        }
        let word = |at: usize| {
            if little {
                u16::from_le_bytes([bytes[at], bytes[at + 1]])
            } else {
                u16::from_be_bytes([bytes[at], bytes[at + 1]])
            }
        };
        let mut result = Vec::new();
        while at < bytes.len() {
            if bytes.len() - at < 2 {
                result.push(0xfffd);
                break;
            }
            let first = word(at);
            at += 2;
            if (0xd800..=0xdbff).contains(&first) {
                if bytes.len() - at < 2 {
                    result.push(0xfffd);
                    break;
                }
                let second = word(at);
                at += 2;
                if (0xdc00..=0xdfff).contains(&second) {
                    result.extend([first, second]);
                } else {
                    result.push(0xfffd);
                }
            } else if first == 0xfffe || (0xdc00..=0xdfff).contains(&first) {
                result.push(0xfffd);
            } else {
                result.push(first);
            }
        }
        result
    }
    fn field(name: &str) -> Option<Self> {
        Some(match name {
            "UTF_8" => Self::Utf8,
            "ISO_8859_1" => Self::Latin1,
            "US_ASCII" => Self::Ascii,
            "UTF_16BE" => Self::Utf16Be,
            "UTF_16LE" => Self::Utf16Le,
            "UTF_16" => Self::Utf16,
            _ => return None,
        })
    }
}

fn valid_name(name: &str) -> bool {
    !name.is_empty()
        && name.bytes().enumerate().all(|(i, b)| {
            b.is_ascii_alphanumeric() || i > 0 && matches!(b, b'-' | b'+' | b'.' | b':' | b'_')
        })
}
impl Runtime {
    pub(super) fn charset(&mut self, encoding: Encoding) -> Result<u32> {
        let index = encoding as usize;
        if self.charsets[index] == 0 {
            self.charsets[index] =
                self.allocate("Lorg/kyvex/rift/NativeCharset;", Payload::Charset(encoding))?;
        }
        Ok(self.charsets[index])
    }
    pub(super) fn charset_encoding(&self, id: u32) -> Result<Encoding> {
        let Payload::Charset(encoding) = self.object(id)?.payload else {
            return Err("Expected supported guest Charset".into());
        };
        Ok(encoding)
    }
    pub(super) fn charset_static(&mut self, name: &str, descriptor: &str) -> Result<u64> {
        if descriptor != "Ljava/nio/charset/Charset;" {
            return Err("StandardCharsets field descriptor".into());
        }
        let encoding = Encoding::field(name).ok_or("Unknown StandardCharsets field")?;
        Ok(self.charset(encoding)? as u64)
    }
    fn named_encoding(&self, id: u32, string_api: bool) -> Result<Option<Encoding>> {
        if id == 0 && !string_api {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Null charset name",
            ));
        }
        let name = self.text(id)?;
        if !valid_name(&name) {
            return Err(fault(
                if string_api {
                    "Ljava/io/UnsupportedEncodingException;"
                } else {
                    "Ljava/nio/charset/IllegalCharsetNameException;"
                },
                &name,
            ));
        }
        Ok(Encoding::parse(&name))
    }
    pub(super) fn charset_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Charset signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Charset argument count");
        if class == "Ljava/nio/charset/Charset;" {
            if method == "defaultCharset()Ljava/nio/charset/Charset;" {
                return Ok(Some(self.charset(Encoding::Utf8)? as u64));
            }
            if matches!(
                method,
                "forName(Ljava/lang/String;)Ljava/nio/charset/Charset;"
                    | "isSupported(Ljava/lang/String;)Z"
            ) {
                let encoding = self.named_encoding(arg(0)?, false)?;
                if method.starts_with("isSupported") {
                    return Ok(Some(encoding.is_some() as u64));
                }
                let encoding = encoding.ok_or_else(|| {
                    fault(
                        "Ljava/nio/charset/UnsupportedCharsetException;",
                        "Unsupported charset",
                    )
                })?;
                return Ok(Some(self.charset(encoding)? as u64));
            }
        }
        if class == "Ljava/lang/String;" {
            if matches!(
                method,
                "getBytes()[B"
                    | "getBytes(Ljava/lang/String;)[B"
                    | "getBytes(Ljava/nio/charset/Charset;)[B"
            ) {
                let units = self.units(arg(0)?)?;
                let encoding = if method == "getBytes()[B" {
                    Encoding::Utf8
                } else if method.contains("Ljava/lang/String;") {
                    self.named_encoding(arg(1)?, true)?.ok_or_else(|| {
                        fault(
                            "Ljava/io/UnsupportedEncodingException;",
                            "Unsupported charset",
                        )
                    })?
                } else {
                    self.charset_encoding(arg(1)?)?
                };
                let bytes = encoding.encode(&units);
                if bytes.len() > 16384 {
                    return Err("Encoded byte array quota".into());
                }
                return Ok(Some(self.allocate(
                    "[B",
                    Payload::Array(bytes.into_iter().map(|b| b as i8 as i64 as u64).collect()),
                )? as u64));
            }
            if matches!(
                method,
                "<init>([B)V"
                    | "<init>([BII)V"
                    | "<init>([BLjava/lang/String;)V"
                    | "<init>([BLjava/nio/charset/Charset;)V"
                    | "<init>([BIILjava/lang/String;)V"
                    | "<init>([BIILjava/nio/charset/Charset;)V"
            ) {
                let id = arg(0)?;
                let object = self.object(arg(1)?)?;
                let Payload::Array(array) = &object.payload else {
                    return Err("String byte constructor input".into());
                };
                if object.class != "[B" {
                    return Err("String byte constructor needs byte[]".into());
                }
                let sliced = method.starts_with("<init>([BII");
                let offset = if sliced { arg(2)? as usize } else { 0 };
                let length = if sliced {
                    arg(3)? as usize
                } else {
                    array.len()
                };
                let end = offset
                    .checked_add(length)
                    .filter(|end| *end <= array.len())
                    .ok_or_else(|| {
                        fault(
                            "Ljava/lang/StringIndexOutOfBoundsException;",
                            "Byte constructor range",
                        )
                    })?;
                let bytes: Vec<u8> = array[offset..end].iter().map(|v| *v as u8).collect();
                let encoding = if method.contains("Ljava/nio/charset/Charset;") {
                    self.charset_encoding(arg(if sliced { 4 } else { 2 })?)?
                } else if method.contains("Ljava/lang/String;") {
                    self.named_encoding(arg(if sliced { 4 } else { 2 })?, true)?
                        .ok_or_else(|| {
                            fault(
                                "Ljava/io/UnsupportedEncodingException;",
                                "Unsupported charset",
                            )
                        })?
                } else {
                    Encoding::Utf8
                };
                let units = encoding.decode(&bytes);
                let Payload::String(old) = &self.object(id)?.payload else {
                    return Err("String byte constructor receiver".into());
                };
                if units.len() > 16384
                    || self
                        .heap_bytes()
                        .saturating_sub(old.len() * 2)
                        .saturating_add(units.len() * 2)
                        > self.heap_limit
                {
                    return Err("Decoded string memory quota".into());
                }
                self.object_mut(id)?.payload = Payload::String(units);
                return Ok(Some(0));
            }
        }
        if !matches!(
            class,
            "Ljava/nio/charset/Charset;"
                | "Lorg/kyvex/rift/NativeCharset;"
                | "Ljava/lang/Object;"
                | "Ljava/lang/Comparable;"
        ) {
            return Ok(None);
        }
        let Some(&id) = a.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        let Payload::Charset(encoding) = object.payload else {
            return Ok(None);
        };
        let result = match method {
            "name()Ljava/lang/String;"
            | "toString()Ljava/lang/String;"
            | "displayName()Ljava/lang/String;" => self.string(encoding.name())? as u64,
            "isRegistered()Z" | "canEncode()Z" => 1,
            "equals(Ljava/lang/Object;)Z" => {
                if arg(1)? == 0 {
                    0
                } else {
                    matches!(self.object(arg(1)?)?.payload,Payload::Charset(other) if encoding==other)
                        as u64
                }
            }
            "hashCode()I" => encoding
                .name()
                .bytes()
                .fold(0u32, |h, b| h.wrapping_mul(31).wrapping_add(b as u32))
                as u64,
            "compareTo(Ljava/nio/charset/Charset;)I" | "compareTo(Ljava/lang/Object;)I" => {
                let other = self.charset_encoding(arg(1)?)?;
                let left = encoding.name().as_bytes();
                let right = other.name().as_bytes();
                left.iter()
                    .zip(right)
                    .find_map(|(l, r)| (l != r).then_some(*l as i32 - *r as i32))
                    .unwrap_or(left.len() as i32 - right.len() as i32) as u32 as u64
            }
            "contains(Ljava/nio/charset/Charset;)Z" => {
                let other = self.charset_encoding(arg(1)?)?;
                (match encoding {
                    Encoding::Ascii => other == Encoding::Ascii,
                    Encoding::Latin1 => matches!(other, Encoding::Ascii | Encoding::Latin1),
                    _ => true,
                }) as u64
            }
            "aliases()Ljava/util/Set;" => {
                let mut aliases = Vec::new();
                for alias in encoding.aliases() {
                    aliases.push(self.string(alias)?);
                }
                let set = self.allocate("Ljava/util/HashSet;", Payload::Set(aliases))?;
                self.allocate(
                    "Ljava/util/Collections$UnmodifiableSet;",
                    Payload::CollectionWrapper {
                        target: set,
                        readonly: true,
                        mutex: 0,
                    },
                )? as u64
            }
            _ => return Ok(None),
        };
        Ok(Some(result))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn vm() -> Runtime {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/rift-native-demo.apk");
        let package = crate::package::Package::open(&path, "auto").unwrap();
        Runtime::new(
            package.dex,
            Machine::new(64, 32, 8).unwrap(),
            package.libraries,
            4 * 1024 * 1024,
        )
    }
    fn hex(text: &str, width: usize) -> Vec<u16> {
        text.as_bytes()
            .chunks_exact(width)
            .map(|part| u16::from_str_radix(std::str::from_utf8(part).unwrap(), 16).unwrap())
            .collect()
    }
    #[test]
    fn all_six_codecs_match_960_independent_stock_java8_vectors() {
        let rows: serde_json::Value = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../tests/fixtures/charsets.json"
        )))
        .unwrap();
        let rows = rows.as_array().unwrap();
        assert_eq!(rows.len(), 960);
        for (index, row) in rows.iter().enumerate() {
            let encoding = Encoding::parse(row["name"].as_str().unwrap()).unwrap();
            let units = hex(row["units"].as_str().unwrap(), 4);
            let bytes: Vec<u8> = hex(row["bytes"].as_str().unwrap(), 2)
                .into_iter()
                .map(|v| v as u8)
                .collect();
            let expected: Vec<u8> = hex(row["encoded"].as_str().unwrap(), 2)
                .into_iter()
                .map(|v| v as u8)
                .collect();
            assert_eq!(
                encoding.encode(&units),
                expected,
                "encoding vector {index}: {row}"
            );
            assert_eq!(
                encoding.decode(&bytes),
                hex(row["decoded"].as_str().unwrap(), 4),
                "decoding vector {index}: {row}"
            );
        }
    }
    #[test]
    fn canonical_charset_identity_and_alias_contents_are_gc_owned() {
        let mut vm = vm();
        let utf = vm.charset(Encoding::Utf8).unwrap();
        let alias_set = vm
            .hle(
                "Ljava/nio/charset/Charset;->aliases()Ljava/util/Set;",
                &[utf],
            )
            .unwrap() as u32;
        let roots = vm.scoped_library_roots(&[alias_set]).unwrap();
        vm.collect().unwrap();
        assert_eq!(vm.charset(Encoding::Utf8).unwrap(), utf);
        let alias = vm.string("UTF8").unwrap();
        assert_eq!(
            vm.hle(
                "Ljava/util/Set;->contains(Ljava/lang/Object;)Z",
                &[alias_set, alias]
            )
            .unwrap(),
            1
        );
        let error = vm
            .hle("Ljava/util/Set;->clear()V", &[alias_set])
            .unwrap_err();
        assert!(error.to_string().contains("UnsupportedOperationException"));
        drop(roots);
        vm.collect().unwrap();
        assert!(!vm.heap.contains_key(&alias_set));
        assert!(vm.heap.contains_key(&utf));
        assert!(vm.execution_roots.borrow().is_empty());
    }
    #[test]
    fn oversized_encoded_arrays_fail_without_adding_a_heap_object() {
        let mut vm = vm();
        let utf = vm.charset(Encoding::Utf8).unwrap();
        let source = vm.string_units(vec![0x20ac; 16384]).unwrap();
        let before = vm.heap.len();
        let error = vm
            .hle(
                "Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B",
                &[source, utf],
            )
            .unwrap_err();
        assert!(error.to_string().contains("quota"));
        assert_eq!(vm.heap.len(), before);
    }
}
