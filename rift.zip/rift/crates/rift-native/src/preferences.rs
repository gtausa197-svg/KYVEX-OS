//! Bounded app preferences with a preopened two-slot journal. No guest host paths.
use crate::Result;
use serde::{Deserialize, Serialize};
use sha1::{Digest, Sha1};
use std::{
    collections::BTreeMap,
    fs::{File, OpenOptions},
    os::{
        fd::AsRawFd,
        unix::fs::{FileExt, MetadataExt, OpenOptionsExt},
    },
    path::Path,
};
pub type Key = Option<Vec<u16>>;
pub type Group = BTreeMap<Key, Value>;
#[derive(Clone, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub struct Name {
    pub units: Vec<u16>,
    pub device_protected: bool,
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum Value {
    Scalar { kind: char, bits: u64 },
    String(Vec<u16>),
    Strings(Vec<Vec<u16>>),
}
impl Value {
    pub fn bytes(&self) -> usize {
        match self {
            Self::Scalar { .. } => 16,
            Self::String(s) => 32 + s.len() * 2,
            Self::Strings(v) => 32 + v.iter().map(|s| 32 + s.len() * 2).sum::<usize>(),
        }
    }
}
#[derive(Default)]
pub struct Store {
    pub groups: BTreeMap<Name, Group>,
    journal: Option<Journal>,
}
// A third field is written only for device-protected groups. The original
// two-field groups retain their wire format and load into the ordinary store.
#[derive(Serialize, Deserialize)]
struct SnapshotGroup(
    Vec<u16>,
    Vec<(Key, Value)>,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")] bool,
);
#[derive(Serialize, Deserialize)]
struct Snapshot(Vec<SnapshotGroup>);
const SLOT: usize = 131072;
const HEADER: usize = 48;
const MAGIC: &[u8; 8] = b"KYVPREF1";
struct Journal {
    file: File,
    generation: u64,
}
impl Store {
    pub fn open(path: &Path) -> Result<Self> {
        let mut journal = Journal::open(path)?;
        let groups = journal.load()?;
        Ok(Self {
            groups,
            journal: Some(journal),
        })
    }
    pub fn fd(&self) -> Option<i32> {
        self.journal.as_ref().map(|j| j.file.as_raw_fd())
    }
    pub fn bytes(&self) -> usize {
        self.groups
            .iter()
            .map(|(name, g)| {
                64 + name.units.len() * 2
                    + g.iter()
                        .map(|(k, v)| 64 + k.as_ref().map_or(0, |k| k.len() * 2) + v.bytes())
                        .sum::<usize>()
            })
            .sum()
    }
    pub fn save(&mut self) -> Result<bool> {
        validate(&self.groups)?;
        let snapshot = Snapshot(
            self.groups
                .iter()
                .map(|(n, g)| {
                    SnapshotGroup(
                        n.units.clone(),
                        g.iter().map(|(k, v)| (k.clone(), v.clone())).collect(),
                        n.device_protected,
                    )
                })
                .collect(),
        );
        let bytes = serde_json::to_vec(&snapshot)?;
        if bytes.len() > SLOT - HEADER {
            return Err("Preference persistence quota (128 KiB)".into());
        }
        if let Some(journal) = &mut self.journal {
            journal.save(&bytes)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }
}
fn validate(groups: &BTreeMap<Name, Group>) -> Result<()> {
    if groups.len() > 128 {
        return Err("Preference group quota".into());
    }
    for (name, group) in groups {
        if name.units.len() > 1024 || group.len() > 1024 {
            return Err("Preference name/entry quota".into());
        }
        for (key, value) in group {
            if key.as_ref().is_some_and(|k| k.len() > 1024) {
                return Err("Preference key quota".into());
            }
            match value {
                Value::String(s) if s.len() <= 16384 => {}
                Value::Strings(v) if v.len() <= 1024 && v.iter().all(|s| s.len() <= 16384) => {}
                Value::Scalar { kind, bits }
                    if match kind {
                        'J' => true,
                        'I' | 'F' => *bits <= u32::MAX as u64,
                        'Z' => *bits <= 1,
                        _ => false,
                    } => {}
                _ => return Err("Invalid preference value or quota".into()),
            }
        }
    }
    Ok(())
}
impl Journal {
    fn open(path: &Path) -> Result<Self> {
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .mode(0o600)
            .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(path)?;
        let meta = file.metadata()?;
        if !meta.is_file()
            || meta.nlink() != 1
            || meta.uid() != unsafe { libc::geteuid() }
            || meta.mode() & 0o077 != 0
        {
            return Err("Preference journal must be a private owned regular file".into());
        }
        if unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 {
            return Err("Preference journal is already in use".into());
        }
        let mut journal = Self {
            file,
            generation: 0,
        };
        if meta.len() == 0 {
            journal.file.set_len((2 * SLOT) as u64)?;
            journal.save(b"[]")?;
        } else if meta.len() != (2 * SLOT) as u64 {
            return Err("Invalid preference journal size; existing data was not modified".into());
        }
        Ok(journal)
    }
    fn slot(&self, index: usize) -> Result<Option<(u64, Vec<u8>)>> {
        let mut header = [0; HEADER];
        self.file
            .read_exact_at(&mut header, (index * SLOT) as u64)?;
        if &header[..8] != MAGIC {
            return Ok(None);
        }
        let generation = u64::from_le_bytes(header[8..16].try_into()?);
        let length = u32::from_le_bytes(header[16..20].try_into()?) as usize;
        if length > SLOT - HEADER {
            return Ok(None);
        }
        let mut bytes = vec![0; length];
        self.file
            .read_exact_at(&mut bytes, (index * SLOT + HEADER) as u64)?;
        let mut hash = Sha1::new();
        hash.update(&header[8..20]);
        hash.update(&bytes);
        if hash.finalize().as_slice() != &header[20..40] {
            return Ok(None);
        }
        Ok(Some((generation, bytes)))
    }
    fn load(&mut self) -> Result<BTreeMap<Name, Group>> {
        let (generation, bytes) = [self.slot(0)?, self.slot(1)?]
            .into_iter()
            .flatten()
            .max_by_key(|(g, _)| *g)
            .ok_or("No valid preference journal generation")?;
        let snapshot: Snapshot = serde_json::from_slice(&bytes)?;
        let mut groups = BTreeMap::new();
        for SnapshotGroup(units, values, device_protected) in snapshot.0 {
            let mut group = BTreeMap::new();
            for (k, v) in values {
                if group.insert(k, v).is_some() {
                    return Err("Duplicate preference key".into());
                }
            }
            if groups
                .insert(
                    Name {
                        units,
                        device_protected,
                    },
                    group,
                )
                .is_some()
            {
                return Err("Duplicate preference group".into());
            }
        }
        validate(&groups)?;
        self.generation = generation;
        Ok(groups)
    }
    fn save(&mut self, bytes: &[u8]) -> Result<()> {
        if bytes.len() > SLOT - HEADER {
            return Err("Preference journal payload quota".into());
        }
        let generation = self
            .generation
            .checked_add(1)
            .ok_or("Preference journal generation exhausted")?;
        let offset = (generation as usize % 2 * SLOT) as u64;
        self.file.write_all_at(&[0; 8], offset)?;
        self.file.sync_data()?;
        let mut header = [0; HEADER];
        header[8..16].copy_from_slice(&generation.to_le_bytes());
        header[16..20].copy_from_slice(&(bytes.len() as u32).to_le_bytes());
        let mut hash = Sha1::new();
        hash.update(&header[8..20]);
        hash.update(bytes);
        header[20..40].copy_from_slice(&hash.finalize());
        self.file.write_all_at(bytes, offset + HEADER as u64)?;
        self.file.write_all_at(&header[8..], offset + 8)?;
        self.file.sync_data()?;
        self.file.write_all_at(MAGIC, offset)?;
        self.file.sync_data()?;
        self.generation = generation;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::fs::PermissionsExt;

    #[test]
    fn device_groups_keep_old_journals_and_same_named_values_distinct() {
        let path = std::env::temp_dir().join(format!(
            "kyvex-prefs-storage-{}.journal",
            std::process::id()
        ));
        let mut journal = Journal::open(&path).unwrap();
        journal
            .save(br#"[[[42],[[[7],{"Scalar":{"kind":"I","bits":19}}]]]]"#)
            .unwrap();
        drop(journal);
        let mut store = Store::open(&path).unwrap();
        let ordinary = Name {
            units: vec![42],
            device_protected: false,
        };
        let device = Name {
            device_protected: true,
            ..ordinary.clone()
        };
        let key = Some(vec![7]);
        let original = Value::Scalar {
            kind: 'I',
            bits: 19,
        };
        let new = Value::String(vec![0xd800, 0, 42]);
        assert_eq!(store.groups[&ordinary][&key], original);
        assert!(!store.groups.contains_key(&device));
        store
            .groups
            .entry(device.clone())
            .or_default()
            .insert(key.clone(), new.clone());
        assert!(store.save().unwrap());
        drop(store);
        let store = Store::open(&path).unwrap();
        assert_eq!(store.groups[&ordinary][&key], original);
        assert_eq!(store.groups[&device][&key], new);
        drop(store);
        std::fs::remove_file(path).unwrap();
    }

    #[test]
    fn journal_roundtrip_rejects_parallel_writers_and_recovers_torn_generation() {
        let path = std::env::temp_dir().join(format!("kyvex-prefs-{}.journal", std::process::id()));
        let mut store = Store::open(&path).unwrap();
        assert!(Store::open(&path).is_err());
        let name = Name {
            units: vec![42],
            device_protected: false,
        };
        let key = Some(vec![7]);
        let value = Value::String(vec![0xd800, 0, 42]);
        store
            .groups
            .entry(name.clone())
            .or_default()
            .insert(key.clone(), value.clone());
        assert!(store.save().unwrap());
        store.groups.get_mut(&name).unwrap().insert(
            key.clone(),
            Value::Scalar {
                kind: 'J',
                bits: u64::MAX,
            },
        );
        assert!(store.save().unwrap());
        // Corrupt only the latest committed slot: the prior generation remains valid.
        let journal = store.journal.as_mut().unwrap();
        let offset = (journal.generation as usize % 2 * SLOT + HEADER) as u64;
        journal.file.write_all_at(b"broken", offset).unwrap();
        drop(store);
        let loaded = Store::open(&path).unwrap();
        assert_eq!(loaded.groups[&name][&key], value);
        drop(loaded);
        std::fs::remove_file(path).unwrap();
    }
    #[test]
    fn preferences_do_not_overwrite_unrelated_files_or_accept_shared_permissions() {
        let path =
            std::env::temp_dir().join(format!("kyvex-prefs-invalid-{}.txt", std::process::id()));
        std::fs::write(&path, b"unrelated user data").unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
        assert!(Store::open(&path).is_err());
        assert_eq!(std::fs::read(&path).unwrap(), b"unrelated user data");
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644)).unwrap();
        assert!(Store::open(&path).is_err());
        std::fs::remove_file(path).unwrap();
    }
}
