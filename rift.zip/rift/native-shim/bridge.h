/* KYVEX's C ABI adapter. Dynarmic remains the credited upstream CPU JIT. */
#pragma once
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef int (*kv_read)(void *, uint64_t, uint8_t *, size_t, uint32_t);
typedef int (*kv_write)(void *, uint64_t, const uint8_t *, size_t);
typedef struct {
  uint64_t regs[32], vectors[64], pc;
  uint32_t flags, fp_control, fp_status, reason, svc;
  uint64_t ticks;
} kv_state;
uint32_t kv_dynarmic_abi(void);
size_t kv_dynarmic_state_size(void);
void *kv_cpu_new(uint32_t arch, void *context, kv_read, kv_write,
                 size_t cache_bytes, char *error, size_t error_size);
int kv_cpu_run(void *, kv_state *, uint64_t ticks, uint32_t single_step,
               char *error, size_t error_size);
void kv_cpu_free(void *);
void kv_cpu_clear_cache(void *);
void kv_cpu_set_thread_pointer(void *, uint64_t address);
#ifdef __cplusplus
}
#endif
