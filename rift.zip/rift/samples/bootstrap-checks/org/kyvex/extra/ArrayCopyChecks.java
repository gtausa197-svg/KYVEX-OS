package org.kyvex.extra;

public final class ArrayCopyChecks {
    private static int checks;

    private static void check(boolean condition, String name) {
        if (!condition) throw new IllegalStateException(name);
        checks++;
    }

    public static int verify() {
        checks = 0;
        String[] source = {"A", "B"};
        Object[] widened = {"x", "y", "z"};
        System.arraycopy(source, 0, widened, 0, 2);
        check(widened[0] == source[0] && widened[1] == source[1] && "z".equals(widened[2]), "Covariant copy");

        String[] narrowed = {"old", "old"};
        System.arraycopy(new Object[]{"new", null}, 0, narrowed, 0, 2);
        check("new".equals(narrowed[0]) && narrowed[1] == null, "Element checks and null");

        String[] partial = {"a", "b", "c", "d"};
        boolean rejected = false;
        try { System.arraycopy(new Object[]{"first", Integer.valueOf(13), "after"}, 0, partial, 1, 3); }
        catch (ArrayStoreException expected) { rejected = true; }
        check(rejected && "a".equals(partial[0]) && "first".equals(partial[1])
                && "c".equals(partial[2]) && "d".equals(partial[3]), "Partial copy before invalid element");

        CharSequence[] sequences = new CharSequence[2];
        System.arraycopy(source, 0, sequences, 0, 2);
        check(sequences[1] == source[1], "Interface component");
        int[][] nested = {{42}};
        Object[] row = new Object[1];
        System.arraycopy(nested, 0, row, 0, 1);
        check(row[0] == nested[0], "Nested primitive array is a reference");

        boolean primitiveRejected = false;
        try { System.arraycopy(new byte[0], 0, new int[0], 0, 0); }
        catch (ArrayStoreException expected) { primitiveRejected = true; }
        System.arraycopy(new Integer[0], 0, new String[0], 0, 0);
        check(primitiveRejected, "Zero-length copy still checks primitive types");

        boolean boundsRejected = false;
        try { System.arraycopy(source, 0, widened, 2, 2); }
        catch (IndexOutOfBoundsException expected) { boundsRejected = true; }
        check(boundsRejected && "z".equals(widened[2]), "Bounds failure leaves destination intact");

        String[] overlap = {"A", "B", "C", "D"};
        System.arraycopy(overlap, 0, overlap, 1, 3);
        check("A".equals(overlap[1]) && "B".equals(overlap[2]) && "C".equals(overlap[3]), "Overlapping copy");
        return checks;
    }

    public static void main(String[] args) {
        System.out.println("System.arraycopy checks: " + verify());
    }
}
