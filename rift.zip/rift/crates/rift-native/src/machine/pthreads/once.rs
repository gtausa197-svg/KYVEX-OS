use super::{Machine, NativeStep, Pthreads, READ, Result, State, WRITE, Wait};
use crate::machine::{EXEC, ONCE_RETURN};

const INITIAL: u32 = 0;
const RUNNING: u32 = 1;
const DONE: u32 = 2;
const MAX_NESTED_INITIALIZERS: usize = 16;

#[derive(Clone, Copy)]
pub(super) struct Initializer {
    control: u64,
    resume_pc: u64,
    resume_lr: u64,
    resume_flags: u32,
}

impl Pthreads {
    pub(super) fn once_owner(&self, control: u64) -> Option<u32> {
        self.initializers
            .iter()
            .find(|(_, stack)| stack.iter().any(|init| init.control == control))
            .map(|(&tid, _)| tid)
    }
}

impl Machine {
    fn read_once(&self, address: u64) -> std::result::Result<u32, i32> {
        if !address.is_multiple_of(4) {
            return Err(libc::EINVAL);
        }
        let mut bytes = [0; 4];
        self.cpu
            .memory()
            .read(address, &mut bytes, READ | WRITE)
            .map_err(|_| libc::EFAULT)?;
        Ok(u32::from_le_bytes(bytes))
    }

    pub(super) fn completed_pthread_once(&self, address: u64) -> u64 {
        match self.read_once(address) {
            Ok(DONE) => 0,
            Ok(_) => libc::EINVAL as u64,
            Err(error) => error as u64,
        }
    }

    pub(super) fn start_pthread_once(&mut self, state: &mut State) -> NativeStep {
        match self.begin_once(state) {
            Ok(step) => step,
            Err(error) => {
                state.regs[0] = error as u64;
                NativeStep::Resume
            }
        }
    }

    fn begin_once(&mut self, state: &mut State) -> std::result::Result<NativeStep, i32> {
        let [control, start, ..] = state.regs;
        let tid = self.current_tid;
        match self.read_once(control)? {
            DONE => {
                state.regs[0] = 0;
                return Ok(NativeStep::Resume);
            }
            RUNNING if self.pthreads.once_owner(control).is_some() => {
                let wait = Wait::Once(control);
                if self.pthreads.would_deadlock(tid, wait) {
                    return Err(libc::EDEADLK);
                }
                return Ok(NativeStep::Wait(wait));
            }
            INITIAL => {}
            _ => return Err(libc::EINVAL),
        }
        let arm32 = self.arch == 32;
        let thumb = arm32 && start & 1 != 0;
        let pc = if arm32 { start & !1 } else { start };
        if !pc.is_multiple_of(if thumb { 2 } else { 4 })
            || self.cpu.memory().read(pc, &mut [0; 1], EXEC).is_err()
        {
            return Err(libc::EINVAL);
        }
        let initializers = self.pthreads.initializers.entry(tid).or_default();
        if initializers.len() >= MAX_NESTED_INITIALIZERS {
            return Err(libc::EAGAIN);
        }
        self.cpu
            .memory_mut()
            .write(control, &RUNNING.to_le_bytes())
            .map_err(|_| libc::EFAULT)?;
        let lr = if arm32 { 14 } else { 30 };
        initializers.push(Initializer {
            control,
            resume_pc: state.pc,
            resume_lr: state.regs[lr],
            resume_flags: state.flags,
        });
        state.regs[lr] = ONCE_RETURN;
        state.pc = pc;
        if arm32 {
            state.flags = (state.flags & !0x20) | if thumb { 0x20 } else { 0 };
        }
        Ok(NativeStep::Resume)
    }

    pub(in crate::machine) fn finish_pthread_once(&mut self, state: &mut State) -> Result<()> {
        let tid = self.current_tid;
        let initializers = self
            .pthreads
            .initializers
            .get_mut(&tid)
            .ok_or("Unexpected guest pthread_once return")?;
        let init = *initializers
            .last()
            .ok_or("Missing guest pthread_once frame")?;
        self.cpu
            .memory_mut()
            .write(init.control, &DONE.to_le_bytes())?;
        initializers.pop();
        if initializers.is_empty() {
            self.pthreads.initializers.remove(&tid);
        }
        state.pc = init.resume_pc;
        state.regs[if self.arch == 32 { 14 } else { 30 }] = init.resume_lr;
        state.flags = init.resume_flags;
        state.regs[0] = 0;
        Ok(())
    }

    pub(in crate::machine) fn reset_pthread_once(&mut self, tid: u32) {
        if let Some(stack) = self.pthreads.initializers.remove(&tid) {
            for init in stack {
                // An unsuccessful guest initializer may have unmapped its control.
                let _ = self
                    .cpu
                    .memory_mut()
                    .write(init.control, &INITIAL.to_le_bytes());
            }
        }
    }
}
