.syntax unified
.arm
.fpu neon
.text
.global _start
_start:
    vmov.i32 q0, #6
    vmov.i32 q1, #7
    vmul.i32 q0, q0, q1
    vmov r0, s2
    mov r7, #1
    svc #0
