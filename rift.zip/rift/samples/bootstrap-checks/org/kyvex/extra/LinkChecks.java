package org.kyvex.extra;

public final class LinkChecks {
    private static int checks;
    private static native int nativeResult();
    private static native int nativeHelpers();
    private static native int nativeHeap();
    private static native int nativeErrno(int next);
    private static native int nativeInteger();
    private static native int nativeStdio();
    private static native int nativeScan();
    private static native int nativeAllocFormat();
    private static native int nativeStrings();
    private static native int nativePthreads();
    private static native int nativeCLocale();

    private static void check(boolean condition, String label) {
        if (!condition) throw new IllegalStateException(label);
        checks++;
    }

    private static String loadFailure(String name) {
        try { System.loadLibrary(name); }
        catch (UnsatisfiedLinkError failure) { return failure.getMessage(); }
        throw new IllegalStateException("Expected linker rejection of " + name);
    }

    public static int verify() {
        checks = 0;
        String failed = loadFailure("link-unresolved");
        check(failed.contains("absent_strong_import"), "Missing strong import rejected");
        check(failed.equals(loadFailure("link-unresolved")), "Retry preserves the original failure");

        System.loadLibrary("link-root");
        check(nativeResult() == 71, "Dependency constructors, breadth-first symbols and no implicit JNI_OnLoad");
        System.loadLibrary("link-root");
        check(nativeResult() == 71, "Root initializes once after a failed link");

        System.loadLibrary("link-leaf");
        check(nativeResult() == 72, "Explicit dependency load runs its own JNI_OnLoad");
        System.loadLibrary("link-leaf");
        check(nativeResult() == 72, "Dependency JNI_OnLoad runs once");

        check(loadFailure("link-broken-jni").contains("0x1234"), "Rejected version after actual registration");
        check(nativeResult() == 72, "Failed JNI initialization rolls back the registered method");
        check(nativeHelpers() == 17, "Native platform log, Adler-32 and ARM memory ABI");
        return checks;
    }

    public static int verifyHeap() {
        int result = nativeHeap();
        if (result != 11) throw new IllegalStateException("Native heap result " + result);
        if (nativeErrno(39) != 0) throw new IllegalStateException("Initial main errno");
        final int[] observed = {-1};
        Thread child = new Thread(new Runnable() {
            public void run() {
                int first = nativeErrno(73);
                observed[0] = first == 0 ? nativeErrno(0) : -2;
            }
        });
        child.start();
        try { child.join(); }
        catch (InterruptedException unexpected) { throw new IllegalStateException(unexpected); }
        if (observed[0] != 73 || nativeErrno(0) != 39) {
            throw new IllegalStateException("Native errno slots must belong to individual guest threads");
        }
        return result + 2;
    }

    public static int verifyInteger() {
        int result = nativeInteger();
        if (result != 15) throw new IllegalStateException("Native integer result " + result);
        return result;
    }

    public static int verifyStdio() {
        int result = nativeStdio();
        if (result != 14) throw new IllegalStateException("Native stdio result " + result);
        return result;
    }

    public static int verifyScan() {
        int result = nativeScan();
        if (result != 13) throw new IllegalStateException("Native scan result " + result);
        return result;
    }

    public static int verifyAllocFormat() {
        int result = nativeAllocFormat();
        if (result != 4) throw new IllegalStateException("Native allocated format result " + result);
        return result;
    }

    public static int verifyStrings() {
        System.loadLibrary("link-native-strings");
        int result = nativeStrings();
        if (result != 16) throw new IllegalStateException("Native string result " + result);
        return result;
    }

    public static int verifyPthreads() {
        System.loadLibrary("link-native-threads");
        int result = nativePthreads();
        if (result != 26) throw new IllegalStateException("Native pthread result " + result);
        return result;
    }

    public static int verifyCLocale() {
        System.loadLibrary("link-native-locale");
        int result = nativeCLocale();
        if (result != 13) throw new IllegalStateException("Native C locale result " + result);
        return result;
    }
}
