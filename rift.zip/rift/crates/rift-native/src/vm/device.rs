//! Guest identity and construction of optional, unregistered telephony listeners.
use super::*;
pub(super) fn payload(class: &str) -> Option<Payload> {
    (class == "Landroid/telephony/PhoneStateListener;").then_some(Payload::Instance)
}
impl Runtime {
    pub(super) fn device_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Device signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Device argument count");
        if class == "Landroid/os/Process;" {
            return Ok(Some(match method {
                "myPid()I" => crate::identity::PID as u64,
                "myTid()I" => self.current_guest_tid() as u64,
                "myUid()I" => crate::identity::UID as u64,
                _ => return Ok(None),
            }));
        }
        if class != "Landroid/telephony/PhoneStateListener;" {
            return Ok(None);
        }
        if matches!(method, "<init>()V" | "<init>(Landroid/os/Looper;)V") {
            let looper = if a.len() == 2 {
                arg(1)?
            } else {
                self.events_api("Landroid/os/Looper;->myLooper()Landroid/os/Looper;", &[])?
                    .ok_or("Phone listener Looper")? as u32
            };
            if !matches!(self.object(looper)?.payload, Payload::Looper(_)) {
                return Err("Phone listener requires Looper".into());
            }
            let handler = self.allocate(
                "Landroid/os/Handler;",
                Payload::Handler(events::Handler {
                    looper,
                    callback: 0,
                    asynchronous: false,
                    messenger_binder: 0,
                }),
            )?;
            self.object_mut(arg(0)?)?
                .fields
                .insert(usize::MAX - 70, handler as u64);
            return Ok(Some(0));
        }
        Ok(None)
    }
}
