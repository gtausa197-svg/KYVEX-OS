package android.os;
public class Bundle {
    public Bundle(){}
    public java.util.Set<String> keySet(){return null;}
    public void putInt(String key,int value){}
    public void putAll(Bundle other){}
    public Object get(String key){return null;}
    public int size(){return 0;}
    public void putString(String key,String value){}
    public String getString(String key){return null;}
    public void putLong(String key,long value){}
    public long getLong(String key){return 0;}
    public int getInt(String key,int fallback){return fallback;}
    public int getInt(String key){return 0;}
    public float getFloat(String key){return 0;}
    public boolean getBoolean(String key){return false;}
    public boolean containsKey(String key){return false;}
}
