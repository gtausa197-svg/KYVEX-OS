//! Small, actual Java library implementations. No catch-all success stubs.
use super::*;
pub(super) fn payload(class: &str) -> Option<Payload> {
    if let Some(kind) = atomic_arrays::kind(class) {
        return Some(Payload::AtomicArray { kind, values: None });
    }
    Some(match class {
        "Landroid/database/sqlite/SQLiteOpenHelper;" => Payload::SqliteHelper(None),
        "Ljava/io/ObjectStreamField;" => Payload::Instance,
        "Ljava/util/logging/Level;" => Payload::Instance,
        "Ljava/lang/String;" => Payload::String(Vec::new()),
        "Ljava/lang/ThreadLocal;" | "Ljava/lang/InheritableThreadLocal;" => Payload::Instance,
        "Ljava/util/UUID;" => Payload::Uuid(0, 0),
        date::DATE => Payload::Date(0),
        decimal_format::DECIMAL => Payload::Decimal(None),
        paint::PAINT | paint::TEXT_PAINT => Payload::Paint(paint::Paint::default()),
        rwlock::RW_LOCK => Payload::RwLock(rwlock::RwLock::default()),
        local_binder::BINDER => Payload::LocalBinder(local_binder::Binder::default()),
        "Landroid/util/SparseIntArray;" => Payload::SparseInt(Vec::new()),
        "Ljava/util/Random;" => Payload::Random(super::random::Random::seeded(0)),
        "Ljava/lang/Thread;" | "Ljava/lang/ThreadGroup;" | "Ljava/lang/StackTraceElement;" => {
            Payload::Instance
        }
        "Ljava/util/concurrent/atomic/AtomicReference;" => Payload::Atomic {
            value: 0,
            kind: 'R',
        },
        "Ljava/util/concurrent/atomic/AtomicInteger;" => Payload::Atomic {
            value: 0,
            kind: 'I',
        },
        "Ljava/util/concurrent/atomic/AtomicLong;" => Payload::Atomic {
            value: 0,
            kind: 'J',
        },
        "Ljava/util/concurrent/atomic/AtomicBoolean;" => Payload::Atomic {
            value: 0,
            kind: 'Z',
        },
        "Ljava/util/concurrent/locks/ReentrantLock;" => Payload::Lock {
            owner: 0,
            holds: 0,
            fair: false,
        },
        "Landroid/os/Bundle;" => Payload::Bundle(BTreeMap::new()),
        _ => {
            return super::collections::payload(class)
                .or_else(|| super::concurrency::payload(class));
        }
    })
}
impl Runtime {
    pub(super) fn value_equal(&mut self, a: u32, b: u32) -> Result<bool> {
        if a == b {
            return Ok(true);
        }
        if a == 0 || b == 0 {
            return Ok(false);
        }
        let x = self.object(a)?;
        let y = self.object(b)?;
        if x.class == "Ljava/lang/StackTraceElement;" {
            return self.element_equal(a, b);
        }
        if let (Payload::Boxed { kind: a, bits: x }, Payload::Boxed { kind: b, bits: y }) =
            (&x.payload, &y.payload)
        {
            return Ok(super::android::boxes_equal(*a, *x, *b, *y));
        }
        if let (Payload::String(x), Payload::String(y)) = (&x.payload, &y.payload) {
            return Ok(x == y);
        }
        if let (Payload::Uuid(am, al), Payload::Uuid(bm, bl)) = (&x.payload, &y.payload) {
            return Ok(am == bm && al == bl);
        }
        if matches!(x.payload, Payload::File(_)) {
            return Ok(self.collection_dispatch(
                a,
                "Ljava/io/File;",
                "equals(Ljava/lang/Object;)Z",
                &[b],
            )? != 0);
        }
        if matches!(x.payload, Payload::Date(_)) {
            return Ok(self.collection_dispatch(
                a,
                date::DATE,
                "equals(Ljava/lang/Object;)Z",
                &[b],
            )? != 0);
        }
        if let (Payload::Charset(a), Payload::Charset(b)) = (&x.payload, &y.payload) {
            return Ok(a == b);
        }
        if let (Payload::LogLevel(a), Payload::LogLevel(b)) = (&x.payload, &y.payload) {
            return Ok(a.value == b.value);
        }
        if let (Payload::Messenger(a), Payload::Messenger(b)) = (&x.payload, &y.payload) {
            self.object(*a)?;
            self.object(*b)?;
            return Ok(a == b);
        }
        if let Some(method) = self.callback_method(a, "equals", "(Ljava/lang/Object;)Z")? {
            return Ok(self.invoke(method, &[a, b], true)? != 0);
        }
        if pair::has_members(self.object(a)?) {
            return self.pair_equal(a, b);
        }
        if self.object(a)?.class == point::POINT {
            return Ok(self.point_api(
                "Landroid/graphics/Point;->equals(Ljava/lang/Object;)Z",
                &[a, b],
            )? == Some(1));
        }
        Ok(false)
    }
    pub(super) fn core_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Java method signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Java library argument count");
        if class == "Ljava/util/Objects;"
            && matches!(
                method,
                "requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;"
                    | "requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;"
                    | "requireNonNull(Ljava/lang/Object;Ljava/util/function/Supplier;)Ljava/lang/Object;"
            )
        {
            let value = arg(0)?;
            if value != 0 {
                self.object(value)?;
                return Ok(Some(value as u64));
            }
            let message = if method.contains("Supplier;") {
                self.collection_dispatch(
                    arg(1)?,
                    "Ljava/util/function/Supplier;",
                    "get()Ljava/lang/Object;",
                    &[],
                )? as u32
            } else if method.contains("Ljava/lang/String;)") {
                arg(1)?
            } else {
                0
            };
            if message != 0 && !matches!(self.object(message)?.payload, Payload::String(_)) {
                return Err(fault(
                    "Ljava/lang/ClassCastException;",
                    "Expected String detail message",
                ));
            }
            let detail = if message == 0 {
                String::new()
            } else {
                self.text(message)?
            };
            let mut roots = self.scoped_library_roots(&[message])?;
            let class = "Ljava/lang/NullPointerException;";
            let exception = self.allocate(class, Payload::Instance)?;
            roots.keep(exception)?;
            self.throwable_api(
                "Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V",
                &[exception, message],
            )?;
            return Err(Box::new(JavaFault {
                class: class.into(),
                object: exception,
                message: detail,
            }));
        }
        if matches!(class, "Ljava/lang/Math;" | "Ljava/lang/StrictMath;") {
            if method == "random()D" {
                return Ok(Some(self.next_math_random()?));
            }
            let wide =
                |i| -> Result<u64> { Ok(u64::from(arg(i)?) | (u64::from(arg(i + 1)?) << 32)) };
            return Ok(Some(match method {
                "abs(I)I" => (arg(0)? as i32).wrapping_abs() as u32 as u64,
                "abs(J)J" => (wide(0)? as i64).wrapping_abs() as u64,
                "abs(F)F" => f32::from_bits(arg(0)?).abs().to_bits() as u64,
                "abs(D)D" => f64::from_bits(wide(0)?).abs().to_bits(),
                "ceil(D)D" => f64::from_bits(wide(0)?).ceil().to_bits(),
                "min(II)I" => (arg(0)? as i32).min(arg(1)? as i32) as u32 as u64,
                "max(II)I" => (arg(0)? as i32).max(arg(1)? as i32) as u32 as u64,
                "min(JJ)J" => (wide(0)? as i64).min(wide(2)? as i64) as u64,
                "max(JJ)J" => (wide(0)? as i64).max(wide(2)? as i64) as u64,
                _ => return Ok(None),
            }));
        }
        if sig == "Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z" {
            // The guest log has no per-tag property overrides.
            return Ok(Some((arg(0)? != 0 && arg(1)? as i32 >= 4) as u64));
        }
        if sig == "Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;"
        {
            let stack = self.diagnostic_stack(arg(0)?)?;
            return Ok(Some(u64::from(self.string(&stack)?)));
        }
        if class == "Landroid/util/Log;"
            && let Some((level, descriptor)) = method.split_once('(')
            && matches!(level, "d" | "e" | "i" | "v" | "w")
            && descriptor == "Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I"
        {
            let tag = self.text(arg(0)?)?;
            let message = self.text(arg(1)?)?;
            let stack = self.diagnostic_stack(arg(2)?)?;
            let mut line = format!("{tag}: {message}");
            if !stack.is_empty() {
                line.push('\n');
                line.push_str(&stack);
            }
            let count = line.len();
            self.append_guest_log(line);
            return Ok(Some(count as u64));
        }
        if class == "Landroid/util/Log;"
            && matches!(
                method,
                "d(Ljava/lang/String;Ljava/lang/String;)I"
                    | "e(Ljava/lang/String;Ljava/lang/String;)I"
                    | "i(Ljava/lang/String;Ljava/lang/String;)I"
                    | "w(Ljava/lang/String;Ljava/lang/String;)I"
                    | "v(Ljava/lang/String;Ljava/lang/String;)I"
            )
        {
            let line = format!("{}: {}", self.text(arg(0)?)?, self.text(arg(1)?)?);
            let count = line.len();
            self.append_guest_log(line);
            return Ok(Some(count as u64));
        }
        match sig {
            "Landroid/app/Application;->getProcessName()Ljava/lang/String;" => {
                let name = self.package_name.clone();
                return Ok(Some(self.string(&name)? as u64));
            }
            "Landroid/os/SystemClock;->currentThreadTimeMillis()J" => {
                let mut time = libc::timespec {
                    tv_sec: 0,
                    tv_nsec: 0,
                };
                if unsafe { libc::clock_gettime(libc::CLOCK_THREAD_CPUTIME_ID, &mut time) } != 0 {
                    return Err("Thread CPU clock unavailable".into());
                }
                return Ok(Some(
                    time.tv_sec as u64 * 1000 + time.tv_nsec as u64 / 1000000,
                ));
            }
            "Landroid/os/SystemClock;->uptimeMillis()J"
            | "Landroid/os/SystemClock;->elapsedRealtime()J" => {
                return Ok(Some(self.uptime_millis()));
            }
            "Landroid/os/SystemClock;->elapsedRealtimeNanos()J" => {
                return Ok(Some(
                    (self.clock.elapsed().as_nanos() as u64).saturating_add(1_000_000),
                ));
            }
            "Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z" => {
                let id = arg(0)?;
                return Ok(Some(
                    (id == 0 || self.sequence_units(id)?.is_empty()) as u64,
                ));
            }
            "Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z" =>
            {
                let x = arg(0)?;
                let y = arg(1)?;
                if x == y {
                    return Ok(Some(1));
                }
                if x == 0 || y == 0 {
                    return Ok(Some(0));
                }
                return Ok(Some(
                    (self.sequence_units(x)? == self.sequence_units(y)?) as u64,
                ));
            }
            "Ljava/lang/System;->currentTimeMillis()J" => {
                return Ok(Some(
                    std::time::SystemTime::now()
                        .duration_since(std::time::UNIX_EPOCH)?
                        .as_millis() as u64,
                ));
            }
            "Ljava/lang/System;->nanoTime()J" => {
                return Ok(Some(self.clock.elapsed().as_nanos() as u64));
            }
            "Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I" => {
                let id = arg(0)?;
                if id != 0 {
                    self.object(id)?;
                }
                return Ok(Some(id as u64));
            }
            "Ljava/lang/Class;->desiredAssertionStatus()Z" => {
                self.object(arg(0)?)?;
                return Ok(Some(0));
            }
            _ => {}
        }
        if class == "Ljava/lang/String;" {
            match method {
                "isEmpty()Z" => return Ok(Some(self.units(arg(0)?)?.is_empty() as u64)),
                "concat(Ljava/lang/String;)Ljava/lang/String;" => {
                    let mut s = self.units(arg(0)?)?;
                    s.extend(self.units(arg(1)?)?);
                    return Ok(Some(self.string_units(s)? as u64));
                }
                "substring(I)Ljava/lang/String;" | "substring(II)Ljava/lang/String;" => {
                    let words = self.units(arg(0)?)?;
                    let start = arg(1)? as usize;
                    let end = if method.starts_with("substring(II)") {
                        arg(2)? as usize
                    } else {
                        words.len()
                    };
                    let s = words
                        .get(start..end)
                        .ok_or_else(|| {
                            fault(
                                "Ljava/lang/StringIndexOutOfBoundsException;",
                                "substring range",
                            )
                        })?
                        .to_vec();
                    return Ok(Some(self.string_units(s)? as u64));
                }
                "startsWith(Ljava/lang/String;)Z" | "endsWith(Ljava/lang/String;)Z" => {
                    let x = self.units(arg(0)?)?;
                    let y = self.units(arg(1)?)?;
                    let value = if method.starts_with("startsWith") {
                        x.starts_with(&y)
                    } else {
                        x.ends_with(&y)
                    };
                    return Ok(Some(value as u64));
                }
                "toCharArray()[C" => {
                    let words = self.units(arg(0)?)?;
                    return Ok(Some(self.allocate(
                        "[C",
                        Payload::Array(words.iter().map(|c| *c as u64).collect()),
                    )? as u64));
                }
                _ => {}
            }
        }
        if class.starts_with("Ljava/util/") && !a.is_empty() {
            let id = arg(0)?;
            let sequence = match &self.object(id)?.payload {
                Payload::List(v) | Payload::Set(v) => Some(v.clone()),
                _ => None,
            };
            if let Some(mut values) = sequence {
                let set = matches!(self.object(id)?.payload, Payload::Set(_));
                let result = match method {
                    "<init>()V" => 0,
                    "<init>(I)V" => {
                        if (arg(1)? as i32) < 0 {
                            return Err(fault(
                                "Ljava/lang/IllegalArgumentException;",
                                "negative capacity",
                            ));
                        }
                        0
                    }
                    "size()I" => values.len() as u64,
                    "isEmpty()Z" => values.is_empty() as u64,
                    "add(Ljava/lang/Object;)Z" => {
                        let value = arg(1)?;
                        let mut exists = false;
                        if set {
                            for v in &values {
                                if self.value_equal(*v, value)? {
                                    exists = true;
                                    break;
                                }
                            }
                        }
                        if !exists {
                            if values.len() >= 4096 {
                                return Err("Java collection quota".into());
                            }
                            values.push(value);
                        }
                        (!exists) as u64
                    }
                    "get(I)Ljava/lang/Object;" if !set => {
                        *values.get(arg(1)? as usize).ok_or_else(|| {
                            fault("Ljava/lang/IndexOutOfBoundsException;", "list index")
                        })? as u64
                    }
                    "clear()V" => {
                        values.clear();
                        0
                    }
                    "contains(Ljava/lang/Object;)Z" | "remove(Ljava/lang/Object;)Z" => {
                        let mut at = None;
                        for (i, v) in values.iter().enumerate() {
                            if self.value_equal(*v, arg(1)?)? {
                                at = Some(i);
                                break;
                            }
                        }
                        if method.starts_with("remove")
                            && let Some(i) = at
                        {
                            values.remove(i);
                        }
                        at.is_some() as u64
                    }
                    "toArray()[Ljava/lang/Object;" => {
                        return Ok(Some(self.allocate(
                            "[Ljava/lang/Object;",
                            Payload::Array(values.iter().map(|v| *v as u64).collect()),
                        )? as u64));
                    }
                    _ => return Ok(None),
                };
                self.object_mut(id)?.payload = if set {
                    Payload::Set(values)
                } else {
                    Payload::List(values)
                };
                return Ok(Some(result));
            }
            let map = match &self.object(id)?.payload {
                Payload::Map(v) => Some(v.clone()),
                _ => None,
            };
            if let Some(mut values) = map {
                let result = match method {
                    "<init>()V" => 0,
                    "<init>(I)V" => {
                        if (arg(1)? as i32) < 0 {
                            return Err(fault(
                                "Ljava/lang/IllegalArgumentException;",
                                "negative capacity",
                            ));
                        }
                        0
                    }
                    "size()I" => values.len() as u64,
                    "isEmpty()Z" => values.is_empty() as u64,
                    "clear()V" => {
                        values.clear();
                        0
                    }
                    "get(Ljava/lang/Object;)Ljava/lang/Object;"
                    | "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"
                    | "remove(Ljava/lang/Object;)Ljava/lang/Object;"
                    | "containsKey(Ljava/lang/Object;)Z" => {
                        let mut at = None;
                        for (i, (k, _)) in values.iter().enumerate() {
                            if self.value_equal(*k, arg(1)?)? {
                                at = Some(i);
                                break;
                            }
                        }
                        let previous = at.map(|i| values[i].1).unwrap_or(0);
                        if method.starts_with("put") {
                            if let Some(i) = at {
                                values[i].1 = arg(2)?;
                            } else {
                                if values.len() >= 4096 {
                                    return Err("Java map quota".into());
                                }
                                values.push((arg(1)?, arg(2)?));
                            }
                        } else if method.starts_with("remove")
                            && let Some(i) = at
                        {
                            values.remove(i);
                        }
                        if method.starts_with("containsKey") {
                            at.is_some() as u64
                        } else {
                            previous as u64
                        }
                    }
                    _ => return Ok(None),
                };
                self.object_mut(id)?.payload = Payload::Map(values);
                return Ok(Some(result));
            }
        }
        Ok(None)
    }
    pub(super) fn sequence_units(&self, id: u32) -> Result<Vec<u16>> {
        match &self.object(id)?.payload {
            Payload::String(s) | Payload::Builder(s) => Ok(s.clone()),
            _ => Err("Custom CharSequence implementation is not supported by TextUtils yet".into()),
        }
    }
}
