//! In-process Binder objects with an attached Java interface and descriptor.
use super::*;

pub(super) const BINDER: &str = "Landroid/os/Binder;";
const IBINDER: &str = "Landroid/os/IBinder;";

#[derive(Clone, Copy, Default)]
pub(super) struct Binder {
    pub owner: u32,
    pub descriptor: u32,
}

impl Runtime {
    pub(super) fn local_binder_api(
        &mut self,
        signature: &str,
        args: &[u32],
    ) -> Result<Option<u64>> {
        let (class, method) = signature.split_once("->").ok_or("Binder signature")?;
        if !matches!(class, BINDER | IBINDER) {
            return Ok(None);
        }
        let arg = |index: usize| args.get(index).copied().ok_or("Binder argument");
        if class == BINDER {
            match method {
                "getCallingPid()I" => return Ok(Some(u64::from(crate::identity::PID))),
                "getCallingUid()I" => return Ok(Some(u64::from(crate::identity::UID))),
                "<init>()V" | "<init>(Ljava/lang/String;)V" => {
                    let id = arg(0)?;
                    if !self.subclass(&self.object(id)?.class, BINDER)? {
                        return Err("Expected Binder constructor receiver".into());
                    }
                    let descriptor = if args.len() > 1 { arg(1)? } else { 0 };
                    if descriptor != 0 {
                        self.units(descriptor)?;
                    }
                    self.object_mut(id)?.payload = Payload::LocalBinder(Binder {
                        owner: 0,
                        descriptor,
                    });
                    return Ok(Some(0));
                }
                _ => {}
            }
        }
        let id = arg(0)?;
        let Payload::LocalBinder(mut binder) = self.object(id)?.payload else {
            return Ok(None);
        };
        let result = match method {
            "attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V" => {
                binder.owner = arg(1)?;
                binder.descriptor = arg(2)?;
                if binder.owner != 0 {
                    self.object(binder.owner)?;
                }
                if binder.descriptor != 0 {
                    self.units(binder.descriptor)?;
                }
                self.object_mut(id)?.payload = Payload::LocalBinder(binder);
                0
            }
            "getInterfaceDescriptor()Ljava/lang/String;" => u64::from(binder.descriptor),
            "queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;" => {
                let requested = arg(1)?;
                if binder.descriptor != 0
                    && requested != 0
                    && self.units(binder.descriptor)? == self.units(requested)?
                {
                    u64::from(binder.owner)
                } else {
                    0
                }
            }
            "pingBinder()Z" | "isBinderAlive()Z" => 1,
            _ => return Ok(None),
        };
        Ok(Some(result))
    }
}
