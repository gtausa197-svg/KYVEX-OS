package org.xmlpull.v1;
/** Compile-only signature; excluded from APK. */
public class XmlPullParserException extends Exception {public XmlPullParserException(String s){super(s);}}
