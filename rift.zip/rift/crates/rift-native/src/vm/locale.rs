//! The virtual device's locale and locale-aware String case conversion.
use super::*;
use std::ffi::{CString, c_char};

pub(super) const LOCALE: &str = "Ljava/util/Locale;";
pub(super) const DEFAULT: &std::ffi::CStr = c"en_US";

unsafe extern "C" {
    fn rift_case_map(
        text: *const u16,
        length: i32,
        locale: *const c_char,
        upper: i32,
        out: *mut u16,
        capacity: i32,
    ) -> i32;
}

impl Runtime {
    pub(super) fn default_locale(&mut self) -> Result<u32> {
        if self.us_locale == 0 {
            let language = self.string("en")?;
            let country = self.string("US")?;
            self.us_locale = self.allocate(
                LOCALE,
                Payload::Record(BTreeMap::from([
                    ("language".into(), u64::from(language)),
                    ("country".into(), u64::from(country)),
                ])),
            )?;
        }
        Ok(self.us_locale)
    }

    pub(super) fn locale_id(&self, id: u32) -> Result<CString> {
        let object = self.object(id)?;
        let Payload::Record(fields) = &object.payload else {
            return Err("Unsupported Locale value".into());
        };
        if object.class != LOCALE {
            return Err("Expected Locale".into());
        }
        let language = self.text(*fields.get("language").ok_or("Locale language")? as u32)?;
        let country = self.text(*fields.get("country").ok_or("Locale country")? as u32)?;
        Ok(CString::new(format!("{language}_{country}"))?)
    }

    pub(super) fn locale_api(&mut self, sig: &str, args: &[u32]) -> Result<Option<u64>> {
        let arg = |index: usize| args.get(index).copied().ok_or("Locale argument count");
        let upper = match sig {
            "Ljava/util/Locale;->getDefault()Ljava/util/Locale;" => {
                return Ok(Some(u64::from(self.default_locale()?)));
            }
            "Ljava/lang/String;->toLowerCase()Ljava/lang/String;"
            | "Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;" => false,
            "Ljava/lang/String;->toUpperCase()Ljava/lang/String;"
            | "Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;" => true,
            _ => return Ok(None),
        };
        let locale = args.get(1).map(|&id| self.locale_id(id)).transpose()?;
        let id = arg(0)?;
        let text = self.units(id)?;
        let mut output = vec![0; (text.len() * 3).clamp(1, 16384)];
        let length = unsafe {
            rift_case_map(
                text.as_ptr(),
                text.len() as i32,
                locale.as_deref().unwrap_or(DEFAULT).as_ptr(),
                i32::from(upper),
                output.as_mut_ptr(),
                output.len() as i32,
            )
        };
        if length < 0 || length as usize > output.len() {
            return Err(format!("ICU case conversion capability/budget error {length}").into());
        }
        output.truncate(length as usize);
        Ok(Some(u64::from(if output == text {
            id
        } else {
            self.string_units(output)?
        })))
    }
}
