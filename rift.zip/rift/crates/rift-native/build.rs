use std::{env, path::PathBuf, process::Command};

fn build_text_bridge() {
    let source = "support/platform-text.c";
    let out = PathBuf::from(env::var_os("OUT_DIR").expect("Cargo OUT_DIR"));
    let object = out.join("platform-text.o");
    println!("cargo:rerun-if-changed={source}");
    println!("cargo:rerun-if-env-changed=CC");
    println!("cargo:rerun-if-env-changed=AR");
    let cc = env::var_os("CC").unwrap_or_else(|| "cc".into());
    let status = Command::new(cc)
        .args([
            "-std=c11", "-O2", "-fPIC", "-Wall", "-Wextra", "-Werror", "-c", source, "-o",
        ])
        .arg(&object)
        .status()
        .expect("Run C compiler for the ICU and HarfBuzz bridge");
    assert!(status.success(), "Compile the ICU and HarfBuzz bridge");
    let ar = env::var_os("AR").unwrap_or_else(|| "ar".into());
    let status = Command::new(ar)
        .arg("crs")
        .arg(out.join("librift_platform_text.a"))
        .arg(object)
        .status()
        .expect("Archive the ICU and HarfBuzz bridge");
    assert!(status.success(), "Archive the ICU and HarfBuzz bridge");
    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=rift_platform_text");
    println!("cargo:rustc-link-lib=dylib=icui18n");
    println!("cargo:rustc-link-lib=dylib=icuuc");
    println!("cargo:rustc-link-lib=dylib=harfbuzz");
}

fn main() {
    build_text_bridge();
    println!("cargo:rerun-if-env-changed=KYVEX_DYNARMIC_LIB_DIR");
    if let Ok(path) = std::env::var("KYVEX_DYNARMIC_LIB_DIR") {
        println!("cargo:rustc-link-search=native={path}");
    }
    println!("cargo:rustc-link-lib=dylib=kyvex_dynarmic");
    println!("cargo:rustc-link-arg=-Wl,-rpath,/usr/lib/kyvex");
}
