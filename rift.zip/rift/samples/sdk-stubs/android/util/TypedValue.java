package android.util;
public class TypedValue {
 public int type,data,assetCookie,resourceId,changingConfigurations,density;
 public CharSequence string;
}
