// Built only for the integration executable. Uses the actual bridge and QML.
#include <QQuickWindow>
#include <QTextStream>

int testNativeEvents(QGuiApplication &app, Rift &bridge,
                     QQmlApplicationEngine &engine) {
  if (app.arguments().size() != 3)
    return 2;
  bool initial = false, delayed = false, clicked = false, finished = false;
  int frames = 0;
  const auto output = app.arguments()[2];
  auto fail = [&](QString error) {
    if (finished)
      return;
    finished = true;
    QTextStream(stderr) << error << '\n';
    bridge.closeNative();
    app.exit(1);
  };
  QObject::connect(&bridge, &Rift::nativeChanged, &app, [&] {
    ++frames;
    if (finished)
      return;
    const auto data = QJsonObject::fromVariantMap(bridge.nativeData());
    const auto widgets = data["scene"].toObject()["widgets"].toArray();
    QStringList texts;
    quint32 button = 0;
    for (const auto &widget : widgets) {
      const auto object = widget.toObject();
      texts << object["text"].toString();
      if (object["kind"] == "button")
        button = object["id"].toInteger();
    }
    if (texts.contains("Events: FABM / ticks 0"))
      initial = true;
    if (texts.contains("Events: FABMT / ticks 1")) {
      if (!initial) {
        fail("The initial frame was not observed before the delayed event");
        return;
      }
      delayed = true;
      if (!clicked) {
        clicked = true;
        QTimer::singleShot(0, &bridge,
                           [&, button] { bridge.nativeClick(button); });
      }
    }
    if (!delayed || !texts.contains("ARM result: 14"))
      return;
    finished = true;
    QTimer::singleShot(
        150, &app, [&, data] {
          QQuickWindow *window = nullptr;
          for (auto *root : engine.rootObjects()) {
            window = root->findChild<QQuickWindow *>("nativeApplicationWindow");
            if (window)
              break;
          }
          const auto image = window ? window->grabWindow() : QImage();
          const bool captured = !image.isNull() && image.save(output);
          const bool quiet = frames == 3;
          QTextStream(stdout)
              << QJsonDocument(QJsonObject{{"ok", captured && quiet},
                                           {"initial", initial},
                                           {"delayed", delayed},
                                           {"clicked", clicked},
                                           {"scene_notifications", frames},
                                           {"unchanged_scene_is_quiet", quiet},
                                           {"native", data}})
                     .toJson(QJsonDocument::Compact)
              << '\n';
          bridge.closeNative();
          app.exit(captured && quiet ? 0 : 1);
        });
  });
  QTimer::singleShot(15000, &app, [&] {
    fail("Studio event integration deadline: " + bridge.message());
  });
  const auto apk = QFileInfo(app.arguments()[1]).absoluteFilePath();
  QTimer::singleShot(1000, &bridge,
                     [&, apk] { bridge.openApk(QUrl::fromLocalFile(apk)); });
  return app.exec();
}
