package org.kyvex.extra;
/** Actual Java calls, exceptions and side effects used to verify sliced execution. */
public final class ExecutionChecks {
 public static int calls;
 public static final java.util.concurrent.atomic.AtomicInteger committedCalls=new java.util.concurrent.atomic.AtomicInteger();
 public static int term(int value){committedCalls.incrementAndGet();calls++;if(value%7==3)throw new IllegalArgumentException("term");return value*3+1;}
 public static int sequence(int count){int result=0;for(int i=0;i<count;i++){try{result+=term(i);}catch(IllegalArgumentException expected){result-=3;}}return result;}
 public static int verify(){calls=0;int value=sequence(37);if(value!=1760||calls!=37)throw new IllegalStateException("Resumable calls/exceptions replayed or lost");return value;}
 public static Object carry(int count){Object value=new Object();for(int i=0;i<count;i++){if(value.getClass()!=Object.class)throw new IllegalStateException("Lost local reference");}return value;}
 public static void main(String[] args){System.out.println("Execution result: "+verify()+" / calls: "+calls);}
}
