//! Selected Java8 String.format conversions over UTF16, never host printf.
use super::*;
use std::sync::OnceLock;
const LIMIT: usize = 16384;
const LEFT: u16 = 1;
const SHARP: u16 = 2;
const PLUS: u16 = 4;
const SPACE: u16 = 8;
const ZERO: u16 = 16;
const COMMA: u16 = 32;
const PAREN: u16 = 64;
const PREVIOUS: u16 = 128;
#[derive(Clone, Copy)]
enum Index {
    Ordinary,
    Explicit(usize),
    Previous,
}
struct Spec {
    index: Index,
    flags: u16,
    width: Option<usize>,
    precision: Option<usize>,
    conversion: u8,
    upper: bool,
    raw: String,
}
enum Token {
    Literal(Vec<u16>),
    Spec(Spec),
}
#[derive(Clone)]
enum Value {
    Null,
    Text(Vec<u16>),
    Boolean(bool),
    Character(u16),
    Integer { value: i64, bits: u8 },
    Hash(u32),
    Other { text: Vec<u16>, class: String },
}
impl Value {
    fn class(&self) -> &str {
        match self {
            Self::Null => "null",
            Self::Text(_) => "java.lang.String",
            Self::Boolean(_) => "java.lang.Boolean",
            Self::Character(_) => "java.lang.Character",
            Self::Integer { bits: 8, .. } => "java.lang.Byte",
            Self::Integer { bits: 16, .. } => "java.lang.Short",
            Self::Integer { bits: 32, .. } => "java.lang.Integer",
            Self::Integer { .. } => "java.lang.Long",
            Self::Hash(_) => "java.lang.Object",
            Self::Other { class, .. } => class,
        }
    }
}
fn error(name: &str, message: &str) -> Box<dyn std::error::Error + Send + Sync> {
    fault(&format!("Ljava/util/{name};"), message)
}
fn mismatch(spec: &Spec, flags: u16) -> Box<dyn std::error::Error + Send + Sync> {
    error(
        "FormatFlagsConversionMismatchException",
        &format!("Flags {flags:#x} for {}", spec.raw),
    )
}
fn number(units: &[u16]) -> Option<i32> {
    let mut n = 0i32;
    for unit in units {
        n = n
            .checked_mul(10)?
            .checked_add((*unit - b'0' as u16) as i32)?;
    }
    Some(n)
}
fn parse(input: &[u16]) -> Result<Vec<Token>> {
    if input.len() > 32768 {
        return Err("Formatter input quota".into());
    }
    let mut result = Vec::new();
    let mut pos = 0;
    let mut literal = 0;
    while pos < input.len() {
        if input[pos] != b'%' as u16 {
            pos += 1;
            continue;
        }
        if literal < pos {
            result.push(Token::Literal(input[literal..pos].to_vec()));
        }
        let start = pos;
        pos += 1;
        if pos == input.len() {
            return Err(error(
                "UnknownFormatConversionException",
                "Incomplete format specifier",
            ));
        }
        let digits = pos;
        while pos < input.len() && (b'0' as u16..=b'9' as u16).contains(&input[pos]) {
            pos += 1;
        }
        let index = if pos > digits && input.get(pos) == Some(&(b'$' as u16)) {
            let index = match number(&input[digits..pos]) {
                Some(0) => Index::Ordinary,
                Some(n) => Index::Explicit((n - 1) as usize),
                None => Index::Previous,
            };
            pos += 1;
            index
        } else {
            pos = digits;
            Index::Ordinary
        };
        let mut flags = 0;
        while pos < input.len() {
            let flag = match input[pos] {
                45 => LEFT,
                35 => SHARP,
                43 => PLUS,
                32 => SPACE,
                48 => ZERO,
                44 => COMMA,
                40 => PAREN,
                60 => PREVIOUS,
                _ => break,
            };
            if flags & flag != 0 {
                return Err(error(
                    "DuplicateFormatFlagsException",
                    "Repeated format flag",
                ));
            }
            flags |= flag;
            pos += 1;
        }
        let digits = pos;
        while pos < input.len() && (b'0' as u16..=b'9' as u16).contains(&input[pos]) {
            pos += 1;
        }
        let width = if pos > digits {
            Some(
                number(&input[digits..pos])
                    .ok_or_else(|| error("IllegalFormatWidthException", "Format width overflow"))?
                    as usize,
            )
        } else {
            None
        };
        let precision = if input.get(pos) == Some(&(b'.' as u16)) {
            pos += 1;
            let digits = pos;
            while pos < input.len() && (b'0' as u16..=b'9' as u16).contains(&input[pos]) {
                pos += 1;
            }
            if pos == digits {
                return Err(error(
                    "UnknownFormatConversionException",
                    "Missing precision digits",
                ));
            }
            Some(number(&input[digits..pos]).ok_or_else(|| {
                error(
                    "IllegalFormatPrecisionException",
                    "Format precision overflow",
                )
            })? as usize)
        } else {
            None
        };
        let raw_conversion = *input
            .get(pos)
            .ok_or_else(|| error("UnknownFormatConversionException", "Missing conversion"))?;
        pos += 1;
        if raw_conversion > 127 {
            return Err(error(
                "UnknownFormatConversionException",
                "Unknown format conversion",
            ));
        }
        let raw_conversion = raw_conversion as u8;
        let conversion = raw_conversion.to_ascii_lowercase();
        let upper = raw_conversion.is_ascii_uppercase();
        if !matches!(
            raw_conversion,
            b'b' | b'B'
                | b's'
                | b'S'
                | b'h'
                | b'H'
                | b'c'
                | b'C'
                | b'd'
                | b'o'
                | b'x'
                | b'X'
                | b'%'
                | b'n'
        ) {
            if matches!(
                raw_conversion,
                b'e' | b'E' | b'f' | b'g' | b'G' | b'a' | b'A' | b't' | b'T'
            ) {
                return Err("Floating/date Formatter conversions are not implemented".into());
            }
            return Err(error(
                "UnknownFormatConversionException",
                &format!("Unknown conversion {}", raw_conversion as char),
            ));
        }
        let spec = Spec {
            index: if flags & PREVIOUS != 0 {
                Index::Previous
            } else {
                index
            },
            flags,
            width,
            precision,
            conversion,
            upper,
            raw: String::from_utf16_lossy(&input[start..pos]),
        };
        let f = flags & !PREVIOUS;
        if conversion == b'n' {
            if precision.is_some() {
                return Err(error("IllegalFormatPrecisionException", &spec.raw));
            }
            if width.is_some() {
                return Err(error("IllegalFormatWidthException", &spec.raw));
            }
            if flags != 0 {
                return Err(error("IllegalFormatFlagsException", &spec.raw));
            }
        } else if conversion == b'%' {
            if precision.is_some() {
                return Err(error("IllegalFormatPrecisionException", &spec.raw));
            }
            if flags & !LEFT != 0 {
                return Err(error("IllegalFormatFlagsException", &spec.raw));
            }
            if f & LEFT != 0 && width.is_none() {
                return Err(error("MissingFormatWidthException", &spec.raw));
            }
        } else if matches!(conversion, b's' | b'b' | b'h' | b'c') {
            if conversion == b'c' && precision.is_some() {
                return Err(error("IllegalFormatPrecisionException", &spec.raw));
            }
            if matches!(conversion, b'b' | b'h') && f & SHARP != 0 {
                return Err(mismatch(&spec, SHARP));
            }
            if conversion != b'c' && f & LEFT != 0 && width.is_none() {
                return Err(error("MissingFormatWidthException", &spec.raw));
            }
            let allowed = LEFT | if conversion == b's' { SHARP } else { 0 };
            if f & !allowed != 0 {
                return Err(mismatch(&spec, f & !allowed));
            }
            if f & LEFT != 0 && width.is_none() {
                return Err(error("MissingFormatWidthException", &spec.raw));
            }
        } else {
            if f & (LEFT | ZERO) != 0 && width.is_none() {
                return Err(error("MissingFormatWidthException", &spec.raw));
            }
            if f & PLUS != 0 && f & SPACE != 0 || f & LEFT != 0 && f & ZERO != 0 {
                return Err(error("IllegalFormatFlagsException", &spec.raw));
            }
            if precision.is_some() {
                return Err(error("IllegalFormatPrecisionException", &spec.raw));
            }
            let forbidden = if conversion == b'd' { SHARP } else { COMMA };
            if f & forbidden != 0 {
                return Err(mismatch(&spec, f & forbidden));
            }
        }
        if width.is_some_and(|value| value > LIMIT) || precision.is_some_and(|value| value > LIMIT)
        {
            return Err("Formatter field quota".into());
        }
        result.push(Token::Spec(spec));
        literal = pos;
    }
    if literal < input.len() {
        result.push(Token::Literal(input[literal..].to_vec()));
    }
    Ok(result)
}
fn uppercase(input: &[u16]) -> Result<Vec<u16>> {
    type UppercaseTable = Vec<(u32, Vec<u16>)>;
    static DATA: OnceLock<std::result::Result<UppercaseTable, String>> = OnceLock::new();
    let table = DATA
        .get_or_init(|| {
            let data: serde_json::Value =
                serde_json::from_str(include_str!("../../support/java8-uppercase.json"))
                    .map_err(|error| error.to_string())?;
            let mut result = Vec::new();
            for row in data["mappings"].as_array().ok_or("Uppercase table rows")? {
                let cp = row[0].as_u64().ok_or("Uppercase codepoint")? as u32;
                let units = row[1].as_str().ok_or("Uppercase units")?;
                let (chunks, remainder) = units.as_bytes().as_chunks::<4>();
                if !remainder.is_empty() {
                    return Err("Incomplete uppercase code unit".into());
                }
                let decoded = chunks
                    .iter()
                    .map(|part| {
                        let hex = std::str::from_utf8(part).map_err(|error| error.to_string())?;
                        u16::from_str_radix(hex, 16).map_err(|error| error.to_string())
                    })
                    .collect::<std::result::Result<Vec<_>, _>>()?;
                result.push((cp, decoded));
            }
            Ok(result)
        })
        .as_ref()
        .map_err(|error| format!("Invalid trusted uppercase data: {error}"))?;
    let mut out = Vec::new();
    for cp in char::decode_utf16(input.iter().copied()) {
        match cp {
            Err(error) => out.push(error.unpaired_surrogate()),
            Ok(cp) => {
                let cp = cp as u32;
                if let Ok(index) = table.binary_search_by_key(&cp, |row| row.0) {
                    out.extend(&table[index].1);
                } else if cp <= 0xffff {
                    out.push(cp as u16);
                } else {
                    let cp = cp - 0x10000;
                    out.extend([0xd800 + (cp >> 10) as u16, 0xdc00 + (cp & 1023) as u16]);
                }
            }
        }
        if out.len() > LIMIT {
            return Err("Formatter uppercase output quota".into());
        }
    }
    Ok(out)
}
fn bounded_extend(out: &mut Vec<u16>, value: &[u16]) -> Result<()> {
    if out.len().saturating_add(value.len()) > LIMIT {
        return Err("Formatter output quota".into());
    }
    out.extend(value);
    Ok(())
}
fn general(spec: &Spec, mut value: Vec<u16>) -> Result<Vec<u16>> {
    if let Some(precision) = spec.precision {
        value.truncate(precision);
    }
    if spec.upper {
        value = uppercase(&value)?;
    }
    let padding = spec.width.unwrap_or(0).saturating_sub(value.len());
    if value.len().saturating_add(padding) > LIMIT {
        return Err("Formatter output quota".into());
    }
    if spec.flags & LEFT != 0 {
        value.resize(value.len() + padding, 32);
        Ok(value)
    } else {
        let mut out = vec![32; padding];
        out.extend(value);
        Ok(out)
    }
}
fn integer(spec: &Spec, value: i64, bits: u8) -> Result<Vec<u16>> {
    let decimal = spec.conversion == b'd';
    if !decimal && spec.flags & (PLUS | SPACE | PAREN) != 0 {
        return Err(mismatch(spec, spec.flags & (PLUS | SPACE | PAREN)));
    }
    let unsigned = if bits == 64 {
        value as u64
    } else {
        value as u64 & ((1u64 << bits) - 1)
    };
    let mut digits = match spec.conversion {
        b'd' => (value as i128).abs().to_string(),
        b'o' => format!("{unsigned:o}"),
        _ => format!("{unsigned:x}"),
    };
    if decimal && spec.flags & COMMA != 0 {
        let mut grouped = String::new();
        for (i, c) in digits.chars().enumerate() {
            if i > 0 && (digits.len() - i).is_multiple_of(3) {
                grouped.push(',');
            }
            grouped.push(c);
        }
        digits = grouped;
    }
    if spec.upper {
        digits.make_ascii_uppercase();
    }
    let negative = decimal && value < 0;
    let sign = if negative {
        if spec.flags & PAREN != 0 { "(" } else { "-" }
    } else if decimal && spec.flags & PLUS != 0 {
        "+"
    } else if decimal && spec.flags & SPACE != 0 {
        " "
    } else {
        ""
    };
    let prefix = if spec.flags & SHARP != 0 {
        if spec.conversion == b'o' {
            "0"
        } else if spec.upper {
            "0X"
        } else {
            "0x"
        }
    } else {
        ""
    };
    let suffix = if negative && spec.flags & PAREN != 0 {
        ")"
    } else {
        ""
    };
    let pad = spec
        .width
        .unwrap_or(0)
        .saturating_sub(sign.len() + prefix.len() + digits.len() + suffix.len());
    let mut out = String::new();
    if spec.flags & (LEFT | ZERO) == 0 {
        out.extend(std::iter::repeat_n(' ', pad));
    }
    out.push_str(sign);
    out.push_str(prefix);
    if spec.flags & ZERO != 0 {
        out.extend(std::iter::repeat_n('0', pad));
    }
    out.push_str(&digits);
    out.push_str(suffix);
    if spec.flags & LEFT != 0 {
        out.extend(std::iter::repeat_n(' ', pad));
    }
    if out.len() > LIMIT {
        return Err("Formatter output quota".into());
    }
    Ok(out.encode_utf16().collect())
}
fn render(spec: &Spec, value: Value) -> Result<Vec<u16>> {
    let conversion = spec.conversion;
    let text = |value: &str| value.encode_utf16().collect::<Vec<_>>();
    if conversion == b's' && spec.flags & SHARP != 0 {
        return Err(mismatch(spec, SHARP));
    }
    if matches!(value, Value::Null) {
        return general(
            spec,
            text(if conversion == b'b' { "false" } else { "null" }),
        );
    }
    let failure = || {
        error(
            "IllegalFormatConversionException",
            &format!("{} != {}", conversion as char, value.class()),
        )
    };
    let result = match conversion {
        b's' => match &value {
            Value::Text(value) | Value::Other { text: value, .. } => value.clone(),
            Value::Boolean(value) => text(if *value { "true" } else { "false" }),
            Value::Character(value) => vec![*value],
            Value::Integer { value, .. } => text(&value.to_string()),
            _ => return Err(failure()),
        },
        b'b' => text(if matches!(value, Value::Boolean(false)) {
            "false"
        } else {
            "true"
        }),
        b'h' => {
            let hash = match &value {
                Value::Hash(value) => *value,
                Value::Boolean(value) => {
                    if *value {
                        1231
                    } else {
                        1237
                    }
                }
                Value::Character(value) => *value as u32,
                Value::Integer { value, bits: 64 } => {
                    *value as u32 ^ ((*value as u64 >> 32) as u32)
                }
                Value::Integer { value, .. } => *value as u32,
                Value::Text(units) => units.iter().fold(0u32, |hash, unit| {
                    hash.wrapping_mul(31).wrapping_add(*unit as u32)
                }),
                _ => return Err(failure()),
            };
            text(&format!("{hash:x}"))
        }
        b'c' => {
            let cp = match value {
                Value::Character(value) => value as i64,
                Value::Integer { value, bits } if bits < 64 => value,
                _ => return Err(failure()),
            };
            if !(0..=0x10ffff).contains(&cp) {
                return Err(error(
                    "IllegalFormatCodePointException",
                    "Invalid format codepoint",
                ));
            }
            if cp <= 0xffff {
                vec![cp as u16]
            } else {
                let cp = cp as u32 - 0x10000;
                vec![0xd800 + (cp >> 10) as u16, 0xdc00 + (cp & 1023) as u16]
            }
        }
        b'd' | b'o' | b'x' => {
            if let Value::Integer { value, bits } = value {
                return integer(spec, value, bits);
            } else {
                return Err(failure());
            }
        }
        _ => return Err("Unsupported Formatter renderer".into()),
    };
    general(spec, result)
}
fn format_tokens(
    tokens: Vec<Token>,
    mut argument: impl FnMut(usize, &Spec) -> Result<Value>,
) -> Result<Vec<u16>> {
    let mut ordinary = 0;
    let mut previous = None;
    let mut result = Vec::new();
    for token in tokens {
        match token {
            Token::Literal(text) => bounded_extend(&mut result, &text)?,
            Token::Spec(spec) => {
                if spec.conversion == b'%' {
                    bounded_extend(&mut result, &[37])?;
                    continue;
                }
                if spec.conversion == b'n' {
                    bounded_extend(&mut result, &[10])?;
                    continue;
                }
                let index = match spec.index {
                    Index::Ordinary => {
                        let index = ordinary;
                        ordinary += 1;
                        index
                    }
                    Index::Explicit(index) => index,
                    Index::Previous => previous
                        .ok_or_else(|| error("MissingFormatArgumentException", &spec.raw))?,
                };
                previous = Some(index);
                let value = argument(index, &spec)?;
                bounded_extend(&mut result, &render(&spec, value)?)?;
            }
        }
    }
    Ok(result)
}
impl Runtime {
    fn formatting_value(&mut self, id: u32, spec: &Spec) -> Result<Value> {
        if id == 0 {
            return Ok(Value::Null);
        }
        let object = self.object(id)?;
        let class = object.class.clone();
        if spec.conversion == b's' && self.subclass(&class, "Ljava/util/Formattable;")? {
            return Err("Formattable/Formatter objects are not implemented".into());
        }
        if spec.conversion == b's' && spec.flags & SHARP != 0 {
            return Ok(Value::Other {
                text: Vec::new(),
                class,
            });
        }
        match &self.object(id)?.payload {
            Payload::String(units) => return Ok(Value::Text(units.clone())),
            Payload::Boxed { kind, bits } => {
                return Ok(match kind {
                    'Z' => Value::Boolean(*bits != 0),
                    'C' => Value::Character(*bits as u16),
                    'B' => Value::Integer {
                        value: *bits as i8 as i64,
                        bits: 8,
                    },
                    'S' => Value::Integer {
                        value: *bits as i16 as i64,
                        bits: 16,
                    },
                    'I' => Value::Integer {
                        value: *bits as i32 as i64,
                        bits: 32,
                    },
                    'J' => Value::Integer {
                        value: *bits as i64,
                        bits: 64,
                    },
                    'F' if spec.conversion == b'h' => {
                        Value::Hash(if f32::from_bits(*bits as u32).is_nan() {
                            0x7fc00000
                        } else {
                            *bits as u32
                        })
                    }
                    'D' if spec.conversion == b'h' => {
                        let bits = if f64::from_bits(*bits).is_nan() {
                            0x7ff8000000000000
                        } else {
                            *bits
                        };
                        Value::Hash(bits as u32 ^ (bits >> 32) as u32)
                    }
                    _ => Value::Other {
                        text: if spec.conversion == b's' {
                            self.object_units(id)?
                        } else {
                            Vec::new()
                        },
                        class: class
                            .trim_start_matches('L')
                            .trim_end_matches(';')
                            .replace('/', "."),
                    },
                });
            }
            _ => {}
        }
        if spec.conversion == b'h' {
            let owner = if matches!(
                self.object(id)?.payload,
                Payload::Charset(_) | Payload::Uuid(_, _) | Payload::LogLevel(_)
            ) {
                class.as_str()
            } else {
                "Ljava/lang/Object;"
            };
            return Ok(Value::Hash(
                self.collection_dispatch(id, owner, "hashCode()I", &[])? as u32,
            ));
        }
        let text = if spec.conversion == b's' {
            if let Some(method) = self.callback_method(id, "toString", "()Ljava/lang/String;")? {
                let result = self.invoke(method, &[id], true)? as u32;
                if result == 0 {
                    "null".encode_utf16().collect()
                } else {
                    self.units(result)?
                }
            } else {
                match &self.object(id)?.payload{
                Payload::Enum{name,..}=>self.units(*name)?,
                Payload::Array(_)=>format!("{}@{id:x}",class.replace('/',".")).encode_utf16().collect(),
                Payload::List(_)|Payload::Set(_)|Payload::Map(_)|Payload::HashedMap(_)|Payload::WeakMap(_)|Payload::MapView{..}|Payload::CollectionWrapper{..}|Payload::Class(_)=>return Err("Formatter string representation of this native library type is not implemented".into()),
                _=>self.object_units(id)?,
            }
            }
        } else {
            Vec::new()
        };
        Ok(Value::Other {
            text,
            class: class
                .trim_start_matches('L')
                .trim_end_matches(';')
                .replace('/', "."),
        })
    }
    pub(super) fn formatting_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        if sig
            != "Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;"
        {
            return Ok(None);
        }
        let format = *a.first().ok_or("Formatter format argument")?;
        let arguments = *a.get(1).ok_or("Formatter argument array")?;
        let tokens = parse(&self.units(format)?)?;
        let _roots = self.scoped_library_roots(&[format, arguments])?;
        if arguments != 0 {
            let object = self.object(arguments)?;
            if !matches!(object.payload, Payload::Array(_))
                || !(object.class.starts_with("[L") || object.class.starts_with("[["))
            {
                return Err("Formatter requires a reference array".into());
            }
        }
        let result = format_tokens(tokens, |index, spec| {
            let id = if arguments == 0 {
                0
            } else {
                let Payload::Array(values) = &self.object(arguments)?.payload else {
                    unreachable!()
                };
                u32::try_from(
                    *values
                        .get(index)
                        .ok_or_else(|| error("MissingFormatArgumentException", &spec.raw))?,
                )?
            };
            let _argument = self.scoped_library_roots(&[id])?;
            self.formatting_value(id, spec)
        })?;
        Ok(Some(self.string_units(result)? as u64))
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use sha2::{Digest, Sha256};
    fn decode(text: &str) -> Vec<u16> {
        text.as_bytes()
            .as_chunks::<4>()
            .0
            .iter()
            .map(|part| u16::from_str_radix(std::str::from_utf8(part).unwrap(), 16).unwrap())
            .collect()
    }
    fn value(data: &serde_json::Value) -> Value {
        let kind = data["type"].as_str().unwrap();
        let text = data["value"].as_str().unwrap_or("");
        match kind {
            "N" => Value::Null,
            "T" => Value::Text(decode(text)),
            "Z" => Value::Boolean(text == "true"),
            "C" => Value::Character(text.parse().unwrap()),
            _ => Value::Integer {
                value: text.parse().unwrap(),
                bits: match kind {
                    "B" => 8,
                    "S" => 16,
                    "I" => 32,
                    _ => 64,
                },
            },
        }
    }
    #[test]
    fn selected_conversions_match_6981_stock_java8_results_and_error_classes() {
        let data: serde_json::Value = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../tests/fixtures/formatter.json"
        )))
        .unwrap();
        let rows = data["cases"].as_array().unwrap();
        assert_eq!(rows.len(), 6981);
        let mut failures = Vec::new();
        for (index, row) in rows.iter().enumerate() {
            let input = decode(row["format"].as_str().unwrap());
            let result = parse(&input).and_then(|tokens| {
                format_tokens(tokens, |index, spec| {
                    if row["args"].is_null() {
                        Ok(Value::Null)
                    } else {
                        row["args"]
                            .get(index)
                            .map(value)
                            .ok_or_else(|| error("MissingFormatArgumentException", &spec.raw))
                    }
                })
            });
            let problem = if let Some(expected) = row["error"].as_str() {
                match result {
                    Ok(result) => Some(format!("expected {expected}, got {result:?}")),
                    Err(error) => {
                        let actual =
                            error
                                .downcast_ref::<JavaFault>()
                                .map_or("capability", |fault| {
                                    fault
                                        .class
                                        .trim_start_matches("Ljava/util/")
                                        .trim_end_matches(';')
                                });
                        (actual != expected)
                            .then(|| format!("expected {expected}, got {actual}: {error}"))
                    }
                }
            } else {
                match result {
                    Ok(actual) => {
                        let expected = decode(row["out"].as_str().unwrap());
                        (actual != expected)
                            .then(|| format!("expected {expected:?}, got {actual:?}"))
                    }
                    Err(error) => Some(format!("unexpected {error}")),
                }
            };
            if let Some(problem) = problem
                && failures.len() < 24
            {
                failures.push(format!(
                    "row{index}: {:?} {}: {problem}",
                    String::from_utf16_lossy(&input),
                    row["args"]
                ));
            }
        }
        assert!(failures.is_empty(), "{}", failures.join("\n"));
    }
    #[test]
    fn uppercase_data_is_source_bound_and_output_limits_fail_without_truncated_success() {
        let pin: serde_json::Value =
            serde_json::from_str(include_str!("../../support/java8-uppercase.pin.json")).unwrap();
        let hash = |bytes: &[u8]| format!("{:x}", Sha256::digest(bytes));
        assert_eq!(
            hash(include_bytes!("../../support/java8-uppercase.json")),
            pin["data_sha256"]
        );
        assert_eq!(
            hash(include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../samples/oracles/UppercaseData.java"
            ))),
            pin["generator_sha256"]
        );
        let data: serde_json::Value =
            serde_json::from_str(include_str!("../../support/java8-uppercase.json")).unwrap();
        assert_eq!(data["mappings"].as_array().unwrap().len(), 1126);
        assert!(parse(&"%16385s".encode_utf16().collect::<Vec<_>>()).is_err());
        let tokens = parse(&"%s%s".encode_utf16().collect::<Vec<_>>()).unwrap();
        assert!(format_tokens(tokens, |_, _| Ok(Value::Text(vec![65; 10000]))).is_err());
    }
}
