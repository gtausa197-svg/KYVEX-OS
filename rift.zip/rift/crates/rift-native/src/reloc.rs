//! Bounded Android APS2 and ELF RELR decoding. Original Rust implementation.
use crate::Result;
#[derive(Clone, Debug)]
pub struct Relocation {
    pub at: u64,
    pub info: u64,
    pub addend: Option<i64>,
}
fn signed(b: &[u8], p: &mut usize) -> Result<i64> {
    let mut value = 0i128;
    for i in 0..10 {
        let byte = *b.get(*p).ok_or("Truncated APS2 LEB128")?;
        *p += 1;
        value |= ((byte & 127) as i128) << (i * 7);
        if byte & 128 == 0 {
            if byte & 64 != 0 {
                value |= !0i128 << (7 * (i + 1));
            }
            return Ok(i64::try_from(value).map_err(|_| "APS2 LEB128 overflow")?);
        }
    }
    Err("APS2 LEB128 exceeds 64 bits".into())
}
pub fn aps2(b: &[u8], rela: bool) -> Result<Vec<Relocation>> {
    if !b.starts_with(b"APS2") {
        return Err("Invalid Android APS2 signature".into());
    }
    let mut p = 4;
    let count =
        usize::try_from(signed(b, &mut p)?).map_err(|_| "Negative APS2 relocation count")?;
    if count > 262144 {
        return Err("APS2 relocation count quota".into());
    }
    let mut at = u64::try_from(signed(b, &mut p)?).map_err(|_| "Negative APS2 initial offset")?;
    let mut result = Vec::with_capacity(count);
    let mut addend = 0i64;
    while result.len() < count {
        let n = usize::try_from(signed(b, &mut p)?).map_err(|_| "Negative APS2 group size")?;
        let flags = signed(b, &mut p)?;
        if n == 0
            || n > count - result.len()
            || !(0..=15).contains(&flags)
            || flags & 4 != 0 && flags & 8 == 0
            || !rela && flags & 8 != 0
        {
            return Err("Invalid APS2 relocation group".into());
        }
        let delta = if flags & 2 != 0 {
            signed(b, &mut p)?
        } else {
            0
        };
        let info = if flags & 1 != 0 {
            u64::try_from(signed(b, &mut p)?).map_err(|_| "Negative APS2 info")?
        } else {
            0
        };
        if flags & 8 == 0 {
            addend = 0;
        } else if flags & 4 != 0 {
            addend = addend
                .checked_add(signed(b, &mut p)?)
                .ok_or("APS2 addend overflow")?;
        }
        for _ in 0..n {
            let d = if flags & 2 != 0 {
                delta
            } else {
                signed(b, &mut p)?
            };
            at = at.checked_add_signed(d).ok_or("APS2 offset overflow")?;
            let info = if flags & 1 != 0 {
                info
            } else {
                u64::try_from(signed(b, &mut p)?).map_err(|_| "Negative APS2 info")?
            };
            if flags & 8 != 0 && flags & 4 == 0 {
                addend = addend
                    .checked_add(signed(b, &mut p)?)
                    .ok_or("APS2 addend overflow")?;
            }
            result.push(Relocation {
                at,
                info,
                addend: rela.then_some(addend),
            });
        }
    }
    if p != b.len() {
        return Err("Trailing data in APS2 relocation stream".into());
    }
    Ok(result)
}
pub fn relr(b: &[u8], wide: bool) -> Result<Vec<u64>> {
    let width = if wide { 8 } else { 4 };
    if !b.len().is_multiple_of(width) || b.len() / width > 262144 {
        return Err("Invalid RELR table size".into());
    }
    let mut result = Vec::new();
    let mut cursor = None;
    for part in b.chunks_exact(width) {
        let word = if wide {
            u64::from_le_bytes(part.try_into()?)
        } else {
            u32::from_le_bytes(part.try_into()?) as u64
        };
        if word & 1 == 0 {
            if word % (width as u64) != 0 {
                return Err("Unaligned RELR address".into());
            }
            result.push(word);
            cursor = Some(
                word.checked_add(width as u64)
                    .ok_or("RELR address overflow")?,
            );
        } else {
            let at = cursor.ok_or("RELR bitmap has no initial address")?;
            for bit in 1..width * 8 {
                if word & (1u64 << bit) != 0 {
                    result.push(
                        at.checked_add((bit - 1) as u64 * width as u64)
                            .ok_or("RELR bitmap address overflow")?,
                    );
                }
            }
            cursor = Some(
                at.checked_add((width * 8 - 1) as u64 * width as u64)
                    .ok_or("RELR cursor overflow")?,
            );
        }
        if result.len() > 262144 {
            return Err("RELR expanded relocation quota".into());
        }
    }
    Ok(result)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_malformed_packed_streams() {
        for b in [
            b"".as_slice(),
            b"APS2",
            b"APS2\x01\x00\x00\x00",
            b"APS2\x01\x00\x02\x00",
        ] {
            assert!(aps2(b, true).is_err());
        }
        assert!(aps2(b"APS2\x01\x00\x01\x08\x01\x01\x00", false).is_err());
    }
    #[test]
    fn decodes_grouped_offsets_info_and_addends() {
        let r = aps2(b"APS2\x02\x00\x02\x0f\x08\x17\x10", true).unwrap();
        assert_eq!(
            (r[0].at, r[1].at, r[0].info, r[1].addend),
            (8, 16, 23, Some(16))
        );
    }
    #[test]
    fn relr_bitmap_word_sizes_and_bounds() {
        for wide in [false, true] {
            let width = if wide { 8 } else { 4 };
            let mut b = Vec::new();
            for word in [0x1000u64, 0b1011] {
                if wide {
                    b.extend(word.to_le_bytes())
                } else {
                    b.extend((word as u32).to_le_bytes())
                }
            }
            assert_eq!(
                relr(&b, wide).unwrap(),
                vec![0x1000, 0x1000 + width, 0x1000 + width * 3]
            );
        }
        assert!(relr(&3u64.to_le_bytes(), true).is_err());
        assert!(relr(&[0; 3], false).is_err());
    }
}
