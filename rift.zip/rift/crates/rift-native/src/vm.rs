//! Bounded Java/DEX interpreter and a deliberately small Android UI API.
//! Object references are integers in a private heap, never host pointers.
use crate::{
    Result,
    assets::Assets,
    dexfile::{Body, Dex, Refs, StaticValue, mutf8_from_units, mutf8_units},
    machine::{JAVA_VM, Machine, Trap},
};
use serde::Serialize;
use std::collections::{BTreeMap, BTreeSet};
mod android;
mod apk_files;
mod arrays;
mod atomic_arrays;
mod atomic_updaters;
mod base64_api;
mod byte_input;
mod charsets;
mod collections;
#[cfg(test)]
mod compat_tests;
mod concurrency;
mod constructors;
mod content_resolver;
mod date;
mod decimal_format;
mod decimal_parse;
mod default_methods;
mod device;
mod display_api;
mod events;
mod execution;
mod executors;
mod filesystem;
mod formatting;
mod framework;
mod guest_unsafe;
mod hash_maps;
mod initialization;
mod interpolators;
mod interpreter;
mod java;
mod lang;
mod lifecycle;
mod local_binder;
mod locale;
mod logging;
mod map_set;
mod native_libraries;
mod number_parse;
mod numeric_bits;
mod objects;
mod paint;
mod pair;
mod platform;
mod point;
mod providers;
mod random;
mod readers;
mod rect;
mod references;
mod reflection;
mod regex_api;
mod resources_api;
mod rounding;
mod runtime_info;
mod rwlock;
mod scheduler;
mod services;
mod sparse;
mod sqlite;
mod stack_trace;
mod startup_trace;
mod stream_fields;
mod strict_mode;
mod string_search;
mod thread_groups;
mod thread_local;
mod threads;
mod throwable;
mod uuid_api;
mod view_configuration;
mod xml_pull;
const MAX_ARRAY_ELEMENTS: usize = 16384;
#[derive(Debug)]
struct JavaFault {
    class: String,
    object: u32,
    message: String,
}
impl std::fmt::Display for JavaFault {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Java exception {}: {}", self.class, self.message)
    }
}
impl std::error::Error for JavaFault {}
fn fault(class: &str, message: &str) -> Box<dyn std::error::Error + Send + Sync> {
    Box::new(JavaFault {
        class: class.into(),
        object: 0,
        message: message.into(),
    })
}

#[derive(Default, Clone, Serialize)]
pub struct Widget {
    pub id: u32,
    pub kind: String,
    pub text: String,
    pub color: u32,
    pub size: f32,
    pub children: Vec<u32>,
    pub padding: [u32; 4],
    #[serde(skip)]
    pub listener: u32,
}
#[derive(Clone, Serialize)]
pub struct Scene {
    pub title: String,
    pub background: u32,
    pub widgets: Vec<Widget>,
    pub root: u32,
    pub padding: [u32; 4],
    pub no_title: bool,
}
enum Payload {
    Instance,
    String(Vec<u16>),
    Builder(Vec<u16>),
    Array(Vec<u64>),
    Class(String),
    Charset(charsets::Encoding),
    Logger(logging::Logger),
    LogLevel(logging::Level),
    List(Vec<u32>),
    ArrayListView(u32),
    Set(Vec<u32>),
    Map(Vec<(u32, u32)>),
    HashedMap(hash_maps::HashMapData),
    WeakMap(Vec<(u32, u32)>),
    MapView {
        map: u32,
        kind: u8,
    },
    MapEntry {
        map: u32,
        key: u32,
        insertion_hash: Option<u32>,
        readonly: bool,
    },
    Iterator(collections::IteratorState),
    MapSet {
        map: u32,
        keys: u32,
    },
    ReadOnlyIterator {
        iterator: u32,
        protect_entries: bool,
    },
    CollectionWrapper {
        target: u32,
        readonly: bool,
        mutex: u32,
    },
    Reference {
        target: u32,
        queue: u32,
        enqueued: bool,
    },
    ReferenceQueue(Vec<u32>),
    Enum {
        name: u32,
        ordinal: u32,
    },
    Random(random::Random),
    Uuid(u64, u64),
    SparseInt(Vec<(i32, i32)>),
    Date(i64),
    Decimal(Option<decimal_format::Decimal>),
    Paint(paint::Paint),
    Executor(concurrency::Executor),
    ExecutorWrapper(u32),
    HandoffQueue(Option<bool>),
    ScheduledQueue(executors::scheduled::Queue),
    ScheduledTask(executors::scheduled::Task),
    PoolWorker(executors::Worker),
    ThreadFactory(executors::Factory),
    Latch(Option<u32>),
    ThreadGroup(thread_groups::Group),
    Looper(u32),
    Handler(events::Handler),
    Messenger(u32),
    MessengerBinder(u32),
    LocalBinder(local_binder::Binder),
    Record(BTreeMap<String, u64>),
    File(Vec<u16>),
    FileStream(Option<filesystem::Stream>),
    ByteInput(Option<byte_input::Input>),
    SqliteHelper(Option<sqlite::Helper>),
    SqliteDatabase(Option<Box<sqlite::Open>>),
    SqliteCursor(sqlite::Cursor),
    Reader(Option<readers::Reader>),
    Xml(Option<Box<xml_pull::Parser>>),
    ReflectedField(reflection::Field),
    StreamField(stream_fields::Field),
    FieldUpdater(atomic_updaters::Updater),
    AtomicArray {
        kind: char,
        values: Option<Vec<u64>>,
    },
    ReflectedConstructor(constructors::Constructor),
    DeviceStorageContext,
    StrictPolicy(u32),
    StrictPolicyBuilder(u32),
    Preferences(crate::preferences::Name),
    PreferenceEditor(android::Editor),
    Intent(android::Intent),
    Component {
        package: u32,
        name: u32,
    },
    Boxed {
        kind: char,
        bits: u64,
    },
    Pattern(std::rc::Rc<crate::regex::Regex>),
    Matcher(regex_api::Matcher),
    Lock {
        owner: u32,
        holds: u32,
        fair: bool,
    },
    RwLock(rwlock::RwLock),
    RwView(rwlock::View),
    Atomic {
        value: u64,
        kind: char,
    },
    Bundle(BTreeMap<Option<Vec<u16>>, objects::BundleValue>),
    BundleKeys(u32),
}
struct Object {
    class: String,
    fields: BTreeMap<usize, u64>,
    payload: Payload,
    version: u64,
}
pub struct Runtime {
    pub dex: Dex,
    pub machine: Machine,
    libraries: Assets,
    fonts: crate::fonts::Fonts,
    heap: BTreeMap<u32, Object>,
    next: u32,
    statics: BTreeMap<usize, u64>,
    initialization_states: BTreeMap<usize, initialization::State>,
    defer_initialization: bool,
    pub scene: Scene,
    widgets: BTreeMap<u32, Widget>,
    activity: u32,
    application: u32,
    package_name: String,
    fuel: u64,
    depth: usize,
    callers: Vec<usize>,
    native_calls: u32,
    pub instructions: u64,
    pub bit_operations: u64,
    pub events: u64,
    heap_limit: usize,
    monitors: BTreeMap<u32, scheduler::Monitor>,
    registered: BTreeMap<usize, u64>,
    globals: BTreeMap<u32, u32>,
    pending_jni_exception: u32,
    jni_buffers: BTreeMap<u64, (usize, u32, bool)>,
    pub logs: Vec<String>,
    logging: logging::State,
    executors: executors::State,
    clock: std::time::Instant,
    startup_trace: Option<startup_trace::Trace>,
    properties: BTreeMap<Vec<u16>, Vec<u16>>,
    class_loader: u32,
    literals: BTreeMap<Vec<u16>, u32>,
    interned: BTreeMap<Vec<u16>, u32>,
    class_objects: BTreeMap<String, u32>,
    preferences: crate::preferences::Store,
    preference_handles: BTreeMap<crate::preferences::Name, u32>,
    launch_intent: u32,
    launcher_name: String,
    boxed_cache: BTreeMap<(char, u64), u32>,
    charsets: [u32; 6],
    preference_listeners: BTreeMap<crate::preferences::Name, BTreeSet<u32>>,
    default_uncaught: u32,
    guest_unsafe: guest_unsafe::State,
    current_thread: u32,
    main_thread: u32,
    system_group: u32,
    main_group: u32,
    scheduler: scheduler::Scheduler,
    suspension_allowed: bool,
    time_units: BTreeMap<u32, u32>,
    main_looper: u32,
    pending_events: Vec<events::Pending>,
    next_event: u64,
    files: crate::vfs::Fs,
    metadata: Option<framework::Metadata>,
    application_info: u32,
    package_manager: u32,
    providers: Vec<u32>,
    next_thread_id: u64,
    next_thread_name: u64,
    thread_local_values: BTreeMap<u32, u32>,
    resource_table: Option<crate::resources::Table>,
    resources: u32,
    resource_config: u32,
    display_metrics: u32,
    asset_manager: u32,
    library_status: BTreeMap<String, native_libraries::Status>,
    activity_callbacks: Vec<u32>,
    component_callbacks: Vec<u32>,
    activity_stage: u8,
    activity_manager: u32,
    window_manager: u32,
    user_manager: u32,
    empty_collections: [u32; 3],
    java_runtime: u32,
    us_locale: u32,
    rounding_modes: [u32; 8],
    math_random: Option<random::Random>,
    gc_requested: bool,
    execution_roots: execution::Roots,
    trace_contexts: stack_trace::Registry,
    next_execution: u64,
}
impl Runtime {
    pub fn new(mut dex: Dex, machine: Machine, libraries: Assets, heap_limit: usize) -> Self {
        let properties = platform::properties(machine.arch);
        dex.remove_class_definitions(crate::android_json::is_platform_class);
        Self {
            dex,
            machine,
            libraries,
            fonts: crate::fonts::Fonts::default(),
            heap: BTreeMap::new(),
            next: 0x60000000,
            statics: BTreeMap::new(),
            initialization_states: BTreeMap::new(),
            defer_initialization: false,
            scene: Scene {
                title: "Rift Native".into(),
                background: 0xff101a2a,
                widgets: Vec::new(),
                root: 0,
                padding: [0; 4],
                no_title: false,
            },
            widgets: BTreeMap::new(),
            activity: 0,
            application: 0,
            package_name: "org.kyvex.nativehello".into(),
            fuel: 0,
            depth: 0,
            callers: Vec::new(),
            native_calls: 0,
            instructions: 0,
            bit_operations: 0,
            events: 0,
            heap_limit,
            monitors: BTreeMap::new(),
            registered: BTreeMap::new(),
            globals: BTreeMap::new(),
            pending_jni_exception: 0,
            jni_buffers: BTreeMap::new(),
            logs: Vec::new(),
            logging: logging::State::default(),
            executors: executors::State::default(),
            clock: std::time::Instant::now(),
            startup_trace: None,
            properties,
            class_loader: 0,
            literals: BTreeMap::new(),
            interned: BTreeMap::new(),
            class_objects: BTreeMap::new(),
            preferences: crate::preferences::Store::default(),
            preference_handles: BTreeMap::new(),
            launch_intent: 0,
            launcher_name: String::new(),
            boxed_cache: BTreeMap::new(),
            charsets: [0; 6],
            preference_listeners: BTreeMap::new(),
            default_uncaught: 0,
            guest_unsafe: guest_unsafe::State::default(),
            current_thread: 0,
            main_thread: 0,
            system_group: 0,
            main_group: 0,
            scheduler: scheduler::Scheduler::default(),
            suspension_allowed: false,
            time_units: BTreeMap::new(),
            main_looper: 0,
            pending_events: Vec::new(),
            next_event: 1,
            files: crate::vfs::Fs::new(heap_limit / 2, "org.kyvex.nativehello"),
            metadata: None,
            application_info: 0,
            package_manager: 0,
            providers: Vec::new(),
            next_thread_id: 2,
            next_thread_name: 0,
            thread_local_values: BTreeMap::new(),
            resource_table: None,
            resources: 0,
            resource_config: 0,
            display_metrics: 0,
            asset_manager: 0,
            library_status: BTreeMap::new(),
            activity_callbacks: Vec::new(),
            component_callbacks: Vec::new(),
            activity_stage: 0,
            activity_manager: 0,
            window_manager: 0,
            user_manager: 0,
            empty_collections: [0; 3],
            java_runtime: 0,
            us_locale: 0,
            rounding_modes: [0; 8],
            math_random: None,
            gc_requested: false,
            execution_roots: Default::default(),
            trace_contexts: Default::default(),
            next_execution: 1,
        }
    }
    pub fn heap_bytes(&self) -> usize {
        let thread_local_bytes = self.thread_local_values.len() * 48
            + self.scheduler_bytes()
            + self.initialization_bytes()
            + self
                .trace_contexts
                .borrow()
                .values()
                .map(|context| 64 + context.methods.len() * 8)
                .sum::<usize>();
        thread_local_bytes
            + self
                .execution_roots
                .borrow()
                .values()
                .map(|v| 48 + v.capacity() * 4)
                .sum::<usize>()
            + self.guest_unsafe.bytes()
            + self.logging.bytes()
            + self.logs.iter().map(|s| 24 + s.capacity()).sum::<usize>()
            + (self.activity_callbacks.capacity() + self.component_callbacks.capacity()) * 4
            + self.providers.capacity() * 4
            + self
                .library_status
                .iter()
                .map(|(name, status)| 64 + name.len() + status.bytes())
                .sum::<usize>()
            + self.resource_table.as_ref().map_or(0, |t| t.bytes())
            + self
                .heap
                .values()
                .map(|o| {
                    128 + o.class.len()
                        + o.fields.len() * 24
                        + match &o.payload {
                            Payload::String(s) | Payload::Builder(s) => s.len() * 2,
                            Payload::Class(s) => s.len(),
                            Payload::SparseInt(v) => v.capacity() * 8,
                            Payload::ThreadGroup(g) => 32 + g.children.capacity() * 4,
                            Payload::File(s) => s.len() * 2,
                            Payload::Reader(Some(reader)) => reader.bytes(),
                            Payload::SqliteDatabase(Some(db)) => db.bytes(),
                            Payload::SqliteCursor(cursor) => cursor.rows.bytes(),
                            Payload::Executor(executor) => executor.workers.capacity() * 4,
                            Payload::ScheduledQueue(queue) => queue.bytes(),
                            Payload::Xml(Some(parser)) => parser.bytes(),
                            Payload::FieldUpdater(updater) => updater.bytes(),
                            Payload::AtomicArray {
                                values: Some(values),
                                ..
                            } => values.capacity() * 8,
                            Payload::ReflectedField(f) => {
                                f.owner.len() + f.name.len() + f.descriptor.len() + 64
                            }
                            Payload::ReflectedConstructor(c) => {
                                c.owner.len()
                                    + c.descriptor.len()
                                    + c.parameters.iter().map(|p| 24 + p.len()).sum::<usize>()
                                    + 64
                            }
                            Payload::Array(a) => a.len() * 8,
                            Payload::List(v) | Payload::Set(v) => v.len() * 4,
                            Payload::Map(v) | Payload::WeakMap(v) => v.len() * 8,
                            Payload::HashedMap(map) => map.bytes(),
                            Payload::Iterator(i) => i.snapshot.as_ref().map_or(0, |s| s.len() * 4),
                            Payload::ReferenceQueue(v) => v.len() * 4,
                            Payload::Preferences(n) => n.units.len() * 2,
                            Payload::PreferenceEditor(e) => e.bytes(),
                            Payload::Intent(i) => i.categories.len() * 4,
                            Payload::Record(v) => v.keys().map(|k| 64 + k.len()).sum(),
                            Payload::Pattern(p) => p.bytes + p.source.len() * 2,
                            Payload::Decimal(Some(_)) => 16 * 1024,
                            Payload::Matcher(m) => m.groups.as_ref().map_or(0, |g| g.len() * 24),
                            Payload::RwLock(lock) => lock.bytes(),
                            Payload::Bundle(v) => v
                                .keys()
                                .map(|k| 64 + k.as_ref().map_or(0, |k| k.len() * 2))
                                .sum(),
                            _ => 0,
                        }
                })
                .sum::<usize>()
            + self.pending_events.len() * 64
            + self.preferences.bytes()
            + self.files.bytes()
            + self.metadata.as_ref().map_or(0, |m| m.bytes())
            + self
                .properties
                .iter()
                .map(|(k, v)| 64 + (k.len() + v.len()) * 2)
                .sum::<usize>()
            + self
                .literals
                .keys()
                .map(|k| 48 + k.len() * 2)
                .sum::<usize>()
            + self
                .interned
                .keys()
                .map(|k| 48 + k.len() * 2)
                .sum::<usize>()
            + self
                .class_objects
                .keys()
                .map(|k| 48 + k.len())
                .sum::<usize>()
    }
    fn allocate(&mut self, class: &str, payload: Payload) -> Result<u32> {
        if self.heap.len() >= 16384 || self.heap_bytes() > self.heap_limit {
            return Err("Java heap quota exceeded".into());
        }
        let id = self.next;
        self.next = self
            .next
            .checked_add(8)
            .ok_or("Object handle space exhausted")?;
        self.heap.insert(
            id,
            Object {
                class: class.into(),
                fields: BTreeMap::new(),
                payload,
                version: 0,
            },
        );
        Ok(id)
    }
    fn string(&mut self, s: &str) -> Result<u32> {
        self.string_units(s.encode_utf16().collect())
    }
    fn string_units(&mut self, s: Vec<u16>) -> Result<u32> {
        if s.len() > 16384 {
            return Err("Java string quota (16 KiB)".into());
        }
        self.allocate("Ljava/lang/String;", Payload::String(s))
    }
    fn literal(&mut self, units: Vec<u16>) -> Result<u32> {
        if let Some(id) = self.literals.get(&units) {
            return Ok(*id);
        }
        let id = if let Some(id) = self.interned.get(&units) {
            *id
        } else {
            self.string_units(units.clone())?
        };
        self.literals.insert(units.clone(), id);
        self.interned.insert(units, id);
        Ok(id)
    }
    fn units(&self, id: u32) -> Result<Vec<u16>> {
        match &self.object(id)?.payload {
            Payload::String(s) => Ok(s.clone()),
            _ => Err("Expected Java string".into()),
        }
    }
    fn text(&self, id: u32) -> Result<String> {
        if id == 0 {
            return Ok("null".into());
        }
        match &self.object(id)?.payload {
            Payload::String(s) => Ok(String::from_utf16_lossy(s)),
            _ => Err("Expected a Java string".into()),
        }
    }
    fn string_equals(&self, left: u32, right: u32) -> Result<bool> {
        let Payload::String(left) = &self.object(left)?.payload else {
            return Err("Expected a Java string receiver".into());
        };
        if right == 0 {
            return Ok(false);
        }
        Ok(matches!(&self.object(right)?.payload,Payload::String(right) if left==right))
    }
    fn object(&self, id: u32) -> Result<&Object> {
        if id == 0 {
            return Err(fault(
                "Ljava/lang/NullPointerException;",
                "null object reference",
            ));
        }
        self.heap
            .get(&id)
            .ok_or_else(|| format!("Invalid Java object handle 0x{id:x}").into())
    }
    fn object_mut(&mut self, id: u32) -> Result<&mut Object> {
        if id == 0 {
            return Err(fault(
                "Ljava/lang/NullPointerException;",
                "null object reference",
            ));
        }
        self.heap
            .get_mut(&id)
            .ok_or_else(|| format!("Invalid Java object handle 0x{id:x}").into())
    }
    fn load_field(&self, id: u32, index: usize) -> Result<u64> {
        let object = self.object(id)?;
        let field = self.dex.fields.get(index).ok_or("DEX field index")?;
        let name = &self.dex.strings[field.name];
        if let Some(slot) = pair::field_slot(self.dex.ty(field.class), name) {
            return Ok(object.fields.get(&slot).copied().unwrap_or(0));
        }
        Ok(if let Payload::Record(fields) = &object.payload {
            *fields.get(name).unwrap_or(&0)
        } else {
            *object.fields.get(&index).unwrap_or(&0)
        })
    }
    fn store_field(&mut self, id: u32, index: usize, value: u64) -> Result<()> {
        let field = self
            .dex
            .fields
            .get(index)
            .ok_or("Native record field index")?;
        let name = self.dex.strings[field.name].clone();
        if pair::field_slot(self.dex.ty(field.class), &name).is_some() {
            return Err(fault(
                "Ljava/lang/IllegalAccessError;",
                "Pair fields are final",
            ));
        }
        let object = self.object_mut(id)?;
        if let Payload::Record(fields) = &mut object.payload {
            if fields.len() >= 64 && !fields.contains_key(&name) {
                return Err("Native record field quota".into());
            }
            fields.insert(name, value);
        } else {
            object.fields.insert(index, value);
        }
        Ok(())
    }
    fn subclass(&self, class: &str, base: &str) -> Result<bool> {
        if collections::inherits(class, base) {
            return Ok(true);
        }
        if let Some(ty) = self.dex.type_id(class) {
            let mut pending = vec![ty];
            let mut seen = BTreeSet::new();
            while let Some(ty) = pending.pop() {
                if !seen.insert(ty) {
                    continue;
                }
                if seen.len() > 256 {
                    return Err("Java interface graph budget".into());
                }
                if self.dex.ty(ty) == base {
                    return Ok(true);
                }
                if let Some(class) = self.dex.classes.get(&ty) {
                    pending.extend(&class.interfaces);
                    if let Some(parent) = class.parent {
                        pending.push(parent);
                    }
                } else {
                    // An app can implement a framework interface which itself
                    // extends another interface absent from the APK's DEX.
                    let mut name = self.dex.ty(ty);
                    for _ in 0..64 {
                        if lang::inherits(name, base)
                            || collections::inherits(name, base)
                            || concurrency::inherits(name, base)
                            || filesystem::inherits(name, base)
                            || display_api::inherits(name, base)
                            || interpolators::inherits(name, base)
                            || rect::inherits(name, base)
                        {
                            return Ok(true);
                        }
                        let Some(parent) = framework_parent(name) else {
                            break;
                        };
                        if parent == base {
                            return Ok(true);
                        }
                        name = parent;
                    }
                }
            }
        }
        let mut name = class;
        for _ in 0..64 {
            if lang::inherits(name, base)
                || collections::inherits(name, base)
                || concurrency::inherits(name, base)
                || filesystem::inherits(name, base)
                || readers::inherits(name, base)
                || display_api::inherits(name, base)
                || interpolators::inherits(name, base)
                || rect::inherits(name, base)
            {
                return Ok(true);
            }
            if name == base || base == "Ljava/lang/Object;" {
                return Ok(true);
            }
            let parent = self
                .dex
                .type_id(name)
                .and_then(|ty| self.dex.classes.get(&ty))
                .and_then(|class| class.parent)
                .map(|ty| self.dex.ty(ty))
                .or_else(|| framework_parent(name));
            let Some(parent) = parent else {
                return Ok(false);
            };
            name = parent;
        }
        Err("DEX class hierarchy depth/cycle limit".into())
    }
    fn instantiate(&mut self, class: &str) -> Result<u32> {
        let payload = if matches!(
            class,
            "Ljava/lang/StringBuilder;" | "Ljava/lang/StringBuffer;"
        ) {
            Payload::Builder(Vec::new())
        } else if let Some(payload) = java::payload(class)
            .or_else(|| references::payload(class))
            .or_else(|| android::payload(class))
            .or_else(|| events::payload(class))
            .or_else(|| filesystem::payload(class))
            .or_else(|| readers::payload(class))
            .or_else(|| framework::payload(class))
            .or_else(|| interpolators::payload(class))
            .or_else(|| rect::payload(class))
            .or_else(|| device::payload(class))
            .or_else(|| strict_mode::payload(class))
        {
            payload
        } else if self.dex.has_class(class)
            || self.subclass(class, "Landroid/view/View;")?
            || matches!(
                class,
                "Landroid/widget/LinearLayout;"
                    | "Landroid/widget/TextView;"
                    | "Landroid/widget/Button;"
                    | "Ljava/lang/Object;"
                    | "Ljava/lang/Thread;"
                    | "Landroid/app/Application;"
                    | "Landroid/content/ContextWrapper;"
                    | pair::PAIR
            )
            || self.subclass(class, "Ljava/lang/Throwable;")?
        {
            Payload::Instance
        } else {
            return Err(format!("Unsupported Android/Java class {class}").into());
        };
        let id = self.allocate(class, payload)?;
        if self.subclass(class, "Landroid/view/View;")? {
            if self.widgets.len() >= 128 {
                return Err("Native UI widget quota".into());
            }
            let kind = if self.subclass(class, "Landroid/widget/Button;")? {
                "button"
            } else if self.subclass(class, "Landroid/widget/TextView;")? {
                "text"
            } else if self.subclass(class, "Landroid/widget/LinearLayout;")? {
                "column"
            } else {
                "frame"
            };
            self.widgets.insert(
                id,
                Widget {
                    id,
                    kind: kind.into(),
                    text: String::new(),
                    color: 0xffeeeeff,
                    size: 18.0,
                    children: Vec::new(),
                    listener: 0,
                    padding: [0; 4],
                },
            );
        }
        Ok(id)
    }
    fn reset_budget(&mut self) {
        self.fuel = 200000;
        self.depth = 0;
        self.native_calls = 0;
    }
    fn ensure_class(&mut self, name: &str) -> Result<()> {
        if self.dex.has_class(name) {
            return Ok(());
        }
        if crate::android_json::is_platform_class(name) {
            return self.dex.append(Dex::parse(crate::android_json::DEX)?);
        }
        if let Some(mut dex) = self.libraries.dex_for_class(name)? {
            if dex
                .classes
                .keys()
                .any(|ty| dex.ty(*ty).starts_with("Lorg/kyvex/rift/internal/"))
            {
                return Err("APK defines reserved Native support namespace".into());
            }
            dex.remove_class_definitions(crate::android_json::is_platform_class);
            self.dex.append(dex)?;
        }
        Ok(())
    }
    pub fn apk_fd(&self) -> i32 {
        self.libraries.fd()
    }
    pub fn preferences_file(&mut self, path: &std::path::Path) -> Result<()> {
        self.preferences = crate::preferences::Store::open(path)?;
        Ok(())
    }
    pub fn preferences_fd(&self) -> Option<i32> {
        self.preferences.fd()
    }
    pub fn loaded_dex(&self) -> usize {
        self.libraries.dex_loaded
    }
    pub fn start_application(&mut self, package: &str, application: &str) -> Result<()> {
        self.reset_budget();
        if self.metadata.as_ref().is_some_and(|m| m.package != package) {
            return Err("APK metadata/package mismatch".into());
        }
        self.package_name = package.into();
        if !rift_core::apk::package_valid(package) {
            return Err("Invalid application package for virtual files".into());
        }
        self.files = crate::vfs::Fs::new(self.heap_limit / 2, package);
        self.mount_native_libraries()?;
        self.properties
            .insert("user.dir".encode_utf16().collect(), self.files.cwd.clone());
        self.properties.insert(
            "java.io.tmpdir".encode_utf16().collect(),
            crate::vfs::join(&self.files.cwd, &crate::vfs::units("cache")),
        );
        let class = if application.is_empty() {
            "Landroid/app/Application;".into()
        } else {
            format!("L{};", application.replace('.', "/"))
        };
        self.ensure_class(&class)?;
        if let Some(ty) = self.dex.type_id(&class) {
            self.initialize(ty)?;
        }
        let obj = self.instantiate(&class)?;
        self.application = obj;
        if let Some(init) = self.dex.find(&class, "<init>", "()V") {
            self.invoke(init, &[obj], false)?;
        }
        let context = self.allocate("Landroid/app/ContextImpl;", Payload::Instance)?;
        if let Some(attach) =
            self.dex
                .find(&class, "attachBaseContext", "(Landroid/content/Context;)V")
            && self.dex.bodies.contains_key(&attach)
        {
            self.invoke(attach, &[obj, context], false)?;
        } else {
            self.hle(
                "Landroid/app/Application;->attachBaseContext(Landroid/content/Context;)V",
                &[obj, context],
            )?;
        }
        self.start_providers(context)?;
        if let Some(create) = self.dex.find(&class, "onCreate", "()V")
            && self.dex.bodies.contains_key(&create)
        {
            self.invoke(create, &[obj], false)?;
        }
        Ok(())
    }
    pub fn start(&mut self, launcher: &str) -> Result<Scene> {
        self.reset_budget();
        self.launcher_name = launcher.into();
        let class = format!("L{};", launcher.replace('.', "/"));
        self.ensure_class(&class)?;
        let ty = self
            .dex
            .type_id(&class)
            .ok_or("Launcher activity is absent from the APK's DEX files")?;
        self.initialize(ty)?;
        let obj = self.instantiate(&class)?;
        self.activity = obj;
        let init = self
            .dex
            .find(&class, "<init>", "()V")
            .ok_or("Launcher needs a no-argument constructor")?;
        self.invoke(init, &[obj], false)?;
        let context = self.allocate("Landroid/app/ContextImpl;", Payload::Instance)?;
        self.object_mut(obj)?
            .fields
            .insert(usize::MAX - 1, context as u64);
        let oncreate = self
            .dex
            .find(&class, "onCreate", "(Landroid/os/Bundle;)V")
            .ok_or("Unsupported activity: no onCreate(Bundle)")?;
        self.invoke(oncreate, &[obj, 0], false)?;
        if self.activity_stage != 1 {
            return Err(fault(
                "Landroid/util/SuperNotCalledException;",
                "Activity did not call super.onCreate",
            ));
        }
        self.activity_transition("onStart", 2)?;
        self.activity_transition("onResume", 3)?;
        self.process_events(32)?;
        if self.scene.root == 0 {
            return Err("The activity did not provide a supported native UI".into());
        }
        self.finish_scene()
    }
    pub fn click(&mut self, id: u32) -> Result<Scene> {
        self.reset_budget();
        let w = self.widgets.get(&id).ok_or("Unknown native widget")?;
        if w.kind != "button" || w.listener == 0 {
            return Err("This widget has no click handler".into());
        }
        let listener = w.listener;
        let class = self.object(listener)?.class.clone();
        let index = self
            .dex
            .find(&class, "onClick", "(Landroid/view/View;)V")
            .ok_or("Unsupported click-listener implementation")?;
        self.invoke(index, &[listener, id], true)?;
        self.events += 1;
        self.process_events(32)?;
        self.finish_scene()
    }
    pub fn tick(&mut self) -> Result<Scene> {
        self.reset_budget();
        self.ensure_main_thread()?;
        self.pump_guest_workers(8)?;
        self.process_events(32)?;
        self.finish_scene()
    }
    pub fn pending_events(&self) -> usize {
        self.pending_events.len()
    }
    pub fn guest_threads(&self) -> usize {
        self.scheduler
            .records
            .values()
            .filter(|r| r.alive())
            .count()
    }
    pub fn thread_switches(&self) -> u64 {
        self.scheduler.switches
    }
    pub fn virtual_file_bytes(&self) -> usize {
        self.files.bytes()
    }
    fn collect(&mut self) -> Result<()> {
        self.gc_requested = false;
        // Events and top-level execution safe points can collect. Registered
        // execution leases retain paused Java frames and returned references.
        let mut roots = vec![
            self.activity,
            self.application,
            self.scene.root,
            self.class_loader,
            self.launch_intent,
            self.default_uncaught,
            self.guest_unsafe.singleton,
            self.current_thread,
            self.main_thread,
            self.system_group,
            self.main_group,
            self.main_looper,
            self.application_info,
            self.package_manager,
            self.resources,
            self.resource_config,
            self.display_metrics,
            self.asset_manager,
            self.activity_manager,
            self.window_manager,
            self.user_manager,
            self.java_runtime,
            self.us_locale,
        ];
        roots.extend(self.preference_handles.values().copied());
        roots.extend(self.empty_collections);
        for frame_roots in self.execution_roots.borrow().values() {
            roots.extend(frame_roots);
        }
        roots.extend(self.activity_callbacks.iter().copied());
        roots.extend(self.component_callbacks.iter().copied());
        roots.extend(self.providers.iter().copied());
        roots.extend(self.thread_local_values.values().copied());
        roots.extend(self.scheduler_roots());
        roots.extend(self.initialization_roots());
        roots.extend(self.boxed_cache.values().copied());
        roots.extend(self.charsets);
        roots.extend(self.rounding_modes);
        roots.extend(self.logging.roots());
        roots.extend(self.time_units.values().copied());
        for event in &self.pending_events {
            roots.extend([event.handler, event.message]);
        }
        roots.extend(self.statics.values().filter_map(|v| u32::try_from(*v).ok()));
        roots.extend(self.monitors.keys().copied());
        roots.extend(self.globals.keys().copied());
        roots.extend(self.literals.values().copied());
        roots.extend(self.class_objects.values().copied());
        roots.extend(self.jni_buffers.values().map(|(_, id, _)| *id));
        let mut live = BTreeSet::new();
        while let Some(id) = roots.pop() {
            if id == 0 || !live.insert(id) {
                continue;
            }
            if let Some(widget) = self.widgets.get(&id) {
                roots.push(widget.listener);
                roots.extend(&widget.children);
            }
            if let Some(o) = self.heap.get(&id) {
                roots.extend(self.scheduler_object_roots(id));
                roots.extend(o.fields.values().filter_map(|v| u32::try_from(*v).ok()));
                if let Payload::Array(a) = &o.payload {
                    roots.extend(a.iter().filter_map(|v| u32::try_from(*v).ok()));
                }
                match &o.payload {
                    Payload::Atomic { value, kind: 'R' } => roots.push(*value as u32),
                    Payload::AtomicArray {
                        kind: 'R',
                        values: Some(values),
                    } => roots.extend(values.iter().map(|v| *v as u32)),
                    Payload::Bundle(v) => roots.extend(
                        v.values()
                            .filter(|v| matches!(v.kind, 'S' | 'B'))
                            .map(|v| v.value as u32),
                    ),
                    Payload::Matcher(m) => {
                        roots.push(m.pattern);
                        roots.push(m.input);
                    }
                    Payload::RwLock(lock) => roots.extend(lock.roots()),
                    Payload::RwView(view) => roots.push(view.parent),
                    Payload::LocalBinder(binder) => roots.extend([binder.owner, binder.descriptor]),
                    Payload::List(v) | Payload::Set(v) => roots.extend(v),
                    Payload::WeakMap(v) => roots.extend(v.iter().map(|(_, v)| *v)),
                    Payload::MapView { map, .. } => roots.push(*map),
                    Payload::BundleKeys(bundle) => roots.push(*bundle),
                    Payload::Reader(Some(reader)) => roots.push(reader.reference()),
                    Payload::ByteInput(Some(input)) => roots.push(input.array),
                    Payload::SqliteHelper(Some(helper)) => roots.extend(helper.roots()),
                    Payload::Logger(logger) => {
                        roots.extend([logger.name, logger.level, logger.parent])
                    }
                    Payload::LogLevel(level) => roots.push(level.name),
                    Payload::ArrayListView(array) => roots.push(*array),
                    Payload::Xml(Some(parser)) => roots.push(parser.input),
                    Payload::CollectionWrapper { target, mutex, .. } => {
                        roots.extend([*target, *mutex])
                    }
                    Payload::MapSet { map, keys } => roots.extend([*map, *keys]),
                    Payload::ReadOnlyIterator { iterator, .. } => roots.push(*iterator),
                    Payload::Reference { queue, .. } => roots.push(*queue),
                    Payload::ReferenceQueue(v) => roots.extend(v),
                    Payload::Intent(i) => {
                        roots.extend([i.action, i.data, i.component, i.package, i.extras]);
                        roots.extend(&i.categories);
                    }
                    Payload::Component { package, name } => roots.extend([*package, *name]),
                    Payload::Enum { name, .. } => roots.push(*name),
                    Payload::StreamField(field) => {
                        roots.extend([field.name, field.ty, field.signature])
                    }
                    Payload::ThreadGroup(g) => {
                        roots.extend([g.name, g.parent]);
                        roots.extend(&g.children);
                    }
                    Payload::Executor(e) => {
                        roots.extend([e.queue, e.factory, e.handler]);
                        roots.extend(&e.workers);
                    }
                    Payload::PoolWorker(worker) => {
                        roots.extend([worker.pool, worker.thread, worker.first, worker.active])
                    }
                    Payload::ScheduledQueue(queue) => roots.extend(queue.roots()),
                    Payload::ScheduledTask(task) => roots.extend(task.roots()),
                    Payload::ThreadFactory(factory) => roots.push(factory.group),
                    Payload::ExecutorWrapper(id) => roots.push(*id),
                    Payload::Looper(thread) => roots.push(*thread),
                    Payload::Handler(h) => roots.extend([h.looper, h.callback, h.messenger_binder]),
                    Payload::Messenger(binder) => roots.push(*binder),
                    Payload::MessengerBinder(handler) => roots.push(*handler),
                    Payload::Record(fields) => roots.extend(
                        fields
                            .iter()
                            .filter(|(key, _)| framework::record_reference(&o.class, key))
                            .map(|(_, value)| value)
                            .filter_map(|v| u32::try_from(*v).ok()),
                    ),
                    Payload::MapEntry { map, key, .. } => {
                        roots.push(*map);
                        roots.push(*key);
                    }
                    Payload::Iterator(i) => {
                        roots.push(i.source);
                        if let Some(data) = &i.snapshot {
                            roots.extend(data);
                        }
                    }
                    Payload::Map(v) => {
                        for (k, v) in v {
                            roots.push(*k);
                            roots.push(*v);
                        }
                    }
                    Payload::HashedMap(map) => {
                        roots.extend(map.entries.iter().flat_map(|&(key, value)| [key, value]));
                    }
                    _ => {}
                }
            }
        }
        let mut enqueued = Vec::new();
        for (id, object) in &mut self.heap {
            if live.contains(id)
                && let Payload::Reference {
                    target,
                    queue,
                    enqueued: queued,
                } = &mut object.payload
                && *target != 0
                && !live.contains(target)
            {
                *target = 0;
                if *queue != 0 && !*queued {
                    enqueued.push((*queue, *id));
                    *queued = true;
                }
            }
        }
        for (queue, id) in enqueued {
            if let Some(Object {
                payload: Payload::ReferenceQueue(entries),
                ..
            }) = self.heap.get_mut(&queue)
            {
                entries.push(id);
            }
        }
        for object in self.heap.values_mut() {
            if let Payload::WeakMap(entries) = &mut object.payload {
                entries.retain(|(key, _)| *key == 0 || live.contains(key));
            }
        }
        for (id, object) in &self.heap {
            if !live.contains(id)
                && let Payload::SqliteDatabase(Some(db)) = &object.payload
                && let Some(inode) = db.inode
            {
                self.files.release_inode_reservation(inode);
                self.files.close(inode);
            }
            if !live.contains(id)
                && let Payload::FileStream(Some(stream)) = &object.payload
                && !stream.closed
            {
                self.files.close(stream.inode);
            }
        }
        self.heap.retain(|id, _| live.contains(id));
        self.logging.named.retain(|_, id| live.contains(id));
        self.scheduler.records.retain(|id, _| live.contains(id));
        self.widgets.retain(|id, _| live.contains(id));
        for listeners in self.preference_listeners.values_mut() {
            listeners.retain(|id| live.contains(id));
        }
        self.interned.retain(|_, id| self.heap.contains_key(id));
        if self.heap_bytes() > self.heap_limit {
            return Err("Java heap quota exceeded".into());
        }
        Ok(())
    }
    fn finish_scene(&mut self) -> Result<Scene> {
        self.collect()?;
        let mut pending = vec![(self.scene.root, 0)];
        let mut seen = BTreeSet::new();
        let mut visible = Vec::new();
        while let Some((id, depth)) = pending.pop() {
            if depth > 16 || !seen.insert(id) {
                return Err("Native UI tree cycle/depth/duplicate parent".into());
            }
            let w = self
                .widgets
                .get(&id)
                .ok_or("Native UI tree references an unknown view")?;
            if w.kind == "frame" {
                return Err(
                    "Frame/custom View presentation requires the Native graphics bridge".into(),
                );
            }
            for child in w.children.iter().rev() {
                pending.push((*child, depth + 1));
            }
            visible.push(w.clone());
        }
        self.scene.padding = self
            .widgets
            .get(&self.scene.root)
            .ok_or("Content view missing")?
            .padding;
        if visible
            .iter()
            .any(|w| w.id != self.scene.root && w.padding != [0; 4])
        {
            return Err("Native 0.3 supports padding on the root layout only".into());
        }
        self.scene.widgets = visible;
        Ok(self.scene.clone())
    }
    fn descriptor(&self, index: usize) -> String {
        let s = self.dex.signature(index);
        s[s.find('(').unwrap()..].to_owned()
    }
    fn invoke(&mut self, index: usize, args: &[u32], virtual_call: bool) -> Result<u64> {
        self.ensure_main_thread()?;
        let previous = std::mem::replace(&mut self.suspension_allowed, false);
        let begun = self.begin_execution(index, args, virtual_call);
        self.suspension_allowed = previous;
        let mut execution = begun?;
        let result = self.drive_guest_execution(&mut execution);
        if result.is_err() {
            self.cancel_execution(&mut execution)?;
            if let Some(record) = self.scheduler.records.get_mut(&self.current_thread) {
                record.state = scheduler::State::Runnable;
                record.ready = None;
            }
        }
        result
    }
    fn native(&mut self, index: usize, args: &[u32]) -> Result<u64> {
        self.native_calls += 1;
        if self.native_calls > 128 {
            return Err("JNI call quota per event".into());
        }
        let m = self.dex.methods[index].clone();
        let p = self.dex.protos[m.proto].clone();
        let class = self.dex.ty(m.class).to_owned();
        let name = self.dex.strings[m.name].clone();
        let symbol = format!(
            "Java_{}_{}",
            mangle(class.trim_start_matches('L').trim_end_matches(';')),
            mangle(&name)
        );
        let address = self
            .registered
            .get(&index)
            .copied()
            .map(Ok)
            .unwrap_or_else(|| {
                self.native_export(&symbol).or_else(|_| {
                    let suffix = p
                        .parameters
                        .iter()
                        .map(|i| self.dex.ty(*i))
                        .collect::<String>();
                    self.native_export(&format!("{symbol}__{}", mangle(&suffix)))
                })
            })?;
        let static_method = self.dex.bodies[&index].access & 8 != 0;
        let receiver = if static_method {
            self.class_object(&class)?
        } else {
            *args.first().ok_or("JNI receiver missing")?
        };
        let mut at = if static_method { 0 } else { 1 };
        let mut native_args = Vec::new();
        for ty in &p.parameters {
            let word = *args.get(at).ok_or("JNI DEX argument bounds")?;
            at += 1;
            let value = match self.dex.ty(*ty) {
                "J" | "D" => {
                    let high = *args.get(at).ok_or("JNI wide argument bounds")?;
                    at += 1;
                    let bits = word as u64 | ((high as u64) << 32);
                    if self.dex.ty(*ty) == "J" {
                        crate::abi::Value::Wide(bits)
                    } else {
                        crate::abi::Value::Double(bits)
                    }
                }
                "F" => crate::abi::Value::Float(word),
                "I" | "S" | "B" | "C" | "Z" => crate::abi::Value::Word(word),
                name if name.starts_with('L') || name.starts_with('[') => {
                    if word != 0 {
                        self.object(word)?;
                    }
                    crate::abi::Value::Word(word)
                }
                _ => return Err("Unsupported JNI parameter descriptor".into()),
            };
            native_args.push(value);
        }
        if at != args.len() {
            return Err("JNI DEX argument word count mismatch".into());
        }
        let result_type = self.dex.ty(p.result).to_owned();
        let jni_env = self.machine.jni_env;
        let state = crate::abi::prepare(
            &mut self.machine,
            address,
            jni_env,
            receiver as u64,
            &native_args,
        )?;
        let state = self.run_native(state)?;
        Ok(crate::abi::returned(
            &state,
            self.machine.arch,
            &result_type,
        ))
    }
    fn native_bridge(&mut self, address: u64, args: &[u64]) -> Result<u64> {
        let state = self.machine.prepare(address, args)?;
        Ok(self.run_native(state)?.regs[0])
    }
    fn run_native(&mut self, mut state: crate::cpu::State) -> Result<crate::cpu::State> {
        for _ in 0..1024 {
            match self.advance_native(&mut state)? {
                Trap::Returned(_) => {
                    if self.pending_jni_exception != 0 {
                        let object = std::mem::take(&mut self.pending_jni_exception);
                        let class = self.object(object)?.class.clone();
                        return Err(Box::new(JavaFault {
                            class,
                            object,
                            message: "JNI pending exception".into(),
                        }));
                    }
                    return Ok(state);
                }
                Trap::Exit(code) => return Err(format!("JNI library exited ({code})").into()),
                Trap::Vm(index) => {
                    if state.regs[0] != JAVA_VM {
                        return Err("Invalid guest JavaVM pointer".into());
                    }
                    if index != 6 {
                        return Err(format!("Unsupported JavaVM function {index}").into());
                    }
                    if !matches!(state.regs[2], 0x10002 | 0x10004 | 0x10006 | 0x10008) {
                        state.regs[0] = (-3i32) as u32 as u64;
                    } else {
                        self.write_pointer(state.regs[1], self.machine.jni_env)?;
                        state.regs[0] = 0;
                    }
                }
                Trap::Jni(index) => {
                    if state.regs[0] != self.machine.jni_env {
                        return Err("Invalid guest JNIEnv pointer".into());
                    }
                    state.regs[0] = match self.jni(index, &state.regs) {
                        Ok(v) => v,
                        Err(error) => {
                            let Some(e) = error.downcast_ref::<JavaFault>() else {
                                return Err(error);
                            };
                            self.pending_jni_exception = self.materialize_fault(e)?;
                            0
                        }
                    };
                }
            }
        }
        Err("JNI transition quota".into())
    }
    fn load_library(&mut self, name: &str) -> Result<()> {
        if name.is_empty()
            || name.len() > 80
            || !name
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'_' | b'-' | b'.' | b'+'))
        {
            return Err("Invalid native library name".into());
        }
        let name = format!("lib{name}.so");
        self.load_library_file(&name)
    }
    fn read_pointer(&self, at: u64) -> Result<u64> {
        let width = if self.machine.arch == 64 { 8 } else { 4 };
        let b = self.machine.cpu.memory().bytes(at, width)?;
        Ok(if width == 8 {
            u64::from_le_bytes(b.as_slice().try_into()?)
        } else {
            u32::from_le_bytes(b.as_slice().try_into()?) as u64
        })
    }
    fn write_pointer(&mut self, at: u64, value: u64) -> Result<()> {
        if self.machine.arch == 64 {
            self.machine
                .cpu
                .memory_mut()
                .write(at, &value.to_le_bytes())
        } else {
            self.machine
                .cpu
                .memory_mut()
                .write(at, &u32::try_from(value)?.to_le_bytes())
        }
    }
    fn class_object(&mut self, class: &str) -> Result<u32> {
        if let Some(id) = self.class_objects.get(class) {
            return Ok(*id);
        }
        let id = self.allocate("Ljava/lang/Class;", Payload::Class(class.into()))?;
        self.class_objects.insert(class.into(), id);
        Ok(id)
    }
    fn jni_arg(&self, a: &[u64; 32], i: usize) -> Result<u64> {
        if self.machine.arch == 32 && i >= 4 {
            let at = a[13]
                .checked_add(((i - 4) * 4) as u64)
                .ok_or("JNI stack argument overflow")?;
            self.read_pointer(at)
        } else {
            a.get(i).copied().ok_or_else(|| "JNI argument index".into())
        }
    }
    fn string_buffer(&mut self, id: u32, utf: bool, copy: u64) -> Result<u64> {
        let words = self.units(id)?;
        let mut b = if utf {
            mutf8_from_units(&words)
        } else {
            words.iter().flat_map(|v| v.to_le_bytes()).collect()
        };
        b.extend(if utf { vec![0] } else { vec![0, 0] });
        let size = b.len().div_ceil(4096) * 4096;
        let mut at = 0x68000000;
        while self.jni_buffers.contains_key(&at) {
            at += 0x10000;
        }
        if at >= 0x69000000 {
            return Err("JNI string buffer quota".into());
        }
        self.machine
            .cpu
            .memory_mut()
            .map(at, size, crate::memory::READ | crate::memory::WRITE)?;
        self.machine.cpu.memory_mut().write(at, &b)?;
        if copy != 0 {
            self.machine.cpu.memory_mut().write(copy, &[1])?;
        }
        self.jni_buffers.insert(at, (size, id, utf));
        Ok(at)
    }
    fn jni(&mut self, index: u32, a: &[u64; 32]) -> Result<u64> {
        let object = |i: usize| u32::try_from(a[i]).map_err(|_| "JNI object handle width");
        Ok(match index {
            4 => 0x10006,
            13 => {
                let id = object(1)?;
                let class = self.object(id)?.class.clone();
                if !self.subclass(&class, "Ljava/lang/Throwable;")? {
                    return Err("JNI Throw requires Throwable".into());
                }
                self.pending_jni_exception = id;
                0
            }
            14 => {
                let class = match &self.object(object(1)?)?.payload {
                    Payload::Class(c) => c.clone(),
                    _ => return Err("JNI ThrowNew requires jclass".into()),
                };
                if !self.subclass(&class, "Ljava/lang/Throwable;")? {
                    return Err("JNI ThrowNew class is not Throwable".into());
                }
                let id = self.allocate(&class, Payload::Instance)?;
                let text = mutf8_units(&self.machine.cbytes(a[2], 65536)?)?;
                let message = self.string_units(text)?;
                self.object_mut(id)?
                    .fields
                    .insert(usize::MAX, message as u64);
                self.capture_throwable_stack(id)?;
                self.pending_jni_exception = id;
                0
            }
            15 => self.pending_jni_exception as u64,
            17 => {
                self.pending_jni_exception = 0;
                0
            }
            6 => {
                let name = String::from_utf8(self.machine.cbytes(a[1], 512)?)?;
                let class = if name.starts_with('[') {
                    name
                } else {
                    format!("L{name};")
                };
                self.ensure_class(&class)?;
                if !self.dex.has_class(&class) && framework_parent(&class).is_none() {
                    return Err(format!("Unsupported JNI FindClass {class}").into());
                }
                self.class_object(&class)? as u64
            }
            21 | 25 => {
                let id = object(1)?;
                if id != 0 {
                    self.object(id)?;
                    if index == 21 {
                        let count = self.globals.entry(id).or_default();
                        *count = count.checked_add(1).ok_or("JNI global reference count")?;
                    }
                }
                id as u64
            }
            22 => {
                let id = object(1)?;
                if id != 0 {
                    let count = self
                        .globals
                        .get_mut(&id)
                        .ok_or("JNI global reference does not exist")?;
                    *count -= 1;
                    if *count == 0 {
                        self.globals.remove(&id);
                    }
                }
                0
            }
            23 => {
                let id = object(1)?;
                if id != 0 {
                    self.object(id)?;
                }
                0
            }
            24 => {
                for id in [object(1)?, object(2)?] {
                    if id != 0 {
                        self.object(id)?;
                    }
                }
                (a[1] == a[2]) as u64
            }
            26 => {
                if a[1] > 512 {
                    return Err("JNI local reference capacity quota".into());
                }
                0
            }
            31 => {
                let class = self.object(object(1)?)?.class.clone();
                self.class_object(&class)? as u64
            }
            32 => {
                let class = match &self.object(object(2)?)?.payload {
                    Payload::Class(c) => c.clone(),
                    _ => return Err("JNI IsInstanceOf expects jclass".into()),
                };
                let id = object(1)?;
                (id == 0 || self.subclass(&self.object(id)?.class, &class)?) as u64
            }
            163 => {
                let count = usize::try_from(a[2])?;
                if count > 16384 {
                    return Err("JNI UTF-16 allocation quota".into());
                }
                let b = self.machine.cpu.memory().bytes(a[1], count * 2)?;
                self.string_units(
                    b.as_chunks::<2>()
                        .0
                        .iter()
                        .map(|p| u16::from_le_bytes([p[0], p[1]]))
                        .collect(),
                )? as u64
            }
            164 => self.units(object(1)?)?.len() as u64,
            165 | 169 => self.string_buffer(object(1)?, index == 169, a[2])?,
            166 | 170 => {
                let (size, id, utf) = *self
                    .jni_buffers
                    .get(&a[2])
                    .ok_or("Unknown JNI string buffer")?;
                if id != object(1)? || utf != (index == 170) {
                    return Err("JNI string release object/type mismatch".into());
                }
                self.machine.cpu.memory_mut().unmap(a[2], size)?;
                self.jni_buffers.remove(&a[2]);
                0
            }
            167 => {
                let b = self.machine.cbytes(a[1], 65536)?;
                self.string_units(mutf8_units(&b)?)? as u64
            }
            168 => mutf8_from_units(&self.units(object(1)?)?).len() as u64,
            171 => match &self.object(object(1)?)?.payload {
                Payload::Array(v) => v.len() as u64,
                _ => return Err("JNI GetArrayLength expects array".into()),
            },
            175..=182 => {
                let types = ["[Z", "[B", "[C", "[S", "[I", "[J", "[F", "[D"];
                let n = usize::try_from(a[1])?;
                if n > 16384 {
                    return Err("JNI array quota".into());
                }
                self.allocate(types[(index - 175) as usize], Payload::Array(vec![0; n]))? as u64
            }
            199..=214 => {
                let writing = index >= 207;
                let kind = if writing { index - 207 } else { index - 199 } as usize;
                let width = [1usize, 1, 2, 2, 4, 8, 4, 8][kind];
                let types = ["[Z", "[B", "[C", "[S", "[I", "[J", "[F", "[D"];
                let id = object(1)?;
                let start = usize::try_from(a[2])?;
                let len = usize::try_from(a[3])?;
                let buffer = self.jni_arg(a, 4)?;
                let obj = self.object(id)?;
                if obj.class != types[kind] {
                    return Err("JNI array region type mismatch".into());
                }
                let Payload::Array(array) = &obj.payload else {
                    return Err("JNI array payload missing".into());
                };
                let end = start
                    .checked_add(len)
                    .filter(|end| *end <= array.len())
                    .ok_or_else(|| {
                        fault(
                            "Ljava/lang/ArrayIndexOutOfBoundsException;",
                            "JNI array region",
                        )
                    })?;
                if writing {
                    let b = self.machine.cpu.memory().bytes(buffer, len * width)?;
                    let values = b
                        .chunks_exact(width)
                        .map(|s| {
                            s.iter()
                                .enumerate()
                                .fold(0u64, |value, (i, b)| value | (*b as u64) << (8 * i))
                        })
                        .collect::<Vec<_>>();
                    let Payload::Array(array) = &mut self.object_mut(id)?.payload else {
                        unreachable!()
                    };
                    array[start..end].copy_from_slice(&values);
                } else {
                    let b = array[start..end]
                        .iter()
                        .flat_map(|v| v.to_le_bytes()[..width].to_vec())
                        .collect::<Vec<_>>();
                    self.machine.cpu.memory_mut().write(buffer, &b)?;
                }
                0
            }
            215 => {
                let class = match &self.object(object(1)?)?.payload {
                    Payload::Class(c) => c.clone(),
                    _ => return Err("RegisterNatives expects jclass".into()),
                };
                let count = usize::try_from(a[3])?;
                if count > 1024 {
                    return Err("JNI registration quota".into());
                }
                let width = if self.machine.arch == 64 { 8 } else { 4 };
                let mut staged = Vec::new();
                for i in 0..count {
                    let at = a[2]
                        .checked_add((i * 3 * width) as u64)
                        .ok_or("JNI registration address overflow")?;
                    let name = self.read_pointer(at)?;
                    let sig = self.read_pointer(at + width as u64)?;
                    let function = self.read_pointer(at + 2 * width as u64)?;
                    let name = String::from_utf8(self.machine.cbytes(name, 512)?)?;
                    let sig = String::from_utf8(self.machine.cbytes(sig, 512)?)?;
                    let method = self.dex.find(&class, &name, &sig).ok_or_else(|| {
                        format!("JNI registration method missing: {class}->{name}{sig}")
                    })?;
                    if !self
                        .dex
                        .bodies
                        .get(&method)
                        .is_some_and(|b| b.access & 0x100 != 0)
                    {
                        return Err("RegisterNatives requires a declared native method".into());
                    }
                    if self.machine.arch == 64 && !function.is_multiple_of(4) {
                        return Err("Unaligned ARM64 JNI function".into());
                    }
                    self.machine.cpu.memory().read(
                        function & !1,
                        &mut [0; 4],
                        crate::memory::EXEC,
                    )?;
                    if staged.iter().any(|(m, _)| *m == method) {
                        return Err("Duplicate JNI registration entry".into());
                    }
                    staged.push((method, function));
                }
                self.registered.extend(staged);
                0
            }
            216 => {
                let class = match &self.object(object(1)?)?.payload {
                    Payload::Class(c) => c.clone(),
                    _ => return Err("UnregisterNatives expects jclass".into()),
                };
                let methods = self
                    .dex
                    .methods
                    .iter()
                    .enumerate()
                    .filter_map(|(i, m)| (self.dex.ty(m.class) == class).then_some(i))
                    .collect::<Vec<_>>();
                for i in methods {
                    self.registered.remove(&i);
                }
                0
            }
            219 => {
                self.write_pointer(a[1], JAVA_VM)?;
                0
            }
            220 | 221 => {
                let units = self.units(object(1)?)?;
                let start = usize::try_from(a[2])?;
                let len = usize::try_from(a[3])?;
                let end = start
                    .checked_add(len)
                    .filter(|end| *end <= units.len())
                    .ok_or_else(|| {
                        fault(
                            "Ljava/lang/StringIndexOutOfBoundsException;",
                            "JNI string region",
                        )
                    })?;
                let b = if index == 221 {
                    mutf8_from_units(&units[start..end])
                } else {
                    units[start..end]
                        .iter()
                        .flat_map(|w| w.to_le_bytes())
                        .collect()
                };
                let buffer = self.jni_arg(a, 4)?;
                self.machine.cpu.memory_mut().write(buffer, &b)?;
                0
            }
            228 => (self.pending_jni_exception != 0) as u64,
            232 => {
                let id = object(1)?;
                if id == 0 {
                    0
                } else {
                    self.object(id)?;
                    if self.globals.contains_key(&id) { 2 } else { 1 }
                }
            }
            _ => return Err(format!("Unsupported JNI function table index {index}").into()),
        })
    }
    fn hle(&mut self, sig: &str, a: &[u32]) -> Result<u64> {
        if let Some(value) = self.arrays_api(sig, a)? {
            return Ok(value);
        }
        // These static APIs accept null or primitive words in the first slot.
        // Dispatch them before receiver-based Android and collection fallbacks.
        if sig.starts_with("Ljava/util/Objects;->")
            || sig.starts_with("Ljava/lang/Math;->")
            || sig.starts_with("Ljava/lang/StrictMath;->")
        {
            return self
                .core_api(sig, a)?
                .ok_or_else(|| format!("Unsupported Android/Java API {sig}").into());
        }
        if let Some(value) = self.handoff_queue_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = self.formatting_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = self.executors_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = self.logging_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = self.sqlite_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = self.number_parse_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = self.double_parse_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = self.strict_mode_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = self.base64_api(sig, a)? {
            return Ok(value);
        }
        if let Some(value) = numeric_bits::invoke(sig, a)? {
            self.bit_operations = self.bit_operations.saturating_add(1);
            return Ok(value);
        }
        if let Some(value) = self.stack_trace_api(sig, a)? {
            return Ok(value);
        }
        if let Some(v) = self.scheduler_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.readers_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.charset_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.services_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.lifecycle_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.apk_file_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.provider_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.thread_local_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.throwable_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.resources_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.uuid_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.date_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.locale_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.decimal_format_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.rounding_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.paint_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.point_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.view_configuration_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.display_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.interpolator_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.rect_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.local_binder_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.sparse_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.device_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.pair_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.content_resolver_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.framework_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.constructor_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.reflection_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.guest_unsafe_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.thread_metadata_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.thread_group_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.stream_field_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.filesystem_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.events_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.concurrency_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.random_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.lang_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.xml_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.string_search_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.android_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.references_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.map_set_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.collections_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.runtime_info_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.atomic_array_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.updater_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.object_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.platform_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.regex_api(sig, a)? {
            return Ok(v);
        }
        if let Some(v) = self.core_api(sig, a)? {
            return Ok(v);
        }
        let (_, method) = sig.split_once("->").ok_or("Invalid method signature")?;
        let receiver = || a.first().copied().ok_or("Missing Java receiver");
        let arg = |i: usize| a.get(i).copied().ok_or("Missing Java argument");
        match sig {
            "Ljava/lang/Object;-><init>()V"
            | "Ljava/util/AbstractMap;-><init>()V"
            | "Ljava/util/AbstractCollection;-><init>()V"
            | "Ljava/util/AbstractSet;-><init>()V"
            | "Ljava/util/concurrent/AbstractExecutorService;-><init>()V"
            | "Landroid/app/Activity;-><init>()V"
            | "Landroid/app/Application;-><init>()V" => {
                self.object(receiver()?)?;
                return Ok(0);
            }
            "Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V" => return Ok(0),
            "Landroid/app/Activity;->onStart()V"
            | "Landroid/app/Activity;->onResume()V"
            | "Landroid/app/Application;->onCreate()V" => return Ok(0),
            "Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V"
            | "Landroid/app/Application;->attachBaseContext(Landroid/content/Context;)V" => {
                self.object(arg(1)?)?;
                self.object_mut(receiver()?)?
                    .fields
                    .insert(usize::MAX - 1, arg(1)? as u64);
                return Ok(0);
            }
            "Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V" => {
                let name = self.text(arg(0)?)?;
                self.load_library(&name)
                    .map_err(|e| fault("Ljava/lang/UnsatisfiedLinkError;", &e.to_string()))?;
                return Ok(0);
            }
            "Ljava/lang/StringBuilder;-><init>()V" => return Ok(0),
            "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V" => {
                let s = self.units(arg(1)?)?;
                self.object_mut(receiver()?)?.payload = Payload::Builder(s);
                return Ok(0);
            }
            "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;"
            | "Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;" => {
                let id = receiver()?;
                let s = if method.contains("append(I)") {
                    (arg(1)? as i32)
                        .to_string()
                        .encode_utf16()
                        .collect::<Vec<_>>()
                } else {
                    if arg(1)? == 0 {
                        "null".encode_utf16().collect()
                    } else {
                        self.units(arg(1)?)?
                    }
                };
                match &mut self.object_mut(id)?.payload {
                    Payload::Builder(b) => {
                        if b.len() + s.len() > 16384 {
                            return Err("StringBuilder quota".into());
                        }
                        b.extend(&s)
                    }
                    _ => return Err("Expected StringBuilder".into()),
                }
                return Ok(id as u64);
            }
            "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;" => {
                let text = match &self.object(receiver()?)?.payload {
                    Payload::Builder(s) => s.clone(),
                    _ => return Err("Expected StringBuilder".into()),
                };
                return Ok(self.string_units(text)? as u64);
            }
            "Ljava/lang/String;->length()I" => {
                return Ok(self.units(receiver()?)?.len() as u64);
            }
            "Ljava/lang/String;->charAt(I)C" => {
                let words = self.units(receiver()?)?;
                return Ok(*words
                    .get(arg(1)? as usize)
                    .ok_or_else(|| fault("Ljava/lang/StringIndexOutOfBoundsException;", "charAt"))?
                    as u64);
            }
            "Ljava/lang/String;->toString()Ljava/lang/String;" => {
                self.units(receiver()?)?;
                return Ok(receiver()? as u64);
            }
            "Ljava/lang/String;->intern()Ljava/lang/String;" => {
                let id = receiver()?;
                let units = self.units(id)?;
                if let Some(found) = self.interned.get(&units) {
                    return Ok(*found as u64);
                }
                self.interned.insert(units, id);
                return Ok(id as u64);
            }
            "Ljava/lang/String;->hashCode()I" => {
                return Ok(self
                    .units(receiver()?)?
                    .iter()
                    .fold(0u32, |h, c| h.wrapping_mul(31).wrapping_add(*c as u32))
                    as u64);
            }
            "Ljava/lang/Object;->equals(Ljava/lang/Object;)Z" => {
                self.object(receiver()?)?;
                return Ok((receiver()? == arg(1)?) as u64);
            }
            "Ljava/lang/Object;->hashCode()I" => {
                self.object(receiver()?)?;
                return Ok(receiver()? as u64);
            }
            "Ljava/lang/String;->equals(Ljava/lang/Object;)Z" => {
                return Ok(self.string_equals(receiver()?, arg(1)?)? as u64);
            }
            "Ljava/lang/String;->valueOf(I)Ljava/lang/String;" => {
                return Ok(self.string(&(arg(0)? as i32).to_string())? as u64);
            }
            _ => {}
        }
        if self.widgets.contains_key(&receiver().unwrap_or(0))
            && method.starts_with("<init>(Landroid/content/Context;")
        {
            let id = receiver()?;
            if !self.widgets.contains_key(&id) {
                return Err("Unknown UI constructor".into());
            }
            let context = arg(1)?;
            self.object(context)?;
            self.object_mut(id)?
                .fields
                .insert(usize::MAX - 70, context as u64);
            return Ok(0);
        }
        let id = match a.first() {
            Some(id) => *id,
            None => return Err(format!("Unsupported Android/Java API {sig}").into()),
        };
        if self.subclass(&self.object(id)?.class, "Landroid/content/Context;")? {
            match method {
                "getPackageName()Ljava/lang/String;" => {
                    let name = self.package_name.clone();
                    return Ok(self.string(&name)? as u64);
                }
                "getApplicationContext()Landroid/content/Context;"
                | "getApplication()Landroid/app/Application;" => return Ok(self.application as u64),
                _ => {}
            }
        }
        if self.subclass(&self.object(id)?.class, "Landroid/app/Activity;")? {
            match method {
                "requestWindowFeature(I)Z" => {
                    if self.scene.root != 0 {
                        return Err(fault(
                            "Ljava/lang/RuntimeException;",
                            "Window features must be requested before content",
                        ));
                    }
                    if arg(1)? == 1 {
                        self.scene.no_title = true;
                        return Ok(1);
                    }
                    return Ok(0);
                }
                "setTitle(Ljava/lang/CharSequence;)V" => {
                    self.scene.title = self.text(arg(1)?)?;
                    return Ok(0);
                }
                "setContentView(Landroid/view/View;)V" => {
                    let root = arg(1)?;
                    if !self.widgets.contains_key(&root) {
                        return Err("Unknown content view".into());
                    }
                    self.scene.root = root;
                    return Ok(0);
                }
                _ => {}
            }
        }
        if self.widgets.contains_key(&id) {
            match method {
                "getContext()Landroid/content/Context;" => {
                    return Ok(*self
                        .object(id)?
                        .fields
                        .get(&(usize::MAX - 70))
                        .ok_or("View context is not initialized")?);
                }
                "setText(Ljava/lang/CharSequence;)V" => {
                    let text = self.text(arg(1)?)?;
                    self.widgets.get_mut(&id).unwrap().text = text;
                    return Ok(0);
                }
                "setTextColor(I)V" => {
                    self.widgets.get_mut(&id).unwrap().color = arg(1)?;
                    return Ok(0);
                }
                "setTextSize(F)V" => {
                    let size = f32::from_bits(arg(1)?);
                    if !size.is_finite() || !(4.0..=96.0).contains(&size) {
                        return Err("Invalid UI font size".into());
                    }
                    self.widgets.get_mut(&id).unwrap().size = size;
                    return Ok(0);
                }
                "setBackgroundColor(I)V" => {
                    self.scene.background = arg(1)?;
                    return Ok(0);
                }
                "setPadding(IIII)V" => {
                    let padding = [arg(1)?, arg(2)?, arg(3)?, arg(4)?];
                    if padding.iter().any(|v| *v > 128) {
                        return Err("Native UI padding exceeds the supported range".into());
                    }
                    self.widgets.get_mut(&id).unwrap().padding = padding;
                    return Ok(0);
                }
                "setOrientation(I)V" => {
                    if arg(1)? != 1 {
                        return Err("Native 0.3 supports vertical LinearLayout".into());
                    }
                    return Ok(0);
                }
                "addView(Landroid/view/View;)V" => {
                    let child = arg(1)?;
                    if !self.widgets.contains_key(&child) || child == id {
                        return Err("Invalid UI child".into());
                    }
                    let w = self.widgets.get_mut(&id).unwrap();
                    if w.children.len() >= 128 || w.children.contains(&child) {
                        return Err("UI child quota/duplicate".into());
                    }
                    w.children.push(child);
                    return Ok(0);
                }
                "setOnClickListener(Landroid/view/View$OnClickListener;)V" => {
                    let listener = arg(1)?;
                    if listener != 0 {
                        self.object(listener)?;
                    }
                    self.widgets.get_mut(&id).unwrap().listener = listener;
                    return Ok(0);
                }
                _ => {}
            }
        }
        Err(format!("Unsupported Android/Java API {sig}").into())
    }
}
fn framework_parent(class: &str) -> Option<&'static str> {
    if let Some(parent) = display_api::parent(class)
        .or_else(|| interpolators::parent(class))
        .or_else(|| rect::parent(class))
    {
        return Some(parent);
    }
    Some(match class {
        "Ljava/util/concurrent/atomic/AtomicReferenceArray;"
        | "Ljava/util/concurrent/atomic/AtomicIntegerArray;"
        | "Ljava/util/concurrent/atomic/AtomicLongArray;" => "Ljava/lang/Object;",
        "Lorg/kyvex/rift/ReferenceFieldUpdater;" => {
            "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;"
        }
        "Lorg/kyvex/rift/IntegerFieldUpdater;" => {
            "Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;"
        }
        "Lorg/kyvex/rift/LongFieldUpdater;" => {
            "Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;"
        }
        "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;"
        | "Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;"
        | "Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;" => "Ljava/lang/Object;",
        date::DATE
        | "Ljava/util/UUID;"
        | "Ljava/util/concurrent/Executors$DefaultThreadFactory;"
        | concurrency::ABORT_POLICY
        | concurrency::DISCARD_POLICY
        | "Ljava/util/logging/Logger;"
        | "Ljava/util/logging/Level;"
        | "Ljava/lang/Runtime;"
        | "Landroid/util/SparseIntArray;"
        | "Landroid/telephony/PhoneStateListener;" => "Ljava/lang/Object;",
        "Ljava/util/Arrays$ArrayList;" => "Ljava/util/AbstractList;",
        "Ljava/util/AbstractMap;" | "Ljava/util/AbstractCollection;" => "Ljava/lang/Object;",
        "Ljava/util/AbstractSet;" => "Ljava/util/AbstractCollection;",
        "Ljava/util/Collections$SetFromMap;" => "Ljava/util/AbstractSet;",
        "Lorg/kyvex/rift/ReadOnlyIterator;" => "Ljava/lang/Object;",
        "Lorg/kyvex/rift/NativeCharset;" => "Ljava/nio/charset/Charset;",
        "Ljava/nio/charset/Charset;" => "Ljava/lang/Object;",
        "Ljava/nio/charset/IllegalCharsetNameException;"
        | "Ljava/nio/charset/UnsupportedCharsetException;" => {
            "Ljava/lang/IllegalArgumentException;"
        }
        "Ljava/io/UnsupportedEncodingException;" => "Ljava/io/IOException;",
        "Ljava/io/ByteArrayInputStream;" => "Ljava/io/InputStream;",
        "Landroid/util/Base64;" => "Ljava/lang/Object;",
        events::LOCAL_MESSENGER_BINDER => "Landroid/os/Binder;",
        "Landroid/os/Binder;" | "Landroid/os/Messenger;" => "Ljava/lang/Object;",
        "Landroid/os/RemoteException;" => "Ljava/lang/Exception;",
        executors::scheduled::POOL => "Ljava/util/concurrent/ThreadPoolExecutor;",
        "Ljava/util/concurrent/ThreadPoolExecutor;" => {
            "Ljava/util/concurrent/AbstractExecutorService;"
        }
        "Ljava/util/concurrent/AbstractExecutorService;" => "Ljava/lang/Object;",
        scheduler::HANDOFF_QUEUE => "Ljava/util/AbstractQueue;",
        "Ljava/util/AbstractQueue;" => "Ljava/util/AbstractCollection;",
        executors::scheduled::QUEUE | executors::scheduled::WRAPPER => "Ljava/lang/Object;",
        "Ljava/util/concurrent/ExecutionException;" | "Ljava/util/concurrent/TimeoutException;" => {
            "Ljava/lang/Exception;"
        }
        "Ljava/util/concurrent/CancellationException;" => "Ljava/lang/IllegalStateException;",
        "Landroid/database/sqlite/SQLiteOpenHelper;"
        | "Landroid/database/sqlite/SQLiteClosable;"
        | "Lorg/kyvex/rift/SqliteCursor;" => "Ljava/lang/Object;",
        "Landroid/database/sqlite/SQLiteDatabase;" => "Landroid/database/sqlite/SQLiteClosable;",
        "Landroid/database/sqlite/SQLiteConstraintException;"
        | "Landroid/database/sqlite/SQLiteDatabaseLockedException;"
        | "Landroid/database/sqlite/SQLiteFullException;"
        | "Landroid/database/sqlite/SQLiteDatabaseCorruptException;"
        | "Landroid/database/sqlite/SQLiteDiskIOException;"
        | "Landroid/database/sqlite/SQLiteCantOpenDatabaseException;" => {
            "Landroid/database/sqlite/SQLiteException;"
        }
        "Landroid/database/sqlite/SQLiteException;" => "Landroid/database/SQLException;",
        "Landroid/database/SQLException;" => "Ljava/lang/RuntimeException;",
        "Landroid/database/CursorIndexOutOfBoundsException;" => {
            "Ljava/lang/IndexOutOfBoundsException;"
        }
        "Ljava/util/DuplicateFormatFlagsException;"
        | "Ljava/util/FormatFlagsConversionMismatchException;"
        | "Ljava/util/IllegalFormatCodePointException;"
        | "Ljava/util/IllegalFormatConversionException;"
        | "Ljava/util/IllegalFormatFlagsException;"
        | "Ljava/util/IllegalFormatPrecisionException;"
        | "Ljava/util/IllegalFormatWidthException;"
        | "Ljava/util/MissingFormatArgumentException;"
        | "Ljava/util/MissingFormatWidthException;"
        | "Ljava/util/UnknownFormatConversionException;"
        | "Ljava/util/UnknownFormatFlagsException;" => "Ljava/util/IllegalFormatException;",
        "Ljava/util/IllegalFormatException;" => "Ljava/lang/IllegalArgumentException;",
        "Ljava/lang/NullPointerException;"
        | "Ljava/lang/ArithmeticException;"
        | "Ljava/lang/ClassCastException;"
        | "Ljava/lang/IllegalMonitorStateException;"
        | "Ljava/lang/IllegalArgumentException;"
        | "Ljava/lang/IllegalStateException;"
        | "Ljava/lang/SecurityException;"
        | "Ljava/lang/NegativeArraySizeException;"
        | "Ljava/util/concurrent/RejectedExecutionException;"
        | "Ljava/lang/ArrayStoreException;"
        | "Ljava/lang/UnsupportedOperationException;"
        | "Ljava/util/ConcurrentModificationException;"
        | "Ljava/util/NoSuchElementException;" => "Ljava/lang/RuntimeException;",
        "Ljava/lang/ArrayIndexOutOfBoundsException;"
        | "Ljava/lang/StringIndexOutOfBoundsException;" => "Ljava/lang/IndexOutOfBoundsException;",
        "Ljava/lang/IndexOutOfBoundsException;" => "Ljava/lang/RuntimeException;",
        "Ljava/lang/RuntimeException;" => "Ljava/lang/Exception;",
        "Landroid/util/AndroidRuntimeException;" => "Ljava/lang/RuntimeException;",
        "Landroid/util/SuperNotCalledException;" => "Landroid/util/AndroidRuntimeException;",
        "Ljava/lang/UnsatisfiedLinkError;" => "Ljava/lang/LinkageError;",
        "Ljava/lang/ExceptionInInitializerError;" | "Ljava/lang/NoClassDefFoundError;" => {
            "Ljava/lang/LinkageError;"
        }
        "Ljava/lang/AbstractMethodError;" | "Ljava/lang/IncompatibleClassChangeError;" => {
            "Ljava/lang/LinkageError;"
        }
        "Ljava/lang/LinkageError;" => "Ljava/lang/Error;",
        "Ljava/lang/NumberFormatException;" => "Ljava/lang/IllegalArgumentException;",
        "Ljava/lang/IllegalThreadStateException;" => "Ljava/lang/IllegalArgumentException;",
        "Ljava/lang/ClassNotFoundException;" | "Ljava/lang/InterruptedException;" => {
            "Ljava/lang/Exception;"
        }
        "Ljava/lang/InstantiationException;"
        | "Ljava/lang/NoSuchFieldException;"
        | "Ljava/lang/IllegalAccessException;"
        | "Ljava/lang/NoSuchMethodException;"
        | "Ljava/lang/reflect/InvocationTargetException;" => {
            "Ljava/lang/ReflectiveOperationException;"
        }
        "Ljava/lang/ReflectiveOperationException;" => "Ljava/lang/Exception;",
        "Landroid/content/pm/PackageManager$NameNotFoundException;" => "Ljava/lang/Exception;",
        "Landroid/content/res/Resources$NotFoundException;" => "Ljava/lang/RuntimeException;",
        "Landroid/content/res/Resources;"
        | "Landroid/content/res/AssetManager;"
        | "Landroid/app/ActivityManager;"
        | "Landroid/os/UserManager;"
        | "Landroid/app/ActivityManager$RunningAppProcessInfo;"
        | "Landroid/content/res/Configuration;"
        | "Landroid/util/DisplayMetrics;"
        | "Landroid/util/TypedValue;" => "Ljava/lang/Object;",
        "Landroid/content/pm/ApplicationInfo;" => "Landroid/content/pm/PackageItemInfo;",
        "Landroid/content/pm/ProviderInfo;" => "Landroid/content/pm/ComponentInfo;",
        "Landroid/content/pm/ServiceInfo;" => "Landroid/content/pm/ComponentInfo;",
        "Landroid/content/pm/ComponentInfo;" => "Landroid/content/pm/PackageItemInfo;",
        "Landroid/content/ContentProvider;" => "Ljava/lang/Object;",
        "Landroid/content/pm/PackageItemInfo;"
        | "Landroid/content/pm/PackageInfo;"
        | "Landroid/content/pm/PackageManager;" => "Ljava/lang/Object;",
        "Landroid/app/ApplicationPackageManager;" => "Landroid/content/pm/PackageManager;",
        "Ljava/lang/reflect/Field;" => "Ljava/lang/reflect/AccessibleObject;",
        "Ljava/lang/reflect/Constructor;" => "Ljava/lang/reflect/AccessibleObject;",
        "Ljava/util/concurrent/CountDownLatch;" => "Ljava/lang/Object;",
        "Ljava/lang/reflect/AccessibleObject;"
        | "Ljava/util/Collections$UnmodifiableCollection;"
        | "Ljava/util/Collections$UnmodifiableMap;"
        | "Ljava/util/Collections$SynchronizedCollection;"
        | "Ljava/util/Collections$SynchronizedMap;" => "Ljava/lang/Object;",
        "Ljava/util/Collections$SynchronizedList;" | "Ljava/util/Collections$SynchronizedSet;" => {
            "Ljava/util/Collections$SynchronizedCollection;"
        }
        "Ljava/util/Collections$UnmodifiableList;" | "Ljava/util/Collections$UnmodifiableSet;" => {
            "Ljava/util/Collections$UnmodifiableCollection;"
        }
        "Ljava/util/Collections$UnmodifiableEntrySet;" => "Ljava/util/Collections$UnmodifiableSet;",
        "Ljava/io/FileNotFoundException;"
        | "Ljava/io/EOFException;"
        | "Ljava/io/InterruptedIOException;" => "Ljava/io/IOException;",
        "Ljava/io/IOException;" => "Ljava/lang/Exception;",
        "Ljava/io/StringReader;" | "Ljava/io/BufferedReader;" | "Ljava/io/InputStreamReader;" => {
            "Ljava/io/Reader;"
        }
        "Ljava/io/FileReader;" => "Ljava/io/InputStreamReader;",
        "Ljava/io/Reader;" => "Ljava/lang/Object;",
        "Lorg/xmlpull/v1/XmlPullParserException;" => "Ljava/lang/Exception;",
        "Lorg/kyvex/rift/NativeXmlPullParser;"
        | "Lorg/xmlpull/v1/XmlPullParser;"
        | xml_pull::COMPILED_PARSER
        | xml_pull::RESOURCE_PARSER => "Ljava/lang/Object;",
        "Landroid/app/SharedPreferencesImpl;"
        | "Landroid/app/SharedPreferencesImpl$EditorImpl;" => "Ljava/lang/Object;",
        "Ljava/lang/Exception;" | "Ljava/lang/Error;" => "Ljava/lang/Throwable;",
        "Ljava/lang/Throwable;"
        | "Ljava/lang/ThreadLocal;"
        | "Ljava/util/Locale;"
        | "Ljava/lang/Enum;"
        | "Ljava/lang/Thread;"
        | "Ljava/lang/ThreadGroup;"
        | "Ljava/io/ObjectStreamField;"
        | "Lsun/misc/Unsafe;"
        | "Ljava/lang/Number;"
        | "Ljava/lang/StackTraceElement;"
        | "Ljava/lang/ref/Reference;"
        | "Ljava/lang/ref/ReferenceQueue;"
        | "Ljava/lang/String;"
        | "Ljava/lang/Class;"
        | "Ljava/lang/StringBuilder;" => "Ljava/lang/Object;",
        "Ljava/lang/ref/WeakReference;" => "Ljava/lang/ref/Reference;",
        "Ljava/lang/InheritableThreadLocal;" => "Ljava/lang/ThreadLocal;",
        "Ljava/util/concurrent/TimeUnit;" => "Ljava/lang/Enum;",
        rounding::CLASS => "Ljava/lang/Enum;",
        rwlock::RW_LOCK
        | rwlock::READ_VIEW
        | rwlock::WRITE_VIEW
        | rwlock::RW_INTERFACE
        | rwlock::LOCK_INTERFACE => "Ljava/lang/Object;",
        "Ljava/lang/Thread$State;" => "Ljava/lang/Enum;",
        "Ljava/lang/Integer;"
        | "Ljava/lang/Long;"
        | "Ljava/lang/Short;"
        | "Ljava/lang/Byte;"
        | "Ljava/lang/Float;"
        | "Ljava/lang/Double;" => "Ljava/lang/Number;",
        "Ljava/lang/Boolean;" | "Ljava/lang/Character;" => "Ljava/lang/Object;",
        paint::TEXT_PAINT => paint::PAINT,
        paint::PAINT => "Ljava/lang/Object;",
        point::POINT
        | pair::PAIR
        | content_resolver::RESOLVER
        | content_resolver::SETTINGS
        | content_resolver::NAME_VALUE_TABLE => "Ljava/lang/Object;",
        content_resolver::APPLICATION_RESOLVER => content_resolver::RESOLVER,
        content_resolver::SECURE | content_resolver::SYSTEM | content_resolver::GLOBAL => {
            content_resolver::NAME_VALUE_TABLE
        }
        content_resolver::NOT_FOUND => content_resolver::ANDROID_EXCEPTION,
        content_resolver::ANDROID_EXCEPTION => "Ljava/lang/Exception;",
        "Ljava/lang/IllegalAccessError;" => "Ljava/lang/IncompatibleClassChangeError;",
        decimal_format::DECIMAL => decimal_format::NUMBER,
        decimal_format::NUMBER => decimal_format::FORMAT,
        decimal_format::FORMAT => "Ljava/lang/Object;",
        "Landroid/widget/Button;" => "Landroid/widget/TextView;",
        "Landroid/widget/TextView;" | "Landroid/view/ViewGroup;" => "Landroid/view/View;",
        "Landroid/widget/LinearLayout;" | "Landroid/widget/FrameLayout;" => {
            "Landroid/view/ViewGroup;"
        }
        "Landroid/view/View;" | view_configuration::CLASS => "Ljava/lang/Object;",
        "Landroid/app/Activity;" => "Landroid/view/ContextThemeWrapper;",
        "Landroid/view/ContextThemeWrapper;" | "Landroid/app/Application;" => {
            "Landroid/content/ContextWrapper;"
        }
        "Landroid/content/ContextWrapper;" => "Landroid/content/Context;",
        "Landroid/content/ComponentCallbacks2;" => "Landroid/content/ComponentCallbacks;",
        "Landroid/content/ComponentCallbacks;"
        | "Landroid/app/Application$ActivityLifecycleCallbacks;" => "Ljava/lang/Object;",
        "Landroid/content/res/AssetManager$AssetInputStream;" => "Ljava/io/InputStream;",
        "Landroid/os/Bundle;" => "Landroid/os/BaseBundle;",
        "Landroid/os/BaseBundle;" => "Ljava/lang/Object;",
        "Landroid/content/Context;" => "Ljava/lang/Object;",
        "Landroid/app/ContextImpl;" => "Landroid/content/Context;",
        _ => return None,
    })
}
fn word(c: &[u16], p: usize) -> Result<u16> {
    c.get(p)
        .copied()
        .ok_or_else(|| "Truncated DEX instruction".into())
}
fn dword(c: &[u16], p: usize) -> Result<u32> {
    Ok(word(c, p)? as u32 | ((word(c, p + 1)? as u32) << 16))
}
fn get(r: &[u32], i: usize) -> Result<u32> {
    r.get(i)
        .copied()
        .ok_or_else(|| "DEX register out of bounds".into())
}
fn set(r: &mut [u32], i: usize, v: u32) -> Result<()> {
    *r.get_mut(i).ok_or("DEX register out of bounds")? = v;
    Ok(())
}
fn wide(r: &[u32], i: usize) -> Result<u64> {
    Ok(get(r, i)? as u64 | ((get(r, i + 1)? as u64) << 32))
}
fn setwide(r: &mut [u32], i: usize, v: u64) -> Result<()> {
    if i.checked_add(1).is_none_or(|i| i >= r.len()) {
        return Err("DEX wide register out of bounds".into());
    }
    r[i] = v as u32;
    r[i + 1] = (v >> 32) as u32;
    Ok(())
}
fn branch(c: &[u16], pc: usize, offset: i32) -> Result<usize> {
    let target = pc
        .checked_add_signed(offset as isize)
        .ok_or("DEX branch overflow")?;
    if target >= c.len() {
        return Err("DEX branch target out of bounds".into());
    }
    Ok(target)
}
fn narrow(kind: u8, v: u64) -> u64 {
    match kind {
        3 => (v != 0) as u64,
        4 => v as i8 as i64 as u64,
        5 => v as u16 as u64,
        6 => v as i16 as i64 as u64,
        _ => v,
    }
}
fn unary(op: u8, v: u64) -> Result<u64> {
    Ok(match op {
        0x7b => (v as i32).wrapping_neg() as u32 as u64,
        0x7c => !(v as u32) as u64,
        0x7d => (v as i64).wrapping_neg() as u64,
        0x7e => !v,
        0x7f => (-f32::from_bits(v as u32)).to_bits() as u64,
        0x80 => (-f64::from_bits(v)).to_bits(),
        0x81 => v as i32 as i64 as u64,
        0x82 => (v as i32 as f32).to_bits() as u64,
        0x83 => (v as i32 as f64).to_bits(),
        0x84 => v as u32 as u64,
        0x85 => (v as i64 as f32).to_bits() as u64,
        0x86 => (v as i64 as f64).to_bits(),
        0x87 => (f32::from_bits(v as u32) as i32) as u32 as u64,
        0x88 => (f32::from_bits(v as u32) as i64) as u64,
        0x89 => (f32::from_bits(v as u32) as f64).to_bits(),
        0x8a => (f64::from_bits(v) as i32) as u32 as u64,
        0x8b => (f64::from_bits(v) as i64) as u64,
        0x8c => (f64::from_bits(v) as f32).to_bits() as u64,
        0x8d => v as i8 as i32 as u32 as u64,
        0x8e => v as u16 as u64,
        0x8f => v as i16 as i32 as u32 as u64,
        _ => return Err("Unknown numeric conversion".into()),
    })
}
fn numeric(op: u8, a: u64, b: u64) -> Result<u64> {
    Ok(match op {
        0x90..=0x9a => arithmetic(op - 0x90, a as u32, b as u32)? as u64,
        0x9b => a.wrapping_add(b),
        0x9c => a.wrapping_sub(b),
        0x9d => a.wrapping_mul(b),
        0x9e | 0x9f => {
            if b == 0 {
                return Err(fault(
                    "Ljava/lang/ArithmeticException;",
                    "long division by zero",
                ));
            }
            if op == 0x9e {
                (a as i64).wrapping_div(b as i64) as u64
            } else {
                (a as i64).wrapping_rem(b as i64) as u64
            }
        }
        0xa0 => a & b,
        0xa1 => a | b,
        0xa2 => a ^ b,
        0xa3 => a.wrapping_shl((b & 63) as u32),
        0xa4 => ((a as i64) >> ((b & 63) as u32)) as u64,
        0xa5 => a >> ((b & 63) as u32),
        0xa6..=0xaa => {
            let (x, y) = (f32::from_bits(a as u32), f32::from_bits(b as u32));
            match op {
                0xa6 => x + y,
                0xa7 => x - y,
                0xa8 => x * y,
                0xa9 => x / y,
                _ => x % y,
            }
            .to_bits() as u64
        }
        0xab..=0xaf => {
            let (x, y) = (f64::from_bits(a), f64::from_bits(b));
            match op {
                0xab => x + y,
                0xac => x - y,
                0xad => x * y,
                0xae => x / y,
                _ => x % y,
            }
            .to_bits()
        }
        _ => return Err("Unknown numeric operation".into()),
    })
}
fn arithmetic(kind: u8, a: u32, b: u32) -> Result<u32> {
    Ok(match kind {
        0 => a.wrapping_add(b),
        1 => a.wrapping_sub(b),
        2 => a.wrapping_mul(b),
        3 => {
            if b == 0 {
                return Err(fault(
                    "Ljava/lang/ArithmeticException;",
                    "integer division by zero",
                ));
            }
            (a as i32).wrapping_div(b as i32) as u32
        }
        4 => {
            if b == 0 {
                return Err(fault(
                    "Ljava/lang/ArithmeticException;",
                    "integer remainder by zero",
                ));
            }
            (a as i32).wrapping_rem(b as i32) as u32
        }
        5 => a & b,
        6 => a | b,
        7 => a ^ b,
        8 => a.wrapping_shl(b & 31),
        9 => ((a as i32) >> (b & 31)) as u32,
        10 => a >> (b & 31),
        _ => return Err("Unknown DEX arithmetic operation".into()),
    })
}
fn mangle(name: &str) -> String {
    let mut out = String::new();
    for c in name.encode_utf16() {
        match c {
            0x2f => out.push('_'),
            0x5f => out.push_str("_1"),
            0x3b => out.push_str("_2"),
            0x5b => out.push_str("_3"),
            c if (c as u8).is_ascii_alphanumeric() && c < 128 => out.push(char::from(c as u8)),
            c => out.push_str(&format!("_0{c:04x}")),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn integer_operations_follow_java_overflow_and_shifts() {
        assert_eq!(arithmetic(0, u32::MAX, 1).unwrap(), 0);
        assert_eq!(
            arithmetic(3, i32::MIN as u32, u32::MAX).unwrap(),
            i32::MIN as u32
        );
        assert_eq!(arithmetic(9, 0x80000000, 33).unwrap(), 0xc0000000);
        assert!(arithmetic(3, 1, 0).is_err());
        assert_eq!(mangle("org/kyvex/Hello_world"), "org_kyvex_Hello_1world");
    }
    #[test]
    fn bad_registers_and_branches_are_errors() {
        assert!(get(&[0], 1).is_err());
        assert!(setwide(&mut [0], 0, 1).is_err());
        assert!(branch(&[0], 0, -1).is_err());
        assert!(branch(&[0], 0, 1).is_err());
    }
    #[test]
    fn string_equality_respects_null_and_non_string_objects() {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/rift-native-demo.apk");
        let p = crate::package::Package::open(&path, "auto").unwrap();
        let m = Machine::new(64, 32, 8).unwrap();
        let mut vm = Runtime::new(p.dex, m, p.libraries, 4 * 1024 * 1024);
        let empty = vm.string("").unwrap();
        let null_text = vm.string("null").unwrap();
        let second = vm.string("").unwrap();
        let object = vm.instantiate("Ljava/lang/Object;").unwrap();
        assert!(vm.string_equals(empty, second).unwrap());
        assert!(!vm.string_equals(empty, object).unwrap());
        assert!(!vm.string_equals(null_text, 0).unwrap());
        assert!(vm.string_equals(0, null_text).is_err());
        let literal = vm.literal("first".encode_utf16().collect()).unwrap();
        let dynamic = vm.string("first").unwrap();
        assert_ne!(literal, dynamic);
        assert_eq!(
            vm.hle("Ljava/lang/String;->intern()Ljava/lang/String;", &[dynamic])
                .unwrap(),
            literal as u64
        );
        assert_eq!(
            vm.literal("first".encode_utf16().collect()).unwrap(),
            literal
        );
        let first = vm.class_object("Ljava/lang/String;").unwrap();
        assert_eq!(vm.class_object("Ljava/lang/String;").unwrap(), first);
    }
}
