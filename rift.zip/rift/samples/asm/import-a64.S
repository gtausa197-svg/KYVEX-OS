.text
.global _start
_start:
    adrp x0, message_pointer
    ldr x0, [x0, :lo12:message_pointer]
    bl strlen
    mov x8, #93
    svc #0
.section .rodata
.Lmessage: .asciz "012345678901234567890123456789012345678901"
.data
.hidden message_pointer
message_pointer: .quad .Lmessage
