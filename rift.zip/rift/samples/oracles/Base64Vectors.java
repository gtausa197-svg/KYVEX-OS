import android.util.Base64;
import java.util.Random;
public final class Base64Vectors {
 static final char[] DIGITS="0123456789abcdef".toCharArray();
 static String hex(byte[] data){StringBuilder s=new StringBuilder(data.length*2);for(byte b:data){s.append(DIGITS[(b&255)>>>4]);s.append(DIGITS[b&15]);}return s.toString();}
 public static void main(String[] args){Random random=new Random(0x52494654);System.out.print("{\"encoding\":[");boolean comma=false;
  for(int flags=0;flags<32;flags++)for(int i=0;i<64;i++){
   byte[] input=new byte[i<60?i:76+(i-60)*63];random.nextBytes(input);
   if(comma)System.out.print(",");comma=true;
   System.out.print("{\"flags\":"+flags+",\"input\":\""+hex(input)+"\",\"output\":\""+hex(Base64.encode(input,flags))+"\"}");
  }
  System.out.print("],\"decoding\":[");comma=false;
  String[] cases={"","A","AB","ABC","ABCD","AB==","ABC=","A===","AB=","AB===","AB==A","ABC==","====","AA\n==","AA= \t=","\u00ffAA==","-_8=","+/8=","A!B@C#D$"," \n\r\t","AB C=","AB=C","AB==!","ABC=\r\n","AA==AA=="};
  for(int i=0;i<1100;i++)for(int flags:new int[]{0,8}){
   byte[] input;
   if(i<cases.length)input=cases[i].getBytes(java.nio.charset.StandardCharsets.UTF_8);
   else if(i<500){input=new byte[(i*7)%193];random.nextBytes(input);input=Base64.encode(input,flags|2);}
   else{input=new byte[i%29];random.nextBytes(input);}
   String value;try{value="\"output\":\""+hex(Base64.decode(input,flags))+"\"";}catch(IllegalArgumentException expected){value="\"error\":true";}
   if(comma)System.out.print(",");comma=true;
   System.out.print("{\"flags\":"+flags+",\"input\":\""+hex(input)+"\","+value+"}");
  }
  System.out.println("]}");
 }
}
