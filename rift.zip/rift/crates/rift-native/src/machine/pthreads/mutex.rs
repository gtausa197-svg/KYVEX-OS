use super::{Machine, NativeStep, READ, State, WRITE, Wait};

const MAX_HELD_MUTEXES: usize = 4096;
const TYPE_SHIFT: u32 = 14;
const DESTROYED: u16 = u16::MAX;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Kind {
    Normal = 0,
    Recursive = 1,
    ErrorCheck = 2,
}

impl Kind {
    fn from_type(value: u64) -> Result<Self, i32> {
        match value {
            0 => Ok(Self::Normal),
            1 => Ok(Self::Recursive),
            2 => Ok(Self::ErrorCheck),
            _ => Err(libc::EINVAL),
        }
    }
}

pub(super) struct HeldMutex {
    pub(super) owner: u32,
    depth: u16,
}

impl Machine {
    fn mutex_size(&self) -> usize {
        if self.arch == 64 { 40 } else { 4 }
    }

    fn mutex_kind(&self, address: u64) -> Result<Kind, i32> {
        if !address.is_multiple_of(4) {
            return Err(libc::EINVAL);
        }
        let mut bytes = [0; 40];
        self.cpu
            .memory()
            .read(address, &mut bytes[..self.mutex_size()], READ | WRITE)
            .map_err(|_| libc::EFAULT)?;
        let state = u16::from_le_bytes([bytes[0], bytes[1]]);
        if state == DESTROYED {
            return Err(libc::EINVAL);
        }
        Kind::from_type(u64::from(state >> TYPE_SHIFT))
    }

    fn read_mutex_attr(&self, address: u64) -> Result<u64, i32> {
        let width = if self.arch == 64 { 8 } else { 4 };
        let mut bytes = [0; 8];
        self.cpu
            .memory()
            .read(address, &mut bytes[..width], READ)
            .map_err(|_| libc::EFAULT)?;
        Ok(u64::from_le_bytes(bytes))
    }

    fn init_mutex(&mut self, address: u64, attr: u64) -> Result<(), i32> {
        if !address.is_multiple_of(4) {
            return Err(libc::EINVAL);
        }
        if self.pthreads.mutexes.contains_key(&address) {
            return Err(libc::EBUSY);
        }
        let value = if attr == 0 {
            0
        } else {
            self.read_mutex_attr(attr)?
        };
        let kind = Kind::from_type(value & 15)?;
        if value & !15 != 0 {
            return Err(libc::ENOTSUP);
        }
        let mut bytes = [0; 40];
        bytes[..2].copy_from_slice(&((kind as u16) << TYPE_SHIFT).to_le_bytes());
        let size = self.mutex_size();
        self.cpu
            .memory_mut()
            .write(address, &bytes[..size])
            .map_err(|_| libc::EFAULT)
    }

    fn destroy_mutex(&mut self, address: u64) -> Result<(), i32> {
        self.mutex_kind(address)?;
        if self.pthreads.mutexes.contains_key(&address)
            || self.pthreads.threads.values().any(|thread| {
                matches!(
                    thread.runnable.as_ref().and_then(|run| run.wait),
                    Some(Wait::Mutex(lock)) if lock == address
                )
            })
        {
            return Err(libc::EBUSY);
        }
        self.cpu
            .memory_mut()
            .write(address, &DESTROYED.to_le_bytes())
            .map_err(|_| libc::EFAULT)
    }

    pub(super) fn take_mutex(&mut self, address: u64, try_only: bool) -> Result<Option<Wait>, i32> {
        let kind = self.mutex_kind(address)?;
        let tid = self.current_tid;
        if let Some(mutex) = self.pthreads.mutexes.get_mut(&address) {
            if mutex.owner == tid && kind == Kind::Recursive {
                mutex.depth = mutex.depth.checked_add(1).ok_or(libc::EAGAIN)?;
                return Ok(None);
            }
            if try_only {
                return Err(libc::EBUSY);
            }
            let wait = Wait::Mutex(address);
            return if self.pthreads.would_deadlock(tid, wait) {
                Err(libc::EDEADLK)
            } else {
                Ok(Some(wait))
            };
        }
        if self.pthreads.mutexes.len() >= MAX_HELD_MUTEXES {
            return Err(libc::EAGAIN);
        }
        self.pthreads.mutexes.insert(
            address,
            HeldMutex {
                owner: tid,
                depth: 1,
            },
        );
        Ok(None)
    }

    fn unlock_mutex(&mut self, address: u64) -> Result<(), i32> {
        self.mutex_kind(address)?;
        let mutex = self.pthreads.mutexes.get_mut(&address).ok_or(libc::EPERM)?;
        if mutex.owner != self.current_tid {
            return Err(libc::EPERM);
        }
        mutex.depth -= 1;
        if mutex.depth == 0 {
            self.pthreads.mutexes.remove(&address);
        }
        Ok(())
    }

    pub(super) fn pthread_mutex_call(
        &mut self,
        name: &str,
        state: &mut State,
    ) -> Option<NativeStep> {
        let [address, arg, ..] = state.regs;
        let result = match name {
            "pthread_mutexattr_init" => self.pthread_pointer(address, 0).map_err(|_| libc::EFAULT),
            "pthread_mutexattr_destroy" => self
                .pthread_pointer(address, u64::MAX)
                .map_err(|_| libc::EFAULT),
            "pthread_mutexattr_settype" => self.set_mutex_type(address, arg),
            "pthread_mutex_init" => self.init_mutex(address, arg),
            "pthread_mutex_destroy" => self.destroy_mutex(address),
            "pthread_mutex_lock" | "pthread_mutex_trylock" => {
                match self.take_mutex(address, name == "pthread_mutex_trylock") {
                    Ok(Some(wait)) => return Some(NativeStep::Wait(wait)),
                    Ok(None) => Ok(()),
                    Err(error) => Err(error),
                }
            }
            "pthread_mutex_unlock" => self.unlock_mutex(address),
            _ => return None,
        };
        state.regs[0] = result.err().unwrap_or(0) as u64;
        Some(NativeStep::Resume)
    }

    fn set_mutex_type(&mut self, address: u64, value: u64) -> Result<(), i32> {
        let kind = Kind::from_type(u64::from(value as u32))?;
        let flags = self.read_mutex_attr(address)?;
        if flags & !63 != 0 {
            return Err(libc::EINVAL);
        }
        self.pthread_pointer(address, (flags & !15) | kind as u64)
            .map_err(|_| libc::EFAULT)
    }
}
