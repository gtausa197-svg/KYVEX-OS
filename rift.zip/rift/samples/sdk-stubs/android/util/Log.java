package android.util;

/** Compile-only Android signatures. */
public final class Log {
    public static native int e(String tag, String message, Throwable exception);
    public static native String getStackTraceString(Throwable exception);
}
