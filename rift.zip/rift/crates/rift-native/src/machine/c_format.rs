//! Bounded scalar C formatting over the guest call frame or a guest va_list.
use super::*;
use std::iter::Peekable;

const FIELD_LIMIT: usize = 16384;

pub(super) fn read_word(memory: &Memory, address: u64, size: usize) -> Result<u64> {
    let mut bytes = [0; 8];
    memory.read(address, &mut bytes[..size], READ)?;
    Ok(u64::from_le_bytes(bytes))
}

pub(super) fn call_word(machine: &Machine, state: &State, slot: usize) -> Result<u64> {
    let (registers, stack, size) = if machine.arch == 64 {
        (8, state.regs[31], 8)
    } else {
        (4, state.regs[13], 4)
    };
    if slot < registers {
        return Ok(state.regs[slot]);
    }
    let address = stack
        .checked_add(((slot - registers) * size) as u64)
        .ok_or("C argument address overflow")?;
    read_word(machine.cpu.memory(), address, size)
}

enum Source<'a> {
    Call {
        state: &'a State,
        slot: usize,
    },
    Arm32List(u64),
    Arm64List {
        stack: u64,
        gr_top: u64,
        gr_off: i32,
    },
}

pub(super) struct Arguments<'a> {
    machine: &'a Machine,
    source: Source<'a>,
}

impl<'a> Arguments<'a> {
    pub(super) fn call(machine: &'a Machine, state: &'a State, slot: usize) -> Self {
        Self {
            machine,
            source: Source::Call { state, slot },
        }
    }

    pub(super) fn list(machine: &'a Machine, address: u64) -> Result<Self> {
        let source = if machine.arch == 32 {
            Source::Arm32List(address)
        } else {
            let mut list = [0; 32];
            machine.cpu.memory().read(address, &mut list, READ)?;
            let stack = u64::from_le_bytes(list[..8].try_into()?);
            let gr_top = u64::from_le_bytes(list[8..16].try_into()?);
            let gr_off = i32::from_le_bytes(list[24..28].try_into()?);
            if gr_off < -64 || gr_off % 8 != 0 {
                return Err("Invalid AArch64 va_list register offset".into());
            }
            Source::Arm64List {
                stack,
                gr_top,
                gr_off,
            }
        };
        Ok(Self { machine, source })
    }

    pub(super) fn next(&mut self, bits: u32) -> Result<u64> {
        let wide32 = self.machine.arch == 32 && bits == 64;
        let memory = self.machine.cpu.memory();
        match &mut self.source {
            Source::Call { state, slot } => {
                if wide32 {
                    *slot = (*slot + 1) & !1;
                    let low = call_word(self.machine, state, *slot)? as u32;
                    let high = call_word(self.machine, state, *slot + 1)? as u32;
                    *slot += 2;
                    Ok(u64::from(low) | (u64::from(high) << 32))
                } else {
                    let value = call_word(self.machine, state, *slot)?;
                    *slot += 1;
                    Ok(value)
                }
            }
            Source::Arm32List(cursor) => {
                let size = if wide32 { 8 } else { 4 };
                let address =
                    cursor.checked_add(size - 1).ok_or("ARM va_list overflow")? & !(size - 1);
                *cursor = address.checked_add(size).ok_or("ARM va_list overflow")?;
                read_word(memory, address, size as usize)
            }
            Source::Arm64List {
                stack,
                gr_top,
                gr_off,
            } => {
                let address = if *gr_off < 0 {
                    let address = gr_top
                        .checked_add_signed(i64::from(*gr_off))
                        .ok_or("AArch64 va_list register address overflow")?;
                    *gr_off += 8;
                    address
                } else {
                    let address = *stack;
                    *stack = stack
                        .checked_add(8)
                        .ok_or("AArch64 va_list stack overflow")?;
                    address
                };
                read_word(memory, address, if bits == 64 { 8 } else { 4 })
            }
        }
    }
}

#[derive(Default)]
struct Flags {
    left: bool,
    zero: bool,
    plus: bool,
    space: bool,
    alternate: bool,
}

fn field_size(
    input: &mut Peekable<impl Iterator<Item = u8>>,
    args: &mut Arguments<'_>,
) -> Result<i32> {
    if input.next_if_eq(&b'*').is_some() {
        return Ok(args.next(32)? as i32);
    }
    let mut width = 0;
    while let Some(digit) = input.next_if(u8::is_ascii_digit) {
        width = width * 10 + i32::from(digit - b'0');
        if width as usize > FIELD_LIMIT {
            return Err("C format field quota".into());
        }
    }
    Ok(width)
}

fn integer_field(
    value: u64,
    bits: u32,
    kind: u8,
    flags: &Flags,
    precision: Option<usize>,
) -> (Vec<u8>, Vec<u8>, usize) {
    let shift = 64 - bits;
    let unsigned = value << shift >> shift;
    let signed = ((value << shift) as i64) >> shift;
    let signed_kind = matches!(kind, b'd' | b'i');
    let magnitude = if signed_kind {
        signed.unsigned_abs()
    } else {
        unsigned
    };
    let digits = if magnitude == 0 && precision == Some(0) && kind != b'p' {
        Vec::new()
    } else {
        match kind {
            b'x' | b'p' => format!("{magnitude:x}"),
            b'X' => format!("{magnitude:X}"),
            b'o' => format!("{magnitude:o}"),
            _ => magnitude.to_string(),
        }
        .into_bytes()
    };
    let prefix: &[u8] = match kind {
        b'd' | b'i' if signed < 0 => b"-",
        b'd' | b'i' if flags.plus => b"+",
        b'd' | b'i' if flags.space => b" ",
        b'p' => b"0x",
        b'x' if flags.alternate && magnitude != 0 => b"0x",
        b'X' if flags.alternate && magnitude != 0 => b"0X",
        _ => b"",
    };
    let mut zeros = precision.unwrap_or(0).saturating_sub(digits.len());
    if kind == b'o' && flags.alternate && digits.first() != Some(&b'0') {
        zeros = zeros.max(1);
    }
    (prefix.to_vec(), digits, zeros)
}

impl Machine {
    pub(super) fn bounded_text(&self, address: u64, limit: usize) -> Result<Vec<u8>> {
        let mut value = Vec::new();
        for offset in 0..limit {
            let at = address
                .checked_add(offset as u64)
                .ok_or("C string address overflow")?;
            let byte = read_word(self.cpu.memory(), at, 1)? as u8;
            if byte == 0 {
                break;
            }
            value.push(byte);
        }
        Ok(value)
    }

    pub(super) fn format_c(
        &self,
        address: u64,
        mut args: Arguments<'_>,
        limit: usize,
        clip: bool,
    ) -> Result<Vec<u8>> {
        let format = self.cbytes(address, if clip { 1024 } else { 4096 })?;
        let mut input = format.into_iter().peekable();
        let mut output = Vec::new();
        while let Some(byte) = input.next() {
            if byte != b'%' || input.next_if_eq(&b'%').is_some() {
                output.push(byte);
            } else {
                let mut flags = Flags::default();
                while let Some(flag) = input.next_if(|c| b"-+ #0".contains(c)) {
                    match flag {
                        b'-' => flags.left = true,
                        b'+' => flags.plus = true,
                        b' ' => flags.space = true,
                        b'#' => flags.alternate = true,
                        b'0' => flags.zero = true,
                        _ => unreachable!(),
                    }
                }
                let width = field_size(&mut input, &mut args)?;
                flags.left |= width < 0;
                let width = width.unsigned_abs() as usize;
                let precision = if input.next_if_eq(&b'.').is_some() {
                    usize::try_from(field_size(&mut input, &mut args)?).ok()
                } else {
                    None
                };
                if width > FIELD_LIMIT || precision.is_some_and(|n| n > FIELD_LIMIT) {
                    return Err("C format field quota".into());
                }
                let length = input.next_if(|c| b"hlztj".contains(c));
                let bits = match length {
                    Some(b'h') if input.next_if_eq(&b'h').is_some() => 8,
                    Some(b'h') => 16,
                    Some(b'l') if input.next_if_eq(&b'l').is_some() => 64,
                    Some(b'j') => 64,
                    Some(b'l' | b'z' | b't') => self.arch,
                    _ => 32,
                };
                let kind = input.next().ok_or("Unterminated C conversion")?;
                let numeric = b"diuxXop".contains(&kind);
                let (prefix, bytes, mut zeros) = match kind {
                    b's' if length.is_none() => {
                        let value = args.next(self.arch)?;
                        let bytes = if value == 0 {
                            b"(null)"[..precision.unwrap_or(6).min(6)].to_vec()
                        } else if let Some(count) = precision {
                            self.bounded_text(value, count)?
                        } else if clip {
                            self.bounded_text(value, limit)?
                        } else {
                            self.cbytes(value, limit + 1)?
                        };
                        (Vec::new(), bytes, 0)
                    }
                    b'c' if length.is_none() => (Vec::new(), vec![args.next(32)? as u8], 0),
                    b'p' if length.is_none() => {
                        integer_field(args.next(self.arch)?, self.arch, kind, &flags, precision)
                    }
                    b'd' | b'i' | b'u' | b'x' | b'X' | b'o' => {
                        integer_field(args.next(bits)?, bits, kind, &flags, precision)
                    }
                    _ => return Err("Unsupported C conversion".into()),
                };
                let mut spaces = width.saturating_sub(prefix.len() + bytes.len() + zeros);
                if numeric && flags.zero && !flags.left && precision.is_none() {
                    zeros += spaces;
                    spaces = 0;
                }
                if !flags.left {
                    output.extend(std::iter::repeat_n(b' ', spaces));
                }
                output.extend(prefix);
                output.extend(std::iter::repeat_n(b'0', zeros));
                output.extend(bytes);
                if flags.left {
                    output.extend(std::iter::repeat_n(b' ', spaces));
                }
            }
            if clip && output.len() >= limit {
                output.truncate(limit);
                break;
            }
            if output.len() > limit {
                return Err("C format output quota".into());
            }
        }
        Ok(output)
    }
}
