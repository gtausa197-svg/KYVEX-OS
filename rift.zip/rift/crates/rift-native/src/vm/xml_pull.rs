//! Bounded XMLPull facade. quick-xml tokenizes; namespace/event semantics live here.
use super::*;
use quick_xml::{Reader, XmlVersion, events::Event};
use std::{borrow::Cow, io::Cursor};

mod binary;

const PARSER: &str = "Lorg/kyvex/rift/NativeXmlPullParser;";
pub(super) const COMPILED_PARSER: &str = "Landroid/content/res/XmlBlock$Parser;";
pub(super) const RESOURCE_PARSER: &str = "Landroid/content/res/XmlResourceParser;";
const FEATURE_NS: &str = "http://xmlpull.org/v1/doc/features.html#process-namespaces";
const FEATURE_NS_ATTRIBUTES: &str =
    "http://xmlpull.org/v1/doc/features.html#report-namespace-prefixes";
const XML_NS: &str = "http://www.w3.org/XML/1998/namespace";
const XMLNS_NS: &str = "http://www.w3.org/2000/xmlns/";
fn error(message: &str) -> Box<dyn std::error::Error + Send + Sync> {
    fault("Lorg/xmlpull/v1/XmlPullParserException;", message)
}
fn xml_chars(text: &str) -> Result<()> {
    if text.chars().any(
        |c| !matches!(c as u32, 9 | 10 | 13 | 0x20..=0xd7ff | 0xe000..=0xfffd | 0x10000..=0x10ffff),
    ) {
        return Err(error("Illegal XML 1.0 character"));
    }
    Ok(())
}
fn name_start(c: char) -> bool {
    matches!(c as u32, 0x3a | 0x41..=0x5a | 0x5f | 0x61..=0x7a | 0xc0..=0xd6 | 0xd8..=0xf6 | 0xf8..=0x2ff | 0x370..=0x37d | 0x37f..=0x1fff | 0x200c..=0x200d | 0x2070..=0x218f | 0x2c00..=0x2fef | 0x3001..=0xd7ff | 0xf900..=0xfdcf | 0xfdf0..=0xfffd | 0x10000..=0xeffff)
}
fn valid_name(text: &str) -> bool {
    let mut chars = text.chars();
    chars.next().is_some_and(name_start) && chars.all(|c| name_start(c) || matches!(c as u32, 0x2d | 0x2e | 0x30..=0x39 | 0xb7 | 0x300..=0x36f | 0x203f..=0x2040))
}
#[derive(Clone, Default)]
struct Attribute {
    name: String,
    prefix: Option<String>,
    namespace: String,
    value: String,
    compiled: Option<binary::AttributeInfo>,
}
type Namespace = (usize, String, String);
#[derive(Clone, Default)]
struct XmlEvent {
    kind: i32,
    depth: usize,
    name: Option<String>,
    prefix: Option<String>,
    namespace: Option<String>,
    text: Option<String>,
    attributes: Vec<Attribute>,
    compiled_indices: Option<binary::AttributeIndices>,
    namespaces: Vec<Namespace>,
    empty: bool,
    line: usize,
    column: usize,
}
pub(super) struct Parser {
    pub input: u32,
    character_input: bool,
    encoding: Option<String>,
    namespace_aware: bool,
    compiled: bool,
    binary: Option<binary::Binary>,
    reader: Option<Reader<Cursor<Vec<u8>>>>,
    stack: Vec<XmlEvent>,
    current: XmlEvent,
    lookahead: Option<XmlEvent>,
    empty_end: bool,
    pop: bool,
    root_seen: bool,
    failed: bool,
    tokens: usize,
    position: usize,
    line: usize,
    column: usize,
    previous_cr: bool,
}
impl Parser {
    fn new(namespace_aware: bool) -> Self {
        Self {
            input: 0,
            character_input: false,
            encoding: None,
            namespace_aware,
            compiled: false,
            binary: None,
            reader: None,
            stack: Vec::new(),
            current: XmlEvent {
                line: 1,
                ..XmlEvent::default()
            },
            lookahead: None,
            empty_end: false,
            pop: false,
            root_seen: false,
            failed: false,
            tokens: 0,
            position: 0,
            line: 1,
            column: 0,
            previous_cr: false,
        }
    }
    pub fn bytes(&self) -> usize {
        // Includes tokenizer buffers, two event snapshots and namespace/tag stacks.
        // The input limit is checked against this reservation before allocation.
        self.reader
            .as_ref()
            .map_or(0, |r| r.get_ref().get_ref().capacity() * 8)
            + std::mem::size_of::<Self>()
            + if self.reader.is_some() { 65536 } else { 0 }
            + self
                .binary
                .as_ref()
                .map_or(0, binary::Binary::reserved_bytes)
    }
    fn document(&mut self, data: Vec<u8>) {
        let mut reader = Reader::from_reader(Cursor::new(data));
        reader.config_mut().check_comments = true;
        reader.config_mut().check_end_names = true;
        self.reader = Some(reader);
    }
    fn scope(&self) -> Vec<Namespace> {
        self.stack
            .iter()
            .flat_map(|event| event.namespaces.iter().cloned())
            .collect()
    }
    fn namespace(scope: &[Namespace], prefix: &str) -> Option<String> {
        if prefix == "xml" {
            return Some(XML_NS.into());
        }
        if prefix == "xmlns" {
            return Some(XMLNS_NS.into());
        }
        scope
            .iter()
            .rev()
            .find(|(_, p, _)| p == prefix)
            .map(|(_, _, uri)| uri.clone())
    }
    fn qualified(&self, raw: &str, scope: &[Namespace], attribute: bool) -> Result<Attribute> {
        if !valid_name(raw) {
            return Err(error("Invalid XML name"));
        }
        if !self.namespace_aware {
            return Ok(Attribute {
                name: raw.into(),
                ..Attribute::default()
            });
        }
        if let Some((prefix, name)) = raw.split_once(':') {
            if prefix.is_empty()
                || name.is_empty()
                || name.contains(':')
                || !valid_name(name)
                || prefix == "xmlns"
            {
                return Err(error("Invalid XML qualified name"));
            }
            let namespace = Self::namespace(scope, prefix)
                .filter(|s| !s.is_empty())
                .ok_or_else(|| error("Unbound XML namespace prefix"))?;
            Ok(Attribute {
                name: name.into(),
                prefix: Some(prefix.into()),
                namespace,
                ..Attribute::default()
            })
        } else {
            Ok(Attribute {
                name: raw.into(),
                namespace: if attribute {
                    String::new()
                } else {
                    Self::namespace(scope, "").unwrap_or_default()
                },
                ..Attribute::default()
            })
        }
    }
    fn raw_token(&mut self) -> Result<XmlEvent> {
        if self.failed {
            return Err(error("XML parser failed; call setInput before reusing it"));
        }
        if self.pop {
            self.stack.pop();
            self.pop = false;
        }
        if self.empty_end {
            self.empty_end = false;
            self.pop = true;
            let mut event = self.stack.last().ok_or("XML empty stack")?.clone();
            event.kind = 3;
            event.attributes.clear();
            event.empty = false;
            event.namespaces = self.scope();
            return Ok(event);
        }
        loop {
            self.tokens += 1;
            if self.tokens > 32768 {
                return Err(error("XML token quota"));
            }
            let reader = self
                .reader
                .as_mut()
                .ok_or_else(|| error("XML input is not set"))?;
            let mut buffer = Vec::new();
            let token = reader
                .read_event_into(&mut buffer)
                .map_err(|e| error(&e.to_string()))?;
            let empty = matches!(&token, Event::Empty(_));
            let position = reader.buffer_position() as usize;
            let data = reader.get_ref().get_ref();
            let consumed = std::str::from_utf8(&data[self.position..position.min(data.len())])
                .map_err(|_| error("XML byte input must be UTF-8"))?;
            for c in consumed.chars() {
                if c == '\r' {
                    self.line += 1;
                    self.column = 0;
                } else if c == '\n' {
                    if !self.previous_cr {
                        self.line += 1;
                    }
                    self.column = 0;
                } else {
                    self.column += c.len_utf16();
                }
                self.previous_cr = c == '\r';
            }
            self.position = position;
            let (line, column) = (self.line, self.column);
            let mut event = XmlEvent {
                depth: self.stack.len(),
                namespaces: self.scope(),
                line,
                column,
                ..XmlEvent::default()
            };
            match token {
                Event::Decl(decl) => {
                    if self.root_seen
                        || self.tokens != 1
                        || decl.version().map_err(|e| error(&e.to_string()))? != "1.0"
                    {
                        return Err(error("Only an initial XML 1.0 declaration is supported"));
                    }
                    if !self.character_input
                        && let Some(encoding) = decl.encoding()
                    {
                        let encoding = encoding.map_err(|e| error(&e.to_string()))?;
                        if !matches!(
                            encoding.to_ascii_lowercase().as_str(),
                            "utf-8" | "utf8" | "us-ascii"
                        ) {
                            return Err(error("XML byte input currently supports UTF-8 only"));
                        }
                    }
                    continue;
                }
                Event::DocType(_) => {
                    return Err(error(
                        "XML DTD processing is unsupported; no external entities are opened",
                    ));
                }
                Event::Start(tag) | Event::Empty(tag) => {
                    if self.stack.is_empty() && self.root_seen {
                        return Err(error("Multiple XML document elements"));
                    }
                    if self.stack.len() >= 64 {
                        return Err(error("XML element depth quota"));
                    }
                    let mut raw_attributes = Vec::new();
                    for (index, attribute) in tag.attributes().enumerate() {
                        let attribute = attribute.map_err(|e| error(&e.to_string()))?;
                        if index >= 256 {
                            return Err(error("XML attribute quota"));
                        }
                        let name = attribute.key.into_inner().to_owned();
                        let value = attribute
                            .normalized_value(XmlVersion::Implicit1_0)
                            .map_err(|e| error(&e.to_string()))?
                            .into_owned();
                        xml_chars(&value)?;
                        if self.namespace_aware && (name == "xmlns" || name.starts_with("xmlns:")) {
                            let prefix = name.strip_prefix("xmlns:").unwrap_or("").to_owned();
                            if (!prefix.is_empty()
                                && (!valid_name(&prefix)
                                    || prefix.contains(':')
                                    || value.is_empty()))
                                || prefix == "xmlns"
                                || value == XMLNS_NS
                                || ((prefix == "xml") != (value == XML_NS))
                            {
                                return Err(error("Illegal XML namespace declaration"));
                            }
                            event.namespaces.push((self.stack.len() + 1, prefix, value));
                        } else {
                            raw_attributes.push((name, value));
                        }
                    }
                    if event.namespaces.len() > 1024 {
                        return Err(error("XML namespace quota"));
                    }
                    let name = self.qualified(tag.name().into_inner(), &event.namespaces, false)?;
                    event.name = Some(name.name);
                    event.namespace = Some(name.namespace);
                    event.prefix = name.prefix;
                    let mut unique = BTreeSet::new();
                    for (name, value) in raw_attributes {
                        let mut attribute = self.qualified(&name, &event.namespaces, true)?;
                        if !unique.insert((attribute.namespace.clone(), attribute.name.clone())) {
                            return Err(error("Duplicate expanded XML attribute"));
                        }
                        attribute.value = value;
                        event.attributes.push(attribute);
                    }
                    event.kind = 2;
                    event.depth += 1;
                    event.empty = empty;
                    self.root_seen = true;
                    self.empty_end = empty;
                    // Stack frames need names and scope, not duplicate attribute values.
                    self.stack.push(XmlEvent {
                        kind: 2,
                        depth: event.depth,
                        name: event.name.clone(),
                        prefix: event.prefix.clone(),
                        namespace: event.namespace.clone(),
                        namespaces: event
                            .namespaces
                            .iter()
                            .filter(|(depth, _, _)| *depth == event.depth)
                            .cloned()
                            .collect(),
                        empty,
                        line,
                        column,
                        ..XmlEvent::default()
                    });
                }
                Event::End(_) => {
                    let frame = self
                        .stack
                        .last()
                        .ok_or_else(|| error("Unmatched XML end tag"))?;
                    event.name = frame.name.clone();
                    event.prefix = frame.prefix.clone();
                    event.namespace = frame.namespace.clone();
                    event.kind = 3;
                    self.pop = true;
                }
                Event::Text(text) => {
                    event.text = Some(text.xml10_content().into_owned());
                    event.kind = 4;
                    if self.stack.is_empty() {
                        event.kind = 7;
                    }
                }
                Event::CData(text) => {
                    event.text = Some(text.xml10_content().into_owned());
                    event.kind = 5;
                }
                Event::GeneralRef(entity) => {
                    let name = entity.into_inner().into_owned();
                    event.text = Some(
                        quick_xml::escape::unescape(&format!("&{name};"))
                            .map_err(|e| error(&e.to_string()))?
                            .into_owned(),
                    );
                    event.name = Some(name);
                    event.kind = 6;
                }
                Event::Comment(text) => {
                    event.text = Some(text.xml10_content().into_owned());
                    event.kind = 9;
                }
                Event::PI(pi) => {
                    event.text = Some(pi.into_inner().into_owned());
                    event.kind = 8;
                }
                Event::Eof => {
                    if !self.stack.is_empty() || !self.root_seen {
                        return Err(error("Incomplete XML document"));
                    }
                    event.kind = 1;
                }
            }
            if let Some(text) = &event.text {
                xml_chars(text)?;
                if text.encode_utf16().count() > 16384 {
                    return Err(error("XML text token quota"));
                }
                if self.stack.is_empty()
                    && matches!(event.kind, 4..=7)
                    && (event.kind != 7
                        || !text.chars().all(|c| matches!(c, ' ' | '\t' | '\r' | '\n')))
                {
                    return Err(error("XML text outside document element"));
                }
            }
            return Ok(event);
        }
    }
    fn token(&mut self) -> Result<XmlEvent> {
        if let Some(event) = self.lookahead.take() {
            return Ok(event);
        }
        self.raw_token()
    }
    fn advance(&mut self, tokens: bool) -> Result<i32> {
        if self.current.kind == 1 {
            return Ok(1);
        }
        if self.compiled {
            if self.failed {
                return Err(error("Compiled XML parser failed"));
            }
            let binary = self.binary.as_mut().ok_or("Missing compiled XML cursor")?;
            self.current = binary
                .advance()
                .map_err(|cause| error(&cause.to_string()))?;
            if self.current.kind == 1 {
                self.binary = None;
            }
            return Ok(self.current.kind);
        }
        let mut event = self.token()?;
        if !tokens {
            while matches!(event.kind, 7..=9) {
                event = self.token()?;
            }
            if matches!(event.kind, 4..=6) {
                event.kind = 4;
                event.name = None;
                let mut text = event.text.take().unwrap_or_default();
                loop {
                    let next = self.token()?;
                    if matches!(next.kind, 4..=6) {
                        text.push_str(next.text.as_deref().unwrap_or_default());
                    } else if !matches!(next.kind, 8 | 9) {
                        self.lookahead = Some(next);
                        break;
                    }
                    if text.encode_utf16().count() > 16384 {
                        return Err(error("Coalesced XML text quota"));
                    }
                }
                event.text = Some(text);
            }
        }
        let kind = event.kind;
        self.current = event;
        Ok(kind)
    }
}

impl Runtime {
    pub(super) fn compiled_xml_input_limit(&self) -> usize {
        binary::input_limit(
            self.heap_limit
                .saturating_sub(self.heap_bytes() + std::mem::size_of::<Parser>() + 256),
        )
    }

    pub(super) fn allocate_compiled_xml(&mut self, data: Vec<u8>) -> Result<u32> {
        let mut parser = Parser::new(true);
        parser.compiled = true;
        parser.binary = Some(binary::Binary::new(data)?);
        if parser.bytes() + 256 > self.heap_limit.saturating_sub(self.heap_bytes()) {
            return Err("Compiled XML exceeds the Java heap budget".into());
        }
        self.allocate(COMPILED_PARSER, Payload::Xml(Some(Box::new(parser))))
    }

    fn xml_attribute_text(&mut self, attribute: &Attribute) -> Result<u64> {
        let text = match attribute.compiled {
            None => Some(Cow::Borrowed(attribute.value.as_str())),
            Some(info) if info.has_raw_string || info.value.kind == 3 => {
                Some(Cow::Borrowed(attribute.value.as_str()))
            }
            Some(info) => {
                let data = info.value.data;
                let number = data as i32;
                match info.value.kind {
                    1 | 7 => Some(Cow::Owned(format!("@{number}"))),
                    2 | 8 => Some(Cow::Owned(format!("?{number}"))),
                    4 => Some(Cow::Owned(xml_float(f32::from_bits(data)))),
                    5 => ["px", "dip", "sp", "pt", "in", "mm"]
                        .get((data & 15) as usize)
                        .map(|unit| {
                            Cow::Owned(format!("{}{unit}", xml_float(resources_api::complex(data))))
                        }),
                    6 => ["%", "%p"].get((data & 15) as usize).map(|unit| {
                        Cow::Owned(format!(
                            "{}{unit}",
                            xml_float(resources_api::complex(data) * 100.0)
                        ))
                    }),
                    0x11 => Some(Cow::Owned(format!("0x{data:x}"))),
                    0x12 => Some(Cow::Borrowed(if data == 0 { "false" } else { "true" })),
                    0x1c..=0x1f => Some(Cow::Owned(format!("#{data:x}"))),
                    0x10..=0x1f => Some(Cow::Owned(number.to_string())),
                    _ => None,
                }
            }
        };
        text.map_or(Ok(0), |text| self.string(&text).map(u64::from))
    }

    fn compiled_attribute_by_name<'a>(
        &self,
        event: &'a XmlEvent,
        namespace: u32,
        name: u32,
    ) -> Result<Option<&'a Attribute>> {
        let namespace = if namespace == 0 {
            String::new()
        } else {
            self.text(namespace)?
        };
        let name = self.text(name)?;
        Ok(event
            .attributes
            .iter()
            .find(|attribute| attribute.name == name && attribute.namespace == namespace))
    }

    fn compiled_xml_api(
        &mut self,
        parser: &mut Parser,
        method: &str,
        args: &[u32],
    ) -> Result<Option<u64>> {
        let arg = |i: usize| args.get(i).copied().ok_or("Compiled XML argument count");
        let event = &parser.current;
        let attr = |index: usize| -> Result<&Attribute> {
            event.attributes.get(index).ok_or_else(|| {
                fault(
                    "Ljava/lang/IndexOutOfBoundsException;",
                    "Compiled XML attribute index",
                )
            })
        };
        let result = match method {
            "close()V" => {
                parser.binary = None;
                parser.current = XmlEvent {
                    kind: 1,
                    ..XmlEvent::default()
                };
                0
            }
            "getNamespace()Ljava/lang/String;" => {
                self.string(event.namespace.as_deref().unwrap_or(""))? as u64
            }
            "getPositionDescription()Ljava/lang/String;" => {
                self.string(&format!("Binary XML file line #{}", event.line))? as u64
            }
            "getColumnNumber()I" => u32::MAX as u64,
            "isEmptyElementTag()Z"
            | "isWhitespace()Z"
            | "isAttributeDefault(I)Z"
            | "getProperty(Ljava/lang/String;)Ljava/lang/Object;" => 0,
            "getAttributeType(I)Ljava/lang/String;" => self.string("CDATA")? as u64,
            "getFeature(Ljava/lang/String;)Z" => matches!(
                self.text(arg(1)?)?.as_str(),
                FEATURE_NS | FEATURE_NS_ATTRIBUTES
            ) as u64,
            "setFeature(Ljava/lang/String;Z)V" => {
                if !matches!(
                    self.text(arg(1)?)?.as_str(),
                    FEATURE_NS | FEATURE_NS_ATTRIBUTES
                ) || arg(2)? == 0
                {
                    return Err(error("Unsupported compiled XML feature"));
                }
                0
            }
            "setInput(Ljava/io/Reader;)V"
            | "setInput(Ljava/io/InputStream;Ljava/lang/String;)V"
            | "setProperty(Ljava/lang/String;Ljava/lang/Object;)V"
            | "defineEntityReplacementText(Ljava/lang/String;Ljava/lang/String;)V"
            | "getNamespaceCount(I)I"
            | "getNamespacePrefix(I)Ljava/lang/String;"
            | "getNamespaceUri(I)Ljava/lang/String;" => {
                return Err(error("Operation is unavailable for compiled XML"));
            }
            "getPrefix()Ljava/lang/String;"
            | "getNamespace(Ljava/lang/String;)Ljava/lang/String;"
            | "getAttributePrefix(I)Ljava/lang/String;" => {
                return Err(fault(
                    "Ljava/lang/RuntimeException;",
                    "Compiled XML does not expose prefixes",
                ));
            }
            "getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;" => self
                .compiled_attribute_by_name(event, arg(1)?, arg(2)?)?
                .map_or(Ok(0), |attribute| self.xml_attribute_text(attribute))?,
            "getAttributeNameResource(I)I" => event
                .attributes
                .get(arg(1)? as usize)
                .and_then(|attribute| attribute.compiled)
                .map_or(0, |info| info.resource as u64),
            "getIdAttribute()Ljava/lang/String;" | "getClassAttribute()Ljava/lang/String;" => {
                let indices = event.compiled_indices.unwrap_or_default();
                let index = if method.starts_with("getId") {
                    indices.id
                } else {
                    indices.class
                };
                let attribute = index.and_then(|index| event.attributes.get(index));
                match attribute
                    .filter(|attribute| attribute.compiled.is_some_and(|info| info.has_raw_string))
                {
                    Some(attribute) => self.string(&attribute.value)? as u64,
                    None => 0,
                }
            }
            "getIdAttributeResourceValue(I)I" | "getStyleAttribute()I" => {
                let indices = event.compiled_indices.unwrap_or_default();
                let id = method.starts_with("getId");
                let index = if id { indices.id } else { indices.style };
                let value = index
                    .and_then(|index| event.attributes.get(index))
                    .and_then(|attribute| attribute.compiled)
                    .filter(|info| info.value.kind == 1 || !id && info.value.kind == 2)
                    .map(|info| info.value.data as u64);
                if let Some(value) = value {
                    value
                } else if id {
                    arg(1)? as u64
                } else {
                    0
                }
            }
            _ => {
                let (name, params) = method.split_once('(').ok_or("Compiled XML method")?;
                let (by_name, default_index) = match params {
                    "II)I" | "IZ)Z" | "IF)F" | "I[Ljava/lang/String;I)I" => (false, 2),
                    "Ljava/lang/String;Ljava/lang/String;I)I"
                    | "Ljava/lang/String;Ljava/lang/String;Z)Z"
                    | "Ljava/lang/String;Ljava/lang/String;F)F"
                    | "Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;I)I" => (true, 3),
                    _ => return Ok(None),
                };
                if !matches!(
                    name,
                    "getAttributeResourceValue"
                        | "getAttributeIntValue"
                        | "getAttributeUnsignedIntValue"
                        | "getAttributeFloatValue"
                        | "getAttributeBooleanValue"
                        | "getAttributeListValue"
                ) {
                    return Ok(None);
                }
                let fallback =
                    arg(default_index + usize::from(name == "getAttributeListValue"))? as u64;
                let attribute = if by_name {
                    self.compiled_attribute_by_name(event, arg(1)?, arg(2)?)?
                } else {
                    Some(attr(arg(1)? as usize)?)
                };
                let Some(attribute) = attribute else {
                    return Ok(Some(fallback));
                };
                let value = attribute
                    .compiled
                    .ok_or("Missing compiled attribute type")?
                    .value;
                match name {
                    "getAttributeResourceValue" if matches!(value.kind, 1 | 7) => value.data as u64,
                    "getAttributeIntValue" | "getAttributeUnsignedIntValue"
                        if matches!(value.kind, 0x10..=0x1f) =>
                    {
                        value.data as u64
                    }
                    "getAttributeBooleanValue" if matches!(value.kind, 0x10..=0x1f) => {
                        (value.data != 0) as u64
                    }
                    "getAttributeFloatValue" if value.kind == 4 => value.data as u64,
                    "getAttributeFloatValue" => {
                        return Err(fault(
                            "Ljava/lang/RuntimeException;",
                            "Compiled XML attribute is not a float",
                        ));
                    }
                    "getAttributeListValue" if value.kind == 3 => {
                        let Payload::Array(options) = &self.object(arg(default_index)?)?.payload
                        else {
                            return Err("Compiled XML option array".into());
                        };
                        let mut result = fallback;
                        for (i, option) in options.iter().copied().enumerate() {
                            if option != 0 && self.text(option as u32)? == attribute.value {
                                result = i as u64;
                                break;
                            }
                        }
                        result
                    }
                    "getAttributeListValue" => value.data as u64,
                    _ => fallback,
                }
            }
        };
        Ok(Some(result))
    }

    fn prepare_xml_input(&mut self, parser: &mut Parser) -> Result<()> {
        if parser.reader.is_some() {
            return Ok(());
        }
        self.object(parser.input)?;
        let limit =
            (self.heap_limit.saturating_sub(self.heap_bytes() + 65536) / 8).min(1024 * 1024);
        let mut data = Vec::new();
        if parser.character_input {
            let mut units = Vec::new();
            while let Some(unit) = self.reader_unit(parser.input, 0)? {
                if units.len() >= limit {
                    return Err(error("XML input memory quota"));
                }
                units.push(unit);
            }
            data = String::from_utf16(&units)
                .map_err(|_| error("Unpaired surrogate in XML reader"))?
                .into_bytes();
            if data.len() > limit {
                return Err(error("XML input memory quota"));
            }
        } else {
            loop {
                let bytes = self.read_input_bytes(parser.input, 8192)?;
                if data.len() + bytes.len() > limit {
                    return Err(error("XML input memory quota"));
                }
                if bytes.is_empty() {
                    break;
                }
                data.extend(bytes);
            }
            if parser.encoding.is_none() {
                parser.encoding = Some("UTF-8".into());
            }
        }
        if data.starts_with(&[0xef, 0xbb, 0xbf]) {
            data.drain(..3);
        }
        parser.document(data);
        Ok(())
    }
    pub(super) fn xml_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        if sig == "Landroid/util/Xml;->newPullParser()Lorg/xmlpull/v1/XmlPullParser;" {
            return Ok(Some(
                self.allocate(PARSER, Payload::Xml(Some(Box::new(Parser::new(true)))))? as u64,
            ));
        }
        let (class, method) = sig.split_once("->").ok_or("XML API signature")?;
        if !matches!(
            class,
            PARSER
                | COMPILED_PARSER
                | RESOURCE_PARSER
                | "Lorg/xmlpull/v1/XmlPullParser;"
                | "Landroid/util/AttributeSet;"
                | "Ljava/lang/AutoCloseable;"
        ) {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("XML argument count");
        let id = arg(0)?;
        let Payload::Xml(slot) = &mut self.object_mut(id)?.payload else {
            return Ok(None);
        };
        let mut parser = slot.take().ok_or("Recursive XML parser access")?;
        let result = (|| -> Result<Option<u64>> {
            if parser.compiled
                && let Some(value) = self.compiled_xml_api(&mut parser, method, a)?
            {
                return Ok(Some(value));
            }
            if matches!(
                method,
                "setInput(Ljava/io/Reader;)V"
                    | "setInput(Ljava/io/InputStream;Ljava/lang/String;)V"
            ) {
                let input = arg(1)?;
                let character_input = method.contains("Ljava/io/Reader;");
                let encoding = if !character_input && arg(2)? != 0 {
                    let value = self.text(arg(2)?)?;
                    if !matches!(value.to_ascii_lowercase().as_str(), "utf-8" | "utf8") {
                        return Err(error("XML byte input currently supports UTF-8 only"));
                    }
                    Some("UTF-8".into())
                } else {
                    None
                };
                if input != 0 {
                    let payload = &self.object(input)?.payload;
                    if !(character_input && matches!(payload, Payload::Reader(Some(_)))
                        || !character_input && matches!(payload, Payload::FileStream(Some(_))))
                    {
                        return Err(
                            "Custom XML Reader/InputStream adapters are not implemented".into()
                        );
                    }
                }
                *parser = Parser::new(parser.namespace_aware);
                parser.input = input;
                parser.character_input = character_input;
                parser.encoding = encoding;
                return Ok(Some(0));
            }
            if matches!(
                method,
                "next()I" | "nextToken()I" | "nextTag()I" | "nextText()Ljava/lang/String;"
            ) {
                let advance = (|| -> Result<u64> {
                    if parser.input == 0 && !parser.compiled {
                        return Err(error("XML input is not set"));
                    }
                    if !parser.compiled {
                        self.prepare_xml_input(&mut parser)?;
                    }
                    if method.starts_with("nextText") {
                        if parser.current.kind != 2 {
                            return Err(error("nextText requires START_TAG"));
                        }
                        let kind = parser.advance(false)?;
                        let text = if kind == 4 {
                            parser.current.text.clone().unwrap_or_default()
                        } else if kind == 3 {
                            String::new()
                        } else {
                            return Err(error("nextText encountered nested content"));
                        };
                        if kind == 4 && parser.advance(false)? != 3 {
                            return Err(error("nextText requires END_TAG after text"));
                        }
                        return Ok(self.string(&text)? as u64);
                    }
                    let mut kind = parser.advance(method == "nextToken()I")?;
                    if method == "nextTag()I" {
                        if kind == 4
                            && parser
                                .current
                                .text
                                .as_deref()
                                .unwrap_or_default()
                                .chars()
                                .all(|c| matches!(c, ' ' | '\t' | '\r' | '\n'))
                        {
                            kind = parser.advance(false)?;
                        }
                        if !matches!(kind, 2 | 3) {
                            return Err(error("nextTag expected START_TAG or END_TAG"));
                        }
                    }
                    Ok(kind as u64)
                })();
                if advance.is_err() {
                    parser.failed = true;
                }
                return advance.map(Some);
            }
            let event = &parser.current;
            let value = match method {
                "getEventType()I" => event.kind as u32 as u64,
                "getDepth()I" => event.depth as u64,
                "getLineNumber()I" => event.line as u64,
                "getColumnNumber()I" => event.column as u64,
                "getName()Ljava/lang/String;"
                | "getPrefix()Ljava/lang/String;"
                | "getNamespace()Ljava/lang/String;"
                | "getText()Ljava/lang/String;"
                | "getInputEncoding()Ljava/lang/String;" => {
                    let text = match method {
                        "getName()Ljava/lang/String;" => event.name.as_ref(),
                        "getPrefix()Ljava/lang/String;" => event.prefix.as_ref(),
                        "getNamespace()Ljava/lang/String;" => event.namespace.as_ref(),
                        "getInputEncoding()Ljava/lang/String;" => parser.encoding.as_ref(),
                        _ => event.text.as_ref(),
                    };
                    if let Some(text) = text {
                        self.string(text)? as u64
                    } else {
                        0
                    }
                }
                "getPositionDescription()Ljava/lang/String;" => self.string(&format!(
                    "Native XML event {} at {}:{}",
                    event.kind, event.line, event.column
                ))? as u64,
                "getAttributeCount()I" => {
                    if event.kind == 2 {
                        event.attributes.len() as u64
                    } else {
                        u32::MAX as u64
                    }
                }
                "isEmptyElementTag()Z" => {
                    if event.kind != 2 {
                        return Err(error("isEmptyElementTag requires START_TAG"));
                    }
                    event.empty as u64
                }
                "isWhitespace()Z" => {
                    if !matches!(event.kind, 4 | 5 | 7) {
                        return Err(error("isWhitespace requires a text event"));
                    }
                    event
                        .text
                        .as_deref()
                        .unwrap_or_default()
                        .chars()
                        .all(|c| matches!(c, ' ' | '\t' | '\r' | '\n')) as u64
                }
                "getAttributeName(I)Ljava/lang/String;"
                | "getAttributeNamespace(I)Ljava/lang/String;"
                | "getAttributePrefix(I)Ljava/lang/String;"
                | "getAttributeValue(I)Ljava/lang/String;"
                | "getAttributeType(I)Ljava/lang/String;"
                | "isAttributeDefault(I)Z" => {
                    let attribute = event
                        .attributes
                        .get(arg(1)? as usize)
                        .filter(|_| event.kind == 2)
                        .ok_or_else(|| {
                            fault(
                                "Ljava/lang/IndexOutOfBoundsException;",
                                "XML attribute index",
                            )
                        })?;
                    let text = match method {
                        "getAttributeName(I)Ljava/lang/String;" => Some(attribute.name.as_str()),
                        "getAttributeNamespace(I)Ljava/lang/String;" => {
                            Some(attribute.namespace.as_str())
                        }
                        "getAttributePrefix(I)Ljava/lang/String;" => attribute.prefix.as_deref(),
                        "getAttributeValue(I)Ljava/lang/String;" => {
                            return self.xml_attribute_text(attribute).map(Some);
                        }
                        "getAttributeType(I)Ljava/lang/String;" => Some("CDATA"),
                        _ => return Ok(Some(0)),
                    };
                    if let Some(text) = text {
                        self.string(text)? as u64
                    } else {
                        0
                    }
                }
                "getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;" => {
                    if event.kind != 2 {
                        return Err(fault(
                            "Ljava/lang/IndexOutOfBoundsException;",
                            "XML attributes require START_TAG",
                        ));
                    }
                    let namespace = if arg(1)? == 0 {
                        String::new()
                    } else {
                        self.text(arg(1)?)?
                    };
                    let name = String::from_utf16(&self.units(arg(2)?)?)
                        .map_err(|_| error("Invalid XML attribute name"))?;
                    if let Some(attribute) = event
                        .attributes
                        .iter()
                        .find(|a| a.namespace == namespace && a.name == name)
                    {
                        self.xml_attribute_text(attribute)?
                    } else {
                        0
                    }
                }
                "getNamespace(Ljava/lang/String;)Ljava/lang/String;" => {
                    let prefix = if arg(1)? == 0 {
                        String::new()
                    } else {
                        self.text(arg(1)?)?
                    };
                    if parser.namespace_aware
                        && let Some(uri) = Parser::namespace(&event.namespaces, &prefix)
                    {
                        self.string(&uri)? as u64
                    } else {
                        0
                    }
                }
                "getNamespaceCount(I)I" => {
                    let depth = arg(1)? as i32;
                    if depth < 0 || depth as usize > event.depth {
                        return Err(error("XML namespace depth out of range"));
                    }
                    event
                        .namespaces
                        .iter()
                        .filter(|(d, _, _)| *d <= depth as usize)
                        .count() as u64
                }
                "getNamespacePrefix(I)Ljava/lang/String;"
                | "getNamespaceUri(I)Ljava/lang/String;" => {
                    let (_, prefix, uri) = event
                        .namespaces
                        .get(arg(1)? as usize)
                        .ok_or_else(|| error("XML namespace index out of range"))?;
                    if method.starts_with("getNamespacePrefix") {
                        if prefix.is_empty() {
                            0
                        } else {
                            self.string(prefix)? as u64
                        }
                    } else {
                        self.string(uri)? as u64
                    }
                }
                "getFeature(Ljava/lang/String;)Z" => {
                    (self.text(arg(1)?)? == FEATURE_NS && parser.namespace_aware) as u64
                }
                "setFeature(Ljava/lang/String;Z)V" => {
                    if event.kind != 0 {
                        return Err(error("XML features cannot change during parsing"));
                    }
                    let name = self.text(arg(1)?)?;
                    if name == FEATURE_NS {
                        parser.namespace_aware = arg(2)? != 0;
                    } else if arg(2)? != 0
                        || !matches!(
                            name.as_str(),
                            "http://xmlpull.org/v1/doc/features.html#validation"
                                | "http://xmlpull.org/v1/doc/features.html#process-docdecl"
                                | "http://xmlpull.org/v1/doc/features.html#report-namespace-prefixes"
                        )
                    {
                        return Err(error("Unsupported XML parser feature"));
                    }
                    0
                }
                "require(ILjava/lang/String;Ljava/lang/String;)V" => {
                    let namespace = if arg(2)? == 0 {
                        None
                    } else {
                        Some(self.text(arg(2)?)?)
                    };
                    let name = if arg(3)? == 0 {
                        None
                    } else {
                        Some(self.text(arg(3)?)?)
                    };
                    if event.kind != arg(1)? as i32
                        || namespace
                            .as_ref()
                            .is_some_and(|v| event.namespace.as_ref() != Some(v))
                        || name
                            .as_ref()
                            .is_some_and(|v| event.name.as_ref() != Some(v))
                    {
                        return Err(error("XML event does not match require()"));
                    }
                    0
                }
                _ => return Ok(None),
            };
            Ok(Some(value))
        })();
        let bytes = parser.bytes();
        self.object_mut(id)?.payload = Payload::Xml(Some(parser));
        if self.heap_bytes() > self.heap_limit && bytes > 0 {
            return Err("XML parser Java heap quota".into());
        }
        result
    }
}

fn xml_float(value: f32) -> String {
    if value.is_nan() {
        "NaN".into()
    } else if value.is_infinite() {
        if value.is_sign_negative() {
            "-Infinity".into()
        } else {
            "Infinity".into()
        }
    } else if value != 0.0 && !(0.001..10_000_000.0).contains(&value.abs()) {
        let scientific = format!("{value:e}");
        if let Some((mantissa, exponent)) = scientific.split_once('e') {
            let fraction = if mantissa.contains('.') { "" } else { ".0" };
            format!("{mantissa}{fraction}E{exponent}")
        } else {
            scientific
        }
    } else {
        format!("{value:?}")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn parser(text: &str) -> Parser {
        let mut p = Parser::new(true);
        p.document(text.as_bytes().to_vec());
        p
    }
    #[test]
    fn text_coalescing_and_lookahead_preserve_current_namespace_scope() {
        let mut p =
            parser("<r xmlns='outer'>a&amp;<![CDATA[b]]><!--x--><c xmlns='inner'/><tail/></r>");
        assert_eq!(p.advance(false).unwrap(), 2);
        assert_eq!(p.advance(false).unwrap(), 4);
        assert_eq!(p.current.text.as_deref(), Some("a&b"));
        assert_eq!(
            Parser::namespace(&p.current.namespaces, "").as_deref(),
            Some("outer")
        );
        assert_eq!(p.advance(false).unwrap(), 2);
        assert_eq!(p.current.namespace.as_deref(), Some("inner"));
        assert!(p.current.empty);
        assert_eq!(p.advance(false).unwrap(), 3);
        assert_eq!(p.current.depth, 2);
        assert_eq!(p.advance(false).unwrap(), 2);
        assert_eq!(p.current.namespace.as_deref(), Some("outer"));
        assert_eq!(p.current.namespaces.len(), 1);
        assert_eq!(p.advance(false).unwrap(), 3);
        assert_eq!(p.advance(false).unwrap(), 3);
        assert_eq!(p.advance(false).unwrap(), 1);
        assert_eq!(p.current.depth, 0);
    }
    #[test]
    fn malformed_documents_and_resource_exhaustion_are_rejected() {
        for document in [
            "",
            "<r>",
            "<r></s>",
            "<r/><s/>",
            "text<r/>",
            "<r/>tail",
            "<r>&unknown;</r>",
            "<r a='1' a='2'/>",
            "<r xmlns:a='u' xmlns:b='u' a:x='1' b:x='2'/>",
            "<p:r/>",
            "<r>\0</r>",
            "<1invalid/>",
            "<r><!--bad--comment--></r>",
            "<!DOCTYPE r SYSTEM 'file:///etc/passwd'><r/>",
            "<?xml version='1.1'?><r/>",
            "<r xmlns:xml='wrong'/>",
            "<r xmlns:p=''/>",
        ] {
            let mut p = parser(document);
            let mut rejected = false;
            for _ in 0..20 {
                match p.advance(false) {
                    Ok(1) => break,
                    Ok(_) => {}
                    Err(_) => {
                        rejected = true;
                        break;
                    }
                }
            }
            assert!(rejected, "accepted invalid document {document:?}");
        }
        let document = "<r>".repeat(65) + &"</r>".repeat(65);
        let mut p = parser(&document);
        for _ in 0..64 {
            assert_eq!(p.advance(false).unwrap(), 2);
        }
        assert!(p.advance(false).is_err());
    }
}
