#!/usr/bin/env python3
"""Build a multidex APK exercising the real VM and RegisterNatives on both ABIs."""
import argparse,hashlib,json,pathlib,subprocess,tempfile,zipfile
p=argparse.ArgumentParser()
p.add_argument('--r8',required=True);p.add_argument('--output',required=True);p.add_argument('--aapt2')
for kind in ['platform','event','file','bridge','resource','provider','reader','xml','concurrency','thread','initialization','stack','group','stream-field','field-array','unsafe','bit','map-set','charset','base64','sqlite','logging','executor','formatter','messenger','scheduled','handoff','hash-map']:p.add_argument('--'+kind+'-checks',action='store_true')
p.add_argument('--bootstrap-checks', action='store_true')
a=p.parse_args()
kinds=[a.platform_checks,a.event_checks,a.file_checks,a.bridge_checks,a.resource_checks,a.provider_checks,a.reader_checks,a.xml_checks,a.concurrency_checks,a.thread_checks,a.initialization_checks,a.stack_checks,a.group_checks,a.stream_field_checks,a.field_array_checks,a.unsafe_checks,a.bit_checks,a.map_set_checks,a.charset_checks,a.base64_checks,a.sqlite_checks,a.logging_checks,a.executor_checks,a.formatter_checks,a.messenger_checks,a.scheduled_checks,a.handoff_checks,a.hash_map_checks]
kinds.append(a.bootstrap_checks)
if sum(kinds)>1:p.error('Choose a single fixture kind')
if (a.resource_checks or a.provider_checks) and not a.aapt2:p.error('Resource fixture requires --aapt2')
here=pathlib.Path(__file__).resolve().parent;out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=True)
if hashlib.sha256(pathlib.Path(a.r8).read_bytes()).hexdigest()!=json.loads((here/'TOOLCHAIN.json').read_text())['r8_sha256']:raise SystemExit('D8 digest mismatch')
def run(*args):subprocess.run([str(v) for v in args],check=True)
with tempfile.TemporaryDirectory(prefix='rift-advanced-') as temp:
    t=pathlib.Path(temp)
    for name in ['sdk','classes','extra','dex','dex2']:(t/name).mkdir()
    sdk_sources = sorted((here/'sdk-stubs').rglob('*.java'))
    extra_sources = sorted((here/'native-checks').rglob('*.java'))
    if a.bootstrap_checks:
        sdk_sources.extend(sorted((here/'../crates/rift-native/support/aosp-json').glob('*.java')))
        extra_sources.extend(sorted((here/'bootstrap-checks').rglob('*.java')))
    run('javac','--release','8','-d',t/'sdk',*sdk_sources)
    run('jar','cf',t/'sdk.jar','-C',t/'sdk','.')
    run('javac','--release','8','-classpath',t/'sdk.jar','-d',t/'extra',*extra_sources)
    run('jar','cf',t/'extra.jar','-C',t/'extra','.')
    code=(here/'native-demo/org/kyvex/nativehello/MainActivity.java').read_text()
    code=code.replace('private static native String nativeMessage();','''private static native String nativeMessage();
    private static native double mixedNative(long marker,float f,double d,int a,int b,int c,int x,int y,int z,int q,int r);
    private static native long alignedNative(int pad,long wide,int tail);
    private static native float floatingNative(float value);
    private static native double fpStackNative(double a,double b,double c,double d,double f,double g,double h,double i,double j,double k);
    private static void verifyNativeAbi() {
        if(mixedNative(0x1122334455667788L,1.25f,2.5,1,2,3,4,5,6,7,8)!=39.75)throw new IllegalArgumentException("Mixed JNI ABI");
        if(alignedNative(3,0x1122334455667788L,5)!=0x1122334455667790L)throw new IllegalArgumentException("Aligned long JNI ABI");
        if(floatingNative(2.0f)!=3.0f)throw new IllegalArgumentException("Float JNI ABI");
        if(fpStackNative(1,2,3,4,5,6,7,8,9,10)!=55.0)throw new IllegalArgumentException("FP stack JNI ABI");
    }''')
    code=code.replace('super.onCreate(state);','super.onCreate(state);verifyNativeAbi();')
    if a.platform_checks:
        code=code.replace('verifyNativeAbi();','verifyNativeAbi();org.kyvex.extra.PlatformChecks.verify(this);')
    code=code.replace('setTitle("Hello from Rift Native");','setTitle("Rift Native / Multidex + JNI");').replace('"A Java Activity calling real ARM machine code through JNI."','"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)')
    if a.event_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Event queue: pending"')
        code=code.replace('detail.setTextColor(0xffc3cde0);','detail.setTextColor(0xffc3cde0);org.kyvex.extra.EventChecks.watch(detail);')
        code=code.replace('setContentView(layout);','setContentView(layout);org.kyvex.extra.EventChecks.schedule();')
    if a.file_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"File checks: "+org.kyvex.extra.FileChecks.verify(this)')
    if a.bridge_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Bridge checks: "+org.kyvex.extra.BridgeChecks.verify(this)')
    if a.resource_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Resource checks: "+org.kyvex.extra.ResourceChecks.verify(this)')
    if a.provider_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Provider lifecycle: "+org.kyvex.extra.ProviderChecks.verify(this)')
        code=code.replace('detail.setTextColor(0xffc3cde0);','detail.setTextColor(0xffc3cde0);org.kyvex.extra.ProviderChecks.watch(detail);')
        code=code.replace('setContentView(layout);','TextView xml=new TextView(this);xml.setText("Compiled XML checks: "+org.kyvex.extra.CompiledXmlChecks.result());layout.addView(xml);setContentView(layout);')
    if a.reader_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Reader checks: "+org.kyvex.extra.ReaderChecks.verify(this)')
    if a.xml_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"XML checks: "+org.kyvex.extra.XmlChecks.verify(this)')
    if a.concurrency_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Atomic field checks: "+org.kyvex.extra.AtomicFieldChecks.verify()+" / Runtime checks: "+org.kyvex.extra.RuntimeInfoChecks.verify()+" / Execution result: "+org.kyvex.extra.ExecutionChecks.verify()')
    if a.thread_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Thread checks: "+org.kyvex.extra.ThreadChecks.report()+" / JNI thread checks: "+org.kyvex.extra.ThreadNativeChecks.verify()')
        code=code.replace('setContentView(layout);','TextView background=new TextView(this);background.setText("Worker timer: pending");layout.addView(background);setContentView(layout);org.kyvex.extra.ThreadNativeChecks.schedule(background);')
    if a.initialization_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Initialization checks: "+org.kyvex.extra.InitializationChecks.report()')
    if a.stack_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Stack checks: "+org.kyvex.extra.StackChecks.report()+" / Native stack checks: "+org.kyvex.extra.StackChecks.verifyNative()')
    if a.group_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Group checks: "+org.kyvex.extra.GroupChecks.report()')
    if a.stream_field_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Stream field checks: "+org.kyvex.extra.StreamFieldChecks.report()')
    if a.field_array_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Field array checks: "+org.kyvex.extra.FieldArrayChecks.report()')
    if a.unsafe_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Unsafe checks: "+org.kyvex.extra.UnsafeChecks.report()')
    if a.bit_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Bit checks: "+org.kyvex.extra.BitChecks.verify()')
    if a.map_set_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Map set checks: "+org.kyvex.extra.MapSetChecks.verify()')
    if a.charset_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Charset checks: "+org.kyvex.extra.CharsetChecks.report()')
    if a.base64_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Base64 checks: "+org.kyvex.extra.Base64Checks.verify()')
        code=code.replace('setContentView(layout);','TextView numbers=new TextView(this);numbers.setText("Number parse checks: "+org.kyvex.extra.NumberParseChecks.verify());layout.addView(numbers);setContentView(layout);')
    if a.sqlite_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"SQLite checks: "+org.kyvex.extra.SqliteChecks.verify(this)')
    if a.logging_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Logging checks: "+org.kyvex.extra.LoggingChecks.verify()')
    if a.executor_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Executor checks: "+org.kyvex.extra.ExecutorChecks.verify()')
    if a.formatter_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Formatter checks: "+org.kyvex.extra.FormatterChecks.verify()')
    if a.messenger_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Messenger checks: preparing"')
        code=code.replace('setContentView(layout);','setContentView(layout);org.kyvex.extra.MessengerChecks.schedule(detail);')
    if a.scheduled_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Scheduled checks: "+org.kyvex.extra.ScheduledChecks.verify()')
    if a.handoff_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Handoff checks: "+org.kyvex.extra.HandoffChecks.verify()')
    if a.hash_map_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"HashMap checks: "+org.kyvex.extra.HashMapChecks.verify()')
    if a.bootstrap_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Storage checks: "+org.kyvex.extra.StorageChecks.verify(this)')
        code=code.replace('setContentView(layout);','''
        TextView json = new TextView(this);
        json.setText("JSON checks: " + org.kyvex.extra.JsonChecks.verify());
        layout.addView(json);
        TextView executor = new TextView(this);
        executor.setText("Executor delegate checks: " + org.kyvex.extra.DelegateChecks.verify());
        layout.addView(executor);
        TextView link = new TextView(this);
        link.setText("ELF link checks: " + org.kyvex.extra.LinkChecks.verify());
        layout.addView(link);
        TextView heap = new TextView(this);
        heap.setText("Native heap checks: " + org.kyvex.extra.LinkChecks.verifyHeap());
        layout.addView(heap);
        TextView strict = new TextView(this);
        strict.setText("StrictMode checks: " + org.kyvex.extra.StrictChecks.verify(this));
        layout.addView(strict);
        TextView regex = new TextView(this);
        regex.setText("Regex replacement checks: " + org.kyvex.extra.RegexChecks.verify());
        layout.addView(regex);
        TextView integers = new TextView(this);
        integers.setText("Native integer checks: " + org.kyvex.extra.LinkChecks.verifyInteger());
        layout.addView(integers);
        TextView stdio = new TextView(this);
        stdio.setText("Native stdio checks: " + org.kyvex.extra.LinkChecks.verifyStdio());
        layout.addView(stdio);
        TextView text = new TextView(this);
        text.setText("Managed text checks: " + org.kyvex.extra.ManagedTextChecks.verify());
        layout.addView(text);
        TextView paint = new TextView(this);
        paint.setText("TextPaint checks: " + org.kyvex.extra.PaintChecks.verify());
        layout.addView(paint);
        TextView arrays = new TextView(this);
        arrays.setText("System.arraycopy checks: " + org.kyvex.extra.ArrayCopyChecks.verify());
        layout.addView(arrays);
        TextView rounding = new TextView(this);
        rounding.setText("Rounding checks: " + org.kyvex.extra.RoundingChecks.verify());
        layout.addView(rounding);
        TextView locks = new TextView(this);
        locks.setText("Read/write lock checks: " + org.kyvex.extra.ReadWriteChecks.verify());
        layout.addView(locks);
        TextView features = new TextView(this);
        features.setText("Android coordination checks: " + org.kyvex.extra.FeatureChecks.verify(this));
        layout.addView(features);
        TextView graphics = new TextView(this);
        graphics.setText("Android graphics checks: " + org.kyvex.extra.GraphicsChecks.verify(this));
        layout.addView(graphics);
        TextView scan = new TextView(this);
        scan.setText("Native scanf checks: " + org.kyvex.extra.LinkChecks.verifyScan());
        layout.addView(scan);
        TextView allocatedFormat = new TextView(this);
        allocatedFormat.setText("Native allocated format checks: " + org.kyvex.extra.LinkChecks.verifyAllocFormat());
        layout.addView(allocatedFormat);
        TextView pairSettings = new TextView(this);
        pairSettings.setText("Pair and Settings checks: " + org.kyvex.extra.PairSettingsChecks.verify(this));
        layout.addView(pairSettings);
        TextView followup = new TextView(this);
        followup.setText("Discard and array hash checks: " + org.kyvex.extra.FollowupChecks.verify());
        layout.addView(followup);
        TextView strings = new TextView(this);
        strings.setText("Native string checks: " + org.kyvex.extra.LinkChecks.verifyStrings());
        layout.addView(strings);
        TextView pthreads = new TextView(this);
        pthreads.setText("Native pthread checks: " + org.kyvex.extra.LinkChecks.verifyPthreads());
        layout.addView(pthreads);
        TextView cLocale = new TextView(this);
        cLocale.setText("Native C locale checks: " + org.kyvex.extra.LinkChecks.verifyCLocale());
        layout.addView(cLocale);
        setContentView(layout);''')
    (t/'MainActivity.java').write_text(code)
    run('javac','--release','8','-classpath',str(t/'sdk.jar')+':'+str(t/'extra.jar'),'-d',t/'classes',t/'MainActivity.java')
    for source,dest,cp in [('classes','dex','extra.jar'),('extra','dex2','sdk.jar')]:
        run('java','-cp',a.r8,'com.android.tools.r8.D8','--release','--min-api','24' if a.initialization_checks else '23','--lib','/usr/lib/jvm/default','--classpath',t/cp,'--classpath',t/'sdk.jar','--output',t/dest,*sorted((t/source).rglob('*.class')))
    extra_libraries = {}
    for abi,target in [('arm64-v8a','aarch64-linux-android23'),('armeabi-v7a','armv7a-linux-androideabi23')]:
        run('clang','--target='+target,'-O2','-fPIC','-nostdlib','-shared','-fuse-ld=lld','-Wl,--hash-style=sysv','-Wl,--pack-dyn-relocs=android+relr','-Wl,-z,max-page-size=4096',here/'asm/registered-jni.c','-o',t/(abi+'.so'))
        if a.resource_checks:run('clang','--target='+target,'-O2','-fPIC','-nostdlib','-shared','-fuse-ld=lld','-Wl,--hash-style=sysv','-Wl,-z,max-page-size=4096',here/'asm/bad-jni-version.c','-o',t/(abi+'-bad.so'))
        if a.bootstrap_checks:
            from native_links import build
            extra_libraries[abi] = build(target, t / abi, here / 'asm')
    if a.platform_checks:
        code=code.replace('"Core checks: "+org.kyvex.extra.RuntimeChecks.verify(1)','"Platform checks: "+org.kyvex.extra.PlatformChecks.result')
        (t/'MainActivity.java').write_text(code)
        run('javac','--release','8','-classpath',str(t/'sdk.jar')+':'+str(t/'extra.jar'),'-d',t/'classes',t/'MainActivity.java')
        run('java','-cp',a.r8,'com.android.tools.r8.D8','--release','--min-api','23','--lib','/usr/lib/jvm/default','--classpath',t/'extra.jar','--classpath',t/'sdk.jar','--output',t/'dex',*sorted((t/'classes').rglob('*.class')))
    names=['rift-platform-demo','rift-event-demo','rift-files-demo','rift-bridge-demo','rift-resource-demo','rift-provider-demo','rift-reader-demo','rift-xml-demo','rift-concurrency-demo','rift-thread-demo','rift-initialization-demo','rift-stack-demo','rift-group-demo','rift-stream-field-demo','rift-field-array-demo','rift-unsafe-demo','rift-bit-demo','rift-map-set-demo','rift-charset-demo','rift-base64-demo','rift-sqlite-demo','rift-logging-demo','rift-executor-demo','rift-formatter-demo','rift-messenger-demo','rift-scheduled-demo','rift-handoff-demo','rift-hash-map-demo']
    names.append('rift-bootstrap-demo')
    apk=out/(next((name for enabled,name in zip(kinds,names) if enabled),'rift-native-advanced')+'.apk')
    resource_table=None
    resource_members={}
    provider_xml=0
    if a.resource_checks or a.provider_checks:
        (t/'AndroidManifest.xml').write_text('<manifest package="org.kyvex.nativehello"><application/></manifest>')
        run(a.aapt2,'compile','--dir',here/'resources','-o',t/'resources.zip')
        run(a.aapt2,'link','-o',t/'resources.apk','--manifest',t/'AndroidManifest.xml','--emit-ids',t/'resource-ids.txt',t/'resources.zip')
        with zipfile.ZipFile(t/'resources.apk') as compiled:
            resource_table=compiled.read('resources.arsc')
            resource_members={name:compiled.read(name) for name in compiled.namelist() if name.startswith('res/') and not name.endswith('/')}
        if a.provider_checks:
            provider_xml=next(int(line.split('=',1)[1].strip(),16)
                              for line in (t/'resource-ids.txt').read_text().splitlines()
                              if line.split('=',1)[0].strip()=='org.kyvex.nativehello:xml/kyvex_paths')
    with zipfile.ZipFile(here/'built/rift-native-demo.apk') as original:manifest=original.read('AndroidManifest.xml')
    if a.bridge_checks:
        from manifest import manifest as sample_manifest
        manifest=sample_manifest(with_metadata=True)
    if a.provider_checks:
        from manifest import manifest as sample_manifest
        manifest=sample_manifest(with_providers=True,with_services=True,provider_xml=provider_xml)
    if a.initialization_checks:
        from manifest import manifest as sample_manifest
        manifest=sample_manifest(min_sdk=24)
    with zipfile.ZipFile(apk,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('AndroidManifest.xml',manifest);z.write(t/'dex/classes.dex','classes.dex');z.write(t/'dex2/classes.dex','classes2.dex')
        if resource_table is not None:z.writestr('resources.arsc',resource_table)
        for name,blob in resource_members.items():z.writestr(name,blob)
        for asset in sorted((here/'assets').rglob('*')):
            if asset.is_file():z.write(asset,'assets/'+asset.relative_to(here/'assets').as_posix())
        for abi in ['arm64-v8a','armeabi-v7a']:z.write(t/(abi+'.so'),'lib/'+abi+'/libkyvexdemo.so')
        for abi, paths in extra_libraries.items():
            for path in paths:
                z.write(path, f'lib/{abi}/{path.name}')
        if a.resource_checks:
            for abi in ['arm64-v8a','armeabi-v7a']:z.write(t/(abi+'-bad.so'),'lib/'+abi+'/libbadversion.so')
    run('keytool','-genkeypair','-keystore',t/'test.keystore','-storepass','kyvex-native-demo','-alias','sample','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=KYVEX Advanced Native Sample')
    run('jarsigner','-keystore',t/'test.keystore','-storepass','kyvex-native-demo','-sigalg','SHA256withRSA','-digestalg','SHA-256',apk,'sample')
    metadata=apk.with_suffix('.build.json') if any(kinds) else out/'advanced-build.json'
    metadata.write_text(json.dumps(dict(sha256=hashlib.sha256(apk.read_bytes()).hexdigest(),dex_files=2,registration='JNI_OnLoad + JavaVM.GetEnv + RegisterNatives',relocations='Android APS2 / RELR',private_key_included=False),indent=2))
