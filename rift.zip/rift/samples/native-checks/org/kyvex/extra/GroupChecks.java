package org.kyvex.extra;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
/** The same Java 8 contract runs on a stock Java 8 JRE and in Rift Native. */
public final class GroupChecks {
 public static int queuedResult;
 /** Rust harness stops between the real failure and the first handler slice. */
 public static Thread queuedFault(){Thread thread=new Thread(throwing("queued-fault"));thread.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){public void uncaughtException(Thread t,Throwable e){if(t==Thread.currentThread()&&"queued-fault".equals(e.getMessage()))queuedResult=321;}});return thread;}
 private static int checks;
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 private static void await(CountDownLatch latch){try{latch.await();}catch(InterruptedException e){throw new IllegalStateException(e);}}
 private static Runnable throwing(final String message){return new Runnable(){public void run(){throw new IllegalArgumentException(message);}};}
 private static boolean contains(Object[] array,Object value){for(Object next:array)if(next==value)return true;return false;}
 private static final class ParentGroup extends ThreadGroup {
  final AtomicInteger sequence;
  ParentGroup(ThreadGroup parent,String name,AtomicInteger value){super(parent,name);sequence=value;}
  public void uncaughtException(Thread thread,Throwable fault){sequence.set(sequence.get()+1);super.uncaughtException(thread,fault);sequence.set(sequence.get()+1);}
 }
 private static final class ChildGroup extends ThreadGroup {
  final AtomicInteger sequence;
  ChildGroup(ThreadGroup parent,String name,AtomicInteger value){super(parent,name);sequence=value;}
  public void uncaughtException(Thread thread,Throwable fault){sequence.set(sequence.get()+10);super.uncaughtException(thread,fault);sequence.set(sequence.get()+10);}
 }
 public static int verify() throws InterruptedException {
  checks=0;final Thread main=Thread.currentThread();ThreadGroup mainGroup=main.getThreadGroup();
  check(mainGroup!=null&&mainGroup.getParent()!=null,"Main has real guest group ancestry");
  ThreadGroup root=new ThreadGroup("group-checks"),child=new ThreadGroup(root,"child"),leaf=new ThreadGroup(child,"leaf");
  check(root.getParent()==mainGroup&&child.getParent()==root&&leaf.getParent()==child,"Explicit and inherited group parents");
  check(root.parentOf(root)&&root.parentOf(leaf)&&!child.parentOf(root)&&!root.parentOf(null),"Group ancestry includes identity");
  check("child".equals(child.getName())&&child.toString().equals("java.lang.ThreadGroup[name=child,maxpri=10]"),"Group name and actual text");
  ThreadGroup nullName=new ThreadGroup(root,null);check(nullName.getName()==null,"ThreadGroup permits a null name");nullName.destroy();
  try{new ThreadGroup(null,"bad");throw new IllegalStateException("Null group parent accepted");}catch(NullPointerException expected){checks++;}
  root.setMaxPriority(7);check(child.getMaxPriority()==7&&leaf.getMaxPriority()==7,"Maximum priority propagates");
  child.setMaxPriority(2);root.setMaxPriority(8);check(child.getMaxPriority()==8&&leaf.getMaxPriority()==8,"Priority propagation uses original requested maximum");
  leaf.setMaxPriority(10);check(leaf.getMaxPriority()==8,"Child maximum capped by parent");
  leaf.setMaxPriority(0);leaf.setMaxPriority(11);check(leaf.getMaxPriority()==8,"Invalid group priority is ignored");
  final AtomicInteger outcome=new AtomicInteger();Thread configured=new Thread(child,new Runnable(){public void run(){outcome.set(41);}},"configured",32768L);
  check(configured.getThreadGroup()==child&&configured.getName().equals("configured"),"Thread group/target/name/stack-size constructor");
  configured.setPriority(8);child.setMaxPriority(3);check(configured.getPriority()==8,"Lowering group cap leaves existing priority alone");
  configured.setPriority(9);check(configured.getPriority()==3,"Thread priority clamps at group maximum");
  Thread inheritedPriority=new Thread(child,"priority");check(inheritedPriority.getPriority()==3,"New priority is capped");
  try{configured.setPriority(0);throw new IllegalStateException("Bad thread priority accepted");}catch(IllegalArgumentException expected){checks++;}
  configured.start();configured.join();check(outcome.get()==41,"Grouped constructor preserves and executes actual target");
  check(configured.getThreadGroup()==null&&configured.getUncaughtExceptionHandler()==null,"Exit releases group and uncaught handler");
  configured.setPriority(10);check(configured.getPriority()==3,"Terminated thread priority is unchanged");
  Thread byRunnable=new Thread(root,new Runnable(){public void run(){outcome.set(42);}});byRunnable.start();byRunnable.join();check(outcome.get()==42,"Unnamed grouped Runnable executes");
  Thread inheritedGroup=new Thread((ThreadGroup)null,"inherited");check(inheritedGroup.getThreadGroup()==mainGroup,"Null Thread constructor group inherits current group");
  ThreadGroup daemonGroup=new ThreadGroup(root,"daemon");daemonGroup.setDaemon(true);
  ThreadGroup daemonChild=new ThreadGroup(daemonGroup,"daemon-child");
  check(daemonChild.isDaemon()&&!new Thread(daemonChild,"unstarted-daemon").isDaemon(),"Group daemon inheritance differs from Thread daemon inheritance");
  daemonChild.destroy();check(daemonGroup.isDestroyed(),"Empty daemon parent destroyed after last child removal");
  final CountDownLatch ready=new CountDownLatch(2),gate=new CountDownLatch(1);final ThreadGroup[] defaultChild={null};
  Thread direct=new Thread(root,new Runnable(){public void run(){ready.countDown();await(gate);}},"direct");
  Thread nested=new Thread(leaf,new Runnable(){public void run(){defaultChild[0]=new ThreadGroup("worker-child");ready.countDown();await(gate);}},"nested");
  direct.start();nested.start();ready.await();
  check(defaultChild[0].getParent()==leaf,"Group constructor inherits actual worker group");
  check(root.activeCount()==2&&leaf.activeCount()==1,"Counts include alive descendants, exclude unstarted/finished threads");
  check(root.activeGroupCount()==3,"Group count includes real nested groups");
  Thread[] all=new Thread[4];check(root.enumerate(all)==2&&contains(all,direct)&&contains(all,nested),"Recursive thread enumeration has actual identities");
  Thread[] local=new Thread[4];check(root.enumerate(local,false)==1&&local[0]==direct,"Nonrecursive thread enumeration");
  Thread[] shortArray=new Thread[1];check(root.enumerate(shortArray)==1&&shortArray[0]!=null,"Enumeration respects output capacity");
  ThreadGroup[] groups=new ThreadGroup[5];check(root.enumerate(groups)==3&&contains(groups,child)&&contains(groups,leaf)&&contains(groups,defaultChild[0]),"Recursive group enumeration");
  ThreadGroup[] immediate=new ThreadGroup[5];check(root.enumerate(immediate,false)==1&&immediate[0]==child,"Nonrecursive group enumeration includes immediate children");
  try{root.enumerate((Thread[])null);throw new IllegalStateException("Null enumeration accepted");}catch(NullPointerException expected){checks++;}
  try{leaf.destroy();throw new IllegalStateException("Active group destroyed");}catch(IllegalThreadStateException expected){checks++;}
  gate.countDown();direct.join();nested.join();check(root.activeCount()==0,"Finished threads leave active membership");
  final CountDownLatch sleeping=new CountDownLatch(1);final AtomicInteger interrupted=new AtomicInteger();
  Thread sleeper=new Thread(leaf,new Runnable(){public void run(){sleeping.countDown();try{Thread.sleep(10000);}catch(InterruptedException expected){if(!Thread.currentThread().isInterrupted())interrupted.set(1);}}});
  sleeper.start();sleeping.await();root.interrupt();sleeper.join();check(interrupted.get()==1,"Group interrupt actually wakes descendant and clears interrupted wait");
  ThreadGroup daemonExit=new ThreadGroup(root,"daemon-exit");daemonExit.setDaemon(true);Thread last=new Thread(daemonExit,"last");last.start();last.join();check(daemonExit.isDestroyed(),"Last thread exit destroys empty daemon group");
  ThreadGroup daemonNew=new ThreadGroup(root,"daemon-new");daemonNew.setDaemon(true);Thread neverStarted=new Thread(daemonNew,"pending"),first=new Thread(daemonNew,"first");first.start();first.join();check(!daemonNew.isDestroyed(),"Unstarted count prevents automatic daemon destruction");
  daemonNew.destroy();check(daemonNew.isDestroyed(),"Explicit destroy permits unstarted threads");
  try{neverStarted.start();throw new IllegalStateException("Started in destroyed group");}catch(IllegalThreadStateException expected){checks++;}
  try{new Thread(daemonNew,"bad");throw new IllegalStateException("Constructed in destroyed group");}catch(IllegalThreadStateException expected){checks++;}
  try{new ThreadGroup(daemonNew,"bad");throw new IllegalStateException("Constructed child of destroyed group");}catch(IllegalThreadStateException expected){checks++;}
  final AtomicInteger sequence=new AtomicInteger();final CountDownLatch handlerReady=new CountDownLatch(1),handlerGate=new CountDownLatch(1);
  Thread.UncaughtExceptionHandler old=Thread.getDefaultUncaughtExceptionHandler();
  Thread.UncaughtExceptionHandler defaultHandler=new Thread.UncaughtExceptionHandler(){public void uncaughtException(Thread thread,Throwable fault){
   if(thread!=Thread.currentThread()||!thread.isAlive()||thread.getThreadGroup()==null)throw new IllegalStateException("Handler thread lost identity");
   handlerReady.countDown();await(handlerGate);System.gc();if(!"group-fault".equals(fault.getMessage()))throw new IllegalStateException("Lost queued or paused Throwable");sequence.set(sequence.get()+100);
  }};
  Thread.setDefaultUncaughtExceptionHandler(defaultHandler);
  ParentGroup parent=new ParentGroup(root,"parent-handler",sequence);ChildGroup group=new ChildGroup(parent,"child-handler",sequence);
  Thread bad=new Thread(group,throwing("group-fault"),"bad");
  check(bad.getUncaughtExceptionHandler()==group,"Default per-thread handler is its group");
  bad.setUncaughtExceptionHandler(defaultHandler);check(bad.getUncaughtExceptionHandler()==defaultHandler,"Explicit handler identity");bad.setUncaughtExceptionHandler(null);check(bad.getUncaughtExceptionHandler()==group,"Null explicit handler restores group");
  bad.start();handlerReady.await();check(bad.isAlive()&&bad.getThreadGroup()==group&&sequence.get()==11,"Group override and parent delegation can really suspend in default handler");
  System.gc();handlerGate.countDown();bad.join();check(sequence.get()==122,"Group/default handler resumes and returns through both overrides");
  check(bad.getThreadGroup()==null&&bad.getUncaughtExceptionHandler()==null,"Handler exit releases membership");
  Thread handlerFault=new Thread(root,throwing("fault"));handlerFault.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){public void uncaughtException(Thread t,Throwable e){sequence.set(123);throw new IllegalStateException("expected-handler-error");}});handlerFault.start();handlerFault.join();check(sequence.get()==123&&!handlerFault.isAlive(),"Fault in actual handler terminates without recursive delivery");
  Thread.setDefaultUncaughtExceptionHandler(old);group.destroy();parent.destroy();
  root.checkAccess();root.destroy();check(root.isDestroyed()&&child.isDestroyed()&&leaf.isDestroyed(),"Empty group subtree is recursively destroyed");
  check(root.activeCount()==0&&root.activeGroupCount()==0&&root.enumerate(new Thread[2])==0,"Destroyed group has no active members");
  return checks;
 }
 public static int report(){try{return verify();}catch(InterruptedException e){throw new IllegalStateException(e);}}
 public static void main(String[] args)throws Exception{System.out.println("Group checks: "+verify());}
}
