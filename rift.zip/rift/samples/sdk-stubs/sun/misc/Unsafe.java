package sun.misc;
/** Compile-only declarations. This class is excluded from every fixture APK. */
public final class Unsafe {
 private Unsafe(){}
 public static native Unsafe getUnsafe();
 public native long objectFieldOffset(java.lang.reflect.Field field);
 public native long staticFieldOffset(java.lang.reflect.Field field);
 public native Object staticFieldBase(java.lang.reflect.Field field);
 public native int arrayBaseOffset(Class<?> type);
 public native int arrayIndexScale(Class<?> type);
 public native int addressSize();
 public native void loadFence();public native void storeFence();public native void fullFence();
 public native int getInt(Object o,long p);public native int getIntVolatile(Object o,long p);
 public native void putInt(Object o,long p,int x);public native void putIntVolatile(Object o,long p,int x);public native void putOrderedInt(Object o,long p,int x);
 public native long getLong(Object o,long p);public native long getLongVolatile(Object o,long p);
 public native void putLong(Object o,long p,long x);public native void putLongVolatile(Object o,long p,long x);public native void putOrderedLong(Object o,long p,long x);
 public native Object getObject(Object o,long p);public native Object getObjectVolatile(Object o,long p);
 public native void putObject(Object o,long p,Object x);public native void putObjectVolatile(Object o,long p,Object x);public native void putOrderedObject(Object o,long p,Object x);
 public native boolean getBoolean(Object o,long p);public native boolean getBooleanVolatile(Object o,long p);public native void putBoolean(Object o,long p,boolean x);public native void putBooleanVolatile(Object o,long p,boolean x);
 public native byte getByte(Object o,long p);public native byte getByteVolatile(Object o,long p);public native void putByte(Object o,long p,byte x);public native void putByteVolatile(Object o,long p,byte x);
 public native short getShort(Object o,long p);public native short getShortVolatile(Object o,long p);public native void putShort(Object o,long p,short x);public native void putShortVolatile(Object o,long p,short x);
 public native char getChar(Object o,long p);public native char getCharVolatile(Object o,long p);public native void putChar(Object o,long p,char x);public native void putCharVolatile(Object o,long p,char x);
 public native float getFloat(Object o,long p);public native float getFloatVolatile(Object o,long p);public native void putFloat(Object o,long p,float x);public native void putFloatVolatile(Object o,long p,float x);
 public native double getDouble(Object o,long p);public native double getDoubleVolatile(Object o,long p);public native void putDouble(Object o,long p,double x);public native void putDoubleVolatile(Object o,long p,double x);
 public native boolean compareAndSwapInt(Object o,long p,int expected,int value);
 public native boolean compareAndSwapLong(Object o,long p,long expected,long value);
 public native boolean compareAndSwapObject(Object o,long p,Object expected,Object value);
 public native int getAndAddInt(Object o,long p,int x);public native long getAndAddLong(Object o,long p,long x);
 public native int getAndSetInt(Object o,long p,int x);public native long getAndSetLong(Object o,long p,long x);public native Object getAndSetObject(Object o,long p,Object x);
}
