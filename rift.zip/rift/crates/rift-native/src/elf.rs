//! Bounded little-endian ELF32/ELF64 loader. No host linker or host imports.
use crate::{
    Result,
    memory::{EXEC, Memory, READ, WRITE},
};
use std::collections::BTreeMap;
const MAX_SYMBOLS: usize = 262144;
pub(crate) const SHARED_SLOT: u64 = 0x02000000;
pub(crate) const ADDRESS_LIMIT: u64 = 0x30000000;
#[derive(Clone, Debug)]
struct Segment {
    offset: usize,
    va: u64,
    files: usize,
    size: usize,
    permissions: u8,
}
#[derive(Clone, Debug)]
struct Symbol {
    name: String,
    value: u64,
    weak: bool,
    defined: bool,
    exported: bool,
}
#[derive(Debug)]
pub struct Image {
    pub arch: u32,
    pub entry: u64,
    pub base: u64,
    pub exports: BTreeMap<String, u64>,
    pub constructors: Vec<u64>,
    pub needed: Vec<String>,
}
pub(crate) struct Plan<'a> {
    data: &'a [u8],
    pub arch: u32,
    pub shared: bool,
    entry: u64,
    segments: Vec<Segment>,
    attributes: BTreeMap<u64, u64>,
    strings: Option<&'a [u8]>,
    pub needed: Vec<String>,
}

pub(crate) fn valid_library_name(name: &str) -> bool {
    name.len() > 3
        && name.len() <= 100
        && name.ends_with(".so")
        && name
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'.' | b'-' | b'+'))
}
struct Reader<'a>(&'a [u8]);
impl<'a> Reader<'a> {
    fn bytes(&self, o: usize, n: usize) -> Result<&'a [u8]> {
        self.0
            .get(o..o.checked_add(n).ok_or("ELF offset overflow")?)
            .ok_or_else(|| "Truncated ELF field".into())
    }
    fn u16(&self, o: usize) -> Result<u16> {
        Ok(u16::from_le_bytes(self.bytes(o, 2)?.try_into()?))
    }
    fn u32(&self, o: usize) -> Result<u32> {
        Ok(u32::from_le_bytes(self.bytes(o, 4)?.try_into()?))
    }
    fn u64(&self, o: usize) -> Result<u64> {
        Ok(u64::from_le_bytes(self.bytes(o, 8)?.try_into()?))
    }
    fn word(&self, o: usize, wide: bool) -> Result<u64> {
        if wide {
            self.u64(o)
        } else {
            Ok(self.u32(o)? as u64)
        }
    }
}
fn offset(segments: &[Segment], va: u64, n: usize) -> Result<usize> {
    for s in segments {
        if va >= s.va {
            let d = va - s.va;
            if d <= s.files as u64 && (n as u64) <= s.files as u64 - d {
                return s
                    .offset
                    .checked_add(d as usize)
                    .ok_or_else(|| "ELF translated offset overflow".into());
            }
        }
    }
    Err("ELF table is outside a file-backed segment".into())
}
fn cstr(table: &[u8], o: u64) -> Result<String> {
    let start = usize::try_from(o)?;
    let b = table.get(start..).ok_or("ELF string offset")?;
    let n = b
        .iter()
        .take(1025)
        .position(|v| *v == 0)
        .ok_or("ELF string exceeds limit or is unterminated")?;
    Ok(std::str::from_utf8(&b[..n])?.to_owned())
}
fn add(base: u64, n: i64) -> Result<u64> {
    base.checked_add_signed(n)
        .ok_or_else(|| "ELF relocation address overflow".into())
}
pub fn load(
    data: &[u8],
    memory: &mut Memory,
    preferred: u64,
    imports: &BTreeMap<String, u64>,
) -> Result<Image> {
    link_standalone(plan(data)?, memory, preferred, imports)
}

pub(crate) fn link_standalone(
    image: Plan<'_>,
    memory: &mut Memory,
    preferred: u64,
    imports: &BTreeMap<String, u64>,
) -> Result<Image> {
    if let Some(name) = image.needed.iter().find(|name| name.as_str() != "libc.so") {
        return Err(format!("Unsupported native dependency: {name}").into());
    }
    let mut staging = memory.staging();
    let image = link(image, &mut staging, preferred, |name| {
        imports.get(name).copied()
    })?;
    memory.commit(staging)?;
    Ok(image)
}

pub(crate) fn plan(data: &[u8]) -> Result<Plan<'_>> {
    if data.len() > 192 * 1024 * 1024 || data.len() < 52 {
        return Err("ELF file size limit".into());
    }
    let r = Reader(data);
    if r.bytes(0, 4)? != b"\x7fELF" || data[5] != 1 || data[6] != 1 {
        return Err("Only little-endian ELF version 1 is supported".into());
    }
    let wide = match data[4] {
        1 => false,
        2 => true,
        _ => return Err("Invalid ELF class".into()),
    };
    let machine = r.u16(18)?;
    let arch = match (wide, machine) {
        (false, 40) => 32,
        (true, 183) => 64,
        _ => return Err("Only ARM32 / AArch64 ELF is supported".into()),
    };
    let kind = r.u16(16)?;
    if !matches!(kind, 2 | 3) || r.u32(20)? != 1 {
        return Err("ELF must be a version 1 executable or shared object".into());
    }
    let shared = kind == 3;
    let entry = r.word(24, wide)?;
    let phoff = usize::try_from(r.word(if wide { 32 } else { 28 }, wide)?)?;
    let ents = r.u16(if wide { 54 } else { 42 })? as usize;
    let count = r.u16(if wide { 56 } else { 44 })? as usize;
    if ents != if wide { 56 } else { 32 } || count == 0 || count > 128 {
        return Err("ELF program header limits".into());
    }
    r.bytes(
        phoff,
        count
            .checked_mul(ents)
            .ok_or("ELF program table overflow")?,
    )?;
    let mut segments = Vec::new();
    let mut dynamic = None;
    for i in 0..count {
        let p = phoff + i * ents;
        let t = r.u32(p)?;
        let flags = r.u32(p + if wide { 4 } else { 24 })?;
        let off = usize::try_from(r.word(p + if wide { 8 } else { 4 }, wide)?)?;
        let va = r.word(p + if wide { 16 } else { 8 }, wide)?;
        let files = usize::try_from(r.word(p + if wide { 32 } else { 16 }, wide)?)?;
        let size = usize::try_from(r.word(p + if wide { 40 } else { 20 }, wide)?)?;
        if t == 3 {
            return Err("Unsupported ELF interpreter; this prototype loads static executables or JNI shared objects".into());
        }
        if t == 1 {
            let alignment = r.word(p + if wide { 48 } else { 28 }, wide)?;
            if alignment > 1
                && (!alignment.is_power_of_two() || va % alignment != off as u64 % alignment)
            {
                return Err("Invalid ELF segment alignment".into());
            }
            if files > size || size > 256 * 1024 * 1024 {
                return Err("ELF segment size limit".into());
            }
            r.bytes(off, files)?;
            if size == 0 {
                continue;
            }
            if shared && (va > SHARED_SLOT || size as u64 > SHARED_SLOT - va) {
                return Err("ELF segment overlaps a reserved guest address region".into());
            }
            let permissions = if flags & 4 != 0 { READ } else { 0 }
                | if flags & 2 != 0 { WRITE } else { 0 }
                | if flags & 1 != 0 { EXEC } else { 0 };
            segments.push(Segment {
                offset: off,
                va,
                files,
                size,
                permissions,
            });
        } else if t == 7 {
            return Err("Unsupported native ELF thread-local storage".into());
        } else if t == 2 {
            if files > 65536 {
                return Err("ELF dynamic table limit".into());
            }
            r.bytes(off, files)?;
            dynamic = Some((off, files));
        }
    }
    if segments.is_empty() {
        return Err("ELF contains no loadable segments".into());
    }
    let mut attributes = BTreeMap::<u64, u64>::new();
    let mut dependencies = Vec::new();
    if let Some((o, n)) = dynamic {
        let stride = if wide { 16 } else { 8 };
        if n % stride != 0 {
            return Err("Malformed ELF dynamic table".into());
        }
        let mut terminated = false;
        for p in (o..o + n).step_by(stride) {
            let k = r.word(p, wide)?;
            let v = r.word(p + stride / 2, wide)?;
            if k == 0 {
                terminated = true;
                break;
            }
            if k == 1 {
                dependencies.push(v);
            } else {
                attributes.insert(k, v);
            }
        }
        if !terminated {
            return Err("Unterminated ELF dynamic table".into());
        }
    }
    let mut needed = Vec::new();
    let strings = if let Some(strings) = attributes.get(&5) {
        let strings_size =
            usize::try_from(*attributes.get(&10).ok_or("ELF string table size missing")?)?;
        if strings_size > 1024 * 1024 {
            return Err("ELF string allocation limit".into());
        }
        let table = r.bytes(offset(&segments, *strings, strings_size)?, strings_size)?;
        for d in dependencies {
            let name = cstr(table, d)?;
            if !valid_library_name(&name) {
                return Err("Invalid ELF dependency filename".into());
            }
            if !needed.contains(&name) {
                if needed.len() >= 64 {
                    return Err("ELF direct dependency quota".into());
                }
                needed.push(name);
            }
        }
        Some(table)
    } else {
        if !dependencies.is_empty() || attributes.contains_key(&6) {
            return Err("ELF dependencies or symbols have no string table".into());
        }
        None
    };
    Ok(Plan {
        data,
        arch,
        shared,
        entry,
        segments,
        attributes,
        strings,
        needed,
    })
}

/// Only write into a private staging memory before committing the whole group.
pub(crate) fn link(
    plan: Plan<'_>,
    memory: &mut Memory,
    preferred: u64,
    import: impl Fn(&str) -> Option<u64>,
) -> Result<Image> {
    let Plan {
        data,
        arch,
        shared,
        entry,
        segments,
        attributes,
        strings,
        needed,
    } = plan;
    let r = Reader(data);
    let wide = arch == 64;
    let base = if shared { preferred } else { 0 };
    if !base.is_multiple_of(crate::memory::PAGE) {
        return Err("Unaligned ELF load bias".into());
    }
    let entry = entry.checked_add(base).ok_or("ELF entry overflow")?;
    for segment in &segments {
        let start = segment.va.checked_add(base).ok_or("ELF base overflow")?;
        let end = start
            .checked_add(segment.size as u64)
            .ok_or("ELF segment overflow")?;
        if start < 0x10000 || end > ADDRESS_LIMIT {
            return Err("ELF segment overlaps a reserved guest address region".into());
        }
        memory.map(start, segment.size, segment.permissions)?;
        memory.initialize(start, r.bytes(segment.offset, segment.files)?)?;
    }
    let mut symbols = Vec::new();
    if let Some(table) = strings
        && let Some(symtable) = attributes.get(&6)
    {
        let syment = usize::try_from(*attributes.get(&11).ok_or("ELF symbol entry size missing")?)?;
        if syment != if wide { 24 } else { 16 } {
            return Err("Invalid ELF symbol entry size".into());
        }
        let symbol_count = if let Some(hash) = attributes.get(&4) {
            let o = offset(&segments, *hash, 8)?;
            let buckets = r.u32(o)? as usize;
            let n = r.u32(o + 4)? as usize;
            if n > MAX_SYMBOLS || buckets > MAX_SYMBOLS {
                return Err("ELF symbol count limit".into());
            }
            r.bytes(o, (2 + buckets + n) * 4)?;
            n
        } else if let Some(hash) = attributes.get(&0x6ffffef5) {
            let o = offset(&segments, *hash, 16)?;
            let buckets = r.u32(o)? as usize;
            let first = r.u32(o + 4)? as usize;
            let bloom = r.u32(o + 8)? as usize;
            if buckets > MAX_SYMBOLS || first > MAX_SYMBOLS || bloom > MAX_SYMBOLS {
                return Err("ELF GNU hash limit".into());
            }
            let bucket_offset = o + 16 + bloom * if wide { 8 } else { 4 };
            let mut highest = 0;
            for i in 0..buckets {
                highest = highest.max(r.u32(bucket_offset + i * 4)? as usize);
            }
            if highest == 0 {
                first
            } else {
                if highest < first || highest >= MAX_SYMBOLS {
                    return Err("ELF GNU symbol bounds".into());
                }
                let chains = bucket_offset + buckets * 4;
                let mut idx = highest;
                loop {
                    if idx >= MAX_SYMBOLS {
                        return Err("Unterminated ELF GNU hash chain".into());
                    }
                    let h = r.u32(chains + (idx - first) * 4)?;
                    idx += 1;
                    if h & 1 != 0 {
                        break idx;
                    }
                }
            }
        } else {
            return Err("Unsupported ELF symbol table without SysV/GNU hash".into());
        };
        let o = offset(
            &segments,
            *symtable,
            symbol_count
                .checked_mul(syment)
                .ok_or("ELF symbol overflow")?,
        )?;
        for i in 0..symbol_count {
            let p = o + i * syment;
            let name = cstr(table, r.u32(p)? as u64)?;
            let info = data[p + if wide { 4 } else { 12 }];
            let visibility = data[p + if wide { 5 } else { 13 }] & 3;
            let section = r.u16(p + if wide { 6 } else { 14 })?;
            let value = r.word(p + if wide { 8 } else { 4 }, wide)?;
            let value = if section == 0 || section == 0xfff1 {
                value
            } else {
                value.checked_add(base).ok_or("ELF symbol value overflow")?
            };
            symbols.push(Symbol {
                name,
                value,
                weak: info >> 4 == 2,
                defined: section != 0,
                exported: matches!(info >> 4, 1 | 2) && matches!(visibility, 0 | 3),
            });
        }
    }
    let resolve = |idx: usize| -> Result<u64> {
        if idx == 0 {
            return Ok(0);
        }
        let s = symbols.get(idx).ok_or("ELF relocation symbol index")?;
        if s.defined {
            return Ok(s.value);
        }
        if let Some(v) = import(&s.name) {
            return Ok(v);
        }
        if s.weak {
            return Ok(0);
        }
        Err(format!("Unsupported native import: {}", s.name).into())
    };
    let mut entries = Vec::new();
    for (address_tag, size_tag, entry_tag, rela) in
        [(7, 8, 9, true), (17, 18, 19, false), (23, 2, 0, true)]
    {
        let Some(&address) = attributes.get(&address_tag) else {
            continue;
        };
        let size = *attributes
            .get(&size_tag)
            .ok_or("ELF relocation size missing")? as usize;
        let rela = if address_tag == 23 {
            match attributes.get(&20) {
                Some(7) => true,
                Some(17) => false,
                _ => return Err("Unsupported ELF PLT relocation format".into()),
            }
        } else {
            rela
        };
        let stride = match (wide, rela) {
            (true, true) => 24,
            (true, false) => 16,
            (false, true) => 12,
            (false, false) => 8,
        };
        if entry_tag != 0
            && attributes.get(&entry_tag).copied().unwrap_or(stride as u64) != stride as u64
        {
            return Err("ELF relocation entry size".into());
        }
        if !size.is_multiple_of(stride) || size / stride > 65536 {
            return Err("ELF relocation count limit".into());
        }
        let o = offset(&segments, address, size)?;
        for p in (o..o + size).step_by(stride) {
            let at = r.word(p, wide)?;
            let encoded = r.word(p + if wide { 8 } else { 4 }, wide)?;
            let addend = if rela {
                Some(if wide {
                    r.u64(p + 16)? as i64
                } else {
                    r.u32(p + 8)? as i32 as i64
                })
            } else {
                None
            };
            entries.push(crate::reloc::Relocation {
                at,
                info: encoded,
                addend,
            });
        }
    }
    for (tag, size, rela) in [
        (0x6000000f, 0x60000010, false),
        (0x60000011, 0x60000012, true),
    ] {
        if let Some(&address) = attributes.get(&tag) {
            let size = usize::try_from(
                *attributes
                    .get(&size)
                    .ok_or("Android packed relocation size missing")?,
            )?;
            if size > 8 * 1024 * 1024 {
                return Err("APS2 compressed size quota".into());
            }
            entries.extend(crate::reloc::aps2(
                r.bytes(offset(&segments, address, size)?, size)?,
                rela,
            )?);
        }
    }
    for (address_tag, size_tag, entry_tag) in [(36, 35, 37), (0x6fffe000, 0x6fffe001, 0x6fffe003)] {
        if let Some(&address) = attributes.get(&address_tag) {
            let size = usize::try_from(*attributes.get(&size_tag).ok_or("RELR size missing")?)?;
            let width = if wide { 8 } else { 4 };
            if attributes.get(&entry_tag).copied().unwrap_or(width) != width
                || size > 2 * 1024 * 1024
            {
                return Err("RELR entry/size quota".into());
            }
            for at in crate::reloc::relr(r.bytes(offset(&segments, address, size)?, size)?, wide)? {
                entries.push(crate::reloc::Relocation {
                    at,
                    info: if wide { 1027 } else { 23 },
                    addend: None,
                });
            }
        }
    }
    if entries.len() > 262144 {
        return Err("ELF expanded relocation budget".into());
    }
    let mut targets = std::collections::BTreeSet::new();
    for relocation in entries {
        let at = relocation.at;
        let (kind, index) = if wide {
            (relocation.info as u32, (relocation.info >> 32) as usize)
        } else {
            (
                (relocation.info & 255) as u32,
                (relocation.info >> 8) as usize,
            )
        };
        if kind == 0 {
            continue;
        }
        let width = if wide { 8 } else { 4 };
        if !targets.insert(at) {
            return Err("Duplicate ELF relocation target".into());
        }
        if !segments.iter().any(|s| {
            at >= s.va
                && at
                    .checked_add(width)
                    .is_some_and(|end| end <= s.va + s.size as u64)
        }) {
            return Err("ELF relocation target is outside this image".into());
        }
        let target = at
            .checked_add(base)
            .ok_or("ELF relocation target overflow")?;
        let rela = relocation.addend.is_some();
        let value = if let Some(value) = relocation.addend {
            value
        } else {
            let b = memory.bytes(target, width as usize)?;
            if wide {
                u64::from_le_bytes(b.as_slice().try_into()?) as i64
            } else {
                u32::from_le_bytes(b.as_slice().try_into()?) as i32 as i64
            }
        };
        let resolved = match (arch, kind) {
            (64, 1027) | (32, 23) => {
                if index != 0 {
                    return Err("Relative relocation contains a symbol".into());
                }
                add(base, value)?
            }
            (64, 257 | 1025 | 1026) | (32, 2) => add(resolve(index)?, value)?,
            // Android/Bionic REL GOT/PLT slots use a zero implicit
            // addend; a prefilled resolver address is not that addend.
            // RELA still carries its explicit addend.
            (32, 21 | 22) => add(resolve(index)?, if rela { value } else { 0 })?,
            _ => return Err(format!("Unsupported ARM{arch} relocation {kind}").into()),
        };
        if wide {
            memory.initialize(target, &resolved.to_le_bytes())?
        } else {
            memory.initialize(target, &u32::try_from(resolved)?.to_le_bytes())?
        }
    }
    let mut constructors = Vec::new();
    if let Some(&init) = attributes.get(&12)
        && init != 0
    {
        constructors.push(init.checked_add(base).ok_or("ELF initializer overflow")?);
    }
    if let Some(&array) = attributes.get(&25) {
        let n = usize::try_from(*attributes.get(&27).ok_or("ELF initializer size")?)?;
        let width = if wide { 8 } else { 4 };
        if n % width != 0 || n / width > 64 {
            return Err("ELF initializer count limit".into());
        }
        if n != 0
            && !segments.iter().any(|segment| {
                array >= segment.va
                    && array
                        .checked_add(n as u64)
                        .is_some_and(|end| end <= segment.va + segment.size as u64)
            })
        {
            return Err("ELF initializer array is outside this image".into());
        }
        let address = array
            .checked_add(base)
            .ok_or("ELF initializer array overflow")?;
        let b = memory.bytes(address, n)?;
        let rr = Reader(&b);
        for i in (0..n).step_by(width) {
            let v = rr.word(i, wide)?;
            if v != 0 {
                constructors.push(v);
            }
        }
    }
    let exports = symbols
        .into_iter()
        .filter(|s| s.defined && s.exported && !s.name.is_empty())
        .map(|s| (s.name, s.value))
        .collect();
    Ok(Image {
        arch,
        entry,
        base,
        exports,
        constructors,
        needed,
    })
}
#[cfg(test)]
mod tests {
    use super::*;
    fn fixture(arch: u32) -> Vec<u8> {
        let wide = arch == 64;
        let mut b = vec![0u8; 0x1004];
        b[..4].copy_from_slice(b"\x7fELF");
        b[4] = if wide { 2 } else { 1 };
        b[5] = 1;
        b[6] = 1;
        b[16..18].copy_from_slice(&2u16.to_le_bytes());
        b[18..20].copy_from_slice(&(if wide { 183u16 } else { 40 }).to_le_bytes());
        b[20..24].copy_from_slice(&1u32.to_le_bytes());
        if wide {
            b[24..32].copy_from_slice(&0x11000u64.to_le_bytes());
            b[32..40].copy_from_slice(&64u64.to_le_bytes());
            b[52..54].copy_from_slice(&64u16.to_le_bytes());
            b[54..56].copy_from_slice(&56u16.to_le_bytes());
            b[56..58].copy_from_slice(&1u16.to_le_bytes());
            b[64..68].copy_from_slice(&1u32.to_le_bytes());
            b[68..72].copy_from_slice(&5u32.to_le_bytes());
            b[72..80].copy_from_slice(&0x1000u64.to_le_bytes());
            b[80..88].copy_from_slice(&0x11000u64.to_le_bytes());
            b[96..104].copy_from_slice(&4u64.to_le_bytes());
            b[104..112].copy_from_slice(&4096u64.to_le_bytes());
        } else {
            b[24..28].copy_from_slice(&0x11000u32.to_le_bytes());
            b[28..32].copy_from_slice(&52u32.to_le_bytes());
            b[40..42].copy_from_slice(&52u16.to_le_bytes());
            b[42..44].copy_from_slice(&32u16.to_le_bytes());
            b[44..46].copy_from_slice(&1u16.to_le_bytes());
            b[52..56].copy_from_slice(&1u32.to_le_bytes());
            b[56..60].copy_from_slice(&0x1000u32.to_le_bytes());
            b[60..64].copy_from_slice(&0x11000u32.to_le_bytes());
            b[68..72].copy_from_slice(&4u32.to_le_bytes());
            b[72..76].copy_from_slice(&4096u32.to_le_bytes());
            b[76..80].copy_from_slice(&5u32.to_le_bytes());
        }
        b[0x1000..].copy_from_slice(&[1, 2, 3, 4]);
        b
    }
    #[test]
    fn loads_both_elf_classes_and_zeroes_bss() {
        for a in [32, 64] {
            let mut m = Memory::new(65536);
            let i = load(&fixture(a), &mut m, 0x1000000, &BTreeMap::new()).unwrap();
            assert_eq!(i.arch, a);
            assert_eq!(m.bytes(0x11000, 8).unwrap(), [1, 2, 3, 4, 0, 0, 0, 0]);
            assert!(m.write(0x11000, &[0]).is_err());
        }
    }
    #[test]
    fn malformed_segments_and_architectures_are_rejected() {
        let mut b = fixture(64);
        b[18] = 62;
        assert!(load(&b, &mut Memory::new(65536), 0, &BTreeMap::new()).is_err());
        let mut b = fixture(64);
        b[96..104].copy_from_slice(&8192u64.to_le_bytes());
        assert!(load(&b, &mut Memory::new(65536), 0, &BTreeMap::new()).is_err());
    }
    #[test]
    fn executable_data_and_memory_exhaustion_are_rejected() {
        let mut b = fixture(64);
        b[68..72].copy_from_slice(&7u32.to_le_bytes());
        assert!(load(&b, &mut Memory::new(65536), 0, &BTreeMap::new()).is_err());
        assert!(load(&fixture(64), &mut Memory::new(1), 0, &BTreeMap::new()).is_err());
    }
}
