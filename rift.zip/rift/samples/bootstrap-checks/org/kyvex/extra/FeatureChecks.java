package org.kyvex.extra;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.util.Log;

public final class FeatureChecks {
    private static int checks;

    private static void check(boolean condition, String name) {
        if (!condition) throw new IllegalStateException(name);
        checks++;
    }

    private static final class Owner extends Binder implements IInterface {
        Owner() { attachInterface(this, "org.kyvex.Probe"); }
        public IBinder asBinder() { return this; }
    }

    public static int verify(Context context) {
        checks = 0;
        PackageManager manager = context.getPackageManager();
        String portrait = "android.hardware.screen.portrait";
        check(manager.hasSystemFeature(portrait), "Portrait profile");
        check(manager.hasSystemFeature(portrait, 0), "Portrait version");
        check(!manager.hasSystemFeature(portrait, 1), "Unsupported version");
        check(!manager.hasSystemFeature("com.amazon.hardware.fire_tv"), "Vendor profile");
        check(!manager.hasSystemFeature("android.hardware.camera"), "Absent camera");
        check(!manager.hasSystemFeature(null), "Missing feature name");

        Point point = new Point();
        check(point.x == 0 && point.y == 0, "Default coordinates");
        point.x = 11;
        point.y = -2;
        Point copy = new Point(point);
        check(copy.equals(11, -2) && copy.equals(point) && copy.hashCode() == 339, "Copy, fields and hash");
        copy.offset(3, 7);
        check(copy.equals(14, 5) && point.equals(11, -2), "Independent coordinate state");
        copy.negate();
        check("Point(-14, -5)".equals(copy.toString()), "Negation and point text");
        copy.set(Integer.MAX_VALUE, 0);
        copy.offset(1, 0);
        check(copy.x == Integer.MIN_VALUE && !copy.equals((Object)null), "Coordinate overflow and null");

        Owner owner = new Owner();
        IBinder token = owner.asBinder();
        String descriptor = new String(new char[]{'o','r','g','.','k','y','v','e','x','.','P','r','o','b','e'});
        check(token.pingBinder() && token.isBinderAlive() && token.queryLocalInterface(descriptor) == owner,
                "Local Binder lookup by descriptor content");
        check(descriptor.equals(owner.getInterfaceDescriptor()) && token.queryLocalInterface("other") == null,
                "Exact descriptor matching");
        Binder empty = new Binder();
        check(empty.getInterfaceDescriptor() == null && empty.queryLocalInterface(null) == null, "Unattached Binder");
        owner.attachInterface(null, "org.kyvex.Empty");
        check(token.queryLocalInterface(descriptor) == null && "org.kyvex.Empty".equals(owner.getInterfaceDescriptor()),
                "Local interface replacement");

        Throwable reason = new IllegalStateException("wrapper", new IllegalArgumentException("underlying"));
        String stack = Log.getStackTraceString(reason);
        check(stack.startsWith("java.lang.IllegalStateException: wrapper")
                && stack.contains("Caused by: java.lang.IllegalArgumentException: underlying"), "Captured cause chain");
        check(Log.e("RiftCoordination", "bootstrap throwable", reason) > 0, "Android exception log");
        check("".equals(Log.getStackTraceString(null)), "Empty stack for null");
        return checks;
    }
}
