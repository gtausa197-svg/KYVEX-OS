//! Delayed work for the existing cooperative executor workers.
use super::*;
use std::{cmp::Ordering, time::Duration};

pub(in crate::vm) const POOL: &str = "Ljava/util/concurrent/ScheduledThreadPoolExecutor;";
pub(in crate::vm) const QUEUE: &str =
    "Ljava/util/concurrent/ScheduledThreadPoolExecutor$DelayedWorkQueue;";
pub(in crate::vm) const WRAPPER: &str =
    "Ljava/util/concurrent/Executors$DelegatedScheduledExecutorService;";
pub(super) const TASK: &str = "Lorg/kyvex/rift/internal/ScheduledTask;";
const FUTURE: &str = "Ljava/util/concurrent/ScheduledFuture;";
pub(in crate::vm) const SCHEDULED_SERVICE: &str = "Ljava/util/concurrent/ScheduledExecutorService;";
const MAX_QUEUED: usize = 1024;
const QUEUE_ENTRY_BYTES: usize = 64;

#[derive(Clone, Copy, Eq, Ord, PartialEq, PartialOrd)]
struct Key {
    when: Instant,
    order: u64,
    task: u32,
}

pub(in crate::vm) struct Queue {
    entries: BTreeSet<Key>,
    remove_cancelled: bool,
    keep_delayed: bool,
    keep_periodic: bool,
}
impl Default for Queue {
    fn default() -> Self {
        Self {
            entries: BTreeSet::new(),
            remove_cancelled: false,
            keep_delayed: true,
            keep_periodic: false,
        }
    }
}
impl Queue {
    pub(super) fn len(&self) -> usize {
        self.entries.len()
    }
    pub(in crate::vm) fn bytes(&self) -> usize {
        self.entries.len() * QUEUE_ENTRY_BYTES
    }
    pub(in crate::vm) fn roots(&self) -> impl Iterator<Item = u32> + '_ {
        self.entries.iter().map(|key| key.task)
    }
    pub(super) fn poll(&mut self, include_delayed: bool) -> u32 {
        match self.entries.first() {
            Some(key) if include_delayed || key.when <= Instant::now() => {
                self.entries.pop_first().unwrap().task
            }
            _ => 0,
        }
    }
}

#[derive(Clone, Copy)]
enum Outcome {
    Value(u32),
    Failed(u32),
    Cancelled,
}

pub(in crate::vm) struct Task {
    pool: u32,
    key: Key,
    command: u32,
    callable: bool,
    runnable_result: u32,
    // Zero is one-shot. Positive is fixed rate. Negative is fixed delay.
    repeat_nanos: i64,
    runner: u32,
    outcome: Option<Outcome>,
}
impl Task {
    pub(in crate::vm) fn roots(&self) -> [u32; 5] {
        [
            self.pool,
            self.command,
            self.runnable_result,
            self.runner,
            match self.outcome {
                Some(Outcome::Value(value) | Outcome::Failed(value)) => value,
                _ => 0,
            },
        ]
    }
    fn complete(&mut self, outcome: Outcome) {
        self.outcome = Some(outcome);
        self.command = 0;
        self.runnable_result = 0;
    }
}

pub(in crate::vm) fn inherits(class: &str, base: &str) -> bool {
    match class {
        POOL | WRAPPER | SCHEDULED_SERVICE => matches!(
            base,
            SCHEDULED_SERVICE
                | "Ljava/util/concurrent/Executor;"
                | "Ljava/util/concurrent/ExecutorService;"
        ),
        TASK | "Ljava/util/concurrent/RunnableScheduledFuture;" => matches!(
            base,
            FUTURE
                | "Ljava/util/concurrent/RunnableScheduledFuture;"
                | "Ljava/util/concurrent/RunnableFuture;"
                | "Ljava/util/concurrent/Future;"
                | "Ljava/util/concurrent/Delayed;"
                | "Ljava/lang/Comparable;"
                | "Ljava/lang/Runnable;"
        ),
        FUTURE => matches!(
            base,
            "Ljava/util/concurrent/Future;"
                | "Ljava/util/concurrent/Delayed;"
                | "Ljava/lang/Comparable;"
        ),
        "Ljava/util/concurrent/RunnableFuture;" => matches!(
            base,
            "Ljava/util/concurrent/Future;" | "Ljava/lang/Runnable;"
        ),
        "Ljava/util/concurrent/Delayed;" => base == "Ljava/lang/Comparable;",
        QUEUE => matches!(
            base,
            "Ljava/util/concurrent/BlockingQueue;"
                | "Ljava/util/Queue;"
                | "Ljava/util/Collection;"
                | "Ljava/lang/Iterable;"
        ),
        _ => false,
    }
}

fn nanos_until(when: Instant, now: Instant) -> i64 {
    let remaining = if when >= now {
        when.duration_since(now).as_nanos() as i128
    } else {
        -(now.duration_since(when).as_nanos() as i128)
    };
    remaining.clamp(i64::MIN as i128, i64::MAX as i128) as i64
}

impl Runtime {
    fn schedule_queue(&self, id: u32) -> Result<&Queue> {
        let Payload::ScheduledQueue(queue) = &self.object(id)?.payload else {
            return Err("Expected Native scheduled work queue".into());
        };
        Ok(queue)
    }
    fn schedule_queue_mut(&mut self, id: u32) -> Result<&mut Queue> {
        let Payload::ScheduledQueue(queue) = &mut self.object_mut(id)?.payload else {
            return Err("Expected Native scheduled work queue".into());
        };
        Ok(queue)
    }
    fn scheduled_task(&self, id: u32) -> Result<&Task> {
        let Payload::ScheduledTask(task) = &self.object(id)?.payload else {
            return Err("Expected Native scheduled task".into());
        };
        Ok(task)
    }
    fn scheduled_task_mut(&mut self, id: u32) -> Result<&mut Task> {
        let Payload::ScheduledTask(task) = &mut self.object_mut(id)?.payload else {
            return Err("Expected Native scheduled task".into());
        };
        Ok(task)
    }
    pub(in crate::vm) fn scheduled_task_done(&self, task: u32) -> Result<bool> {
        Ok(self.scheduled_task(task)?.outcome.is_some())
    }
    pub(super) fn scheduled_deadline(&self, id: u32) -> Result<Option<Instant>> {
        Ok(match &self.object(id)?.payload {
            Payload::ScheduledQueue(queue) => queue.entries.first().map(|key| key.when),
            _ => None,
        })
    }

    fn init_scheduled_pool(
        &mut self,
        pool: u32,
        core: u32,
        factory: Option<u32>,
        handler: Option<u32>,
    ) -> Result<()> {
        if core > i32::MAX as u32 {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Negative core pool size",
            ));
        }
        let mut roots = self.scoped_library_roots(&[pool])?;
        let factory = match factory {
            Some(id) => {
                self.object(id)?;
                id
            }
            None => self.executor_default_factory()?,
        };
        roots.keep(factory)?;
        let handler = match handler {
            Some(id) => {
                self.object(id)?;
                id
            }
            None => self.default_rejection()?,
        };
        roots.keep(handler)?;
        let queue = self.allocate(QUEUE, Payload::ScheduledQueue(Queue::default()))?;
        self.object_mut(pool)?.payload = Payload::Executor(concurrency::Executor {
            core,
            maximum: i32::MAX as u32,
            queue,
            factory,
            handler,
            ..concurrency::Executor::default()
        });
        Ok(())
    }

    fn submit_scheduled(
        &mut self,
        pool: u32,
        command: u32,
        callable: bool,
        runnable_result: u32,
        delay: i64,
        repeat_nanos: i64,
    ) -> Result<u32> {
        let interface = if callable {
            "Ljava/util/concurrent/Callable;"
        } else {
            "Ljava/lang/Runnable;"
        };
        if !self.subclass(&self.object(command)?.class, interface)? {
            return Err("Scheduled command has an incompatible type".into());
        }
        let mut roots = self.scoped_library_roots(&[pool, command, runnable_result])?;
        self.ensure_pool_support()?;
        let when = Self::deadline(delay.max(0) as u64).ok_or("Scheduled time range")?;
        let order = self.executors.next_scheduled;
        self.executors.next_scheduled = order
            .checked_add(1)
            .ok_or("Scheduled task order exhausted")?;
        let key = Key {
            when,
            order,
            task: 0,
        };
        let task = self.allocate(
            TASK,
            Payload::ScheduledTask(Task {
                pool,
                key,
                command,
                callable,
                runnable_result,
                repeat_nanos,
                runner: 0,
                outcome: None,
            }),
        )?;
        roots.keep(task)?;
        let key = Key { task, ..key };
        self.scheduled_task_mut(task)?.key = key;
        let decorate = format!(
            "({interface}Ljava/util/concurrent/RunnableScheduledFuture;)Ljava/util/concurrent/RunnableScheduledFuture;"
        );
        if let Some(method) = self.callback_method(pool, "decorateTask", &decorate)?
            && self.invoke(method, &[pool, command, task], true)? != task as u64
        {
            return Err(
                "Replacing a Native scheduled task with a custom future is unsupported".into(),
            );
        }
        let queue = self.pool(pool)?.queue;
        if self.pool(pool)?.shutdown || self.schedule_queue(queue)?.len() >= MAX_QUEUED {
            self.reject_pool_task(pool, task)?;
            return Ok(task);
        }
        if self.heap_bytes() + QUEUE_ENTRY_BYTES > self.heap_limit {
            return Err("Scheduled work queue exceeds the Java heap quota".into());
        }
        self.schedule_queue_mut(queue)?.entries.insert(key);
        let state = self.pool(pool)?;
        if (state.workers.is_empty() || state.workers.len() < state.core as usize)
            && let Err(error) = self.create_pool_worker(pool, 0)
        {
            self.schedule_queue_mut(queue)?.entries.remove(&key);
            return Err(error);
        }
        Ok(task)
    }

    fn cancel_scheduled(&mut self, id: u32, interrupt: bool) -> Result<bool> {
        let task = self.scheduled_task_mut(id)?;
        if task.outcome.is_some() {
            return Ok(false);
        }
        let (pool, key, runner) = (task.pool, task.key, task.runner);
        task.complete(Outcome::Cancelled);
        if interrupt && let Some(thread) = self.scheduler.records.get_mut(&runner) {
            thread.interrupted = true;
        }
        let queue = self.schedule_queue_mut(self.pool(pool)?.queue)?;
        if queue.remove_cancelled {
            queue.entries.remove(&key);
        }
        Ok(true)
    }

    pub(super) fn prune_scheduled_shutdown(&mut self, pool: u32) -> Result<()> {
        let queue_id = self.pool(pool)?.queue;
        let Payload::ScheduledQueue(queue) = &self.object(queue_id)?.payload else {
            return Ok(());
        };
        let mut removed = Vec::new();
        for key in &queue.entries {
            let task = self.scheduled_task(key.task)?;
            let keep = if task.repeat_nanos == 0 {
                queue.keep_delayed
            } else {
                queue.keep_periodic
            };
            if !keep || matches!(task.outcome, Some(Outcome::Cancelled)) {
                removed.push(*key);
            }
        }
        for key in removed {
            self.schedule_queue_mut(queue_id)?.entries.remove(&key);
            self.cancel_scheduled(key.task, false)?;
        }
        Ok(())
    }

    fn scheduled_can_run(&self, task: &Task) -> Result<bool> {
        let pool = self.pool(task.pool)?;
        let queue = self.schedule_queue(pool.queue)?;
        let keep = if task.repeat_nanos == 0 {
            queue.keep_delayed
        } else {
            queue.keep_periodic
        };
        Ok(!pool.stopping && (!pool.shutdown || keep))
    }

    fn run_scheduled_bridge(&mut self, method: &str, args: &[u32]) -> Result<u64> {
        let caller = self.callers.iter().rev().nth(1).copied();
        if caller.is_none_or(|index| self.dex.signature(index) != format!("{TASK}->run()V")) {
            return Err("Private scheduled bridge requires the owned task frame".into());
        }
        let id = *args.first().ok_or("Missing scheduled task")?;
        let task = self.scheduled_task(id)?;
        let current = self.current_thread;
        match method {
            "startTask" => {
                if task.runner != 0 || task.outcome.is_some() {
                    return Ok(0);
                }
                if !self.scheduled_can_run(task)? {
                    self.cancel_scheduled(id, false)?;
                    return Ok(0);
                }
                let task = self.scheduled_task_mut(id)?;
                task.runner = current;
                Ok(task.command as u64)
            }
            "isCallable" if task.runner == current => Ok(task.callable as u64),
            "finishTask" if task.runner == current => {
                let result = *args.get(1).ok_or("Missing scheduled task result")?;
                let failure = *args.get(2).ok_or("Missing scheduled task error")?;
                self.finish_scheduled(id, result, failure)?;
                Ok(0)
            }
            _ => Err("Invalid private scheduled task transition".into()),
        }
    }

    fn finish_scheduled(&mut self, id: u32, result: u32, failure: u32) -> Result<()> {
        let task = self.scheduled_task(id)?;
        let pool = task.pool;
        let key = task.key;
        let repeat = task.repeat_nanos;
        let can_repeat = repeat != 0 && self.scheduled_can_run(task)?;
        let task = self.scheduled_task_mut(id)?;
        task.runner = 0;
        if task.outcome.is_some() {
            return Ok(());
        }
        if failure != 0 {
            task.complete(Outcome::Failed(failure));
        } else if repeat == 0 {
            task.complete(Outcome::Value(if task.callable {
                result
            } else {
                task.runnable_result
            }));
        } else if can_repeat {
            let queue_id = self.pool(pool)?.queue;
            let next = if repeat > 0 { key.when } else { Instant::now() }
                .checked_add(Duration::from_nanos(repeat.unsigned_abs()));
            self.schedule_queue_mut(queue_id)?.entries.remove(&key);
            let room = self.schedule_queue(queue_id)?.len() < MAX_QUEUED
                && self.heap_bytes() + QUEUE_ENTRY_BYTES <= self.heap_limit;
            if let Some(when) = next.filter(|_| room) {
                let next = Key { when, ..key };
                self.schedule_queue_mut(queue_id)?.entries.insert(next);
                self.scheduled_task_mut(id)?.key = next;
            } else {
                self.scheduled_task_mut(id)?.complete(Outcome::Cancelled);
            }
        } else {
            task.complete(Outcome::Cancelled);
        }
        Ok(())
    }

    fn get_scheduled(&mut self, task: u32, timeout: Option<i64>) -> Result<u64> {
        const EXECUTION: &str = "Ljava/util/concurrent/ExecutionException;";
        match self.scheduled_task(task)?.outcome {
            Some(Outcome::Value(value)) => Ok(value as u64),
            Some(Outcome::Cancelled) => {
                Err(fault("Ljava/util/concurrent/CancellationException;", ""))
            }
            Some(Outcome::Failed(cause)) => {
                let mut roots = self.scoped_library_roots(&[task, cause])?;
                let object = self.allocate(EXECUTION, Payload::Instance)?;
                roots.keep(object)?;
                self.throwable_api(
                    "Ljava/util/concurrent/ExecutionException;-><init>(Ljava/lang/Throwable;)V",
                    &[object, cause],
                )?;
                Err(Box::new(JavaFault {
                    class: EXECUTION.into(),
                    object,
                    message: "Scheduled task failed".into(),
                }))
            }
            None => {
                self.check_interrupted()?;
                if timeout.is_some_and(|time| time <= 0) {
                    return Err(fault("Ljava/util/concurrent/TimeoutException;", ""));
                }
                let until = timeout
                    .map(|time| Self::deadline(time as u64).ok_or("Scheduled Future timeout range"))
                    .transpose()?;
                self.suspend(scheduler::Wait::Future { task, until })
            }
        }
    }

    fn scheduled_task_api(&mut self, id: u32, method: &str, args: &[u32]) -> Result<Option<u64>> {
        let arg = |index: usize| {
            args.get(index)
                .copied()
                .ok_or("Scheduled Future argument count")
        };
        let task = self.scheduled_task(id)?;
        let value = match method {
            "get()Ljava/lang/Object;" => self.get_scheduled(id, None)?,
            "get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;" => {
                self.get_scheduled(id, Some(self.timeout_nanos(wide(args, 1)?, arg(3)?)?))?
            }
            "isDone()Z" => task.outcome.is_some() as u64,
            "isCancelled()Z" => matches!(task.outcome, Some(Outcome::Cancelled)) as u64,
            "isPeriodic()Z" => (task.repeat_nanos != 0) as u64,
            "cancel(Z)Z" => {
                let pool = task.pool;
                let cancelled = self.cancel_scheduled(id, arg(1)? != 0)?;
                if cancelled {
                    self.try_terminate_pool(pool)?;
                }
                cancelled as u64
            }
            "getDelay(Ljava/util/concurrent/TimeUnit;)J" => {
                self.nanos_to_unit(nanos_until(task.key.when, Instant::now()), arg(1)?)? as u64
            }
            "compareTo(Ljava/util/concurrent/Delayed;)I" | "compareTo(Ljava/lang/Object;)I" => {
                let other = arg(1)?;
                let key = task.key;
                let order = if let Payload::ScheduledTask(other) = &self.object(other)?.payload {
                    key.cmp(&other.key)
                } else {
                    if !self
                        .subclass(&self.object(other)?.class, "Ljava/util/concurrent/Delayed;")?
                    {
                        return Err(fault("Ljava/lang/ClassCastException;", "Expected Delayed"));
                    }
                    let unit = self.time_unit(0)?;
                    let nanos = self.collection_dispatch(
                        other,
                        "Ljava/util/concurrent/Delayed;",
                        "getDelay(Ljava/util/concurrent/TimeUnit;)J",
                        &[unit],
                    )? as i64;
                    nanos_until(key.when, Instant::now()).cmp(&nanos)
                };
                match order {
                    Ordering::Less => u32::MAX as u64,
                    Ordering::Equal => 0,
                    Ordering::Greater => 1,
                }
            }
            "equals(Ljava/lang/Object;)Z" => (id == arg(1)?) as u64,
            "hashCode()I" => id as u64,
            _ => return Ok(None),
        };
        Ok(Some(value))
    }

    fn scheduled_queue_api(&mut self, id: u32, method: &str, args: &[u32]) -> Result<Option<u64>> {
        let queue = self.schedule_queue(id)?;
        Ok(Some(match method {
            "size()I" => queue.len() as u64,
            "isEmpty()Z" => queue.entries.is_empty() as u64,
            "peek()Ljava/lang/Object;" => queue.entries.first().map_or(0, |key| key.task as u64),
            "poll()Ljava/lang/Object;" => self.schedule_queue_mut(id)?.poll(false) as u64,
            "remainingCapacity()I" => (MAX_QUEUED - queue.len()) as u64,
            "clear()V" => {
                self.schedule_queue_mut(id)?.entries.clear();
                0
            }
            "contains(Ljava/lang/Object;)Z" | "remove(Ljava/lang/Object;)Z" => {
                let other = *args.get(1).ok_or("Scheduled queue argument count")?;
                let Some(Payload::ScheduledTask(task)) = self.heap.get(&other).map(|o| &o.payload)
                else {
                    return Ok(Some(0));
                };
                let key = task.key;
                if method.starts_with("contains") {
                    queue.entries.contains(&key) as u64
                } else {
                    self.schedule_queue_mut(id)?.entries.remove(&key) as u64
                }
            }
            "toArray()[Ljava/lang/Object;" => {
                let tasks = queue.roots().map(u64::from).collect();
                self.allocate("[Ljava/lang/Object;", Payload::Array(tasks))? as u64
            }
            _ => return Ok(None),
        }))
    }

    pub(super) fn scheduled_api(
        &mut self,
        class: &str,
        method: &str,
        args: &[u32],
    ) -> Result<Option<u64>> {
        let arg = |index: usize| {
            args.get(index)
                .copied()
                .ok_or("Scheduled executor argument count")
        };
        if class == ACCESS {
            let name = match method {
                "startTask(Lorg/kyvex/rift/internal/ScheduledTask;)Ljava/lang/Object;" => {
                    "startTask"
                }
                "isCallable(Lorg/kyvex/rift/internal/ScheduledTask;)Z" => "isCallable",
                "finishTask(Lorg/kyvex/rift/internal/ScheduledTask;Ljava/lang/Object;Ljava/lang/Throwable;)V" => {
                    "finishTask"
                }
                _ => return Ok(None),
            };
            return self.run_scheduled_bridge(name, args).map(Some);
        }
        if class == "Ljava/util/concurrent/Executors;"
            && matches!(
                method,
                "newScheduledThreadPool(I)Ljava/util/concurrent/ScheduledExecutorService;"
                    | "newScheduledThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;"
                    | "newSingleThreadScheduledExecutor()Ljava/util/concurrent/ScheduledExecutorService;"
                    | "newSingleThreadScheduledExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;"
            )
        {
            let single = method.starts_with("newSingle");
            let core = if single { 1 } else { arg(0)? };
            let factory = method
                .contains("ThreadFactory;")
                .then(|| arg(usize::from(!single)))
                .transpose()?;
            let pool = self.instantiate(POOL)?;
            let _roots = self.scoped_library_roots(&[pool])?;
            self.init_scheduled_pool(pool, core, factory, None)?;
            return Ok(Some(if single {
                self.allocate(WRAPPER, Payload::ExecutorWrapper(pool))? as u64
            } else {
                pool as u64
            }));
        }
        let Some(&id) = args.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        if class == POOL
            && matches!(
                method,
                "<init>(I)V"
                    | "<init>(ILjava/util/concurrent/ThreadFactory;)V"
                    | "<init>(ILjava/util/concurrent/RejectedExecutionHandler;)V"
                    | "<init>(ILjava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V"
            )
        {
            if !self.subclass(&object.class, POOL)? {
                return Err("Scheduled executor constructor receiver".into());
            }
            let has_factory = method.contains("ThreadFactory;");
            let factory = has_factory.then(|| arg(2)).transpose()?;
            let handler = method
                .contains("RejectedExecutionHandler;")
                .then(|| arg(2 + usize::from(has_factory)))
                .transpose()?;
            self.init_scheduled_pool(id, arg(1)?, factory, handler)?;
            return Ok(Some(0));
        }
        let queue_id = match &object.payload {
            Payload::ScheduledTask(_) => return self.scheduled_task_api(id, method, args),
            Payload::ScheduledQueue(_) => return self.scheduled_queue_api(id, method, args),
            Payload::Executor(pool)
                if matches!(
                    self.heap.get(&pool.queue).map(|o| &o.payload),
                    Some(Payload::ScheduledQueue(_))
                ) =>
            {
                pool.queue
            }
            _ => return Ok(None),
        };
        let value = match method {
            "execute(Ljava/lang/Runnable;)V" => {
                self.submit_scheduled(id, arg(1)?, false, 0, 0, 0)?;
                0
            }
            "submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;" => {
                self.submit_scheduled(id, arg(1)?, false, 0, 0, 0)? as u64
            }
            "submit(Ljava/lang/Runnable;Ljava/lang/Object;)Ljava/util/concurrent/Future;" => {
                self.submit_scheduled(id, arg(1)?, false, arg(2)?, 0, 0)? as u64
            }
            "submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;" => {
                self.submit_scheduled(id, arg(1)?, true, 0, 0, 0)? as u64
            }
            "schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;"
            | "schedule(Ljava/util/concurrent/Callable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;" =>
            {
                let command = arg(1)?;
                let delay = self.timeout_nanos(wide(args, 2)?, arg(4)?)?;
                self.submit_scheduled(id, command, method.contains("Callable;"), 0, delay, 0)?
                    as u64
            }
            "scheduleAtFixedRate(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;"
            | "scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;" =>
            {
                let command = arg(1)?;
                self.object(command)?;
                let unit = arg(6)?;
                let delay = self.timeout_nanos(wide(args, 2)?, unit)?;
                let repeat = self.timeout_nanos(wide(args, 4)?, unit)?;
                if repeat <= 0 {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Nonpositive task period",
                    ));
                }
                let repeat = if method.starts_with("scheduleWith") {
                    -repeat
                } else {
                    repeat
                };
                self.submit_scheduled(id, command, false, 0, delay, repeat)? as u64
            }
            "getRemoveOnCancelPolicy()Z" => self.schedule_queue(queue_id)?.remove_cancelled as u64,
            "getExecuteExistingDelayedTasksAfterShutdownPolicy()Z" => {
                self.schedule_queue(queue_id)?.keep_delayed as u64
            }
            "getContinueExistingPeriodicTasksAfterShutdownPolicy()Z" => {
                self.schedule_queue(queue_id)?.keep_periodic as u64
            }
            "setRemoveOnCancelPolicy(Z)V" => {
                self.schedule_queue_mut(queue_id)?.remove_cancelled = arg(1)? != 0;
                0
            }
            "setExecuteExistingDelayedTasksAfterShutdownPolicy(Z)V"
            | "setContinueExistingPeriodicTasksAfterShutdownPolicy(Z)V" => {
                let enable = arg(1)? != 0;
                let queue = self.schedule_queue_mut(queue_id)?;
                if method.starts_with("setExecute") {
                    queue.keep_delayed = enable;
                } else {
                    queue.keep_periodic = enable;
                }
                if !enable && self.pool(id)?.shutdown {
                    self.prune_scheduled_shutdown(id)?;
                    self.try_terminate_pool(id)?;
                }
                0
            }
            "remove(Ljava/lang/Runnable;)Z" => {
                let removed = self
                    .scheduled_queue_api(
                        queue_id,
                        "remove(Ljava/lang/Object;)Z",
                        &[queue_id, arg(1)?],
                    )?
                    .unwrap_or(0);
                self.try_terminate_pool(id)?;
                removed
            }
            "purge()V" => {
                let queue = self.schedule_queue(queue_id)?;
                let mut cancelled = Vec::new();
                for key in &queue.entries {
                    if matches!(
                        self.scheduled_task(key.task)?.outcome,
                        Some(Outcome::Cancelled)
                    ) {
                        cancelled.push(*key);
                    }
                }
                self.schedule_queue_mut(queue_id)?
                    .entries
                    .retain(|key| !cancelled.contains(key));
                self.try_terminate_pool(id)?;
                0
            }
            "decorateTask(Ljava/lang/Runnable;Ljava/util/concurrent/RunnableScheduledFuture;)Ljava/util/concurrent/RunnableScheduledFuture;"
            | "decorateTask(Ljava/util/concurrent/Callable;Ljava/util/concurrent/RunnableScheduledFuture;)Ljava/util/concurrent/RunnableScheduledFuture;" => {
                arg(2)? as u64
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}

fn wide(args: &[u32], index: usize) -> Result<i64> {
    let low = *args.get(index).ok_or("Missing scheduled time word")? as u64;
    let high = *args.get(index + 1).ok_or("Missing scheduled time word")? as u64;
    Ok((low | (high << 32)) as i64)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn queue_checks_deadlines_and_keeps_fifo_order_for_equal_times() {
        let now = Instant::now();
        let future = now + Duration::from_secs(60);
        let mut queue = Queue::default();
        queue.entries.extend([
            Key {
                when: future,
                order: 0,
                task: 3,
            },
            Key {
                when: now,
                order: 2,
                task: 2,
            },
            Key {
                when: now,
                order: 1,
                task: 1,
            },
        ]);

        assert_eq!(queue.poll(false), 1);
        assert_eq!(queue.poll(false), 2);
        assert_eq!(queue.poll(false), 0);
        assert_eq!(queue.roots().collect::<Vec<_>>(), [3]);
        assert_eq!(queue.poll(true), 3);
        assert_eq!(queue.poll(true), 0);
        assert_eq!(nanos_until(future, now), 60_000_000_000);
        assert_eq!(nanos_until(now, future), -60_000_000_000);
    }
}
