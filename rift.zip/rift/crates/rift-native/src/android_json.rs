//! Pinned AOSP org.json bytecode, executed by the same VM as the application.

pub const DEX: &[u8] = include_bytes!("../support/android-json.dex");

pub fn is_platform_class(class: &str) -> bool {
    matches!(
        class,
        "Lorg/json/JSON;"
            | "Lorg/json/JSONArray;"
            | "Lorg/json/JSONException;"
            | "Lorg/json/JSONObject;"
            | "Lorg/json/JSONObject$1;"
            | "Lorg/json/JSONStringer;"
            | "Lorg/json/JSONStringer$Scope;"
            | "Lorg/json/JSONTokener;"
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dexfile::Dex;
    use sha2::{Digest, Sha256};

    #[test]
    fn module_matches_the_pinned_dex_and_owns_only_its_platform_classes() {
        let pin: serde_json::Value =
            serde_json::from_str(include_str!("../support/android-json.json")).unwrap();
        assert_eq!(format!("{:x}", Sha256::digest(DEX)), pin["dex_sha256"]);
        let mut dex = Dex::parse(DEX).unwrap();
        assert_eq!(dex.classes.len(), 8);
        assert!(dex.classes.keys().all(|ty| is_platform_class(dex.ty(*ty))));
        assert!(dex.bodies.values().all(|body| body.access & 0x100 == 0));
        assert!(!is_platform_class("Lorg/json/AppExtension;"));
        dex.remove_class_definitions(is_platform_class);
        assert!(dex.classes.is_empty() && dex.bodies.is_empty());
    }
}
