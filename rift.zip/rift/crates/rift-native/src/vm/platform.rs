//! Identity of the emulated API environment, never host account/OS secrets.
use super::*;
pub(super) fn properties(arch: u32) -> BTreeMap<Vec<u16>, Vec<u16>> {
    [
        ("java.vm.name", "KYVEX Rift Native"),
        ("java.vm.vendor", "KYVEX"),
        // 2.1 is the compatibility contract used by AndroidX to detect native multidex.
        ("java.vm.version", "2.1.0"),
        ("rift.version", "0.3.0"),
        ("java.version", "1.8.0"),
        ("java.specification.version", "1.8"),
        ("os.name", "Linux"),
        ("os.arch", if arch == 64 { "aarch64" } else { "armv7l" }),
        ("line.separator", "\n"),
        ("file.separator", "/"),
        ("path.separator", ":"),
        ("user.language", "en"),
        ("user.country", "US"),
    ]
    .into_iter()
    .map(|(k, v)| (k.encode_utf16().collect(), v.encode_utf16().collect()))
    .collect()
}
impl Runtime {
    fn native_interface(class: &str) -> bool {
        matches!(
            class,
            "Ljava/lang/Cloneable;"
                | display_api::WINDOW_MANAGER
                | display_api::VIEW_MANAGER
                | interpolators::INTERPOLATOR
                | interpolators::TIME_INTERPOLATOR
                | "Landroid/database/Cursor;"
                | "Landroid/database/DatabaseErrorHandler;"
                | "Landroid/database/sqlite/SQLiteDatabase$CursorFactory;"
                | "Ljava/io/Serializable;"
                | "Ljava/lang/Comparable;"
                | "Ljava/lang/CharSequence;"
                | "Ljava/lang/Runnable;"
                | "Ljava/lang/Iterable;"
                | "Ljava/lang/AutoCloseable;"
                | "Ljava/io/Closeable;"
                | "Ljava/util/Collection;"
                | "Ljava/util/List;"
                | "Ljava/util/Set;"
                | "Ljava/util/Map;"
                | "Ljava/util/Map$Entry;"
                | "Ljava/util/Queue;"
                | "Ljava/util/Deque;"
                | "Ljava/util/Iterator;"
                | "Ljava/util/ListIterator;"
                | "Ljava/util/RandomAccess;"
                | "Ljava/util/concurrent/ConcurrentMap;"
                | "Ljava/util/concurrent/BlockingQueue;"
                | "Ljava/util/concurrent/BlockingDeque;"
                | "Ljava/util/concurrent/Executor;"
                | "Ljava/util/concurrent/ThreadFactory;"
                | "Ljava/util/concurrent/RejectedExecutionHandler;"
                | "Ljava/util/concurrent/ExecutorService;"
                | "Ljava/util/concurrent/ScheduledExecutorService;"
                | "Ljava/util/concurrent/Callable;"
                | "Ljava/util/function/Predicate;"
                | "Ljava/util/function/Supplier;"
                | "Ljava/util/concurrent/Future;"
                | "Ljava/util/concurrent/RunnableFuture;"
                | "Ljava/util/concurrent/ScheduledFuture;"
                | "Ljava/util/concurrent/RunnableScheduledFuture;"
                | "Ljava/util/concurrent/Delayed;"
                | "Ljava/util/concurrent/locks/Lock;"
                | "Ljava/lang/Thread$UncaughtExceptionHandler;"
                | "Landroid/content/SharedPreferences;"
                | "Landroid/content/SharedPreferences$Editor;"
                | "Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;"
                | "Landroid/content/ComponentCallbacks;"
                | "Landroid/content/ComponentCallbacks2;"
                | "Landroid/app/Application$ActivityLifecycleCallbacks;"
                | "Landroid/view/View$OnClickListener;"
                | "Landroid/os/Handler$Callback;"
                | "Landroid/os/IBinder;"
                | "Landroid/os/Parcelable;"
                | "Lorg/xmlpull/v1/XmlPullParser;"
                | xml_pull::RESOURCE_PARSER
                | "Landroid/util/AttributeSet;"
        )
    }
    pub(super) fn class_assignable(&self, target: &str, source: &str) -> Result<bool> {
        if target == source {
            return Ok(true);
        }
        if target.len() == 1 || source.len() == 1 {
            return Ok(false);
        }
        if let Some(source) = source.strip_prefix('[') {
            if let Some(target) = target.strip_prefix('[') {
                return self.class_assignable(target, source);
            }
            return Ok(matches!(
                target,
                "Ljava/lang/Object;" | "Ljava/lang/Cloneable;" | "Ljava/io/Serializable;"
            ));
        }
        if target.starts_with('[') {
            return Ok(false);
        }
        self.subclass(source, target)
    }
    pub(super) fn resolve_field(&mut self, index: usize) -> Result<usize> {
        let original = self.dex.fields.get(index).ok_or("DEX field index")?.clone();
        let mut ty = original.class;
        let name = self.dex.strings[original.name].clone();
        let descriptor = self.dex.ty(original.ty).to_owned();
        for _ in 0..64 {
            let class = self.dex.ty(ty).to_owned();
            self.ensure_class(&class)?;
            let Some(definition) = self.dex.classes.get(&ty) else {
                if let Some(index) = self.dex.fields.iter().position(|field| {
                    self.dex.ty(field.class) == class
                        && self.dex.strings[field.name] == name
                        && self.dex.ty(field.ty) == descriptor
                }) {
                    return Ok(index);
                }
                if pair::declared_field(&class, &name).is_some_and(|(ty, _)| ty == descriptor) {
                    let index = self.dex.fields.len();
                    self.dex.fields.push(crate::dexfile::Field {
                        class: ty,
                        ..original
                    });
                    return Ok(index);
                }
                return Err(format!(
                    "Unsupported inherited framework field {class}->{name}:{descriptor}"
                )
                .into());
            };
            for i in &definition.fields {
                let f = &self.dex.fields[*i];
                if self.dex.strings[f.name] == name && self.dex.ty(f.ty) == descriptor {
                    return Ok(*i);
                }
            }
            let Some(parent) = definition.parent else {
                return Err(format!("Unresolved DEX field {class}->{name}:{descriptor}").into());
            };
            ty = parent;
        }
        Err("DEX field hierarchy budget".into())
    }
    pub(super) fn platform_static(&mut self, index: usize) -> Result<u64> {
        if let Some(v) = self.statics.get(&index) {
            return Ok(*v);
        }
        let field = self.dex.fields.get(index).ok_or("Framework field index")?;
        let class = self.dex.ty(field.class).to_owned();
        let name = self.dex.strings[field.name].clone();
        if class == rounding::CLASS && self.dex.ty(field.ty) == rounding::CLASS {
            let id = self.named_rounding_mode(&name.encode_utf16().collect::<Vec<_>>())?;
            self.statics.insert(index, u64::from(id));
            return Ok(u64::from(id));
        }
        if class == locale::LOCALE && name == "US" && self.dex.ty(field.ty) == locale::LOCALE {
            let value = u64::from(self.default_locale()?);
            self.statics.insert(index, value);
            return Ok(value);
        }
        if class == strict_mode::POLICY
            && name == "LAX"
            && self.dex.ty(field.ty) == strict_mode::POLICY
        {
            let policy = self.new_strict_policy(0)?;
            self.statics.insert(index, policy);
            return Ok(policy);
        }
        if class == "Ljava/util/logging/Level;"
            && self.dex.ty(field.ty) == "Ljava/util/logging/Level;"
        {
            return Ok(self.logging_level_constant(&name)? as u64);
        }
        if class == "Ljava/util/logging/Logger;" {
            return Ok(match (name.as_str(), self.dex.ty(field.ty)) {
                ("GLOBAL_LOGGER_NAME", "Ljava/lang/String;") => self.string("global")? as u64,
                ("global", "Ljava/util/logging/Logger;") => self.logging_global()? as u64,
                _ => return Err("Unsupported Logger static field".into()),
            });
        }
        if class == "Landroid/util/Base64;" && self.dex.ty(field.ty) == "I" {
            return Ok(match name.as_str() {
                "DEFAULT" => 0,
                "NO_PADDING" => 1,
                "NO_WRAP" => 2,
                "CRLF" => 4,
                "URL_SAFE" => 8,
                "NO_CLOSE" => 16,
                _ => return Err("Unknown Base64 constant".into()),
            });
        }
        if class == "Ljava/nio/charset/StandardCharsets;" {
            let descriptor = self.dex.ty(field.ty).to_owned();
            let value = self.charset_static(&name, &descriptor)?;
            self.statics.insert(index, value);
            return Ok(value);
        }
        if class == "Ljava/util/Collections;" {
            let kind = match (name.as_str(), self.dex.ty(field.ty)) {
                ("EMPTY_LIST", "Ljava/util/List;") => 0,
                ("EMPTY_SET", "Ljava/util/Set;") => 1,
                ("EMPTY_MAP", "Ljava/util/Map;") => 2,
                _ => return Err("Unsupported Collections static field".into()),
            };
            let value = self.empty_collection(kind)? as u64;
            self.statics.insert(index, value);
            return Ok(value);
        }
        if class == "Ljava/io/File;" {
            let value = match (name.as_str(), self.dex.ty(field.ty)) {
                ("separator", "Ljava/lang/String;") => self.string("/")? as u64,
                ("pathSeparator", "Ljava/lang/String;") => self.string(":")? as u64,
                ("separatorChar", "C") => 47,
                ("pathSeparatorChar", "C") => 58,
                _ => return Err("Unsupported java.io.File static field".into()),
            };
            self.statics.insert(index, value);
            return Ok(value);
        }
        if class == "Ljava/lang/Boolean;" && matches!(name.as_str(), "TRUE" | "FALSE") {
            let value = self.box_value('Z', (name == "TRUE") as u64)? as u64;
            self.statics.insert(index, value);
            return Ok(value);
        }
        if name == "TYPE"
            && self.dex.ty(field.ty) == "Ljava/lang/Class;"
            && let Some(kind) =
                android::boxed_kind(&class).or((class == "Ljava/lang/Void;").then_some('V'))
        {
            let value = self.class_object(&kind.to_string())? as u64;
            self.statics.insert(index, value);
            return Ok(value);
        }
        if class == "Ljava/lang/Thread$State;" {
            let ordinal = [
                "NEW",
                "RUNNABLE",
                "BLOCKED",
                "WAITING",
                "TIMED_WAITING",
                "TERMINATED",
            ]
            .iter()
            .position(|s| *s == name)
            .ok_or("Unknown Thread.State constant")?;
            let id = self.thread_state_constant(ordinal as u32)?;
            self.statics.insert(index, id as u64);
            return Ok(id as u64);
        }
        if class == "Ljava/util/concurrent/TimeUnit;" {
            let ordinal = [
                "NANOSECONDS",
                "MICROSECONDS",
                "MILLISECONDS",
                "SECONDS",
                "MINUTES",
                "HOURS",
                "DAYS",
            ]
            .iter()
            .position(|s| *s == name)
            .ok_or("Unknown TimeUnit constant")?;
            let id = self.time_unit(ordinal as u32)?;
            self.statics.insert(index, id as u64);
            return Ok(id as u64);
        }
        let value = match (class.as_str(), name.as_str(), self.dex.ty(field.ty)) {
            ("Landroid/os/Build$VERSION;", "SDK_INT", "I") => 28,
            ("Landroid/os/Build$VERSION;", "RELEASE", "Ljava/lang/String;") => {
                self.string("9")? as u64
            }
            ("Landroid/os/Build$VERSION;", "CODENAME", "Ljava/lang/String;") => {
                self.string("REL")? as u64
            }
            ("Landroid/os/Build;", "BRAND" | "MANUFACTURER", "Ljava/lang/String;") => {
                self.string("KYVEX")? as u64
            }
            ("Landroid/os/Build;", "MODEL", "Ljava/lang/String;") => {
                self.string("Rift Native")? as u64
            }
            ("Landroid/os/Build;", "DEVICE" | "PRODUCT", "Ljava/lang/String;") => {
                self.string("kyvex-native")? as u64
            }
            ("Landroid/os/Build;", "HARDWARE", "Ljava/lang/String;") => {
                self.string("dynarmic")? as u64
            }
            ("Landroid/os/Build;", "TAGS" | "FINGERPRINT", "Ljava/lang/String;") => {
                self.string("KYVEX/Rift/experimental")? as u64
            }
            ("Landroid/os/Build;", "CPU_ABI", "Ljava/lang/String;") => {
                self.string(if self.machine.arch == 64 {
                    "arm64-v8a"
                } else {
                    "armeabi-v7a"
                })? as u64
            }
            ("Landroid/os/Build;", "SUPPORTED_ABIS", "[Ljava/lang/String;") => {
                let abi = self.string(if self.machine.arch == 64 {
                    "arm64-v8a"
                } else {
                    "armeabi-v7a"
                })?;
                self.allocate("[Ljava/lang/String;", Payload::Array(vec![abi as u64]))? as u64
            }
            _ => {
                return Err(format!(
                    "Unsupported Android/Java field {class}->{name}:{}",
                    self.dex.ty(field.ty)
                )
                .into());
            }
        };
        self.statics.insert(index, value);
        Ok(value)
    }
    pub(super) fn platform_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let arg = |i: usize| a.get(i).copied().ok_or("Platform API argument count");
        let (class, method) = sig.split_once("->").ok_or("Platform API signature")?;
        // The guest has no enabled trace collector. Disabled Android tracing
        // is intentionally inert; it never reports captured trace data.
        if class == "Landroid/os/Trace;"
            && matches!(
                method,
                "beginSection(Ljava/lang/String;)V"
                    | "endSection()V"
                    | "beginAsyncSection(Ljava/lang/String;I)V"
                    | "endAsyncSection(Ljava/lang/String;I)V"
                    | "setCounter(Ljava/lang/String;J)V"
                    | "isEnabled()Z"
                    | "isTagEnabled(J)Z"
            )
        {
            return Ok(Some(0));
        }
        if class == "Ljava/lang/System;" {
            match method {
                "getProperty(Ljava/lang/String;)Ljava/lang/String;"
                | "getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;" => {
                    let key = self.units(arg(0)?)?;
                    if key.is_empty() {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "empty property name",
                        ));
                    }
                    return Ok(Some(
                        if let Some(value) = self.properties.get(&key).cloned() {
                            self.string_units(value)? as u64
                        } else {
                            a.get(1).copied().unwrap_or(0) as u64
                        },
                    ));
                }
                "setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;"
                | "clearProperty(Ljava/lang/String;)Ljava/lang/String;" => {
                    let key = self.units(arg(0)?)?;
                    if key.is_empty() {
                        return Err(fault(
                            "Ljava/lang/IllegalArgumentException;",
                            "empty property name",
                        ));
                    }
                    if self.properties.len() >= 256 && !self.properties.contains_key(&key) {
                        return Err("VM property quota".into());
                    }
                    let previous = if method.starts_with("set") {
                        let value = self.units(arg(1)?)?;
                        self.properties.insert(key, value)
                    } else {
                        self.properties.remove(&key)
                    };
                    return Ok(Some(if let Some(value) = previous {
                        self.string_units(value)? as u64
                    } else {
                        0
                    }));
                }
                _ => {}
            }
        }
        if method == "getClass()Ljava/lang/Class;" {
            let class = self.object(arg(0)?)?.class.clone();
            return Ok(Some(self.class_object(&class)? as u64));
        }
        if class == "Ljava/lang/Class;" {
            match method {
                "forName(Ljava/lang/String;)Ljava/lang/Class;" => {
                    let name = self.text(arg(0)?)?;
                    return Ok(Some(self.load_class_object(&name, true)? as u64));
                }
                "forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;" => {
                    let name = self.text(arg(0)?)?;
                    let loader = arg(2)?;
                    if loader != 0 && loader != self.class_loader {
                        return Err("Unsupported guest ClassLoader for Class.forName".into());
                    }
                    if loader == 0 {
                        let descriptor = format!("L{};", name.replace('.', "/"));
                        self.ensure_class(&descriptor)?;
                        if self.dex.has_class(&descriptor) {
                            return Err(fault("Ljava/lang/ClassNotFoundException;", &name));
                        }
                    }
                    return Ok(Some(self.load_class_object(&name, arg(1)? != 0)? as u64));
                }
                "getName()Ljava/lang/String;" | "getSimpleName()Ljava/lang/String;" => {
                    let name = match &self.object(arg(0)?)?.payload {
                        Payload::Class(c) => c.clone(),
                        _ => return Err("Expected Class object".into()),
                    };
                    let primitive = match name.as_str() {
                        "Z" => Some("boolean"),
                        "B" => Some("byte"),
                        "S" => Some("short"),
                        "C" => Some("char"),
                        "I" => Some("int"),
                        "J" => Some("long"),
                        "F" => Some("float"),
                        "D" => Some("double"),
                        "V" => Some("void"),
                        _ => None,
                    };
                    let name = if let Some(name) = primitive {
                        name.into()
                    } else if name.starts_with('L') {
                        name.strip_prefix('L')
                            .and_then(|s| s.strip_suffix(';'))
                            .ok_or("Invalid Class descriptor")?
                            .replace('/', ".")
                    } else {
                        name.replace('/', ".")
                    };
                    let name = if method.starts_with("getSimpleName") {
                        name.rsplit(['.', '$']).next().unwrap_or(&name).to_owned()
                    } else {
                        name
                    };
                    return Ok(Some(self.string(&name)? as u64));
                }
                "isAssignableFrom(Ljava/lang/Class;)Z" | "isInstance(Ljava/lang/Object;)Z" => {
                    let Payload::Class(target) = &self.object(arg(0)?)?.payload else {
                        return Err("Expected Class receiver".into());
                    };
                    if method.starts_with("isInstance") {
                        let id = arg(1)?;
                        return Ok(Some(if id == 0 {
                            false
                        } else {
                            self.class_assignable(target, &self.object(id)?.class)?
                        } as u64));
                    }
                    let Payload::Class(source) = &self.object(arg(1)?)?.payload else {
                        return Err("Expected Class argument".into());
                    };
                    return Ok(Some(self.class_assignable(target, source)? as u64));
                }
                "equals(Ljava/lang/Object;)Z" | "hashCode()I" => {
                    let id = arg(0)?;
                    if !matches!(self.object(id)?.payload, Payload::Class(_)) {
                        return Err("Expected Class receiver".into());
                    }
                    return Ok(Some(if method.starts_with("equals") {
                        (id == arg(1)?) as u64
                    } else {
                        id as u64
                    }));
                }
                "getSuperclass()Ljava/lang/Class;" | "isInterface()Z" => {
                    let Payload::Class(name) = &self.object(arg(0)?)?.payload else {
                        return Err("Expected Class receiver".into());
                    };
                    let name = name.clone();
                    self.ensure_class(&name)?;
                    let definition = self
                        .dex
                        .type_id(&name)
                        .and_then(|ty| self.dex.classes.get(&ty));
                    let interface = definition.map_or_else(
                        || Self::native_interface(&name),
                        |class| class.access & 512 != 0,
                    );
                    if method == "isInterface()Z" {
                        return Ok(Some(interface as u64));
                    }
                    if interface || name == "Ljava/lang/Object;" || name.len() == 1 {
                        return Ok(Some(0));
                    }
                    let parent = if name.starts_with('[') {
                        Some("Ljava/lang/Object;".to_owned())
                    } else if let Some(definition) = definition {
                        definition.parent.map(|p| self.dex.ty(p).to_owned())
                    } else {
                        Some(
                            framework_parent(&name)
                                .ok_or_else(|| {
                                    format!("Superclass metadata is not implemented for {name}")
                                })?
                                .to_owned(),
                        )
                    };
                    return Ok(Some(if let Some(parent) = parent {
                        self.class_object(&parent)? as u64
                    } else {
                        0
                    }));
                }
                "isArray()Z" => {
                    let Payload::Class(c) = &self.object(arg(0)?)?.payload else {
                        return Err("Expected Class".into());
                    };
                    return Ok(Some(c.starts_with('[') as u64));
                }
                "isPrimitive()Z" => {
                    let Payload::Class(c) = &self.object(arg(0)?)?.payload else {
                        return Err("Expected Class".into());
                    };
                    return Ok(Some((c.len() == 1 && "ZBCSIJFDV".contains(c)) as u64));
                }
                _ => {}
            }
        }
        if method == "getClassLoader()Ljava/lang/ClassLoader;"
            && (class == "Ljava/lang/Class;"
                || self.subclass(&self.object(arg(0)?)?.class, "Landroid/content/Context;")?)
        {
            if self.class_loader == 0 {
                self.class_loader =
                    self.allocate("Ldalvik/system/PathClassLoader;", Payload::Instance)?;
            }
            return Ok(Some(self.class_loader as u64));
        }
        if sig == "Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;" {
            if arg(0)? != self.class_loader || self.class_loader == 0 {
                return Err("Unknown class loader".into());
            }
            let name = self.text(arg(1)?)?;
            return Ok(Some(self.load_class_object(&name, false)? as u64));
        }
        Ok(None)
    }
    fn load_class_object(&mut self, name: &str, initialize: bool) -> Result<u32> {
        let class = if name.starts_with('[') {
            name.replace('.', "/")
        } else {
            format!("L{};", name.replace('.', "/"))
        };
        self.ensure_class(&class)?;
        if let Some(ty) = self
            .dex
            .classes
            .keys()
            .find(|i| self.dex.ty(**i) == class)
            .copied()
        {
            if initialize {
                self.initialize(ty)?;
            }
        } else if class != "Ljava/lang/Object;" && framework_parent(&class).is_none() {
            return Err(fault("Ljava/lang/ClassNotFoundException;", name));
        }
        self.class_object(&class)
    }
}
