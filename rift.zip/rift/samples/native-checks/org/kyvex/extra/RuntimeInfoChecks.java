package org.kyvex.extra;
public final class RuntimeInfoChecks {
 private static byte[] retained;
 public static int verify(){
  Runtime runtime=Runtime.getRuntime();if(runtime!=Runtime.getRuntime())throw new IllegalStateException("Runtime identity");
  if(runtime.availableProcessors()!=1)throw new IllegalStateException("Guest has one execution lane");
  long maximum=runtime.maxMemory(),total=runtime.totalMemory(),free=runtime.freeMemory();if(maximum<=0||total!=maximum||free<0||free>total)throw new IllegalStateException("Guest heap budgets");
  retained=new byte[2048];retained[0]=7;long after=runtime.freeMemory();runtime.gc();System.gc();if(after>=free||retained[0]!=7)throw new IllegalStateException("Heap use and advisory GC preserve live objects");
  return 4;
 }
}
