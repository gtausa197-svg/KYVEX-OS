import java.io.*;
/** Run on a stock Linux JDK to check Unix File constructor/seek semantics. */
public final class FileOracle {
    public static void main(String[] args) throws Exception {
        String[] parents={null,"","/parent","parent/"};
        String[] children={"","/child","child","//"};
        for(String parent:parents)for(String child:children){File file=new File(parent,child);System.out.println("parent="+parent+" child="+child+" path="+file.getPath()+" parentPath="+file.getParent()+" name="+file.getName());}
        File temp=File.createTempFile("rift-file-oracle-",".bin");
        try {FileOutputStream out=new FileOutputStream(temp);out.write(new byte[]{0,127,(byte)128,(byte)255,42});out.close();FileInputStream in=new FileInputStream(temp);in.skip(4);System.out.println("backwards="+in.skip(-2)+" next="+in.read());in.close();}finally{temp.delete();}
    }
}
