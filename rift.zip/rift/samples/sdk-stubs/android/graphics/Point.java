package android.graphics;

/** Compile-only Android signatures. */
public class Point {
    public int x;
    public int y;
    public Point() {}
    public Point(int x, int y) {}
    public Point(Point source) {}
    public native void set(int x, int y);
    public native void offset(int dx, int dy);
    public native void negate();
    public native boolean equals(int x, int y);
    public native boolean equals(Object other);
    public native int hashCode();
    public native String toString();
}
