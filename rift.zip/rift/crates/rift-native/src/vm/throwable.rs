//! Exception messages and cause chains survive interpreted and JNI boundaries.
use super::*;
pub(super) const MESSAGE: usize = usize::MAX;
pub(super) const CAUSE: usize = usize::MAX - 60;
impl Runtime {
    pub(super) fn materialize_fault(&mut self, fault: &JavaFault) -> Result<u32> {
        if fault.object != 0 {
            self.object(fault.object)?;
            if !self
                .object(fault.object)?
                .fields
                .contains_key(&stack_trace::TRACE)
            {
                self.capture_throwable_stack(fault.object)?;
            }
            return Ok(fault.object);
        }
        let object = self.allocate(&fault.class, Payload::Instance)?;
        let message = self.string(&fault.message)?;
        self.object_mut(object)?
            .fields
            .insert(MESSAGE, message as u64);
        self.capture_throwable_stack(object)?;
        Ok(object)
    }
    pub(super) fn throwable_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Throwable signature")?;
        if !self.subclass(class, "Ljava/lang/Throwable;")? {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Throwable argument count");
        let id = arg(0)?;
        let actual = self.object(id)?.class.clone();
        if !self.subclass(&actual, "Ljava/lang/Throwable;")? {
            return Err("Throwable receiver type".into());
        }
        match method {
            "getException()Ljava/lang/Throwable;"
                if actual == "Ljava/lang/ExceptionInInitializerError;" =>
            {
                return Ok(Some(
                    self.object(id)?.fields.get(&CAUSE).copied().unwrap_or(0),
                ));
            }
            "getMessage()Ljava/lang/String;" | "getLocalizedMessage()Ljava/lang/String;" => {
                return Ok(Some(
                    self.object(id)?.fields.get(&MESSAGE).copied().unwrap_or(0),
                ));
            }
            "toString()Ljava/lang/String;" => {
                let name = actual
                    .trim_start_matches('L')
                    .trim_end_matches(';')
                    .replace('/', ".");
                let message = self.object(id)?.fields.get(&MESSAGE).copied().unwrap_or(0) as u32;
                let mut units: Vec<u16> = name.encode_utf16().collect();
                if message != 0 {
                    units.extend([58, 32]);
                    units.extend(self.units(message)?);
                }
                return Ok(Some(self.string_units(units)? as u64));
            }
            "getCause()Ljava/lang/Throwable;" => {
                return Ok(Some(
                    self.object(id)?.fields.get(&CAUSE).copied().unwrap_or(0),
                ));
            }
            "initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;" => {
                if self.object(id)?.fields.contains_key(&CAUSE) {
                    return Err(fault(
                        "Ljava/lang/IllegalStateException;",
                        "Cause already initialized",
                    ));
                }
                let cause = arg(1)?;
                if cause == id {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Self-causation not permitted",
                    ));
                }
                if cause != 0
                    && !self.subclass(&self.object(cause)?.class, "Ljava/lang/Throwable;")?
                {
                    return Err("Throwable cause type".into());
                }
                self.object_mut(id)?.fields.insert(CAUSE, cause as u64);
                return Ok(Some(id as u64));
            }
            "<init>()V"
            | "<init>(Ljava/lang/String;)V"
            | "<init>(Ljava/lang/Throwable;)V"
            | "<init>(Ljava/lang/String;Ljava/lang/Throwable;)V"
            | "<init>(Ljava/lang/String;Ljava/lang/Throwable;ZZ)V" => {
                let extended = method == "<init>(Ljava/lang/String;Ljava/lang/Throwable;ZZ)V";
                let writable = !extended || arg(4)? != 0;
                let suppression = !extended || arg(3)? != 0;
                self.object_mut(id)?.fields.extend([
                    (stack_trace::TRACE, 0),
                    (stack_trace::WRITABLE, writable as u64),
                ]);
                // Throwable constructors dispatch fillInStackTrace before assigning
                // the message/cause; real subclass overrides must observe that order.
                if writable {
                    if let Some(method) =
                        self.callback_method(id, "fillInStackTrace", "()Ljava/lang/Throwable;")?
                    {
                        self.invoke(method, &[id], true)?;
                    } else {
                        self.capture_throwable_stack(id)?;
                    }
                }
                let has_cause = method.contains("Ljava/lang/Throwable;");
                let mut message = if method.starts_with("<init>(Ljava/lang/String;") {
                    arg(1)?
                } else {
                    0
                };
                let cause = if has_cause {
                    arg(if method.starts_with("<init>(Ljava/lang/String;") {
                        2
                    } else {
                        1
                    })?
                } else {
                    0
                };
                if cause != 0 {
                    if !self.subclass(&self.object(cause)?.class, "Ljava/lang/Throwable;")? {
                        return Err("Throwable constructor cause".into());
                    }
                    if method == "<init>(Ljava/lang/Throwable;)V"
                        && actual != "Ljava/lang/ExceptionInInitializerError;"
                    {
                        let class = self.object(cause)?.class.clone();
                        message = if let Some(index) =
                            self.dex.find(&class, "toString", "()Ljava/lang/String;")
                            && self.dex.bodies.contains_key(&index)
                        {
                            self.invoke(index, &[cause], true)? as u32
                        } else {
                            self.throwable_api(
                                &format!("{class}->toString()Ljava/lang/String;"),
                                &[cause],
                            )?
                            .ok_or("Throwable string")? as u32
                        };
                    }
                }
                if message != 0 {
                    self.units(message)?;
                }
                self.object_mut(id)?.fields.insert(MESSAGE, message as u64);
                if has_cause {
                    self.object_mut(id)?.fields.insert(CAUSE, cause as u64);
                }
                self.object_mut(id)?
                    .fields
                    .insert(stack_trace::SUPPRESSION, suppression as u64);
                if !suppression {
                    self.object_mut(id)?
                        .fields
                        .insert(stack_trace::SUPPRESSED, 0);
                }
                return Ok(Some(0));
            }
            _ => {}
        }
        Ok(None)
    }
}
