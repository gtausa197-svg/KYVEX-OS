//! Java numeric bit operations on primitive register words.
use super::*;
pub(super) fn invoke(sig: &str, a: &[u32]) -> Result<Option<u64>> {
    let arg = |i: usize| a.get(i).copied().ok_or("Bit operation argument count");
    let int = || arg(0);
    let long = || wide(a, 0);
    let highest32 = |x: u32| {
        if x == 0 {
            0
        } else {
            1u32 << (31 - x.leading_zeros())
        }
    };
    let highest64 = |x: u64| {
        if x == 0 {
            0
        } else {
            1u64 << (63 - x.leading_zeros())
        }
    };
    let value = match sig {
        "Ljava/lang/Integer;->numberOfLeadingZeros(I)I" => int()?.leading_zeros() as u64,
        "Ljava/lang/Integer;->numberOfTrailingZeros(I)I" => int()?.trailing_zeros() as u64,
        "Ljava/lang/Integer;->bitCount(I)I" => int()?.count_ones() as u64,
        "Ljava/lang/Integer;->highestOneBit(I)I" => highest32(int()?) as u64,
        "Ljava/lang/Integer;->lowestOneBit(I)I" => {
            let x = int()?;
            x.isolate_lowest_one() as u64
        }
        "Ljava/lang/Integer;->reverse(I)I" => int()?.reverse_bits() as u64,
        "Ljava/lang/Integer;->reverseBytes(I)I" => int()?.swap_bytes() as u64,
        "Ljava/lang/Integer;->signum(I)I" => (int()? as i32).signum() as u32 as u64,
        "Ljava/lang/Integer;->rotateLeft(II)I" => int()?.rotate_left(arg(1)?) as u64,
        "Ljava/lang/Integer;->rotateRight(II)I" => int()?.rotate_right(arg(1)?) as u64,
        "Ljava/lang/Long;->numberOfLeadingZeros(J)I" => long()?.leading_zeros() as u64,
        "Ljava/lang/Long;->numberOfTrailingZeros(J)I" => long()?.trailing_zeros() as u64,
        "Ljava/lang/Long;->bitCount(J)I" => long()?.count_ones() as u64,
        "Ljava/lang/Long;->highestOneBit(J)J" => highest64(long()?),
        "Ljava/lang/Long;->lowestOneBit(J)J" => {
            let x = long()?;
            x.isolate_lowest_one()
        }
        "Ljava/lang/Long;->reverse(J)J" => long()?.reverse_bits(),
        "Ljava/lang/Long;->reverseBytes(J)J" => long()?.swap_bytes(),
        "Ljava/lang/Long;->signum(J)I" => (long()? as i64).signum() as u32 as u64,
        "Ljava/lang/Long;->rotateLeft(JI)J" => long()?.rotate_left(arg(2)?),
        "Ljava/lang/Long;->rotateRight(JI)J" => long()?.rotate_right(arg(2)?),
        "Ljava/lang/Double;->doubleToRawLongBits(D)J"
        | "Ljava/lang/Double;->longBitsToDouble(J)D" => long()?,
        "Ljava/lang/Double;->doubleToLongBits(D)J" => {
            let bits = long()?;
            if f64::from_bits(bits).is_nan() {
                0x7ff8000000000000
            } else {
                bits
            }
        }
        _ => return Ok(None),
    };
    Ok(Some(value))
}
