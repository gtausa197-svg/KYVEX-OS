//! Java Enum metadata, main-thread identity and StringBuilder overloads.
use super::*;
pub(super) fn inherits(class: &str, base: &str) -> bool {
    if matches!(class, xml_pull::COMPILED_PARSER | xml_pull::RESOURCE_PARSER)
        && matches!(
            base,
            xml_pull::RESOURCE_PARSER
                | "Lorg/xmlpull/v1/XmlPullParser;"
                | "Landroid/util/AttributeSet;"
                | "Ljava/lang/AutoCloseable;"
        )
    {
        return true;
    }
    if class == date::DATE
        && matches!(
            base,
            "Ljava/io/Serializable;" | "Ljava/lang/Comparable;" | "Ljava/lang/Cloneable;"
        )
    {
        return true;
    }
    if class == "Landroid/os/Messenger;" && base == "Landroid/os/Parcelable;" {
        return true;
    }
    if class == "Landroid/os/Binder;" && base == "Landroid/os/IBinder;" {
        return true;
    }
    if class == "Ljava/util/concurrent/Executors$DefaultThreadFactory;"
        && base == "Ljava/util/concurrent/ThreadFactory;"
    {
        return true;
    }
    if sqlite::inherits(class, base) {
        return true;
    }
    if class == "Ljava/util/logging/Level;" && base == "Ljava/io/Serializable;" {
        return true;
    }
    if class == "Ljava/nio/charset/Charset;" && base == "Ljava/lang/Comparable;" {
        return true;
    }
    if class == "Ljava/io/ObjectStreamField;" && base == "Ljava/lang/Comparable;" {
        return true;
    }
    if class == "Ljava/lang/StackTraceElement;" && base == "Ljava/io/Serializable;" {
        return true;
    }
    if atomic_arrays::kind(class).is_some() && base == "Ljava/io/Serializable;" {
        return true;
    }
    matches!(
        (class, base),
        (
            "Landroid/app/SharedPreferencesImpl;",
            "Landroid/content/SharedPreferences;"
        ) | (
            "Landroid/app/SharedPreferencesImpl$EditorImpl;",
            "Landroid/content/SharedPreferences$Editor;"
        )
    ) || (class == "Lorg/kyvex/rift/NativeXmlPullParser;"
        && base == "Lorg/xmlpull/v1/XmlPullParser;")
        || (class == "Ljava/util/UUID;"
            && matches!(base, "Ljava/lang/Comparable;" | "Ljava/io/Serializable;"))
        || (class == "Landroid/util/SparseIntArray;" && base == "Ljava/lang/Cloneable;")
        || (class == "Ljava/lang/Thread;" && base == "Ljava/lang/Runnable;")
        || (class == "Ljava/lang/ThreadGroup;"
            && base == "Ljava/lang/Thread$UncaughtExceptionHandler;")
        || (class == "Ljava/lang/Enum;"
            && matches!(base, "Ljava/lang/Comparable;" | "Ljava/io/Serializable;"))
        || (matches!(
            class,
            "Ljava/lang/String;" | "Ljava/lang/StringBuilder;" | "Ljava/lang/StringBuffer;"
        ) && matches!(base, "Ljava/lang/CharSequence;" | "Ljava/io/Serializable;"))
        || (class == "Ljava/lang/String;" && base == "Ljava/lang/Comparable;")
}
impl Runtime {
    pub(super) fn object_units(&mut self, id: u32) -> Result<Vec<u16>> {
        if id == 0 {
            return Ok("null".encode_utf16().collect());
        }
        match &self.object(id)?.payload {
            Payload::String(s) | Payload::Builder(s) => return Ok(s.clone()),
            Payload::File(s) => return Ok(s.clone()),
            Payload::Charset(encoding) => return Ok(encoding.name().encode_utf16().collect()),
            Payload::LogLevel(level) => return self.units(level.name),
            Payload::Uuid(m, l) => return Ok(uuid_api::display(*m, *l).encode_utf16().collect()),
            _ => {}
        }
        let class = self.object(id)?.class.clone();
        if let Some(index) = self.callback_method(id, "toString", "()Ljava/lang/String;")? {
            let value = self.invoke(index, &[id], true)? as u32;
            return self.units(value);
        }
        if pair::has_members(self.object(id)?) {
            return self.pair_units(id);
        }
        let signature = format!("{class}->toString()Ljava/lang/String;");
        if let Some(value) = self.point_api(&signature, &[id])? {
            return self.units(value as u32);
        }
        if let Some(value) = self.stack_trace_api(&signature, &[id])? {
            return self.units(value as u32);
        }
        if let Some(value) = self.throwable_api(&signature, &[id])? {
            return self.units(value as u32);
        }
        if self.subclass(&class, "Ljava/io/ObjectStreamField;")? {
            let value = self
                .stream_field_api(
                    "Ljava/io/ObjectStreamField;->toString()Ljava/lang/String;",
                    &[id],
                )?
                .ok_or("ObjectStreamField text")?;
            return self.units(value as u32);
        }
        if self.subclass(&class, "Ljava/lang/ThreadGroup;")? {
            let value = self
                .thread_group_api(
                    "Ljava/lang/ThreadGroup;->toString()Ljava/lang/String;",
                    &[id],
                )?
                .ok_or("ThreadGroup text")?;
            return self.units(value as u32);
        }
        if let Some(value) =
            self.android_api(&format!("{class}->toString()Ljava/lang/String;"), &[id])?
        {
            return self.units(value as u32);
        }
        Ok(format!(
            "{}@{id:x}",
            class
                .trim_start_matches('L')
                .trim_end_matches(';')
                .replace('/', ".")
        )
        .encode_utf16()
        .collect())
    }
    pub(super) fn lang_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Language signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Language argument count");
        // These static calls contain primitive words, never a boxed receiver.
        if sig == "Ljava/lang/Integer;->toString(I)Ljava/lang/String;" {
            return Ok(Some(self.string(&(arg(0)? as i32).to_string())? as u64));
        }
        if sig == "Ljava/lang/Long;->toString(J)Ljava/lang/String;" {
            let value = arg(0)? as u64 | ((arg(1)? as u64) << 32);
            return Ok(Some(self.string(&(value as i64).to_string())? as u64));
        }
        if class == "Ljava/lang/String;"
            && matches!(
                method,
                "<init>()V"
                    | "<init>(Ljava/lang/String;)V"
                    | "<init>([C)V"
                    | "<init>([CII)V"
                    | "<init>(Ljava/lang/StringBuilder;)V"
                    | "<init>(Ljava/lang/StringBuffer;)V"
            )
        {
            let id = arg(0)?;
            let units = if method == "<init>()V" {
                Vec::new()
            } else if method == "<init>(Ljava/lang/String;)V" {
                self.units(arg(1)?)?
            } else if method.starts_with("<init>([C") {
                let array = self.object(arg(1)?)?;
                let Payload::Array(values) = &array.payload else {
                    return Err("String constructor needs char[]".into());
                };
                if array.class != "[C" {
                    return Err("String constructor needs char[]".into());
                }
                let start = if a.len() > 2 { arg(2)? as usize } else { 0 };
                let count = if a.len() > 3 {
                    arg(3)? as usize
                } else {
                    values.len()
                };
                let end = start
                    .checked_add(count)
                    .filter(|end| *end <= values.len())
                    .ok_or_else(|| {
                        fault(
                            "Ljava/lang/StringIndexOutOfBoundsException;",
                            "String constructor char range",
                        )
                    })?;
                values
                    .get(start..end)
                    .ok_or_else(|| {
                        fault(
                            "Ljava/lang/StringIndexOutOfBoundsException;",
                            "String constructor char range",
                        )
                    })?
                    .iter()
                    .map(|value| u16::try_from(*value).map_err(Into::into))
                    .collect::<Result<Vec<_>>>()?
            } else {
                self.sequence_units(arg(1)?)?
            };
            let Payload::String(old) = &self.object(id)?.payload else {
                return Err("String constructor receiver".into());
            };
            if self
                .heap_bytes()
                .saturating_sub(old.len() * 2)
                .saturating_add(units.len() * 2)
                > self.heap_limit
            {
                return Err("String constructor memory quota".into());
            }
            self.object_mut(id)?.payload = Payload::String(units);
            return Ok(Some(0));
        }
        if class == "Ljava/lang/Boolean;"
            && matches!(
                method,
                "parseBoolean(Ljava/lang/String;)Z"
                    | "valueOf(Ljava/lang/String;)Ljava/lang/Boolean;"
                    | "<init>(Ljava/lang/String;)V"
            )
        {
            let id = arg(if method.starts_with("<init>") { 1 } else { 0 })?;
            let value = if id == 0 {
                false
            } else {
                let units = self.units(id)?;
                units.len() == 4
                    && units
                        .iter()
                        .zip(b"true")
                        .all(|(a, b)| (*a | 32) == *b as u16)
            };
            return Ok(Some(if method.starts_with("parseBoolean") {
                value as u64
            } else if method.starts_with("valueOf") {
                self.box_value('Z', value as u64)? as u64
            } else {
                self.object_mut(arg(0)?)?.payload = Payload::Boxed {
                    kind: 'Z',
                    bits: value as u64,
                };
                0
            }));
        }
        if sig == "Ljava/lang/String;->trim()Ljava/lang/String;" {
            let id = arg(0)?;
            let units = self.units(id)?;
            let start = units.iter().position(|c| *c > 32).unwrap_or(units.len());
            let end = units.iter().rposition(|c| *c > 32).map_or(start, |i| i + 1);
            return Ok(Some(if start == 0 && end == units.len() {
                id
            } else {
                self.string_units(units[start..end].to_vec())?
            } as u64));
        }
        if class == "Ljava/lang/String;"
            && matches!(
                method,
                "contentEquals(Ljava/lang/CharSequence;)Z"
                    | "contentEquals(Ljava/lang/StringBuffer;)Z"
            )
        {
            return Ok(Some(
                (self.units(arg(0)?)? == self.sequence_units(arg(1)?)?) as u64,
            ));
        }
        if class.starts_with('[') && method == "clone()Ljava/lang/Object;" {
            let Payload::Array(v) = &self.object(arg(0)?)?.payload else {
                return Err("Array clone type".into());
            };
            let values = v.clone();
            return Ok(Some(self.allocate(class, Payload::Array(values))? as u64));
        }
        if sig == "Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;" {
            let units = self.object_units(arg(0)?)?;
            return Ok(Some(self.string_units(units)? as u64));
        }
        if class == "Ljava/lang/Thread;" {
            match method {
                "getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;" =>
                {
                    return Ok(Some(self.default_uncaught as u64));
                }
                "setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V" =>
                {
                    let handler = arg(0)?;
                    if handler != 0 {
                        self.object(handler)?;
                    }
                    self.default_uncaught = handler;
                    return Ok(Some(0));
                }
                "currentThread()Ljava/lang/Thread;" => {
                    self.ensure_main_thread()?;
                    return Ok(Some(self.current_thread as u64));
                }
                "getName()Ljava/lang/String;" => {
                    return Ok(Some(
                        *self
                            .object(arg(0)?)?
                            .fields
                            .get(&(usize::MAX - 50))
                            .ok_or("Uninitialized guest Thread")?,
                    ));
                }
                "setName(Ljava/lang/String;)V" => {
                    let name = arg(1)?;
                    self.units(name)?;
                    self.object_mut(arg(0)?)?
                        .fields
                        .insert(usize::MAX - 50, name as u64);
                    return Ok(Some(0));
                }
                _ => return Ok(None),
            }
        }
        if class == "Ljava/lang/Enum;" {
            let id = arg(0)?;
            if method == "<init>(Ljava/lang/String;I)V" {
                let name = arg(1)?;
                self.units(name)?;
                self.object_mut(id)?.payload = Payload::Enum {
                    name,
                    ordinal: arg(2)?,
                };
                return Ok(Some(0));
            }
            if let Payload::Enum { name, ordinal } = self.object(id)?.payload {
                return Ok(Some(match method {
                    "name()Ljava/lang/String;" | "toString()Ljava/lang/String;" => name as u64,
                    "ordinal()I" => ordinal as u64,
                    "equals(Ljava/lang/Object;)Z" => (id == arg(1)?) as u64,
                    "hashCode()I" => id as u64,
                    "compareTo(Ljava/lang/Enum;)I" | "compareTo(Ljava/lang/Object;)I" => {
                        let other = arg(1)?;
                        let Payload::Enum {
                            ordinal: second, ..
                        } = self.object(other)?.payload
                        else {
                            return Err(fault(
                                "Ljava/lang/ClassCastException;",
                                "enum comparison type",
                            ));
                        };
                        if self.object(id)?.class != self.object(other)?.class {
                            return Err(fault(
                                "Ljava/lang/ClassCastException;",
                                "different enum declarations",
                            ));
                        }
                        ordinal.wrapping_sub(second) as u64
                    }
                    _ => return Ok(None),
                }));
            }
        }
        if matches!(
            class,
            "Ljava/lang/StringBuilder;" | "Ljava/lang/StringBuffer;"
        ) {
            let id = arg(0)?;
            let Payload::Builder(v) = &self.object(id)?.payload else {
                return Err("Expected string builder".into());
            };
            let mut text = v.clone();
            if method.starts_with("append(") {
                let descriptor = method.split_once(')').ok_or("Builder descriptor")?.0;
                let units = match descriptor {
                    "append(Ljava/lang/String;"
                    | "append(Ljava/lang/CharSequence;"
                    | "append(Ljava/lang/CharSequence;II" => {
                        let sequence = if arg(1)? == 0 {
                            "null".encode_utf16().collect()
                        } else {
                            self.sequence_units(arg(1)?)?
                        };
                        if descriptor.ends_with(";II") {
                            sequence
                                .get(arg(2)? as usize..arg(3)? as usize)
                                .ok_or_else(|| {
                                    fault(
                                        "Ljava/lang/IndexOutOfBoundsException;",
                                        "Builder sequence range",
                                    )
                                })?
                                .to_vec()
                        } else {
                            sequence
                        }
                    }
                    "append(Ljava/lang/Object;" => self.object_units(arg(1)?)?,
                    "append(C" => vec![arg(1)? as u16],
                    "append(Z" => (arg(1)? != 0).to_string().encode_utf16().collect(),
                    "append(I" => (arg(1)? as i32).to_string().encode_utf16().collect(),
                    "append(J" => ((arg(1)? as u64 | ((arg(2)? as u64) << 32)) as i64)
                        .to_string()
                        .encode_utf16()
                        .collect(),
                    "append(D" => decimal_parse::display(f64::from_bits(wide(a, 1)?))
                        .encode_utf16()
                        .collect(),
                    "append([C" | "append([CII" => {
                        let object = self.object(arg(1)?)?;
                        if object.class != "[C" {
                            return Err("Builder char array type".into());
                        }
                        let Payload::Array(v) = &object.payload else {
                            unreachable!()
                        };
                        let start = if a.len() > 2 { arg(2)? as usize } else { 0 };
                        let count = if a.len() > 3 {
                            arg(3)? as usize
                        } else {
                            v.len()
                        };
                        v.get(start..start.checked_add(count).ok_or("Builder array range")?)
                            .ok_or_else(|| {
                                fault(
                                    "Ljava/lang/IndexOutOfBoundsException;",
                                    "Builder char array range",
                                )
                            })?
                            .iter()
                            .map(|v| *v as u16)
                            .collect()
                    }
                    _ => return Ok(None),
                };
                if text.len() + units.len() > 16384 {
                    return Err("StringBuilder quota".into());
                }
                text.extend(units);
                self.object_mut(id)?.payload = Payload::Builder(text);
                return Ok(Some(id as u64));
            }
            let result = match method {
                "<init>()V" => {
                    text.clear();
                    0
                }
                "<init>(I)V" => {
                    if (arg(1)? as i32) < 0 {
                        return Err(fault(
                            "Ljava/lang/NegativeArraySizeException;",
                            "negative builder capacity",
                        ));
                    }
                    text.clear();
                    0
                }
                "<init>(Ljava/lang/String;)V" | "<init>(Ljava/lang/CharSequence;)V" => {
                    text = self.sequence_units(arg(1)?)?;
                    0
                }
                "toString()Ljava/lang/String;" => return Ok(Some(self.string_units(text)? as u64)),
                "length()I" => return Ok(Some(text.len() as u64)),
                "charAt(I)C" => {
                    return Ok(Some(*text.get(arg(1)? as usize).ok_or_else(|| {
                        fault(
                            "Ljava/lang/StringIndexOutOfBoundsException;",
                            "Builder charAt",
                        )
                    })? as u64));
                }
                "setLength(I)V" => {
                    let n = arg(1)? as usize;
                    if n > 16384 {
                        return Err("Builder length quota".into());
                    }
                    text.resize(n, 0);
                    0
                }
                "setCharAt(IC)V" => {
                    *text.get_mut(arg(1)? as usize).ok_or_else(|| {
                        fault(
                            "Ljava/lang/StringIndexOutOfBoundsException;",
                            "Builder setCharAt",
                        )
                    })? = arg(2)? as u16;
                    0
                }
                _ => return Ok(None),
            };
            self.object_mut(id)?.payload = Payload::Builder(text);
            return Ok(Some(result));
        }
        if class == "Ljava/lang/Object;" && method == "toString()Ljava/lang/String;" {
            let units = self.object_units(arg(0)?)?;
            return Ok(Some(self.string_units(units)? as u64));
        }
        Ok(None)
    }
}
