import java.util.*;
/** Independent stock Java8 outputs/errors for the selected UTF16 conversions. */
public final class FormatterVectors {
 static int count;
 static String hex(String s){StringBuilder out=new StringBuilder();for(int i=0;i<s.length();i++){String h=Integer.toHexString(s.charAt(i));for(int n=h.length();n<4;n++)out.append('0');out.append(h);}return out.toString();}
 static String argument(Object value){
  if(value==null)return "{\"type\":\"N\"}";
  String type=value instanceof String?"T":value instanceof Character?"C":value instanceof Boolean?"Z":value instanceof Byte?"B":value instanceof Short?"S":value instanceof Integer?"I":"J";
  String body=value instanceof String?hex((String)value):value instanceof Character?Integer.toString((Character)value):value.toString();
  return "{\"type\":\""+type+"\",\"value\":\""+body+"\"}";
 }
 static void emit(String pattern,Object[] args){
  if(count++>0)System.out.print(',');System.out.print("{\"format\":\""+hex(pattern)+"\",\"args\":");
  if(args==null)System.out.print("null");else{System.out.print('[');for(int i=0;i<args.length;i++){if(i>0)System.out.print(',');System.out.print(argument(args[i]));}System.out.print(']');}
  try{System.out.print(",\"out\":\""+hex(String.format(pattern,args))+"\"");}catch(Exception error){System.out.print(",\"error\":\""+error.getClass().getSimpleName()+"\"");}System.out.print('}');
 }
 public static void main(String[] ignored){
  Locale.setDefault(Locale.US);
  Object[] values={null,false,true,(byte)-128,(byte)-1,(byte)0,(byte)127,(short)-32768,(short)-1,(short)32767,Integer.MIN_VALUE,-1,0,42,Integer.MAX_VALUE,0xd800,0x1f600,0x110000,Long.MIN_VALUE,-1L,0L,0x100000001L,Long.MAX_VALUE,'a','ß','\ud800','\0',"","plain","ßx","\u043a\u0438\u0457\u0432\ud83d\ude00","\ud801\udc28x","\ud800x","\0\n\\\""};
  String[] conversions={"s","S","b","B","h","H","c","C","d","o","x","X"};
  String[] modifiers={"","12","-12",".1","12.3","#","012",",+12","(12","+ 12","-012","<"};
  System.out.print("{\"profile\":\"stock Java8 en-US\",\"cases\":[");
  for(Object value:values)for(String conversion:conversions)for(String modifier:modifiers)emit("a%"+modifier+conversion+"z",new Object[]{value});
  Random random=new Random(0x4b59564558L);String[] flags={"","-","#","+"," ","0",",","(","--","-0","+ ","#0","#,","-#","0(","(,"};
  for(int i=0;i<2048;i++){String f=flags[random.nextInt(flags.length)],w=new String[]{"","1","7","20"}[random.nextInt(4)],p=new String[]{"",".0",".1",".3"}[random.nextInt(4)];emit("%"+f+w+p+conversions[random.nextInt(conversions.length)],new Object[]{values[random.nextInt(values.length)]});}
  for(String pattern:new String[]{"%","%.s","%..s","%1$s%q","%$s","%--12s","%-0s","%01$s","%0$s","%1$<s","%2147483648$s","%1$s %99999999999999999999999$s","%1$s %0$s","%5n","%-n","%<n","%2$n","%5%","%-5%","%-%","%.2%","%0%","%1$%","%<%","%s%n%%/%<s","%2$s/%s/%s/%s","%2$s/%s/%<s/%1$h/%s"})emit(pattern,new Object[]{"one","ßx","three"});
  for(String pattern:new String[]{"%s/%b/%h/%c/%d/%o/%x","%04d/%S/%3.1c","%2$s/%s/%<s","%s","%d"}){emit(pattern,null);emit(pattern,new Object[0]);}
  System.out.println("]}");System.err.println("Stock Java8 Formatter vectors: "+count);
 }
}
