//! Intent launch metadata and typed SharedPreferences. No fabricated app screens.
use super::*;
use crate::preferences::{Key, Name, Value};
#[derive(Clone, Default)]
pub(super) struct Intent {
    pub action: u32,
    pub data: u32,
    pub component: u32,
    pub package: u32,
    pub extras: u32,
    pub flags: u32,
    pub categories: Vec<u32>,
}
#[derive(Clone)]
pub(super) struct Editor {
    name: Name,
    changes: BTreeMap<Key, Option<Value>>,
    clear: bool,
}
impl Editor {
    pub fn bytes(&self) -> usize {
        self.name.units.len() * 2
            + self
                .changes
                .iter()
                .map(|(k, v)| {
                    64 + k.as_ref().map_or(0, |k| k.len() * 2) + v.as_ref().map_or(0, Value::bytes)
                })
                .sum::<usize>()
    }
}
pub(super) fn boxed_kind(class: &str) -> Option<char> {
    Some(match class {
        "Ljava/lang/Boolean;" => 'Z',
        "Ljava/lang/Byte;" => 'B',
        "Ljava/lang/Short;" => 'S',
        "Ljava/lang/Character;" => 'C',
        "Ljava/lang/Integer;" => 'I',
        "Ljava/lang/Long;" => 'J',
        "Ljava/lang/Float;" => 'F',
        "Ljava/lang/Double;" => 'D',
        _ => return None,
    })
}
fn boxed_class(kind: char) -> &'static str {
    match kind {
        'Z' => "Ljava/lang/Boolean;",
        'B' => "Ljava/lang/Byte;",
        'S' => "Ljava/lang/Short;",
        'C' => "Ljava/lang/Character;",
        'I' => "Ljava/lang/Integer;",
        'J' => "Ljava/lang/Long;",
        'F' => "Ljava/lang/Float;",
        _ => "Ljava/lang/Double;",
    }
}
pub(super) fn payload(class: &str) -> Option<Payload> {
    Some(match class {
        "Landroid/content/Intent;" => Payload::Intent(Intent::default()),
        "Landroid/content/ComponentName;" => Payload::Component {
            package: 0,
            name: 0,
        },
        _ => Payload::Boxed {
            kind: boxed_kind(class)?,
            bits: 0,
        },
    })
}
fn normalized(kind: char, bits: u64) -> u64 {
    match kind {
        'Z' => (bits != 0) as u64,
        'B' => bits as i8 as i32 as u32 as u64,
        'S' => bits as i16 as i32 as u32 as u64,
        'C' => bits as u16 as u64,
        'J' | 'D' => bits,
        _ => bits as u32 as u64,
    }
}
pub(super) fn boxes_equal(a: char, x: u64, b: char, y: u64) -> bool {
    a == b
        && match a {
            'F' => {
                (x == y) || (f32::from_bits(x as u32).is_nan() && f32::from_bits(y as u32).is_nan())
            }
            'D' => (x == y) || (f64::from_bits(x).is_nan() && f64::from_bits(y).is_nan()),
            _ => x == y,
        }
}
impl Runtime {
    pub(super) fn box_value(&mut self, kind: char, bits: u64) -> Result<u32> {
        let bits = normalized(kind, bits);
        let cached = match kind {
            'Z' | 'B' => true,
            'I' | 'S' => (-128..=127).contains(&(bits as u32 as i32)),
            'J' => (-128..=127).contains(&(bits as i64)),
            'C' => bits <= 127,
            _ => false,
        };
        if cached && let Some(id) = self.boxed_cache.get(&(kind, bits)) {
            return Ok(*id);
        }
        let id = self.allocate(boxed_class(kind), Payload::Boxed { kind, bits })?;
        if cached {
            self.boxed_cache.insert((kind, bits), id);
        }
        Ok(id)
    }
    fn preference_key(&self, id: u32) -> Result<Key> {
        if id == 0 {
            Ok(None)
        } else {
            let key = self.units(id)?;
            if key.len() > 1024 {
                return Err("Preference key quota".into());
            }
            Ok(Some(key))
        }
    }
    fn preference_value(&mut self, value: Value) -> Result<u64> {
        Ok(match value {
            Value::Scalar { kind, bits } => self.box_value(kind, bits)? as u64,
            Value::String(s) => self.string_units(s)? as u64,
            Value::Strings(values) => {
                let mut refs = Vec::new();
                for s in values {
                    refs.push(self.string_units(s)?);
                }
                self.allocate("Ljava/util/HashSet;", Payload::Set(refs))? as u64
            }
        })
    }
    fn default_intent(&mut self, activity: u32) -> Result<u32> {
        const FIELD: usize = usize::MAX - 20;
        if let Some(id) = self.object(activity)?.fields.get(&FIELD) {
            return Ok(*id as u32);
        }
        let package = self.string(&self.package_name.clone())?;
        let name = self.string(&self.launcher_name.clone())?;
        let component = self.allocate(
            "Landroid/content/ComponentName;",
            Payload::Component { package, name },
        )?;
        let action = self.string("android.intent.action.MAIN")?;
        let category = self.string("android.intent.category.LAUNCHER")?;
        let intent = self.allocate(
            "Landroid/content/Intent;",
            Payload::Intent(Intent {
                action,
                component,
                categories: vec![category],
                flags: 0x10200000,
                ..Intent::default()
            }),
        )?;
        self.object_mut(activity)?
            .fields
            .insert(FIELD, intent as u64);
        self.launch_intent = intent;
        Ok(intent)
    }
    fn notify_preferences(&mut self, name: &Name, keys: Vec<Key>) -> Result<()> {
        let listeners = self
            .preference_listeners
            .get(name)
            .cloned()
            .unwrap_or_default();
        let preferences = self.preference_handles.get(name).copied().unwrap_or(0);
        for listener in listeners {
            let Some(object) = self.heap.get(&listener) else {
                continue;
            };
            let class = object.class.clone();
            let method = self
                .dex
                .find(
                    &class,
                    "onSharedPreferenceChanged",
                    "(Landroid/content/SharedPreferences;Ljava/lang/String;)V",
                )
                .ok_or("Unsupported inherited SharedPreferences listener")?;
            for key in &keys {
                let key = if let Some(key) = key {
                    self.string_units(key.clone())?
                } else {
                    0
                };
                self.invoke(method, &[listener, preferences, key], true)?;
            }
        }
        Ok(())
    }
    pub(super) fn android_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Android API signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Android API argument count");
        if let Some(kind) = boxed_kind(class) {
            if method.starts_with("valueOf(") && !method.contains("Ljava/lang/String;") {
                let bits = arg(0)? as u64
                    | if matches!(kind, 'J' | 'D') {
                        (arg(1)? as u64) << 32
                    } else {
                        0
                    };
                return Ok(Some(self.box_value(kind, bits)? as u64));
            }
            let id = arg(0)?;
            if let Payload::Boxed { kind, bits } = self.object(id)?.payload {
                let value = match kind {
                    'F' => f32::from_bits(bits as u32) as f64,
                    'D' => f64::from_bits(bits),
                    'J' => bits as i64 as f64,
                    _ => bits as u32 as i32 as f64,
                };
                let result = match method {
                    "<init>(I)V" | "<init>(J)V" | "<init>(F)V" | "<init>(D)V" | "<init>(Z)V"
                    | "<init>(S)V" | "<init>(B)V" | "<init>(C)V" => {
                        let value = arg(1)? as u64
                            | if matches!(kind, 'J' | 'D') {
                                (arg(2)? as u64) << 32
                            } else {
                                0
                            };
                        self.object_mut(id)?.payload = Payload::Boxed {
                            kind,
                            bits: normalized(kind, value),
                        };
                        0
                    }
                    "intValue()I" => {
                        if kind == 'J' {
                            bits as u32 as u64
                        } else {
                            value as i32 as u32 as u64
                        }
                    }
                    "longValue()J" => {
                        if kind == 'J' {
                            bits
                        } else {
                            value as i64 as u64
                        }
                    }
                    "shortValue()S" => {
                        if matches!(kind, 'F' | 'D') {
                            value as i32 as i16 as i32 as u32 as u64
                        } else {
                            bits as i16 as i32 as u32 as u64
                        }
                    }
                    "byteValue()B" => {
                        if matches!(kind, 'F' | 'D') {
                            value as i32 as i8 as i32 as u32 as u64
                        } else {
                            bits as i8 as i32 as u32 as u64
                        }
                    }
                    "charValue()C" => bits as u16 as u64,
                    "booleanValue()Z" => (bits != 0) as u64,
                    "floatValue()F" => {
                        if kind == 'J' {
                            (bits as i64 as f32).to_bits() as u64
                        } else {
                            (value as f32).to_bits() as u64
                        }
                    }
                    "doubleValue()D" => value.to_bits(),
                    "equals(Ljava/lang/Object;)Z" => {
                        let other = arg(1)?;
                        if other == 0 {
                            0
                        } else if let Payload::Boxed { kind: k, bits: b } =
                            self.object(other)?.payload
                        {
                            boxes_equal(kind, bits, k, b) as u64
                        } else {
                            0
                        }
                    }
                    "hashCode()I" => {
                        let bits = if kind == 'F' && f32::from_bits(bits as u32).is_nan() {
                            0x7fc00000
                        } else if kind == 'D' && f64::from_bits(bits).is_nan() {
                            0x7ff8000000000000
                        } else {
                            bits
                        };
                        match kind {
                            'Z' => {
                                if bits == 0 {
                                    1237
                                } else {
                                    1231
                                }
                            }
                            'J' | 'D' => (bits as u32 ^ (bits >> 32) as u32) as u64,
                            _ => bits as u32 as u64,
                        }
                    }
                    "toString()Ljava/lang/String;" => {
                        let s = match kind {
                            'Z' => (bits != 0).to_string(),
                            'C' => String::from_utf16_lossy(&[bits as u16]),
                            'J' => (bits as i64).to_string(),
                            'F' => f32::from_bits(bits as u32).to_string(),
                            'D' => decimal_parse::display(f64::from_bits(bits)),
                            _ => (bits as u32 as i32).to_string(),
                        };
                        self.string(&s)? as u64
                    }
                    _ => return Ok(None),
                };
                return Ok(Some(result));
            }
        }
        if !class.starts_with("Landroid/") {
            return Ok(None);
        }
        let Some(&id) = a.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        let actual_class = object.class.clone();
        if self.subclass(&actual_class, "Landroid/content/Context;")?
            && method
                == "getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;"
        {
            if arg(2)? & 3 != 0 {
                return Err(fault(
                    "Ljava/lang/SecurityException;",
                    "world-readable/writable preferences are unavailable",
                ));
            }
            let units = if arg(1)? == 0 {
                "null".encode_utf16().collect()
            } else {
                self.units(arg(1)?)?
            };
            if units.len() > 1024 {
                return Err("Preference name quota".into());
            }
            let name = Name {
                units,
                device_protected: self.context_device_storage(id)?,
            };
            if let Some(id) = self.preference_handles.get(&name) {
                return Ok(Some(*id as u64));
            }
            if self.preferences.groups.len() >= 128 && !self.preferences.groups.contains_key(&name)
            {
                return Err("Preference group quota".into());
            }
            let handle = self.allocate(
                "Landroid/app/SharedPreferencesImpl;",
                Payload::Preferences(name.clone()),
            )?;
            self.preferences.groups.entry(name.clone()).or_default();
            self.preference_handles.insert(name, handle);
            return Ok(Some(handle as u64));
        }
        if self.subclass(&actual_class, "Landroid/app/Activity;")? {
            match method {
                "getIntent()Landroid/content/Intent;" => {
                    return Ok(Some(self.default_intent(id)? as u64));
                }
                "setIntent(Landroid/content/Intent;)V" => {
                    let intent = arg(1)?;
                    if intent != 0 && !matches!(self.object(intent)?.payload, Payload::Intent(_)) {
                        return Err(fault("Ljava/lang/IllegalArgumentException;", "Intent type"));
                    }
                    self.object_mut(id)?
                        .fields
                        .insert(usize::MAX - 20, intent as u64);
                    self.launch_intent = intent;
                    return Ok(Some(0));
                }
                _ => {}
            }
        }
        if let Payload::Preferences(name) = &self.object(id)?.payload {
            let name = name.clone();
            match method {
                "edit()Landroid/content/SharedPreferences$Editor;" => {
                    return Ok(Some(self.allocate(
                        "Landroid/app/SharedPreferencesImpl$EditorImpl;",
                        Payload::PreferenceEditor(Editor {
                            name,
                            changes: BTreeMap::new(),
                            clear: false,
                        }),
                    )? as u64));
                }
                "getAll()Ljava/util/Map;" => {
                    let values = self
                        .preferences
                        .groups
                        .get(&name)
                        .cloned()
                        .unwrap_or_default();
                    let mut entries = Vec::new();
                    for (key, value) in values {
                        let key = if let Some(s) = key {
                            self.string_units(s)?
                        } else {
                            0
                        };
                        let value = self.preference_value(value)? as u32;
                        entries.push((key, value));
                    }
                    return Ok(Some(self.new_hash_map(entries)? as u64));
                }
                "registerOnSharedPreferenceChangeListener(Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;)V" =>
                {
                    let listener = arg(1)?;
                    if listener != 0 {
                        self.object(listener)?;
                        self.preference_listeners
                            .entry(name)
                            .or_default()
                            .insert(listener);
                    }
                    return Ok(Some(0));
                }
                "unregisterOnSharedPreferenceChangeListener(Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;)V" =>
                {
                    if let Some(v) = self.preference_listeners.get_mut(&name) {
                        v.remove(&arg(1)?);
                    }
                    return Ok(Some(0));
                }
                _ => {}
            }
            let expected = match method {
                "contains(Ljava/lang/String;)Z" => '?',
                "getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;" => 'S',
                "getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;" => 'T',
                "getInt(Ljava/lang/String;I)I" => 'I',
                "getLong(Ljava/lang/String;J)J" => 'J',
                "getBoolean(Ljava/lang/String;Z)Z" => 'Z',
                "getFloat(Ljava/lang/String;F)F" => 'F',
                _ => return Ok(None),
            };
            let key = self.preference_key(arg(1)?)?;
            let value = self
                .preferences
                .groups
                .get(&name)
                .and_then(|g| g.get(&key))
                .cloned();
            if method == "contains(Ljava/lang/String;)Z" {
                return Ok(Some(value.is_some() as u64));
            }
            let fallback = arg(2)? as u64
                | if expected == 'J' {
                    (arg(3)? as u64) << 32
                } else {
                    0
                };
            return Ok(Some(if let Some(value) = value {
                match value {
                    Value::String(s) if expected == 'S' => self.string_units(s)? as u64,
                    Value::Strings(s) if expected == 'T' => {
                        self.preference_value(Value::Strings(s))?
                    }
                    Value::Scalar { kind, bits } if kind == expected => bits,
                    _ => {
                        return Err(fault(
                            "Ljava/lang/ClassCastException;",
                            "SharedPreferences value type",
                        ));
                    }
                }
            } else {
                fallback
            }));
        }
        if let Payload::PreferenceEditor(editor) = &self.object(id)?.payload {
            let mut editor = editor.clone();
            let result = match method {
                "clear()Landroid/content/SharedPreferences$Editor;" => {
                    editor.clear = true;
                    id as u64
                }
                "remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;" => {
                    editor.changes.insert(self.preference_key(arg(1)?)?, None);
                    id as u64
                }
                "commit()Z" | "apply()V" => {
                    let mut values = self
                        .preferences
                        .groups
                        .get(&editor.name)
                        .cloned()
                        .unwrap_or_default();
                    if editor.clear {
                        values.clear();
                    }
                    let mut changed = Vec::new();
                    for (key, value) in &editor.changes {
                        if values.get(key) != value.as_ref() {
                            changed.push(key.clone());
                        }
                        if let Some(value) = value {
                            values.insert(key.clone(), value.clone());
                        } else {
                            values.remove(key);
                        }
                    }
                    if values.len() > 1024 {
                        return Err("Preference entry quota".into());
                    }
                    self.preferences.groups.insert(editor.name.clone(), values);
                    let saved = match self.preferences.save() {
                        Ok(value) => value,
                        Err(error) => {
                            if self.logs.len() == 32 {
                                self.logs.remove(0);
                            }
                            self.logs
                                .push(format!("SharedPreferences persistence failed: {error}"));
                            false
                        }
                    };
                    let name = editor.name.clone();
                    editor.changes.clear();
                    editor.clear = false;
                    self.object_mut(id)?.payload = Payload::PreferenceEditor(editor);
                    self.notify_preferences(&name, changed)?;
                    return Ok(Some(if method == "commit()Z" {
                        saved as u64
                    } else {
                        0
                    }));
                }
                _ => {
                    let kind = match method {
                        "putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;" => {
                            'S'
                        }
                        "putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;" => {
                            'T'
                        }
                        "putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;" => {
                            'I'
                        }
                        "putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;" => {
                            'J'
                        }
                        "putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;" => {
                            'Z'
                        }
                        "putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;" => {
                            'F'
                        }
                        _ => return Ok(None),
                    };
                    let value = match kind {
                        'S' => {
                            if arg(2)? == 0 {
                                None
                            } else {
                                Some(Value::String(self.units(arg(2)?)?))
                            }
                        }
                        'T' => {
                            if arg(2)? == 0 {
                                None
                            } else {
                                let refs = self.collection_values(arg(2)?)?;
                                let mut strings = Vec::new();
                                for id in refs {
                                    strings.push(self.units(id)?);
                                }
                                strings.sort();
                                strings.dedup();
                                Some(Value::Strings(strings))
                            }
                        }
                        _ => Some(Value::Scalar {
                            kind,
                            bits: arg(2)? as u64
                                | if kind == 'J' {
                                    (arg(3)? as u64) << 32
                                } else {
                                    0
                                },
                        }),
                    };
                    editor.changes.insert(self.preference_key(arg(1)?)?, value);
                    id as u64
                }
            };
            if editor.changes.len() > 1024 {
                return Err("Preference editor quota".into());
            }
            self.object_mut(id)?.payload = Payload::PreferenceEditor(editor);
            return Ok(Some(result));
        }
        if let Payload::Component { package, name } = self.object(id)?.payload {
            return Ok(Some(match method {
                "<init>(Ljava/lang/String;Ljava/lang/String;)V"
                | "<init>(Landroid/content/Context;Ljava/lang/String;)V"
                | "<init>(Landroid/content/Context;Ljava/lang/Class;)V" => {
                    let package = if method.contains("Landroid/content/Context;") {
                        self.object(arg(1)?)?;
                        self.string(&self.package_name.clone())?
                    } else {
                        self.units(arg(1)?)?;
                        arg(1)?
                    };
                    let name = if method.contains("Ljava/lang/Class;") {
                        self.platform_api(
                            "Ljava/lang/Class;->getName()Ljava/lang/String;",
                            &[arg(2)?],
                        )?
                        .ok_or("Component Class name")? as u32
                    } else {
                        arg(2)?
                    };
                    self.units(name)?;
                    self.object_mut(id)?.payload = Payload::Component { package, name };
                    0
                }
                "getPackageName()Ljava/lang/String;" => package as u64,
                "getClassName()Ljava/lang/String;" => name as u64,
                "flattenToString()Ljava/lang/String;" | "toString()Ljava/lang/String;" => {
                    let text = format!("{}/{}", self.text(package)?, self.text(name)?);
                    self.string(&text)? as u64
                }
                _ => return Ok(None),
            }));
        }
        let Payload::Intent(intent) = &self.object(id)?.payload else {
            return Ok(None);
        };
        let mut intent = intent.clone();
        let result = match method {
            "<init>()V" => 0,
            "<init>(Ljava/lang/String;)V" => {
                if arg(1)? != 0 {
                    self.units(arg(1)?)?;
                }
                intent.action = arg(1)?;
                0
            }
            "<init>(Landroid/content/Intent;)V" => {
                let Payload::Intent(other) = &self.object(arg(1)?)?.payload else {
                    return Err("Intent copy source".into());
                };
                intent = other.clone();
                if intent.extras != 0 {
                    let Payload::Bundle(values) = &self.object(intent.extras)?.payload else {
                        return Err("Intent extras type".into());
                    };
                    let values = values.clone();
                    intent.extras =
                        self.allocate("Landroid/os/Bundle;", Payload::Bundle(values))?;
                }
                0
            }
            "getAction()Ljava/lang/String;" => intent.action as u64,
            "getPackage()Ljava/lang/String;" => intent.package as u64,
            "getComponent()Landroid/content/ComponentName;" => intent.component as u64,
            "getData()Landroid/net/Uri;" => intent.data as u64,
            "getFlags()I" => intent.flags as u64,
            "setAction(Ljava/lang/String;)Landroid/content/Intent;" => {
                if arg(1)? != 0 {
                    self.units(arg(1)?)?;
                }
                intent.action = arg(1)?;
                id as u64
            }
            "setPackage(Ljava/lang/String;)Landroid/content/Intent;" => {
                if arg(1)? != 0 {
                    self.units(arg(1)?)?;
                }
                intent.package = arg(1)?;
                id as u64
            }
            "setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;" => {
                if arg(1)? != 0
                    && !matches!(self.object(arg(1)?)?.payload, Payload::Component { .. })
                {
                    return Err("Intent component type".into());
                }
                intent.component = arg(1)?;
                id as u64
            }
            "setFlags(I)Landroid/content/Intent;" => {
                intent.flags = arg(1)?;
                id as u64
            }
            "addFlags(I)Landroid/content/Intent;" => {
                intent.flags |= arg(1)?;
                id as u64
            }
            "removeFlags(I)V" => {
                intent.flags &= !arg(1)?;
                0
            }
            "addCategory(Ljava/lang/String;)Landroid/content/Intent;"
            | "hasCategory(Ljava/lang/String;)Z"
            | "removeCategory(Ljava/lang/String;)V" => {
                let key = arg(1)?;
                self.units(key)?;
                let mut at = None;
                for (i, old) in intent.categories.iter().enumerate() {
                    if self.value_equal(key, *old)? {
                        at = Some(i);
                        break;
                    }
                }
                if method.starts_with("add") {
                    if at.is_none() {
                        if intent.categories.len() >= 128 {
                            return Err("Intent category quota".into());
                        }
                        intent.categories.push(key);
                    }
                    id as u64
                } else if method.starts_with("has") {
                    at.is_some() as u64
                } else {
                    if let Some(i) = at {
                        intent.categories.remove(i);
                    }
                    0
                }
            }
            "getCategories()Ljava/util/Set;" => {
                if intent.categories.is_empty() {
                    0
                } else {
                    self.allocate(
                        "Ljava/util/HashSet;",
                        Payload::Set(intent.categories.clone()),
                    )? as u64
                }
            }
            "getExtras()Landroid/os/Bundle;" => {
                if intent.extras == 0 {
                    0
                } else {
                    let Payload::Bundle(values) = &self.object(intent.extras)?.payload else {
                        return Err("Intent extras type".into());
                    };
                    let values = values.clone();
                    self.allocate("Landroid/os/Bundle;", Payload::Bundle(values))? as u64
                }
            }
            "hasExtra(Ljava/lang/String;)Z" | "removeExtra(Ljava/lang/String;)V" => {
                if intent.extras == 0 {
                    0
                } else {
                    let bundle_method = if method.starts_with("has") {
                        "containsKey(Ljava/lang/String;)Z"
                    } else {
                        "remove(Ljava/lang/String;)V"
                    };
                    self.object_api(
                        &format!("Landroid/os/Bundle;->{bundle_method}"),
                        &[intent.extras, arg(1)?],
                    )?
                    .ok_or("Intent Bundle operation")?
                }
            }
            _ => {
                let (bundle_method, writing, wide) = match method {
                    "getStringExtra(Ljava/lang/String;)Ljava/lang/String;" => (
                        "getString(Ljava/lang/String;)Ljava/lang/String;",
                        false,
                        false,
                    ),
                    "getIntExtra(Ljava/lang/String;I)I" => {
                        ("getInt(Ljava/lang/String;I)I", false, false)
                    }
                    "getLongExtra(Ljava/lang/String;J)J" => {
                        ("getLong(Ljava/lang/String;J)J", false, true)
                    }
                    "getBooleanExtra(Ljava/lang/String;Z)Z" => {
                        ("getBoolean(Ljava/lang/String;Z)Z", false, false)
                    }
                    "getFloatExtra(Ljava/lang/String;F)F" => {
                        ("getFloat(Ljava/lang/String;F)F", false, false)
                    }
                    "getDoubleExtra(Ljava/lang/String;D)D" => {
                        ("getDouble(Ljava/lang/String;D)D", false, true)
                    }
                    "getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;" => (
                        "getBundle(Ljava/lang/String;)Landroid/os/Bundle;",
                        false,
                        false,
                    ),
                    "putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;" => (
                        "putString(Ljava/lang/String;Ljava/lang/String;)V",
                        true,
                        false,
                    ),
                    "putExtra(Ljava/lang/String;I)Landroid/content/Intent;" => {
                        ("putInt(Ljava/lang/String;I)V", true, false)
                    }
                    "putExtra(Ljava/lang/String;J)Landroid/content/Intent;" => {
                        ("putLong(Ljava/lang/String;J)V", true, true)
                    }
                    "putExtra(Ljava/lang/String;Z)Landroid/content/Intent;" => {
                        ("putBoolean(Ljava/lang/String;Z)V", true, false)
                    }
                    "putExtra(Ljava/lang/String;F)Landroid/content/Intent;" => {
                        ("putFloat(Ljava/lang/String;F)V", true, false)
                    }
                    "putExtra(Ljava/lang/String;D)Landroid/content/Intent;" => {
                        ("putDouble(Ljava/lang/String;D)V", true, true)
                    }
                    "putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;" => (
                        "putBundle(Ljava/lang/String;Landroid/os/Bundle;)V",
                        true,
                        false,
                    ),
                    _ => return Ok(None),
                };
                if writing && intent.extras == 0 {
                    intent.extras =
                        self.allocate("Landroid/os/Bundle;", Payload::Bundle(BTreeMap::new()))?;
                }
                if intent.extras == 0 {
                    a.get(2).copied().unwrap_or(0) as u64
                        | if wide {
                            (a.get(3).copied().unwrap_or(0) as u64) << 32
                        } else {
                            0
                        }
                } else {
                    let mut args = a.to_vec();
                    args[0] = intent.extras;
                    let value = self
                        .object_api(&format!("Landroid/os/Bundle;->{bundle_method}"), &args)?
                        .ok_or("Intent Bundle operation")?;
                    if writing { id as u64 } else { value }
                }
            }
        };
        self.object_mut(id)?.payload = Payload::Intent(intent);
        Ok(Some(result))
    }
}
