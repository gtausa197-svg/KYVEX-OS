//! Actual ordered main-thread callbacks; canceled messages release their references.
use super::*;
impl Runtime {
    fn message_fields(&self, id: u32) -> Result<&BTreeMap<String, u64>> {
        let object = self.object(id)?;
        if object.class != "Landroid/os/Message;" {
            return Err("Expected Android Message".into());
        }
        match &object.payload {
            Payload::Record(fields) => Ok(fields),
            _ => Err("Message payload".into()),
        }
    }
    fn message_value(&self, id: u32, name: &str) -> Result<u64> {
        Ok(*self.message_fields(id)?.get(name).unwrap_or(&0))
    }
    pub(super) fn message_set(&mut self, id: u32, name: &str, value: u64) -> Result<()> {
        self.message_fields(id)?;
        let Payload::Record(fields) = &mut self.object_mut(id)?.payload else {
            unreachable!()
        };
        fields.insert(name.into(), value);
        Ok(())
    }
    fn new_message(
        &mut self,
        target: u32,
        what: u32,
        arg1: u32,
        arg2: u32,
        object: u32,
        callback: u32,
    ) -> Result<u32> {
        if target != 0 {
            self.object(target)?;
        }
        if object != 0 {
            self.object(object)?;
        }
        if callback != 0 {
            self.object(callback)?;
        }
        let fields = [
            ("target", target as u64),
            ("what", what as u64),
            ("arg1", arg1 as u64),
            ("arg2", arg2 as u64),
            ("obj", object as u64),
            ("callback", callback as u64),
            ("sendingUid", u32::MAX as u64),
        ]
        .into_iter()
        .map(|(k, v)| (k.into(), v))
        .collect();
        self.allocate("Landroid/os/Message;", Payload::Record(fields))
    }
    fn enqueue_message(
        &mut self,
        handler: u32,
        message: u32,
        when: u64,
        front: bool,
    ) -> Result<u64> {
        let Payload::Handler(h) = &self.object(handler)?.payload else {
            return Err("Message target must be Handler".into());
        };
        let asynchronous = h.asynchronous;
        if self.message_value(message, "_in_use")? != 0 {
            return Err(fault(
                "Ljava/lang/IllegalStateException;",
                "Message is already in use",
            ));
        }
        if self.pending_events.len() >= 1024 {
            return Err("Handler event queue quota".into());
        }
        let sequence = self.next_event;
        let when = if front { 0 } else { when };
        self.next_event = self
            .next_event
            .checked_add(1)
            .ok_or("Handler sequence exhausted")?;
        self.message_set(message, "target", handler as u64)?;
        self.message_set(message, "_in_use", 1)?;
        self.message_set(message, "_when", when)?;
        if asynchronous {
            self.message_set(message, "_async", 1)?;
        }
        self.pending_events.push(Pending {
            handler,
            message,
            when,
            sequence,
            front: front || when == 0,
        });
        Ok(1)
    }
    pub(in crate::vm) fn callback_method(
        &mut self,
        object: u32,
        name: &str,
        descriptor: &str,
    ) -> Result<Option<usize>> {
        let mut class = self.object(object)?.class.clone();
        for _ in 0..64 {
            self.ensure_class(&class)?;
            if let Some(index) = self.dex.find(&class, name, descriptor)
                && self.dex.bodies.contains_key(&index)
            {
                return Ok(Some(index));
            }
            let Some(ty) = self.dex.type_id(&class) else {
                return Ok(None);
            };
            let Some(parent) = self.dex.classes.get(&ty).and_then(|c| c.parent) else {
                return Ok(None);
            };
            class = self.dex.ty(parent).into();
        }
        Err("Callback class hierarchy budget".into())
    }
    fn dispatch_message(&mut self, handler: u32, message: u32) -> Result<()> {
        let callback = self.message_value(message, "callback")? as u32;
        if callback != 0 {
            let method = self
                .callback_method(callback, "run", "()V")?
                .ok_or("Runnable has no supported run method")?;
            self.invoke(method, &[callback], true)?;
            return Ok(());
        }
        let Payload::Handler(state) = &self.object(handler)?.payload else {
            return Err("Message target is not initialized".into());
        };
        let receiver = state.callback;
        if receiver != 0 {
            let method = self
                .callback_method(receiver, "handleMessage", "(Landroid/os/Message;)Z")?
                .ok_or("Handler.Callback method is absent")?;
            if self.invoke(method, &[receiver, message], true)? != 0 {
                return Ok(());
            }
        }
        if let Some(method) =
            self.callback_method(handler, "handleMessage", "(Landroid/os/Message;)V")?
        {
            self.invoke(method, &[handler, message], true)?;
        }
        Ok(())
    }
    fn recycle_message(&mut self, id: u32) -> Result<()> {
        self.message_fields(id)?;
        self.object_mut(id)?.payload = Payload::Record(BTreeMap::from([
            ("_in_use".into(), 1),
            ("sendingUid".into(), u32::MAX as u64),
        ]));
        Ok(())
    }
    pub(super) fn pump_handler_events(&mut self, limit: usize) -> Result<()> {
        for _ in 0..limit.min(64) {
            let now = self.uptime_millis();
            let index = self
                .pending_events
                .iter()
                .enumerate()
                .filter(|(_, e)| e.front || e.when <= now)
                .min_by_key(|(_, e)| {
                    (
                        if e.front { 0 } else { 1 },
                        if e.front { 0 } else { e.when },
                        if e.front {
                            u64::MAX - e.sequence
                        } else {
                            e.sequence
                        },
                    )
                })
                .map(|(i, _)| i);
            let Some(index) = index else { break };
            let event = self.pending_events.remove(index);
            if let Some(method) =
                self.callback_method(event.handler, "dispatchMessage", "(Landroid/os/Message;)V")?
            {
                self.invoke(method, &[event.handler, event.message], true)?;
            } else {
                self.dispatch_message(event.handler, event.message)?;
            }
            self.recycle_message(event.message)?;
            self.events += 1;
        }
        Ok(())
    }
    pub(super) fn handler_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Handler signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Handler argument count");
        let wide = |i: usize| -> Result<u64> { Ok(arg(i)? as u64 | ((arg(i + 1)? as u64) << 32)) };
        if class == "Landroid/os/Message;"
            && matches!(
                method,
                "obtain()Landroid/os/Message;"
                    | "obtain(Landroid/os/Message;)Landroid/os/Message;"
                    | "obtain(Landroid/os/Handler;)Landroid/os/Message;"
                    | "obtain(Landroid/os/Handler;Ljava/lang/Runnable;)Landroid/os/Message;"
                    | "obtain(Landroid/os/Handler;I)Landroid/os/Message;"
                    | "obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;"
                    | "obtain(Landroid/os/Handler;III)Landroid/os/Message;"
                    | "obtain(Landroid/os/Handler;IIILjava/lang/Object;)Landroid/os/Message;"
            )
        {
            if method == "obtain(Landroid/os/Message;)Landroid/os/Message;" {
                let mut fields = self.message_fields(arg(0)?)?.clone();
                fields.remove("_in_use");
                fields.remove("_async");
                fields.remove("_when");
                if let Some(data) = fields.get("data").copied().filter(|data| *data != 0) {
                    let Payload::Bundle(bundle) = &self.object(data as u32)?.payload else {
                        return Err("Message data is not a Bundle".into());
                    };
                    let bundle = bundle.clone();
                    fields.insert(
                        "data".into(),
                        self.allocate("Landroid/os/Bundle;", Payload::Bundle(bundle))? as u64,
                    );
                }
                return Ok(Some(self.allocate(class, Payload::Record(fields))? as u64));
            }
            let target = a.first().copied().unwrap_or(0);
            let callback = if method
                == "obtain(Landroid/os/Handler;Ljava/lang/Runnable;)Landroid/os/Message;"
            {
                arg(1)?
            } else {
                0
            };
            let what = if method.starts_with("obtain(Landroid/os/Handler;I") {
                arg(1)?
            } else {
                0
            };
            let args = method.starts_with("obtain(Landroid/os/Handler;III");
            let arg1 = if args { arg(2)? } else { 0 };
            let arg2 = if args { arg(3)? } else { 0 };
            let object = if method.contains("Ljava/lang/Object;") {
                arg(if args { 4 } else { 2 })?
            } else {
                0
            };
            return Ok(Some(
                self.new_message(target, what, arg1, arg2, object, callback)? as u64,
            ));
        }
        if class == "Landroid/os/Handler;"
            && matches!(
                method,
                "createAsync(Landroid/os/Looper;)Landroid/os/Handler;"
                    | "createAsync(Landroid/os/Looper;Landroid/os/Handler$Callback;)Landroid/os/Handler;"
            )
        {
            let looper = arg(0)?;
            if !matches!(self.object(looper)?.payload, Payload::Looper(_)) {
                return Err("Handler Looper type".into());
            }
            let callback = a.get(1).copied().unwrap_or(0);
            if callback != 0 {
                self.object(callback)?;
            }
            return Ok(Some(self.allocate(
                class,
                Payload::Handler(Handler {
                    looper,
                    callback,
                    asynchronous: true,
                    messenger_binder: 0,
                }),
            )? as u64));
        }
        if class == "Landroid/os/Handler;" && method.starts_with("<init>(") {
            let id = arg(0)?;
            self.ensure_main_thread()?;
            let mut looper = if self.current_thread == self.main_thread {
                self.main_looper()?
            } else {
                0
            };
            let mut callback = 0;
            let mut asynchronous = false;
            match method {
                "<init>()V" => {}
                "<init>(Landroid/os/Handler$Callback;)V" => callback = arg(1)?,
                "<init>(Landroid/os/Handler$Callback;Z)V" => {
                    callback = arg(1)?;
                    asynchronous = arg(2)? != 0;
                }
                "<init>(Landroid/os/Looper;)V" => looper = arg(1)?,
                "<init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V" => {
                    looper = arg(1)?;
                    callback = arg(2)?;
                }
                "<init>(Landroid/os/Looper;Landroid/os/Handler$Callback;Z)V" => {
                    looper = arg(1)?;
                    callback = arg(2)?;
                    asynchronous = arg(3)? != 0;
                }
                "<init>(Z)V" => asynchronous = arg(1)? != 0,
                _ => return Ok(None),
            }
            if looper == 0 {
                return Err(fault(
                    "Ljava/lang/RuntimeException;",
                    "Cannot create Handler on a thread without Looper.prepare()",
                ));
            }
            if !matches!(self.object(looper)?.payload, Payload::Looper(_)) {
                return Err("Handler Looper type".into());
            }
            if callback != 0 {
                self.object(callback)?;
            }
            self.object_mut(id)?.payload = Payload::Handler(Handler {
                looper,
                callback,
                asynchronous,
                messenger_binder: 0,
            });
            return Ok(Some(0));
        }
        if class == "Landroid/os/Message;" {
            let id = arg(0)?;
            self.message_fields(id)?;
            return Ok(Some(match method {
                "<init>()V" => 0,
                "getTarget()Landroid/os/Handler;" => self.message_value(id, "target")?,
                "getCallback()Ljava/lang/Runnable;" => self.message_value(id, "callback")?,
                "getWhen()J" => self.message_value(id, "_when")?,
                "setTarget(Landroid/os/Handler;)V" => {
                    let target = arg(1)?;
                    if target != 0 {
                        self.object(target)?;
                    }
                    self.message_set(id, "target", target as u64)?;
                    0
                }
                "isAsynchronous()Z" => self.message_value(id, "_async")?,
                "setAsynchronous(Z)V" => {
                    self.message_set(id, "_async", (arg(1)? != 0) as u64)?;
                    0
                }
                "getData()Landroid/os/Bundle;" => {
                    let mut data = self.message_value(id, "data")?;
                    if data == 0 {
                        data = self
                            .allocate("Landroid/os/Bundle;", Payload::Bundle(BTreeMap::new()))?
                            as u64;
                        self.message_set(id, "data", data)?;
                    }
                    data
                }
                "peekData()Landroid/os/Bundle;" => self.message_value(id, "data")?,
                "setData(Landroid/os/Bundle;)V" => {
                    let data = arg(1)?;
                    if data != 0 && !matches!(self.object(data)?.payload, Payload::Bundle(_)) {
                        return Err("Message Bundle type".into());
                    }
                    self.message_set(id, "data", data as u64)?;
                    0
                }
                "sendToTarget()V" => {
                    let target = self.message_value(id, "target")? as u32;
                    self.enqueue_message(target, id, self.uptime_millis(), false)?;
                    0
                }
                "recycle()V" => {
                    if self.message_value(id, "_in_use")? != 0 {
                        return Err(fault(
                            "Ljava/lang/IllegalStateException;",
                            "Cannot recycle an in-use Message",
                        ));
                    }
                    self.recycle_message(id)?;
                    0
                }
                _ => return Ok(None),
            }));
        }
        let Some(&id) = a.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        let Payload::Handler(state) = &object.payload else {
            return Ok(None);
        };
        let state = state.clone();
        match method {
            "getLooper()Landroid/os/Looper;" => return Ok(Some(state.looper as u64)),
            "handleMessage(Landroid/os/Message;)V" => {
                self.message_fields(arg(1)?)?;
                return Ok(Some(0));
            }
            "dispatchMessage(Landroid/os/Message;)V" => {
                self.dispatch_message(id, arg(1)?)?;
                return Ok(Some(0));
            }
            _ => {}
        }
        if matches!(
            method,
            "obtainMessage()Landroid/os/Message;"
                | "obtainMessage(I)Landroid/os/Message;"
                | "obtainMessage(ILjava/lang/Object;)Landroid/os/Message;"
                | "obtainMessage(III)Landroid/os/Message;"
                | "obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;"
        ) {
            let what = a.get(1).copied().unwrap_or(0);
            let args = method.starts_with("obtainMessage(III");
            let arg1 = if args { arg(2)? } else { 0 };
            let arg2 = if args { arg(3)? } else { 0 };
            let object = if method.contains("Ljava/lang/Object;") {
                arg(if args { 4 } else { 2 })?
            } else {
                0
            };
            return Ok(Some(
                self.new_message(id, what, arg1, arg2, object, 0)? as u64
            ));
        }
        if matches!(
            method,
            "post(Ljava/lang/Runnable;)Z"
                | "postDelayed(Ljava/lang/Runnable;J)Z"
                | "postDelayed(Ljava/lang/Runnable;Ljava/lang/Object;J)Z"
                | "postAtTime(Ljava/lang/Runnable;J)Z"
                | "postAtTime(Ljava/lang/Runnable;Ljava/lang/Object;J)Z"
                | "postAtFrontOfQueue(Ljava/lang/Runnable;)Z"
        ) {
            let callback = arg(1)?;
            self.object(callback)?;
            let token = if method.contains("Ljava/lang/Object;") {
                arg(2)?
            } else {
                0
            };
            let now = self.uptime_millis();
            let time = if method.starts_with("postDelayed") {
                now.saturating_add(
                    (wide(if token != 0 || method.contains("Ljava/lang/Object;") {
                        3
                    } else {
                        2
                    })? as i64)
                        .max(0) as u64,
                )
            } else if method.starts_with("postAtTime") {
                (wide(if method.contains("Ljava/lang/Object;") {
                    3
                } else {
                    2
                })? as i64)
                    .max(0) as u64
            } else {
                now
            };
            let message = self.new_message(id, 0, 0, 0, token, callback)?;
            return Ok(Some(self.enqueue_message(
                id,
                message,
                time,
                method.starts_with("postAtFront"),
            )?));
        }
        if matches!(
            method,
            "sendMessage(Landroid/os/Message;)Z"
                | "sendMessageDelayed(Landroid/os/Message;J)Z"
                | "sendMessageAtTime(Landroid/os/Message;J)Z"
                | "sendMessageAtFrontOfQueue(Landroid/os/Message;)Z"
        ) {
            let message = arg(1)?;
            let now = self.uptime_millis();
            let time = if method.starts_with("sendMessageDelayed") {
                now.saturating_add((wide(2)? as i64).max(0) as u64)
            } else if method.starts_with("sendMessageAtTime") {
                (wide(2)? as i64).max(0) as u64
            } else {
                now
            };
            return Ok(Some(self.enqueue_message(
                id,
                message,
                time,
                method.starts_with("sendMessageAtFront"),
            )?));
        }
        if matches!(
            method,
            "sendEmptyMessage(I)Z" | "sendEmptyMessageDelayed(IJ)Z" | "sendEmptyMessageAtTime(IJ)Z"
        ) {
            let message = self.new_message(id, arg(1)?, 0, 0, 0, 0)?;
            let now = self.uptime_millis();
            let time = if method.starts_with("sendEmptyMessageDelayed") {
                now.saturating_add((wide(2)? as i64).max(0) as u64)
            } else if method.starts_with("sendEmptyMessageAtTime") {
                (wide(2)? as i64).max(0) as u64
            } else {
                now
            };
            return Ok(Some(self.enqueue_message(id, message, time, false)?));
        }
        if matches!(
            method,
            "removeCallbacks(Ljava/lang/Runnable;)V"
                | "removeCallbacks(Ljava/lang/Runnable;Ljava/lang/Object;)V"
                | "removeCallbacksAndMessages(Ljava/lang/Object;)V"
                | "removeMessages(I)V"
                | "removeMessages(ILjava/lang/Object;)V"
                | "hasCallbacks(Ljava/lang/Runnable;)Z"
                | "hasMessages(I)Z"
                | "hasMessages(ILjava/lang/Object;)Z"
        ) {
            let callbacks =
                method.starts_with("removeCallbacks(") || method.starts_with("hasCallbacks(");
            let all = method.starts_with("removeCallbacksAndMessages");
            let token = if all {
                arg(1)?
            } else {
                a.get(2).copied().unwrap_or(0)
            };
            let value = if all { 0 } else { arg(1)? };
            let mut matches = Vec::new();
            for (i, event) in self.pending_events.iter().enumerate() {
                if event.handler != id {
                    continue;
                }
                let fields = self.message_fields(event.message)?;
                let matches_token =
                    token == 0 || fields.get("obj").copied().unwrap_or(0) == token as u64;
                let matches_value = all
                    || if callbacks {
                        fields.get("callback").copied().unwrap_or(0) == value as u64
                    } else {
                        fields.get("what").copied().unwrap_or(0) == value as u64
                    };
                if matches_token && matches_value {
                    matches.push(i);
                }
            }
            if method.starts_with("has") {
                return Ok(Some(!matches.is_empty() as u64));
            }
            for index in matches.into_iter().rev() {
                let event = self.pending_events.remove(index);
                self.recycle_message(event.message)?;
            }
            return Ok(Some(0));
        }
        Ok(None)
    }
}
