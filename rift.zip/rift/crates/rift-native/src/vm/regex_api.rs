use super::*;
use crate::regex::Regex;
use std::rc::Rc;
#[derive(Clone)]
pub(super) struct Matcher {
    pub pattern: u32,
    pub input: u32,
    pub next: usize,
    pub groups: Option<crate::regex::Captures>,
}

enum ReplacementPart {
    Literal(Vec<u16>),
    Group(usize),
}

fn replacement_parts(pattern: &Regex, replacement: &[u16]) -> Result<Vec<ReplacementPart>> {
    let mut parts = Vec::new();
    let mut literal = Vec::new();
    let mut units = replacement.iter().copied().peekable();
    let invalid = |reason| fault("Ljava/lang/IllegalArgumentException;", reason);
    let digit = |unit: u16| (48..=57).contains(&unit).then(|| (unit - 48) as usize);
    while let Some(unit) = units.next() {
        match unit {
            92 => literal.push(
                units
                    .next()
                    .ok_or_else(|| invalid("Missing escaped unit"))?,
            ),
            36 => {
                if !literal.is_empty() {
                    parts.push(ReplacementPart::Literal(std::mem::take(&mut literal)));
                }
                let group = if units.next_if_eq(&123).is_some() {
                    let mut name = Vec::new();
                    while let Some(unit) = units.next_if(|unit| {
                        u8::try_from(*unit).is_ok_and(|byte| byte.is_ascii_alphanumeric())
                    }) {
                        name.push(unit);
                    }
                    if name.is_empty()
                        || digit(name[0]).is_some()
                        || units.next_if_eq(&125).is_none()
                    {
                        return Err(invalid("Invalid named group reference"));
                    }
                    pattern
                        .group_index(&name)
                        .ok_or_else(|| invalid("Unknown named group"))?
                } else {
                    let mut index = units
                        .next()
                        .and_then(digit)
                        .ok_or_else(|| invalid("Missing group reference after dollar sign"))?;
                    if index > pattern.groups {
                        return Err(fault(
                            "Ljava/lang/IndexOutOfBoundsException;",
                            "Regex capture index",
                        ));
                    }
                    while let Some(next) = units.peek().copied().and_then(digit) {
                        let combined = index * 10 + next;
                        if combined > pattern.groups {
                            break;
                        }
                        units.next();
                        index = combined;
                    }
                    index
                };
                parts.push(ReplacementPart::Group(group));
            }
            _ => literal.push(unit),
        }
    }
    if !literal.is_empty() {
        parts.push(ReplacementPart::Literal(literal));
    }
    Ok(parts)
}

fn append_replacement(output: &mut Vec<u16>, units: &[u16]) -> Result<()> {
    if output.len() + units.len() > 16384 {
        return Err("Regex replacement output quota".into());
    }
    output.extend_from_slice(units);
    Ok(())
}

impl Runtime {
    fn pattern(&self, id: u32) -> Result<Rc<Regex>> {
        match &self.object(id)?.payload {
            Payload::Pattern(p) => Ok(p.clone()),
            _ => Err("Expected regex Pattern".into()),
        }
    }
    fn matcher(&self, id: u32) -> Result<Matcher> {
        match &self.object(id)?.payload {
            Payload::Matcher(m) => Ok(m.clone()),
            _ => Err("Expected regex Matcher".into()),
        }
    }

    fn replace_regex(
        &mut self,
        pattern: &Regex,
        matcher: &mut Matcher,
        replacement: u32,
        first_only: bool,
    ) -> Result<u64> {
        if first_only && replacement == 0 {
            return Err(fault("Ljava/lang/NullPointerException;", "replacement"));
        }
        matcher.next = 0;
        matcher.groups = None;
        let input = self.sequence_units(matcher.input)?;
        let subject = pattern.subject(&input)?;
        let mut output = Vec::new();
        let mut parts = None;
        let mut cut = 0;
        let mut remaining_work = 262144usize;
        loop {
            matcher.groups = if matcher.next > input.len() {
                None
            } else {
                subject.search(matcher.next, false)?
            };
            let Some(groups) = &matcher.groups else { break };
            let (start, end) = groups[0].ok_or("Regex full capture missing")?;
            matcher.next = subject.after_match(start, end);
            let parts = match &parts {
                Some(parts) => parts,
                None => parts.insert(replacement_parts(pattern, &self.units(replacement)?)?),
            };
            remaining_work = remaining_work
                .checked_sub(parts.len() + 1)
                .ok_or("Regex replacement work quota")?;
            append_replacement(&mut output, &input[cut..start])?;
            for part in parts {
                match part {
                    ReplacementPart::Literal(units) => append_replacement(&mut output, units)?,
                    ReplacementPart::Group(index) => {
                        if let Some((start, end)) = groups[*index] {
                            append_replacement(&mut output, &input[start..end])?;
                        }
                    }
                }
            }
            cut = end;
            if first_only {
                break;
            }
        }
        if parts.is_none() {
            if matches!(self.object(matcher.input)?.payload, Payload::String(_)) {
                return Ok(matcher.input as u64);
            }
            return Ok(self.string_units(input)? as u64);
        }
        append_replacement(&mut output, &input[cut..])?;
        Ok(self.string_units(output)? as u64)
    }

    pub(super) fn regex_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let arg = |i: usize| a.get(i).copied().ok_or("Regex argument count");
        let (class, method) = sig.split_once("->").ok_or("Regex method signature")?;
        if class == "Ljava/lang/String;"
            && matches!(
                method,
                "split(Ljava/lang/String;)[Ljava/lang/String;"
                    | "split(Ljava/lang/String;I)[Ljava/lang/String;"
            )
        {
            let input = self.units(arg(0)?)?;
            let pattern = self.units(arg(1)?)?;
            let limit = if a.len() == 3 { arg(2)? as i32 } else { 0 };
            let pieces = crate::regex::split(&input, &pattern, 0, limit)?;
            let mut values = Vec::new();
            let unchanged = pieces.len() == 1 && pieces[0] == input;
            for piece in pieces {
                values.push(if unchanged {
                    arg(0)? as u64
                } else {
                    self.string_units(piece)? as u64
                });
            }
            return Ok(Some(
                self.allocate("[Ljava/lang/String;", Payload::Array(values))? as u64,
            ));
        }
        match sig {
            "Ljava/util/regex/Pattern;->quote(Ljava/lang/String;)Ljava/lang/String;" => {
                let source = self.units(arg(0)?)?;
                let mut quoted = vec![92, 81];
                let mut input = source.into_iter().peekable();
                while let Some(unit) = input.next() {
                    if unit == 92 && input.next_if_eq(&69).is_some() {
                        // Close the quoted run, emit a literal backslash and E, then reopen.
                        quoted.extend([92, 69, 92, 92, 69, 92, 81]);
                    } else {
                        quoted.push(unit);
                    }
                }
                quoted.extend([92, 69]);
                return Ok(Some(self.string_units(quoted)? as u64));
            }
            "Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;"
            | "Ljava/util/regex/Pattern;->compile(Ljava/lang/String;I)Ljava/util/regex/Pattern;" => {
                let flags = if a.len() == 2 { arg(1)? } else { 0 };
                let regex = Regex::compile(self.units(arg(0)?)?, flags)?;
                return Ok(Some(
                    self.allocate(class, Payload::Pattern(Rc::new(regex)))? as u64,
                ));
            }
            "Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z" => {
                let p = Regex::compile(self.units(arg(0)?)?, 0)?;
                return Ok(Some(
                    p.search(&self.sequence_units(arg(1)?)?, 0, true)?.is_some() as u64,
                ));
            }
            "Ljava/lang/String;->matches(Ljava/lang/String;)Z" => {
                let p = Regex::compile(self.units(arg(1)?)?, 0)?;
                return Ok(Some(
                    p.search(&self.units(arg(0)?)?, 0, true)?.is_some() as u64
                ));
            }
            "Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;"
            | "Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;" =>
            {
                let p = Regex::compile(self.units(arg(1)?)?, 0)?;
                let mut matcher = Matcher {
                    pattern: 0,
                    input: arg(0)?,
                    next: 0,
                    groups: None,
                };
                return Ok(Some(self.replace_regex(
                    &p,
                    &mut matcher,
                    arg(2)?,
                    method.starts_with("replaceFirst"),
                )?));
            }
            _ => {}
        }
        if class == "Ljava/util/regex/Pattern;" {
            let id = arg(0)?;
            let p = self.pattern(id)?;
            match method {
                "split(Ljava/lang/CharSequence;)[Ljava/lang/String;"
                | "split(Ljava/lang/CharSequence;I)[Ljava/lang/String;" => {
                    let input = self.sequence_units(arg(1)?)?;
                    let limit = if a.len() == 3 { arg(2)? as i32 } else { 0 };
                    let pieces = crate::regex::split(&input, &p.source, p.flags, limit)?;
                    let mut values = Vec::new();
                    for piece in pieces {
                        values.push(self.string_units(piece)? as u64);
                    }
                    return Ok(Some(
                        self.allocate("[Ljava/lang/String;", Payload::Array(values))? as u64,
                    ));
                }
                "matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;" => {
                    self.sequence_units(arg(1)?)?;
                    return Ok(Some(self.allocate(
                        "Ljava/util/regex/Matcher;",
                        Payload::Matcher(Matcher {
                            pattern: id,
                            input: arg(1)?,
                            next: 0,
                            groups: None,
                        }),
                    )? as u64));
                }
                "pattern()Ljava/lang/String;" | "toString()Ljava/lang/String;" => {
                    return Ok(Some(self.string_units(p.source.clone())? as u64));
                }
                "flags()I" => return Ok(Some(p.flags as u64)),
                _ => {}
            }
        }
        if class == "Ljava/util/regex/Matcher;" {
            let id = arg(0)?;
            let mut m = self.matcher(id)?;
            let p = self.pattern(m.pattern)?;
            if matches!(
                method,
                "replaceAll(Ljava/lang/String;)Ljava/lang/String;"
                    | "replaceFirst(Ljava/lang/String;)Ljava/lang/String;"
            ) {
                let result =
                    self.replace_regex(&p, &mut m, arg(1)?, method.starts_with("replaceFirst"));
                self.object_mut(id)?.payload = Payload::Matcher(m);
                return result.map(Some);
            }
            let input = self.sequence_units(m.input)?;
            let result = match method {
                "pattern()Ljava/util/regex/Pattern;" => m.pattern as u64,
                "groupCount()I" => p.groups as u64,
                "reset()Ljava/util/regex/Matcher;" => {
                    m.next = 0;
                    m.groups = None;
                    id as u64
                }
                "reset(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;" => {
                    self.sequence_units(arg(1)?)?;
                    m.input = arg(1)?;
                    m.next = 0;
                    m.groups = None;
                    id as u64
                }
                "find()Z" | "find(I)Z" | "matches()Z" => {
                    let full = method == "matches()Z";
                    let start = if full {
                        0
                    } else if method == "find(I)Z" {
                        arg(1)? as usize
                    } else {
                        m.next
                    };
                    if method == "find(I)Z" && start > input.len() {
                        return Err(fault(
                            "Ljava/lang/IndexOutOfBoundsException;",
                            "Matcher.find start",
                        ));
                    }
                    let subject = p.subject(&input)?;
                    m.groups = if start > input.len() {
                        None
                    } else {
                        subject.search(start, full)?
                    };
                    if let Some(groups) = &m.groups {
                        let (first, end) = groups[0].ok_or("Regex full capture missing")?;
                        m.next = subject.after_match(first, end);
                    }
                    m.groups.is_some() as u64
                }
                "group()Ljava/lang/String;"
                | "group(I)Ljava/lang/String;"
                | "start()I"
                | "start(I)I"
                | "end()I"
                | "end(I)I" => {
                    let group = if method.contains("(I)") {
                        arg(1)? as usize
                    } else {
                        0
                    };
                    let groups = m.groups.as_ref().ok_or_else(|| {
                        fault("Ljava/lang/IllegalStateException;", "No regex match")
                    })?;
                    let range = groups.get(group).ok_or_else(|| {
                        fault(
                            "Ljava/lang/IndexOutOfBoundsException;",
                            "Regex capture index",
                        )
                    })?;
                    if method.starts_with("group") {
                        if let Some((s, e)) = range {
                            let words = input
                                .get(*s..*e)
                                .ok_or_else(|| {
                                    fault(
                                        "Ljava/lang/IndexOutOfBoundsException;",
                                        "Changed regex input",
                                    )
                                })?
                                .to_vec();
                            self.string_units(words)? as u64
                        } else {
                            0
                        }
                    } else {
                        range
                            .map(|(s, e)| {
                                if method.starts_with("start") {
                                    s as u64
                                } else {
                                    e as u64
                                }
                            })
                            .unwrap_or(u32::MAX as u64)
                    }
                }
                _ => return Ok(None),
            };
            self.object_mut(id)?.payload = Payload::Matcher(m);
            return Ok(Some(result));
        }
        Ok(None)
    }
}
