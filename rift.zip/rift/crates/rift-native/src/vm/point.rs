//! Android's mutable integer coordinate pair.
use super::*;

pub(super) const POINT: &str = "Landroid/graphics/Point;";

impl Runtime {
    fn point_coordinates(&self, id: u32) -> Result<(i32, i32)> {
        let object = self.object(id)?;
        if !self.subclass(&object.class, POINT)? {
            return Err("Expected Android Point".into());
        }
        let Payload::Record(fields) = &object.payload else {
            return Ok((0, 0));
        };
        let coordinate = |name: &str| fields.get(name).copied().unwrap_or(0) as i32;
        Ok((coordinate("x"), coordinate("y")))
    }

    fn set_point_coordinates(&mut self, id: u32, x: i32, y: i32) -> Result<()> {
        let object = self.object_mut(id)?;
        if !matches!(object.payload, Payload::Record(_)) {
            object.payload = Payload::Record(BTreeMap::new());
        }
        let Payload::Record(fields) = &mut object.payload else {
            unreachable!()
        };
        fields.insert("x".into(), u64::from(x as u32));
        fields.insert("y".into(), u64::from(y as u32));
        Ok(())
    }

    pub(super) fn point_api(&mut self, signature: &str, args: &[u32]) -> Result<Option<u64>> {
        let Some(method) = signature.strip_prefix("Landroid/graphics/Point;->") else {
            return Ok(None);
        };
        let arg = |index: usize| args.get(index).copied().ok_or("Point argument");
        let id = arg(0)?;
        let (x, y) = self.point_coordinates(id)?;
        let pair = match method {
            "<init>()V" => (0, 0),
            "<init>(II)V" | "set(II)V" => (arg(1)? as i32, arg(2)? as i32),
            "<init>(Landroid/graphics/Point;)V" => self.point_coordinates(arg(1)?)?,
            "negate()V" => (x.wrapping_neg(), y.wrapping_neg()),
            "offset(II)V" => (
                x.wrapping_add(arg(1)? as i32),
                y.wrapping_add(arg(2)? as i32),
            ),
            "equals(II)Z" => {
                return Ok(Some(u64::from((x, y) == (arg(1)? as i32, arg(2)? as i32))));
            }
            "equals(Ljava/lang/Object;)Z" => {
                let other = arg(1)?;
                let equal = other != 0
                    && self.object(id)?.class == self.object(other)?.class
                    && (x, y) == self.point_coordinates(other)?;
                return Ok(Some(u64::from(equal)));
            }
            "hashCode()I" => return Ok(Some(u64::from(x.wrapping_mul(31).wrapping_add(y) as u32))),
            "toString()Ljava/lang/String;" => {
                return Ok(Some(u64::from(self.string(&format!("Point({x}, {y})"))?)));
            }
            "describeContents()I" => return Ok(Some(0)),
            _ => return Ok(None),
        };
        self.set_point_coordinates(id, pair.0, pair.1)?;
        Ok(Some(0))
    }
}
