package org.kyvex.extra;

import android.animation.TimeInterpolator;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Parcelable;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.ViewConfiguration;
import android.view.ViewManager;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;

public final class GraphicsChecks {
    private static final Interpolator EASE_OUT = new DecelerateInterpolator();
    private static final Interpolator EASE_IN = new AccelerateInterpolator();
    private static final Interpolator OVERSHOOT = new OvershootInterpolator();
    private static int checks;

    private static void check(boolean condition, String label) {
        if (!condition) throw new IllegalStateException(label);
        checks++;
    }

    private static void curves() {
        TimeInterpolator easeOut = EASE_OUT;
        check(easeOut.getInterpolation(0.25f) == 0.4375f, "Default deceleration");
        check(EASE_IN.getInterpolation(0.5f) == 0.25f, "Default acceleration");
        check(OVERSHOOT.getInterpolation(0.75f) == 1.078125f, "Default overshoot");
        check(new DecelerateInterpolator(2f).getInterpolation(0.5f) == 0.9375f, "Deceleration factor");
        check(new AccelerateInterpolator(2f).getInterpolation(0.5f) == 0.0625f, "Acceleration factor");
        check(new OvershootInterpolator(0f).getInterpolation(0.5f) == 0.875f, "Zero tension");
        check(easeOut.getInterpolation(1.25f) == 0.9375f, "Unclamped input");
        float notANumber = new AccelerateInterpolator(Float.POSITIVE_INFINITY).getInterpolation(1f);
        check(notANumber != notANumber, "Infinite power with unit base");
        check(TimeInterpolator.class.isInterface() && Interpolator.class.isInterface()
                && TimeInterpolator.class.isAssignableFrom(Interpolator.class), "Interpolator types");
    }

    private static void integerRectangles() {
        Rect rect = new Rect();
        check(rect.isEmpty() && rect.left == 0 && rect.right == 0, "Empty integer rectangle");
        rect.set(-3, -2, 4, 6);
        check(rect.width() == 7 && rect.height() == 8 && rect.exactCenterX() == 0.5f
                && rect.centerX() == 0 && rect.centerY() == 2, "Integer extent and center");
        check(rect.contains(-3, -2) && !rect.contains(4, 5), "Half-open integer containment");
        Rect copy = new Rect(rect);
        check(copy.equals(rect) && copy.hashCode() == rect.hashCode()
                && new Rect((Rect)null).isEmpty(), "Integer copy and hash");
        copy.offsetTo(10, 12);
        copy.inset(1, 2);
        check(copy.equals(new Rect(11, 14, 16, 18)) && rect.left == -3, "Integer mutation and copy isolation");
        Rect near = new Rect(-4, -5, 0, 2);
        check(rect.intersect(near) && rect.equals(new Rect(-3, -2, 0, 2))
                && !rect.intersect(new Rect(0, 0, 1, 1)), "Integer intersection and edge contact");
        rect.left = Integer.MAX_VALUE;
        rect.offset(1, 0);
        check(rect.left == Integer.MIN_VALUE && rect.width() == -2147483647, "Integer wrapping");
        rect.setEmpty();
        check(rect.isEmpty() && rect instanceof Parcelable, "Empty reset and Parcelable type");
    }

    private static void floatRectangles() {
        RectF rect = new RectF(new Rect(1, 2, 7, 8));
        rect.left = 1.25f;
        check(rect.width() == 5.75f && rect.centerX() == 4.125f, "Floating fields and conversion");
        check(rect.contains(1.25f, 2f) && !rect.contains(7f, 8f)
                && rect.contains(new RectF(2f, 3f, 4f, 5f)), "Floating containment");
        RectF other = new RectF(5f, 6f, 9f, 10f);
        RectF dest = new RectF();
        check(RectF.intersects(rect, other) && dest.setIntersect(rect, other)
                && dest.equals(new RectF(5f, 6f, 7f, 8f)), "Floating intersection and output");
        check(!dest.intersect(new RectF(7f, 8f, 9f, 10f))
                && dest.equals(new RectF(5f, 6f, 7f, 8f)), "Miss preserves receiver");
        dest.union(-1f, 3f);
        dest.union(new RectF(6f, 4f, 10f, 9f));
        dest.union(2f, 2f, 1f, 1f);
        check(dest.equals(new RectF(-1f, 3f, 10f, 9f)), "Union with point, rectangle and empty");
        dest.set(-1.5f, 2.5f, 4.2f, 8.1f);
        Rect rounded = new Rect();
        dest.round(rounded);
        check(rounded.equals(new Rect(-1, 3, 4, 8)), "API 28 fixed-point rounding");
        dest.roundOut(rounded);
        check(rounded.equals(new Rect(-2, 2, 5, 9)), "Outward rounding");
        RectF zeros = new RectF(-0.0f, 0.0f, 3f, 4f);
        RectF positive = new RectF(0.0f, -0.0f, 3f, 4f);
        check(zeros.equals(positive) && zeros.hashCode() == positive.hashCode()
                && dest.setIntersect(zeros, positive)
                && 1f / dest.left == Float.POSITIVE_INFINITY, "Signed zeros");
        RectF invalid = new RectF(Float.NaN, 0f, 1f, 2f);
        check(invalid.equals(invalid) && !invalid.equals(new RectF(invalid))
                && new RectF((RectF)null).isEmpty(), "Floating NaN and null copy");
    }

    private static void display(Context context) {
        WindowManager manager = (WindowManager) context.getSystemService("window");
        check(manager != null && manager == context.getSystemService(WindowManager.class)
                && "window".equals(context.getSystemServiceName(WindowManager.class)), "Window service lookup");
        check(ViewManager.class.isAssignableFrom(WindowManager.class)
                && WindowManager.class.isInterface(), "Window manager types");
        Display display = manager.getDefaultDisplay();
        check(display == manager.getDefaultDisplay() && display.getDisplayId() == 0
                && display.getRotation() == 0, "Default virtual display identity");
        Point size = new Point();
        Point real = new Point();
        display.getSize(size);
        display.getRealSize(real);
        check(size.equals(720, 1280) && size.equals(real), "Virtual display dimensions");
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        DisplayMetrics resources = context.getResources().getDisplayMetrics();
        check(metrics.widthPixels == resources.widthPixels && metrics.heightPixels == resources.heightPixels
                && metrics.densityDpi == 320 && metrics.density == 2f && metrics.scaledDensity == 2f
                && metrics.xdpi == 320f && metrics.ydpi == 320f, "Resources and display density");
        metrics.widthPixels = 1;
        display.getRealMetrics(metrics);
        check(metrics.widthPixels == 720 && metrics.heightPixels == 1280
                && metrics != resources, "Metrics snapshots");
        Rect screen = new Rect();
        display.getRectSize(screen);
        check(screen.equals(new Rect(0, 0, 720, 1280)), "Display rectangle");
        float[] rates = display.getSupportedRefreshRates();
        rates[0] = 123f;
        check(display.getRefreshRate() == 60f && display.getSupportedRefreshRates()[0] == 60f,
                "Fixed mode and independent rates array");
        Display.Mode mode = display.getMode();
        check(mode == display.getMode() && mode.getModeId() == 1 && mode.getPhysicalWidth() == size.x
                && mode.getPhysicalHeight() == size.y && mode.getRefreshRate() == 60f, "Display mode");
        Display.HdrCapabilities hdr = display.getHdrCapabilities();
        check(!display.isHdr() && hdr.getSupportedHdrTypes().length == 0
                && hdr.getDesiredMaxLuminance() == -1f, "SDR display profile");
        boolean rejected = false;
        try {
            display.getSize(null);
        } catch (NullPointerException expected) {
            rejected = true;
        }
        check(rejected, "Null point output");
    }

    private static void input(Context context) {
        ViewConfiguration input = ViewConfiguration.get(context);
        check(input != null && input == ViewConfiguration.get(context), "Stable input configuration");
        check(input.getScaledTouchSlop() == 16 && input.getScaledPagingTouchSlop() == 32
                && input.getScaledHoverSlop() == 8 && input.getScaledDoubleTapSlop() == 200,
                "Scaled input thresholds");
        check(input.getScaledMinimumFlingVelocity() == 100
                && input.getScaledMaximumFlingVelocity() == 16000, "Scaled fling velocities");
        check(input.getScaledHorizontalScrollFactor() == 128f
                && input.getScaledVerticalScrollFactor() == 128f, "Scaled scroll factor");
        check(ViewConfiguration.getTapTimeout() == 100
                && ViewConfiguration.getDoubleTapTimeout() == 300
                && ViewConfiguration.getLongPressTimeout() == 500
                && ViewConfiguration.getPressedStateDuration() == 64, "Input timing");
        check(ViewConfiguration.getScrollFriction() == 0.015f
                && ViewConfiguration.getDefaultActionModeHideDuration() == 2000L,
                "Fling friction and action timeout");
        check(!input.hasPermanentMenuKey() && !input.shouldShowMenuShortcutsWhenKeyboardPresent(),
                "Virtual input capabilities");
        boolean rejected = false;
        try {
            ViewConfiguration.get(null);
        } catch (NullPointerException expected) {
            rejected = true;
        }
        check(rejected, "Null input context");
    }

    public static int verify(Context context) {
        checks = 0;
        curves();
        integerRectangles();
        floatRectangles();
        display(context);
        input(context);
        return checks;
    }
}
