package android.content;
public final class ComponentName {
    public ComponentName(Context context,Class<?> type){}
    public ComponentName(Context context,String name){}
    public ComponentName(String pkg,String name){}
    public String getPackageName(){return null;}
    public String getClassName(){return null;}
}
