//! Real Java/D8 APK + clang ARM shared libraries; no mocked CPU or JNI.
use rift_native::{dexfile::Dex, machine::Machine, package::Package, vm::Runtime};
use std::path::Path;
fn sample() -> std::path::PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("../../samples/built/rift-native-demo.apk")
}
#[test]
fn activity_click_executes_dex_and_real_jni_on_both_arm_abis() {
    for abi in ["arm64-v8a", "armeabi-v7a"] {
        let p = Package::open(&sample(), abi).unwrap();
        let m = Machine::new(p.arch, 32, 8).unwrap();
        let mut vm = Runtime::new(p.dex, m, p.libraries, 4 * 1024 * 1024);
        let s = vm.start(&p.info.launcher).unwrap();
        assert_eq!(s.title, "Hello from Rift Native");
        assert!(s.widgets.iter().any(|w| w.text == "ARM result: 7"));
        assert!(
            s.widgets
                .iter()
                .any(|w| w
                    .text
                    .contains(if abi == "arm64-v8a" { "ARM64" } else { "ARM32" }))
        );
        let button = s.widgets.iter().find(|w| w.kind == "button").unwrap().id;
        let baseline = vm.heap_bytes();
        for click in 1..=300 {
            let s = vm.click(button).unwrap();
            assert!(
                s.widgets
                    .iter()
                    .any(|w| w.text == format!("ARM result: {}", (click + 1) * 7))
            );
        }
        assert!(
            vm.heap_bytes() < baseline + 64,
            "temporary Java objects must be collected after each event"
        );
        assert_eq!(vm.events, 300);
        assert!(vm.machine.ticks > 300);
        assert!(vm.click(42).is_err());
    }
}
#[test]
fn apk_abi_selection_is_explicit() {
    assert_eq!(Package::open(&sample(), "auto").unwrap().arch, 64);
    assert!(Package::open(&sample(), "x86").is_err());
    assert!(Package::open(&sample(), "../../x").is_err());
}
#[test]
fn method_and_type_indexes_remain_canonical_after_lazy_multidex_merge() {
    let path =
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../../samples/built/rift-native-advanced.apk");
    let mut p = Package::open(&path, "auto").unwrap();
    let class = "Lorg/kyvex/extra/RuntimeChecks;";
    assert!(!p.dex.has_class(class));
    let before = p.dex.find(class, "verify", "(I)I").unwrap();
    let extra = p.libraries.dex_for_class(class).unwrap().unwrap();
    p.dex.append(extra).unwrap();
    assert!(p.dex.has_class(class));
    assert_eq!(p.dex.find(class, "verify", "(I)I"), Some(before));
    assert!(p.dex.bodies.contains_key(&before));
    for (i, m) in p.dex.methods.iter().enumerate() {
        let signature = p.dex.signature(i);
        let descriptor = &signature[signature.find('(').unwrap()..];
        let found = p
            .dex
            .find(p.dex.ty(m.class), &p.dex.strings[m.name], descriptor)
            .unwrap();
        assert_eq!(found, i);
    }
}
#[test]
fn optimized_direct_reference_resolves_a_superclass_constructor() {
    let p = Package::open(&sample(), "auto").unwrap();
    let m = Machine::new(p.arch, 32, 8).unwrap();
    let mut vm = Runtime::new(p.dex, m, p.libraries, 4 * 1024 * 1024);
    let class = "Lorg/kyvex/nativehello/MainActivity;";
    let ctor = vm.dex.find(class, "<init>", "()V").unwrap();
    vm.dex.bodies.remove(&ctor);
    let scene = vm.start(&p.info.launcher).unwrap();
    assert!(scene.widgets.iter().any(|w| w.text == "ARM result: 7"));
}
#[test]
fn every_truncated_sample_dex_is_rejected_without_panicking() {
    use std::io::Read;
    let mut z = zip::ZipArchive::new(std::fs::File::open(sample()).unwrap()).unwrap();
    let mut b = Vec::new();
    z.by_name("classes.dex")
        .unwrap()
        .read_to_end(&mut b)
        .unwrap();
    assert!(Dex::parse(&b).is_ok());
    for n in (0..b.len()).step_by(13) {
        assert!(Dex::parse(&b[..n]).is_err())
    }
    for index in (8..b.len()).step_by(31) {
        let mut corrupt = b.clone();
        corrupt[index] ^= 0x80;
        assert!(Dex::parse(&corrupt).is_err());
    }
}
#[test]
fn multidex_exceptions_numeric_ops_and_registered_jni_execute_on_both_abis() {
    let path =
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../../samples/built/rift-native-advanced.apk");
    for abi in ["arm64-v8a", "armeabi-v7a"] {
        let p = Package::open(&path, abi).unwrap();
        assert_eq!(p.info.dex_files, 2);
        let m = Machine::new(p.arch, 32, 8).unwrap();
        let mut vm = Runtime::new(p.dex, m, p.libraries, 4 * 1024 * 1024);
        vm.start_application(&p.info.package, &p.info.application)
            .unwrap();
        let scene = vm.start(&p.info.launcher).unwrap();
        assert!(scene.widgets.iter().any(|w| w.text == "Core checks: 42"));
        assert!(scene.widgets.iter().any(|w| w.text
            == if abi == "arm64-v8a" {
                "Registered JNI / ARM64"
            } else {
                "Registered JNI / ARM32"
            }));
        assert_eq!(vm.loaded_dex(), 2);
        let button = scene
            .widgets
            .iter()
            .find(|w| w.kind == "button")
            .unwrap()
            .id;
        for i in 1..=50 {
            assert!(
                vm.click(button)
                    .unwrap()
                    .widgets
                    .iter()
                    .any(|w| w.text == format!("ARM result: {}", (i + 1) * 7))
            );
        }
    }
}
