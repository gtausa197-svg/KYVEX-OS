import java.util.Random;
/** Generate the reference with a stock JDK: java RandomOracle.java */
public class RandomOracle {
    public static void main(String[] args) {
        long[] seeds={0,1,-1,0x123456789abcdef0L,Long.MIN_VALUE,Long.MAX_VALUE};
        String comma="";System.out.print("[");
        for(long seed:seeds) {
            Random r=new Random(seed);System.out.print(comma+"{\"seed\":\""+seed+"\",\"int\":"+Integer.toUnsignedString(r.nextInt())+",\"bounded\":[");
            int[] bounds={1,2,37,2147483647,1073741825};String sep="";
            for(int b:bounds){System.out.print(sep+r.nextInt(b));sep=",";}
            System.out.print("],\"long\":\""+Long.toUnsignedString(r.nextLong())+"\",\"float_bits\":"+Integer.toUnsignedString(Float.floatToRawIntBits(r.nextFloat()))+",\"double_bits\":\""+Long.toUnsignedString(Double.doubleToRawLongBits(r.nextDouble()))+"\",\"gaussian\":["+r.nextGaussian()+","+r.nextGaussian()+"]}");comma=",";
        }
        System.out.println("]");
    }
}
