package android.content;
/** Compile-only API signatures. This class is never packaged into the sample APK. */
public class Context {
    public ContentResolver getContentResolver(){return null;}
    public android.content.res.Resources getResources(){return null;}
    public android.content.res.AssetManager getAssets(){return null;}
    public String getString(int id){return null;}
    public CharSequence getText(int id){return null;}
    public String getPackageName(){return null;}
    public Context getApplicationContext(){return null;}
    public Object getSystemService(String name){return null;}
    public <T> T getSystemService(Class<T> type){return null;}
    public String getSystemServiceName(Class<?> type){return null;}
    public android.content.pm.PackageManager getPackageManager(){return null;}
    public android.content.pm.ApplicationInfo getApplicationInfo(){return null;}
    public SharedPreferences getSharedPreferences(String name,int mode){return null;}
    public Context createDeviceProtectedStorageContext(){return null;}
    public Context createCredentialProtectedStorageContext(){return null;}
    public boolean isDeviceProtectedStorage(){return false;}
    public boolean isCredentialProtectedStorage(){return false;}
    public java.io.File getDataDir(){return null;}
    public java.io.File getFilesDir(){return null;}
    public java.io.File getCacheDir(){return null;}
    public java.io.File getExternalFilesDir(String type){return null;}
    public java.io.File[] getExternalFilesDirs(String type){return null;}
    public java.io.File getExternalCacheDir(){return null;}
    public java.io.File[] getExternalCacheDirs(){return null;}
    public java.io.File[] getExternalMediaDirs(){return null;}
    public java.io.FileInputStream openFileInput(String name) throws java.io.FileNotFoundException{return null;}
    public java.io.FileOutputStream openFileOutput(String name,int mode) throws java.io.FileNotFoundException{return null;}
    public java.io.File getFileStreamPath(String name){return null;}
    public java.io.File getDatabasePath(String name){return null;}
    public boolean deleteFile(String name){return false;}
}
