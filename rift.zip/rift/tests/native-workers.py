#!/usr/bin/env python3
"""Integration tests against real release workers and the private daemon.

Run on Linux as root to create an isolated uid-65534 test session. Guest code
always executes after dropping uid/gid. No desktop session or Android image.
"""
import errno, hashlib, json, os, pathlib, select, shutil, signal, socket, struct, subprocess, tempfile, time, unittest, zipfile, zlib
SOURCE = pathlib.Path(__file__).resolve().parents[1]
SAMPLE = SOURCE / 'samples/built/rift-native-demo.apk'
WORKER = '/usr/lib/kyvex/rift-native'
DAEMON = '/usr/lib/kyvex/rift-daemon'
UID = 65534
def ordinary_user():
    os.setgroups([]); os.setgid(UID); os.setuid(UID)
def packet(process, timeout=10):
    # Unbuffered pipes: no unread Python buffer can hide a complete frame.
    deadline = time.monotonic() + timeout; data = bytearray()
    while b'\n' not in data:
        ready, _, _ = select.select([process.stdout], [], [], max(0, deadline-time.monotonic()))
        if not ready: raise AssertionError('Worker response deadline')
        b = os.read(process.stdout.fileno(), 1)
        if not b: raise AssertionError(f'Worker exited: {process.poll()}')
        data += b
        if len(data)>65536: raise AssertionError('Worker response quota')
    return json.loads(data)
def send(process, value):
    process.stdin.write(json.dumps(value).encode()+b'\n'); process.stdin.flush(); return packet(process)
class NativeWorkers(unittest.TestCase):
    def spawn(self,*args):
        p=subprocess.Popen([WORKER,*args],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0,preexec_fn=ordinary_user,env={'LANG':'C.UTF-8'})
        self.addCleanup(self.reap,p);return p
    @staticmethod
    def reap(p):
        if p.poll() is None:p.kill()
        p.wait(timeout=5)
        for f in [p.stdin,p.stdout,p.stderr]:
            if f:f.close()
    def test_01_filter_denies_host_files_network_and_inherited_descriptors(self):
        p=self.spawn('--probe-sandbox');r=packet(p);self.assertTrue(r['ok']);self.assertTrue(r['sandbox']);self.assertEqual(r['open_errno'],errno.EPERM);self.assertEqual(r['socket_errno'],errno.EPERM);self.assertEqual(r['execute_errno'],errno.EPERM);self.assertEqual(r['inherited_errno'],errno.EBADF);self.assertEqual(p.wait(timeout=3),0)
    def test_interactive_worker_has_no_cumulative_cpu_expiration(self):
        p=self.spawn('--apk',str(SAMPLE));self.assertTrue(packet(p)['ok'])
        limits=pathlib.Path(f'/proc/{p.pid}/limits').read_text()
        cpu=next(line.split() for line in limits.splitlines() if line.startswith('Max cpu time'))
        self.assertEqual(cpu[3:5],['unlimited','unlimited'])
        self.assertTrue(send(p,{'method':'tick'})['ok'])
        self.assertTrue(send(p,{'method':'close'})['closed']);self.assertEqual(p.wait(timeout=3),0)
    def test_startup_trace_is_bounded_stderr_and_preserves_real_sandboxed_protocol(self):
        p=self.spawn('--apk',str(SAMPLE),'--trace-startup')
        first=packet(p);self.assertTrue(first['ok'],first);self.assertTrue(first['metrics']['sandbox'])
        self.assertTrue(send(p,{'method':'tick'})['ok'])
        self.assertTrue(send(p,{'method':'close'})['closed']);self.assertEqual(p.wait(timeout=3),0)
        records=[json.loads(line) for line in p.stderr.read().decode('utf-8').splitlines()]
        phases=[r['phase'] for r in records if r.get('rift_startup_trace')=='phase']
        self.assertIn('package_open_begin',phases);self.assertIn('application_begin',phases);self.assertIn('activity_ready',phases)
        calls=[r for r in records if r.get('rift_startup_trace')=='call'];self.assertGreater(len(calls),0);self.assertLessEqual(len(calls),80)
        self.assertTrue(all(len(r['method'])<=512 and r['dex_instructions']>=0 for r in calls))
    def test_02_arm_static_linux_syscalls_are_translated(self):
        for arch in [32,64]:
            p=self.spawn('--elf',str(SOURCE/f'samples/built/hello-a{arch}.elf'));r=packet(p);self.assertTrue(r['ok']);self.assertEqual(r['stdout'],f'Rift ARM{arch} ELF!\n');self.assertTrue(r['sandbox']);self.assertEqual(p.wait(timeout=3),0)
    def test_03_actual_dex_jni_ui_events_and_memory_reclamation(self):
        for abi in ['arm64-v8a','armeabi-v7a']:
            p=self.spawn('--apk',str(SAMPLE),'--abi',abi);r=packet(p);self.assertTrue(r['ok'],r);self.assertTrue(r['metrics']['sandbox']);button=next(w['id'] for w in r['scene']['widgets'] if w['kind']=='button');baseline=r['metrics'];
            for i in range(200):
                r=send(p,{'method':'click','id':button});self.assertTrue(r['ok'],r);self.assertIn(f'ARM result: {(i+2)*7}',[w['text'] for w in r['scene']['widgets']])
            self.assertLess(r['metrics']['java_heap_bytes'],baseline['java_heap_bytes']+128);self.assertLess(r['metrics']['peak_rss_kib'],baseline['peak_rss_kib']+8192);self.assertEqual(r['metrics']['events'],200)
            print(json.dumps({'abi':abi,'startup':baseline,'after_200_events':r['metrics']}),flush=True)
            self.assertTrue(send(p,{'method':'close'})['closed']);self.assertEqual(p.wait(timeout=3),0)
    def test_neon_simd_registers_on_both_architectures(self):
        for arch in [32,64]:
            p=self.spawn('--elf',str(SOURCE/f'samples/built/simd-a{arch}.elf'));r=packet(p);self.assertEqual(r['exit'],42,r);self.assertTrue(r['sandbox']);self.assertEqual(p.wait(timeout=3),0)
    def test_04_invalid_event_terminates_only_its_worker(self):
        p=self.spawn('--apk',str(SAMPLE));self.assertTrue(packet(p)['ok']);r=send(p,{'method':'click','id':1});self.assertFalse(r['ok']);self.assertIn('widget',r['error']);self.assertEqual(p.wait(timeout=3),1)
    def test_dynamic_relative_and_plt_relocations_use_guest_c_imports(self):
        for arch in [32,64]:
            fixture=SOURCE/f'samples/built/import-a{arch}.elf';p=self.spawn('--elf',str(fixture));r=packet(p);self.assertEqual(r['exit'],42,r);self.assertTrue(r['sandbox']);self.assertEqual(p.wait(timeout=3),0)
            with tempfile.TemporaryDirectory() as d:
                os.chmod(d,0o755);path=pathlib.Path(d)/'unknown-import.elf';data=fixture.read_bytes();self.assertIn(b'strlen\0',data);path.write_bytes(data.replace(b'strlen\0',b'system\0'));p=self.spawn('--elf',str(path));r=packet(p);self.assertFalse(r['ok']);self.assertIn('Unsupported native import: system',r['error']);self.assertEqual(p.wait(timeout=3),1)
    def test_packed_android_relocations_execute_and_malformed_streams_fail(self):
        for arch in [32,64]:
            fixture=SOURCE/f'samples/built/packed-a{arch}.elf'
            p=self.spawn('--elf',str(fixture));r=packet(p);self.assertEqual(r['exit'],42,r);self.assertEqual(p.wait(timeout=3),0)
            data=fixture.read_bytes();self.assertIn(b'APS2',data)
            with tempfile.TemporaryDirectory() as d:
                os.chmod(d,0o755);path=pathlib.Path(d)/'bad.elf';path.write_bytes(data.replace(b'APS2',b'BAD!'))
                p=self.spawn('--elf',str(path));r=packet(p);self.assertFalse(r['ok']);self.assertIn('APS2',r['error']);self.assertEqual(p.wait(timeout=3),1)
    def test_extended_runtime_multidex_registration_and_typed_exceptions(self):
        for abi in ['arm64-v8a','armeabi-v7a']:
            p=self.spawn('--apk',str(SOURCE/'samples/built/rift-native-advanced.apk'),'--abi',abi)
            r=packet(p);self.assertTrue(r['ok'],r);self.assertEqual(r['metrics']['loaded_dex'],2);self.assertTrue(r['metrics']['sandbox'])
            self.assertIn('Core checks: 42',[w['text'] for w in r['scene']['widgets']]);self.assertIn('Registered JNI / '+('ARM64' if abi=='arm64-v8a' else 'ARM32'),[w['text'] for w in r['scene']['widgets']])
            button=next(w['id'] for w in r['scene']['widgets'] if w['kind']=='button')
            for i in range(100):
                r=send(p,{'method':'click','id':button});self.assertTrue(r['ok'],r);self.assertIn(f'ARM result: {(i+2)*7}',[w['text'] for w in r['scene']['widgets']])
            print(json.dumps({'extended_abi':abi,'metrics':r['metrics']}),flush=True)
            self.assertTrue(send(p,{'method':'close'})['closed']);self.assertEqual(p.wait(timeout=3),0)
    def test_05_protocol_size_is_bounded(self):
        p=self.spawn('--apk',str(SAMPLE));self.assertTrue(packet(p)['ok']);p.stdin.write(b' '*65537);p.stdin.flush();r=packet(p);self.assertFalse(r['ok']);self.assertIn('64 KiB',r['error']);self.assertEqual(p.wait(timeout=3),1)
    def test_06_bad_apk_fails_without_guest_execution(self):
        with tempfile.TemporaryDirectory() as d:
            os.chmod(d,0o755);path=pathlib.Path(d)/'bad.apk';path.write_bytes(b'PK\x03\x04broken');p=self.spawn('--apk',str(path));self.assertFalse(packet(p)['ok']);self.assertEqual(p.wait(timeout=3),1)
    def test_07_root_guest_execution_is_refused(self):
        r=subprocess.run([WORKER,'--apk',str(SAMPLE)],capture_output=True,text=True,timeout=4);self.assertEqual(r.returncode,1);self.assertIn('ordinary user',json.loads(r.stdout)['error'])
    def test_08_unsupported_opcode_and_infinite_dex_are_bounded(self):
        with zipfile.ZipFile(SAMPLE) as z: entries={n:z.read(n) for n in z.namelist() if not n.startswith('META-INF/')}
        original=entries['classes.dex']
        # Locate the Activity constructor code_item by its actual instruction
        # stream, preserve all table offsets and repair DEX checksums.
        pattern=bytes.fromhex('7010000000000e00');code=original.find(pattern)
        self.assertGreater(code,112)
        for instruction,expected in [(0xffff,'opcode'),(0x0028,'budget')]:
            b=bytearray(original);struct.pack_into('<H',b,code,instruction);b[12:32]=hashlib.sha1(b[32:]).digest();struct.pack_into('<I',b,8,zlib.adler32(b[12:])&0xffffffff)
            with tempfile.TemporaryDirectory() as d:
                os.chmod(d,0o755);path=pathlib.Path(d)/'hostile.apk'
                with zipfile.ZipFile(path,'w') as z:
                    for n,value in entries.items():z.writestr(n,b if n=='classes.dex' else value)
                p=self.spawn('--apk',str(path));r=packet(p);self.assertFalse(r['ok'],r);self.assertIn(expected,r['error']);self.assertEqual(p.wait(timeout=3),1)
class NativeDaemon(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='rift-native-qa-');cls.home=pathlib.Path(cls.temp.name);os.chown(cls.home,UID,UID);os.chmod(cls.home,0o700)
        cls.runtime=pathlib.Path(f'/run/user/{UID}');cls.runtime.mkdir(exist_ok=True);os.chown(cls.runtime,UID,UID);os.chmod(cls.runtime,0o700);cls.sock=cls.runtime/'kyvex-rift.sock'
        if cls.sock.exists():raise RuntimeError('A different test session is already running; refusing to replace it')
        cls.p=subprocess.Popen([DAEMON],preexec_fn=ordinary_user,env={'HOME':str(cls.home),'XDG_DATA_HOME':str(cls.home/'data'),'LANG':'C.UTF-8'},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        for _ in range(100):
            if cls.sock.exists():break
            if cls.p.poll() is not None:raise RuntimeError(cls.p.stderr.read().decode())
            time.sleep(.05)
    @classmethod
    def tearDownClass(cls):
        # Close native app through its normal owner path before ending daemon.
        try:cls.call('native-close',{'session':getattr(cls,'last_id',0)},owner='qa-b')
        except Exception:pass
        cls.p.terminate();cls.p.wait(timeout=5);cls.p.stdout.close();cls.p.stderr.close();cls.sock.unlink(missing_ok=True);cls.temp.cleanup()
    @classmethod
    def call(cls,method,params=None,owner='qa-a'):
        with socket.socket(socket.AF_UNIX) as s:
            s.settimeout(12)
            os.seteuid(UID)
            try:s.connect(str(cls.sock))
            finally:os.seteuid(0)
            s.sendall(json.dumps({'version':1,'client_id':owner,'method':method,'params':params or {}}).encode()+b'\n');data=b''
            while b'\n' not in data:
                b=s.recv(65536)
                if not b:raise AssertionError('Daemon closed connection')
                data+=b
            return json.loads(data)
    def test_supervisor_ownership_restart_and_child_cleanup(self):
        a=self.call('native-demo');self.assertTrue(a['ok'],a);a=a['data'];old=a['native_session'];self.assertIn('ARM result: 7',[w['text'] for w in a['scene']['widgets']]);button=next(w['id'] for w in a['scene']['widgets'] if w['kind']=='button')
        self.assertFalse(self.call('native-event',{'session':old,'widget':button},owner='wrong')['ok'])
        self.assertFalse(self.call('native-tick',{'session':old},owner='wrong')['ok'])
        self.assertTrue(self.call('native-tick',{'session':old})['ok'])
        r=self.call('native-event',{'session':old,'widget':button});self.assertTrue(r['ok'],r);self.assertIn('ARM result: 14',[w['text'] for w in r['data']['scene']['widgets']])
        b=self.call('native-demo',owner='qa-b');self.assertTrue(b['ok'],b);new=b['data']['native_session'];type(self).last_id=new;self.assertNotEqual(old,new)
        self.assertFalse(self.call('native-tick',{'session':old})['ok'])
        self.assertFalse(self.call('native-close',{'session':old})['ok']);self.assertTrue(self.call('native-close',{'session':new},owner='qa-b')['ok'])
        self.assertIsNone(self.call('status')['data']['native_session']);self.assertIsNone(self.p.poll())
        children=[]
        for path in pathlib.Path('/proc').glob('[0-9]*/status'):
            try:
                if f'PPid:\t{self.p.pid}\n' in path.read_text():children.append(str(path))
            except (OSError,ProcessLookupError):pass
        self.assertEqual(children,[],'closed/replaced workers must be killed and reaped')
    def test_legacy_profiles_migrate_to_native_without_losing_bindings(self):
        import sqlite3
        package='org.kyvex.legacy'
        profile=self.call('profile',{'package':package})['data'];bindings=profile['controls']
        profile['backend']='compatibility';profile['abi']='x86_64'
        with sqlite3.connect(self.home/'data/kyvex/rift/library.sqlite') as db:
            db.execute('INSERT OR REPLACE INTO profiles(package,data)VALUES(?,?)',(package,json.dumps(profile)))
        r=self.call('profile',{'package':package});self.assertTrue(r['ok'],r)
        self.assertEqual(r['data']['backend'],'native');self.assertEqual(r['data']['abi'],'auto');self.assertEqual(r['data']['controls'],bindings)
        status=self.call('status')['data'];self.assertEqual(status['backend'],'native');self.assertFalse(status['runtime']['requires_android_image'])
        self.assertFalse(self.call('authorize')['ok']);self.assertFalse(self.call('session',{'package':package,'android':True})['ok'])
if __name__=='__main__':
    if os.geteuid()!=0:raise SystemExit('Use root only for the test harness; it drops uid for every runtime process')
    unittest.main(verbosity=2)
