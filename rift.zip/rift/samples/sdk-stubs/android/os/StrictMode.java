package android.os;

/** Compile-only signatures. Rift supplies the guest behavior. */
public final class StrictMode {
    public static ThreadPolicy getThreadPolicy() { return null; }
    public static void setThreadPolicy(ThreadPolicy policy) {}
    public static ThreadPolicy allowThreadDiskReads() { return null; }
    public static ThreadPolicy allowThreadDiskWrites() { return null; }
    public static void noteSlowCall(String name) {}

    public static final class ThreadPolicy {
        public static final ThreadPolicy LAX = null;

        public static final class Builder {
            public Builder() {}
            public Builder(ThreadPolicy source) {}
            public Builder detectNetwork() { return this; }
            public Builder detectResourceMismatches() { return this; }
            public Builder detectUnbufferedIo() { return this; }
            public Builder detectDiskReads() { return this; }
            public Builder detectDiskWrites() { return this; }
            public Builder detectCustomSlowCalls() { return this; }
            public Builder permitNetwork() { return this; }
            public Builder permitAll() { return this; }
            public Builder penaltyLog() { return this; }
            public ThreadPolicy build() { return null; }
        }
    }
}
