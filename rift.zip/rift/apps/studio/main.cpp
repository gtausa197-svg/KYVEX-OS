#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QFont>
#include <QGuiApplication>
#include <QIcon>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLocalSocket>
#include <QProcess>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QSaveFile>
#include <QSettings>
#include <QStandardPaths>
#include <QTimer>
#include <QUuid>
#include <functional>
#include <memory>
#include <unistd.h>

class Rift final : public QObject {
  Q_OBJECT
  Q_PROPERTY(QVariantList apps READ apps NOTIFY appsChanged)
  Q_PROPERTY(QVariantMap status READ status NOTIFY statusChanged)
  Q_PROPERTY(QVariantMap profile READ profile NOTIFY profileChanged)
  Q_PROPERTY(QVariantMap nativeData READ nativeData NOTIFY nativeChanged)
  Q_PROPERTY(QVariantList contacts READ contacts NOTIFY contactsChanged)
  Q_PROPERTY(QString selected READ selected NOTIFY profileChanged)
  Q_PROPERTY(QString message READ message NOTIFY messageChanged)
  Q_PROPERTY(bool busy READ busy NOTIFY busyChanged)
  Q_PROPERTY(bool connected READ connected NOTIFY contactsChanged)
  Q_PROPERTY(
      bool ukrainian READ ukrainian WRITE setUkrainian NOTIFY languageChanged)
  QVariantList m_apps, m_contacts;
  QVariantMap m_status, m_profile;
  QVariantMap m_native;
  quint64 m_nativeSession = 0;
  QString m_selected = "org.kyvex.test",
          m_message = "Ready. Import an APK to begin.";
  bool m_busy = false, m_connected = false, m_nativePending = false;
  QList<QVariantMap> undoStack, redoStack;
  QTimer saveTimer, heartbeat, nativePoll;
  QString clientId = QUuid::createUuid().toString(QUuid::WithoutBraces);
  using Callback = std::function<void(QJsonValue)>;
  void say(QString s) {
    m_message = s.left(6000);
    emit messageChanged();
  }
  void setBusy(bool v) {
    m_busy = v;
    emit busyChanged();
  }
  void appendLog(const QString &text) {
    QString base = qEnvironmentVariable("XDG_DATA_HOME");
    if (base.isEmpty())
      base = QDir::homePath() + "/.local/share";
    QString dir = base + "/kyvex/rift/logs";
    QDir().mkpath(dir);
    QFile f(dir + "/operations.log");
    if (f.open(QIODevice::WriteOnly | QIODevice::Append)) {
      f.setPermissions(QFileDevice::ReadOwner | QFileDevice::WriteOwner);
      if (f.size() > 262144)
        f.resize(0);
      f.write(text.toUtf8());
    }
  }
  void rpc(QString method, QJsonObject params = {}, Callback callback = {},
           bool work = false, std::function<void(bool)> completed = {}) {
    auto *socket = new QLocalSocket(this);
    auto bytes = std::make_shared<QByteArray>();
    auto finished = std::make_shared<bool>(false);
    auto *deadline = new QTimer(socket);
    deadline->setSingleShot(true);
    deadline->setInterval(work ? 120000 : 10000);
    connect(deadline, &QTimer::timeout, this, [=, this] {
      if (*finished)
        return;
      *finished = true;
      if (work)
        setBusy(false);
      say("Rift request timed out.");
      if (completed)
        completed(false);
      socket->abort();
      socket->deleteLater();
    });
    deadline->start();
    if (work)
      setBusy(true);
    connect(socket, &QLocalSocket::connected, this, [=, this] {
      socket->write(QJsonDocument(QJsonObject{{"version", 1},
                                              {"client_id", clientId},
                                              {"method", method},
                                              {"params", params}})
                        .toJson(QJsonDocument::Compact) +
                    "\n");
    });
    connect(socket, &QLocalSocket::readyRead, this, [=, this] {
      bytes->append(socket->readAll());
      if (bytes->size() > 2 * 1024 * 1024) {
        socket->abort();
        return;
      }
      int nl = bytes->indexOf('\n');
      if (nl < 0 || *finished)
        return;
      *finished = true;
      deadline->stop();
      QJsonParseError error;
      auto object = QJsonDocument::fromJson(bytes->left(nl), &error).object();
      if (work)
        setBusy(false);
      const bool success = error.error == QJsonParseError::NoError &&
                           object.value("ok").toBool();
      if (!success)
        say(object.value("error").toString(
            "Rift returned an invalid response"));
      else if (callback)
        callback(object.value("data"));
      if (completed)
        completed(success);
      socket->disconnectFromServer();
      socket->deleteLater();
    });
    connect(socket, &QLocalSocket::errorOccurred, this, [=, this](auto) {
      if (!*finished) {
        *finished = true;
        deadline->stop();
        if (work) {
          setBusy(false);
          say("Rift service unavailable. Close and reopen Studio; see "
              "Diagnostics.");
        }
        if (completed)
          completed(false);
      }
      socket->deleteLater();
    });
    socket->connectToServer(
        QString("/run/user/%1/kyvex-rift.sock").arg(getuid()));
  }
  QJsonObject package() const { return {{"package", m_selected}}; }
  void remember() {
    undoStack.append(m_profile);
    if (undoStack.size() > 40)
      undoStack.removeFirst();
    redoStack.clear();
  }
  void changed() {
    emit profileChanged();
    saveTimer.start(450);
  }
  void nativeFrame(quint64 session, QJsonValue value) {
    if (m_nativeSession != session)
      return;
    const auto next = value.toObject();
    const auto revision = next["metrics"].toObject()["events"].toInteger();
    const auto currentFrame = QJsonObject::fromVariantMap(m_native);
    const auto current =
        currentFrame["metrics"].toObject()["events"].toInteger();
    if (revision < current)
      return;
    m_native = next.toVariantMap();
    if (revision == current && next["scene"] == currentFrame["scene"])
      return;
    emit nativeChanged();
  }
  void launched(QJsonValue v) {
    auto o = v.toObject();
    if (o["backend"].toString() == "native") {
      m_native = o.toVariantMap();
      m_nativeSession = o["native_session"].toInteger();
      m_nativePending = false;
      nativePoll.start();
      emit nativeChanged();
      emit nativeReady();
      say("Rift Native is running. Its window executes Java / ARM code "
          "locally.");
    } else
      say("Unexpected runtime response. Check "
          "Diagnostics.");
    refresh();
  }

public:
  explicit Rift(QObject *p = nullptr) : QObject(p) {
    saveTimer.setSingleShot(true);
    connect(&saveTimer, &QTimer::timeout, this, &Rift::saveProfile);
    nativePoll.setInterval(34);
    connect(&nativePoll, &QTimer::timeout, this, [this] {
      if (!m_nativeSession || m_nativePending || m_busy)
        return;
      const auto session = m_nativeSession;
      m_nativePending = true;
      rpc(
          "native-tick", {{"session", qint64(session)}},
          [this, session](auto v) { nativeFrame(session, v); }, false,
          [this, session](bool success) {
            if (m_nativeSession != session)
              return;
            m_nativePending = false;
            if (!success)
              nativePoll.stop();
          });
    });
    heartbeat.setInterval(100);
    connect(&heartbeat, &QTimer::timeout, this, [this] {
      rpc("heartbeat", {}, [this](auto v) {
        auto o = v.toObject();
        m_contacts = o.value("contacts").toArray().toVariantList();
        m_connected = o.value("connected").toBool();
        if (!o.value("error").toString().isEmpty())
          say(o.value("error").toString());
        emit contactsChanged();
      });
    });
    QLocalSocket check;
    check.connectToServer(
        QString("/run/user/%1/kyvex-rift.sock").arg(getuid()));
    if (!check.waitForConnected(150))
      QProcess::startDetached("/usr/lib/kyvex/rift-daemon", {});
    QTimer::singleShot(600, this, [this] {
      refresh();
      choose(m_selected);
    });
  }
  QVariantList apps() const { return m_apps; }
  QVariantMap status() const { return m_status; }
  QVariantMap profile() const { return m_profile; }
  QVariantList contacts() const { return m_contacts; }
  QVariantMap nativeData() const { return m_native; }
  QString selected() const { return m_selected; }
  QString message() const { return m_message; }
  bool busy() const { return m_busy; }
  bool connected() const { return m_connected; }
  bool ukrainian() const {
    return QSettings("KYVEX", "Rift").value("ukrainian", false).toBool();
  }
  void setUkrainian(bool v) {
    QSettings("KYVEX", "Rift").setValue("ukrainian", v);
    emit languageChanged();
  }
  Q_INVOKABLE void refresh() {
    rpc("list", {}, [this](auto v) {
      m_apps = v.toArray().toVariantList();
      emit appsChanged();
    });
    rpc("status", {}, [this](auto v) {
      m_status = v.toObject().toVariantMap();
      emit statusChanged();
    });
  }
  Q_INVOKABLE void choose(QString p) {
    if (saveTimer.isActive())
      saveProfile();
    saveTimer.stop();
    m_selected = p;
    undoStack.clear();
    redoStack.clear();
    rpc("profile", package(), [this, p](auto v) {
      if (m_selected != p)
        return;
      m_profile = v.toObject().toVariantMap();
      emit profileChanged();
    });
  }
  Q_INVOKABLE void importApk(QUrl url) {
    rpc(
        "import", {{"path", url.toLocalFile()}},
        [this](auto v) {
          say("Imported " + v["package"].toString() +
              ". APK code has not been run.");
          choose(v["package"].toString());
          refresh();
        },
        true);
  }
  Q_INVOKABLE void openApk(QUrl url) {
    rpc(
        "import", {{"path", url.toLocalFile()}},
        [this](auto v) {
          choose(v["package"].toString());
          refresh();
          launch();
        },
        true);
  }
  Q_INVOKABLE void launch() {
    saveTimer.stop();
    auto p = package();
    auto start = [this, p](QJsonValue) {
      rpc("launch", p, [this](auto v) { launched(v); }, true);
    };
    if (m_profile["package"].toString() == m_selected)
      rpc("save-profile", QJsonObject::fromVariantMap(m_profile), start, true);
    else
      start({});
  }
  Q_INVOKABLE void nativeDemo() {
    rpc(
        "native-demo", {},
        [this](auto v) {
          choose(v["package"].toString());
          launched(v);
        },
        true);
  }
  Q_INVOKABLE void nativeAdvanced() {
    rpc(
        "native-advanced", {},
        [this](auto v) {
          choose(v["package"].toString());
          launched(v);
        },
        true);
  }
  Q_INVOKABLE void nativeClick(quint32 id) {
    if (!m_nativeSession)
      return;
    const auto session = m_nativeSession;
    rpc(
        "native-event", {{"session", qint64(session)}, {"widget", qint64(id)}},
        [this, session](auto v) { nativeFrame(session, v); }, true);
  }
  Q_INVOKABLE void closeNative() {
    nativePoll.stop();
    m_nativePending = false;
    if (!m_nativeSession)
      return;
    QLocalSocket s;
    s.connectToServer(QString("/run/user/%1/kyvex-rift.sock").arg(getuid()));
    if (s.waitForConnected(200)) {
      s.write(
          QJsonDocument(
              QJsonObject{{"version", 1},
                          {"client_id", clientId},
                          {"method", "native-close"},
                          {"params",
                           QJsonObject{{"session", qint64(m_nativeSession)}}}})
              .toJson(QJsonDocument::Compact) +
          "\n");
      s.waitForBytesWritten(200);
      s.waitForReadyRead(300);
    }
    m_nativeSession = 0;
  }
  Q_INVOKABLE void remove() {
    rpc(
        "remove", package(),
        [this](auto) {
          say("Removed from the Rift library. The control profile is "
              "retained.");
          choose("org.kyvex.test");
          refresh();
        },
        true);
  }
  Q_INVOKABLE void stopApp() {
    rpc("stop-app", package(), [this](auto) { say("Application stopped."); });
  }
  Q_INVOKABLE void nativeTest() {
    rpc("native-test", {}, [this](auto v) {
      say(QJsonDocument(v.toObject()).toJson(QJsonDocument::Indented));
    });
  }
  Q_INVOKABLE void saveProfile() {
    if (m_profile.isEmpty())
      return;
    rpc("save-profile", QJsonObject::fromVariantMap(m_profile));
  }
  Q_INVOKABLE void edit(int index, QString key, QVariant value) {
    auto controls = m_profile["controls"].toList();
    if (index < 0 || index >= controls.size())
      return;
    remember();
    auto c = controls[index].toMap();
    c[key] = value;
    controls[index] = c;
    m_profile["controls"] = controls;
    changed();
  }
  Q_INVOKABLE void orientation(QString value) {
    remember();
    m_profile["orientation"] = value;
    changed();
  }
  Q_INVOKABLE void architecture(QString value) {
    remember();
    m_profile["abi"] = value;
    changed();
  }
  Q_INVOKABLE void backend(QString value) {
    remember();
    m_profile["backend"] = value;
    changed();
  }
  Q_INVOKABLE void nativeMemory(QString value) {
    remember();
    m_profile["native_memory"] = value;
    changed();
  }
  Q_INVOKABLE void moveControl(int index, double x, double y) {
    auto controls = m_profile["controls"].toList();
    if (index < 0 || index >= controls.size())
      return;
    remember();
    auto c = controls[index].toMap();
    c["x"] = qBound(0.0, x, 1.0);
    c["y"] = qBound(0.0, y, 1.0);
    controls[index] = c;
    m_profile["controls"] = controls;
    changed();
  }
  Q_INVOKABLE void add(QString kind) {
    remember();
    auto controls = m_profile["controls"].toList();
    if (controls.size() >= 64) {
      say("A profile supports at most 64 controls.");
      return;
    }
    controls.append(QVariantMap{
        {"id", QString("control-%1").arg(QDateTime::currentMSecsSinceEpoch())},
        {"kind", kind},
        {"key", QString("Key%1").arg(controls.size() + 1)},
        {"x", 0.5},
        {"y", 0.5},
        {"end_x", 0.8},
        {"end_y", 0.5},
        {"radius", 0.1},
        {"duration_ms", 160}});
    m_profile["controls"] = controls;
    changed();
  }
  Q_INVOKABLE void erase(int index) {
    auto controls = m_profile["controls"].toList();
    if (index < 0 || index >= controls.size())
      return;
    remember();
    controls.removeAt(index);
    m_profile["controls"] = controls;
    changed();
  }
  Q_INVOKABLE void undo() {
    if (undoStack.isEmpty())
      return;
    redoStack.append(m_profile);
    m_profile = undoStack.takeLast();
    emit profileChanged();
    saveTimer.start(450);
  }
  Q_INVOKABLE void redo() {
    if (redoStack.isEmpty())
      return;
    undoStack.append(m_profile);
    m_profile = redoStack.takeLast();
    emit profileChanged();
    saveTimer.start(450);
  }
  Q_INVOKABLE void exportProfile(QUrl url) {
    QSaveFile f(url.toLocalFile());
    if (!f.open(QIODevice::WriteOnly)) {
      say(f.errorString());
      return;
    }
    f.write(
        QJsonDocument::fromVariant(m_profile).toJson(QJsonDocument::Indented));
    if (!f.commit())
      say(f.errorString());
    else
      say("Profile exported.");
  }
  Q_INVOKABLE void importProfile(QUrl url) {
    QFile f(url.toLocalFile());
    if (!f.open(QIODevice::ReadOnly) || f.size() > 262144) {
      say("Profile cannot be read or exceeds 256 KiB.");
      return;
    }
    auto o = QJsonDocument::fromJson(f.readAll()).object();
    if (o["package"].toString() != m_selected) {
      say("This profile belongs to another application. Select its app first.");
      return;
    }
    rpc("save-profile", o, [this, o](auto) {
      remember();
      m_profile = o.toVariantMap();
      emit profileChanged();
      say("Profile imported.");
    });
  }
  Q_INVOKABLE void session(bool android) {
    saveTimer.stop();
    auto p = package();
    p["android"] = android;
    rpc("save-profile", QJsonObject::fromVariantMap(m_profile),
        [this, p, android](auto) {
          rpc(
              "session", p,
              [this, android](auto) {
                heartbeat.start();
                say(android ? "Android control channel connected. Keep the "
                              "input overlay focused."
                            : "Test scene ready. Try WASD + Space together.");
                emit sessionReady(android);
              },
              true);
        });
  }
  Q_INVOKABLE void key(QString key, bool down) {
    rpc("input", {{"key", key}, {"down", down}});
  }
  Q_INVOKABLE void aim(double dx, double dy) {
    rpc("aim", {{"dx", dx}, {"dy", dy}});
  }
  Q_INVOKABLE void touch(QString action, double x, double y) {
    rpc("touch", {{"action", action}, {"pointer", 90}, {"x", x}, {"y", y}});
  }
  Q_INVOKABLE void release() { rpc("release"); }
  Q_INVOKABLE void disconnectInput() {
    heartbeat.stop();
    rpc("disconnect");
    m_connected = false;
    emit contactsChanged();
  }
  Q_INVOKABLE void action(QString name) {
    if (name == "power")
      QProcess::startDetached("/usr/local/bin/kyvex-control-center", {});
  }
signals:
  void appsChanged();
  void statusChanged();
  void profileChanged();
  void contactsChanged();
  void messageChanged();
  void busyChanged();
  void languageChanged();
  void sessionReady(bool android);
  void nativeChanged();
  void nativeReady();
};
#ifdef RIFT_STUDIO_EVENT_TEST
#include "event-test.hpp"
#endif
int main(int argc, char **argv) {
  if (QDir("/dev/dri").entryList({"renderD*"}, QDir::System).isEmpty())
    qputenv("QT_QUICK_BACKEND", "software");
  QGuiApplication app(argc, argv);
  app.setApplicationName("KYVEX Rift Studio");
  app.setOrganizationName("KYVEX");
  app.setDesktopFileName("kyvex-rift");
  app.setWindowIcon(QIcon(":/rift.svg"));
  app.setFont(QFont("Noto Sans", 10));
  qputenv("QT_QUICK_CONTROLS_STYLE", "Basic");
  Rift bridge;
  QQmlApplicationEngine engine;
  engine.rootContext()->setContextProperty("rift", &bridge);
  engine.load(QUrl("qrc:/Main.qml"));
  if (engine.rootObjects().isEmpty())
    return 1;
#ifdef RIFT_STUDIO_EVENT_TEST
  return testNativeEvents(app, bridge, engine);
#endif
  if (app.arguments().size() == 2) {
    auto p = app.arguments()[1];
    if (p == "--native-advanced")
      QTimer::singleShot(1300, &bridge, &Rift::nativeAdvanced);
    else if (p == "--native-demo")
      QTimer::singleShot(1300, &bridge, &Rift::nativeDemo);
    else if (QFileInfo(p).isFile())
      QTimer::singleShot(1300, &bridge, [&bridge, p] {
        bridge.openApk(QUrl::fromLocalFile(QFileInfo(p).absoluteFilePath()));
      });
  }
  if (app.arguments().size() == 3 && app.arguments()[1] == "--import-only") {
    auto path = QFileInfo(app.arguments()[2]);
    if (path.isFile())
      QTimer::singleShot(1300, &bridge, [&bridge, path] {
        bridge.importApk(QUrl::fromLocalFile(path.absoluteFilePath()));
      });
  }
  return app.exec();
}
#include "main.moc"
