//! Android Base64 flag and padding semantics over actual bounded guest data.
use super::*;
const STANDARD: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const URL: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
fn encode(input: &[u8], flags: u32) -> Vec<u8> {
    let alphabet = if flags & 8 != 0 { URL } else { STANDARD };
    let mut raw = Vec::new();
    for group in input.chunks(3) {
        let bits = (group[0] as u32) << 16
            | (group.get(1).copied().unwrap_or(0) as u32) << 8
            | group.get(2).copied().unwrap_or(0) as u32;
        raw.extend([
            alphabet[((bits >> 18) & 63) as usize],
            alphabet[((bits >> 12) & 63) as usize],
        ]);
        if group.len() > 1 {
            raw.push(alphabet[((bits >> 6) & 63) as usize]);
        } else if flags & 1 == 0 {
            raw.push(b'=');
        }
        if group.len() > 2 {
            raw.push(alphabet[(bits & 63) as usize]);
        } else if flags & 1 == 0 {
            raw.push(b'=');
        }
    }
    if flags & 2 != 0 {
        return raw;
    }
    let mut result = Vec::new();
    for line in raw.chunks(76) {
        result.extend(line);
        if flags & 4 != 0 {
            result.push(b'\r');
        }
        result.push(b'\n');
    }
    result
}
fn decode(input: &[u8], flags: u32) -> Option<Vec<u8>> {
    let alphabet = if flags & 8 != 0 { URL } else { STANDARD };
    let mut output = Vec::new();
    let mut count = 0;
    let mut bits = 0u32;
    let mut padding = 0;
    for byte in input {
        if *byte == b'=' {
            if padding == 1 {
                padding = 2;
                continue;
            }
            if padding == 2 {
                return None;
            }
            match count {
                2 => {
                    output.push((bits >> 4) as u8);
                    padding = 1;
                }
                3 => {
                    output.extend([(bits >> 10) as u8, (bits >> 2) as u8]);
                    padding = 2;
                }
                _ => return None,
            }
            continue;
        }
        let Some(value) = alphabet.iter().position(|v| v == byte) else {
            continue;
        };
        if padding != 0 {
            return None;
        }
        bits = (bits << 6) | value as u32;
        count += 1;
        if count == 4 {
            output.extend([(bits >> 16) as u8, (bits >> 8) as u8, bits as u8]);
            count = 0;
            bits = 0;
        }
    }
    if padding == 1 {
        return None;
    }
    if padding == 0 {
        match count {
            0 => {}
            1 => return None,
            2 => output.push((bits >> 4) as u8),
            3 => output.extend([(bits >> 10) as u8, (bits >> 2) as u8]),
            _ => unreachable!(),
        }
    }
    Some(output)
}
impl Runtime {
    pub(super) fn base64_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let Some(method) = sig.strip_prefix("Landroid/util/Base64;->") else {
            return Ok(None);
        };
        if !matches!(
            method,
            "encode([BI)[B"
                | "encode([BIII)[B"
                | "encodeToString([BI)Ljava/lang/String;"
                | "encodeToString([BIII)Ljava/lang/String;"
                | "decode([BI)[B"
                | "decode([BIII)[B"
                | "decode(Ljava/lang/String;I)[B"
        ) {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Base64 argument count");
        let sliced = method.contains("[BIII");
        let input = if method.starts_with("decode(Ljava/lang/String;") {
            charsets::Encoding::Utf8.encode(&self.units(arg(0)?)?)
        } else {
            let object = self.object(arg(0)?)?;
            if object.class != "[B" {
                return Err("Base64 input requires byte[]".into());
            }
            let Payload::Array(bytes) = &object.payload else {
                return Err("Base64 input payload".into());
            };
            let start = if sliced { arg(1)? as usize } else { 0 };
            let count = if sliced {
                arg(2)? as usize
            } else {
                bytes.len()
            };
            let end = start
                .checked_add(count)
                .filter(|end| *end <= bytes.len())
                .ok_or_else(|| {
                    fault(
                        "Ljava/lang/ArrayIndexOutOfBoundsException;",
                        "Base64 input range",
                    )
                })?;
            bytes[start..end].iter().map(|v| *v as u8).collect()
        };
        let flags = arg(if sliced { 3 } else { 1 })?;
        let output = if method.starts_with("decode(") {
            decode(&input, flags).ok_or_else(|| {
                fault(
                    "Ljava/lang/IllegalArgumentException;",
                    "Invalid Base64 input",
                )
            })?
        } else {
            encode(&input, flags)
        };
        if output.len() > 16384 {
            return Err("Base64 result quota".into());
        }
        Ok(Some(if method.starts_with("encodeToString(") {
            self.string_units(output.into_iter().map(|v| v as u16).collect())? as u64
        } else {
            self.allocate(
                "[B",
                Payload::Array(output.into_iter().map(|v| v as i8 as i64 as u64).collect()),
            )? as u64
        }))
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn bytes(text: &str) -> Vec<u8> {
        text.as_bytes()
            .as_chunks::<2>()
            .0
            .iter()
            .map(|v| u8::from_str_radix(std::str::from_utf8(v).unwrap(), 16).unwrap())
            .collect()
    }
    fn vm() -> Runtime {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/rift-native-demo.apk");
        let p = crate::package::Package::open(&path, "auto").unwrap();
        Runtime::new(
            p.dex,
            Machine::new(64, 32, 8).unwrap(),
            p.libraries,
            4 * 1024 * 1024,
        )
    }
    #[test]
    fn codec_matches_4248_cases_from_unmodified_android_api28() {
        let cases: serde_json::Value = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../tests/fixtures/android-base64.json"
        )))
        .unwrap();
        let encodings = cases["encoding"].as_array().unwrap();
        assert_eq!(encodings.len(), 2048);
        for (index, row) in encodings.iter().enumerate() {
            assert_eq!(
                encode(
                    &bytes(row["input"].as_str().unwrap()),
                    row["flags"].as_u64().unwrap() as u32
                ),
                bytes(row["output"].as_str().unwrap()),
                "encoding {index}: {row}"
            );
        }
        let decodings = cases["decoding"].as_array().unwrap();
        assert_eq!(decodings.len(), 2200);
        for (index, row) in decodings.iter().enumerate() {
            let expected = row.get("output").and_then(|v| v.as_str()).map(bytes);
            assert_eq!(
                decode(
                    &bytes(row["input"].as_str().unwrap()),
                    row["flags"].as_u64().unwrap() as u32
                ),
                expected,
                "decoding {index}: {row}"
            );
        }
    }
    #[test]
    fn invalid_slice_fails_before_a_result_object_is_allocated() {
        let mut vm = vm();
        let input = vm.allocate("[B", Payload::Array(vec![1, 2, 3])).unwrap();
        let before = vm.heap.len();
        for (offset, count) in [(u32::MAX, 1), (0, u32::MAX), (2, 2), (4, 0)] {
            let error = vm
                .hle(
                    "Landroid/util/Base64;->encodeToString([BIII)Ljava/lang/String;",
                    &[input, offset, count, 2],
                )
                .unwrap_err();
            assert!(error.to_string().contains("ArrayIndexOutOfBoundsException"));
            assert_eq!(vm.heap.len(), before);
        }
    }
    #[test]
    fn output_quota_and_padding_errors_do_not_change_source_data() {
        let mut vm = vm();
        let input = vm.allocate("[B", Payload::Array(vec![255; 16384])).unwrap();
        let before = vm.heap.len();
        let error = vm
            .hle("Landroid/util/Base64;->encode([BI)[B", &[input, 2])
            .unwrap_err();
        assert!(error.to_string().contains("quota"));
        assert_eq!(vm.heap.len(), before);
        let bad = vm.string("AA= bad").unwrap();
        let error = vm
            .hle(
                "Landroid/util/Base64;->decode(Ljava/lang/String;I)[B",
                &[bad, 0],
            )
            .unwrap_err();
        assert!(error.to_string().contains("IllegalArgumentException"));
        let Payload::Array(values) = &vm.object(input).unwrap().payload else {
            panic!()
        };
        assert!(values.iter().all(|v| *v == 255));
    }
}
