//! Android Paint state used by text and emoji compatibility checks.
use super::*;

pub(super) const PAINT: &str = "Landroid/graphics/Paint;";
pub(super) const TEXT_PAINT: &str = "Landroid/text/TextPaint;";

#[derive(Clone, Copy)]
pub(super) struct Paint {
    size: f32,
    flags: u32,
}

impl Default for Paint {
    fn default() -> Self {
        Self {
            size: 12.0,
            flags: 0x100 | 0x400,
        }
    }
}

impl Runtime {
    pub fn prepare_system_fonts(&mut self) {
        self.fonts = crate::fonts::Fonts::system();
    }

    fn paint(&self, id: u32) -> Result<Paint> {
        match self.object(id)?.payload {
            Payload::Paint(paint) => Ok(paint),
            _ => Err("Expected Android Paint".into()),
        }
    }

    pub(super) fn paint_api(&mut self, signature: &str, args: &[u32]) -> Result<Option<u64>> {
        let (class, method) = signature.split_once("->").ok_or("Paint signature")?;
        if !matches!(class, PAINT | TEXT_PAINT) {
            return Ok(None);
        }
        let arg = |index: usize| args.get(index).copied().ok_or("Paint argument count");
        let id = arg(0)?;
        let mut paint = self.paint(id)?;
        match method {
            "<init>()V" | "reset()V" => paint = Paint::default(),
            "<init>(I)V" => {
                paint = Paint {
                    flags: Paint::default().flags | arg(1)?,
                    ..Paint::default()
                }
            }
            "<init>(Landroid/graphics/Paint;)V" | "set(Landroid/graphics/Paint;)V" => {
                paint = self.paint(arg(1)?)?;
            }
            "setTextSize(F)V" => {
                let size = f32::from_bits(arg(1)?);
                if size >= 0.0 {
                    paint.size = size;
                }
            }
            "getTextSize()F" => return Ok(Some(u64::from(paint.size.to_bits()))),
            "setFlags(I)V" => paint.flags = arg(1)?,
            "getFlags()I" => return Ok(Some(u64::from(paint.flags))),
            "setAntiAlias(Z)V" => paint.flags = (paint.flags & !1) | u32::from(arg(1)? != 0),
            "isAntiAlias()Z" => return Ok(Some(u64::from(paint.flags & 1))),
            "hasGlyph(Ljava/lang/String;)Z" => {
                let text = self.units(arg(1)?)?;
                return Ok(Some(u64::from(self.fonts.has_glyph(&text)?)));
            }
            _ => return Ok(None),
        }
        self.object_mut(id)?.payload = Payload::Paint(paint);
        Ok(Some(0))
    }
}
