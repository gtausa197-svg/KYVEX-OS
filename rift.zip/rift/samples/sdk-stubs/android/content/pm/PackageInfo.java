package android.content.pm;
public class PackageInfo {
    public String packageName,versionName;
    public int versionCode,versionCodeMajor;
    public ApplicationInfo applicationInfo;
    public long getLongVersionCode(){return 0;}
}
