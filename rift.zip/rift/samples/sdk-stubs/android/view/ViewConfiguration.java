package android.view;
import android.content.Context;
public class ViewConfiguration {
    public static ViewConfiguration get(Context context) { return null; }
    public static int getTapTimeout() { return 0; }
    public static int getDoubleTapTimeout() { return 0; }
    public static int getLongPressTimeout() { return 0; }
    public static int getPressedStateDuration() { return 0; }
    public static float getScrollFriction() { return 0; }
    public static long getDefaultActionModeHideDuration() { return 0; }
    public int getScaledTouchSlop() { return 0; }
    public int getScaledPagingTouchSlop() { return 0; }
    public int getScaledHoverSlop() { return 0; }
    public int getScaledDoubleTapSlop() { return 0; }
    public int getScaledMinimumFlingVelocity() { return 0; }
    public int getScaledMaximumFlingVelocity() { return 0; }
    public float getScaledHorizontalScrollFactor() { return 0; }
    public float getScaledVerticalScrollFactor() { return 0; }
    public boolean hasPermanentMenuKey() { return false; }
    public boolean shouldShowMenuShortcutsWhenKeyboardPresent() { return false; }
}
