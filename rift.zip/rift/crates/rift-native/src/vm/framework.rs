//! Package metadata belongs to the guest APK, never to the desktop account.
use super::*;
#[derive(Clone)]
pub(super) struct Metadata {
    pub package: String,
    pub version: String,
    pub code: u64,
    pub application: String,
    pub min_sdk: u32,
    pub target_sdk: u32,
    pub app_meta: BTreeMap<String, rift_core::apk::MetaValue>,
    pub process: String,
    pub providers: Vec<rift_core::apk::Provider>,
    pub services: Vec<rift_core::apk::Service>,
}
impl Metadata {
    pub fn bytes(&self) -> usize {
        128 + self.process.len()
            + self
                .services
                .iter()
                .map(|s| {
                    256 + s.name.len()
                        + s.process.len()
                        + s.permission.len()
                        + s.meta_data
                            .iter()
                            .map(|(k, v)| {
                                64 + k.len()
                                    + if let rift_core::apk::MetaValue::String(s) = v {
                                        s.len()
                                    } else {
                                        0
                                    }
                            })
                            .sum::<usize>()
                })
                .sum::<usize>()
            + self
                .providers
                .iter()
                .map(|p| {
                    256 + p.name.len()
                        + p.process.len()
                        + p.authorities.len()
                        + p.read_permission.len()
                        + p.write_permission.len()
                        + p.meta_data
                            .iter()
                            .map(|(k, v)| {
                                k.len()
                                    + 64
                                    + if let rift_core::apk::MetaValue::String(s) = v {
                                        s.len()
                                    } else {
                                        0
                                    }
                            })
                            .sum::<usize>()
                })
                .sum::<usize>()
            + self.package.len()
            + self.version.len()
            + self.application.len()
            + self
                .app_meta
                .iter()
                .map(|(k, v)| {
                    64 + k.len()
                        + if let rift_core::apk::MetaValue::String(s) = v {
                            s.len()
                        } else {
                            0
                        }
                })
                .sum::<usize>()
    }
}
pub(super) fn declared_field(class: &str, name: &str) -> Option<(&'static str, u32)> {
    if let Some(field) = rect::declared_field(class, name) {
        return Some(field);
    }
    if class == pair::PAIR {
        return pair::declared_field(class, name);
    }
    let descriptor = match (class, name) {
        (point::POINT, "x" | "y") => "I",
        ("Landroid/content/pm/PackageItemInfo;", "metaData") => "Landroid/os/Bundle;",
        ("Landroid/content/pm/PackageItemInfo;", "packageName" | "name") => "Ljava/lang/String;",
        ("Landroid/content/pm/ApplicationInfo;", "dataDir" | "className" | "nativeLibraryDir") => {
            "Ljava/lang/String;"
        }
        ("Landroid/content/pm/ApplicationInfo;", "minSdkVersion" | "targetSdkVersion") => "I",
        ("Landroid/content/pm/ComponentInfo;", "applicationInfo") => {
            "Landroid/content/pm/ApplicationInfo;"
        }
        ("Landroid/content/pm/ComponentInfo;", "processName") => "Ljava/lang/String;",
        ("Landroid/content/pm/ComponentInfo;", "enabled" | "exported" | "directBootAware") => "Z",
        (
            "Landroid/content/pm/ProviderInfo;",
            "authority" | "readPermission" | "writePermission",
        ) => "Ljava/lang/String;",
        ("Landroid/content/pm/ProviderInfo;", "initOrder" | "flags") => "I",
        ("Landroid/content/pm/ProviderInfo;", "grantUriPermissions") => "Z",
        ("Landroid/content/pm/ServiceInfo;", "permission") => "Ljava/lang/String;",
        ("Landroid/content/pm/PackageInfo;", "packageName" | "versionName") => "Ljava/lang/String;",
        ("Landroid/content/pm/PackageInfo;", "versionCode" | "versionCodeMajor") => "I",
        ("Landroid/content/pm/PackageInfo;", "applicationInfo") => {
            "Landroid/content/pm/ApplicationInfo;"
        }
        _ => return None,
    };
    Some((descriptor, 1))
}
pub(super) fn field(class: &str, name: &str) -> Option<(&'static str, u32)> {
    resources_api::declared_field(class, name)
        .or_else(|| services::declared_field(class, name))
        .or_else(|| declared_field(class, name))
        .or_else(|| {
            let parent = match class {
                "Landroid/content/pm/ApplicationInfo;" | "Landroid/content/pm/ComponentInfo;" => {
                    "Landroid/content/pm/PackageItemInfo;"
                }
                "Landroid/content/pm/ProviderInfo;" | "Landroid/content/pm/ServiceInfo;" => {
                    "Landroid/content/pm/ComponentInfo;"
                }
                _ => return None,
            };
            field(parent, name)
        })
}
pub(super) fn instance_field(class: &str, name: &str, descriptor: &str) -> bool {
    field(class, name).is_some_and(|(d, _)| d == descriptor)
}
pub(super) fn record_reference(class: &str, name: &str) -> bool {
    if class == "Landroid/os/Message;" {
        matches!(name, "target" | "callback" | "obj" | "replyTo" | "data")
    } else if class == "Ljava/util/Locale;" {
        matches!(name, "language" | "country")
    } else {
        field(class, name).is_some_and(|(d, _)| d.starts_with(['L', '[']))
    }
}
pub(super) fn payload(class: &str) -> Option<Payload> {
    matches!(
        class,
        "Landroid/content/pm/ApplicationInfo;"
            | point::POINT
            | "Landroid/content/pm/PackageItemInfo;"
            | "Landroid/content/pm/PackageInfo;"
            | "Landroid/content/pm/ComponentInfo;"
            | "Landroid/content/pm/ProviderInfo;"
            | "Landroid/content/pm/ServiceInfo;"
            | "Landroid/content/res/Configuration;"
            | "Landroid/util/DisplayMetrics;"
            | "Landroid/util/TypedValue;"
            | "Landroid/app/ActivityManager$RunningAppProcessInfo;"
    )
    .then(|| Payload::Record(BTreeMap::new()))
}
impl Runtime {
    pub fn configure_package(&mut self, info: &rift_core::apk::Apk) -> Result<()> {
        if self.application != 0 || !rift_core::apk::package_valid(&info.package) {
            return Err("Package metadata must be configured before application startup".into());
        }
        self.metadata = Some(Metadata {
            package: info.package.clone(),
            version: info.version.clone(),
            code: info.version_code,
            application: info.application.clone(),
            min_sdk: info.min_sdk.max(1),
            target_sdk: if info.target_sdk == 0 {
                info.min_sdk.max(1)
            } else {
                info.target_sdk
            },
            app_meta: info.application_meta.clone(),
            process: info.process.clone(),
            providers: info.providers.clone(),
            services: info.services.clone(),
        });
        Ok(())
    }
    fn guest_application_info(&mut self) -> Result<u32> {
        if self.application_info != 0 {
            return Ok(self.application_info);
        }
        self.application_info = self.new_application_info(true)?;
        Ok(self.application_info)
    }
    pub(super) fn new_application_info(&mut self, with_metadata: bool) -> Result<u32> {
        let data_dir = self.string_units(self.files.cwd.clone())?;
        let libraries = self.string(&self.native_library_dir())?;
        let package = self.string(&self.package_name.clone())?;
        let mut values = BTreeMap::from([
            ("dataDir".into(), data_dir as u64),
            ("nativeLibraryDir".into(), libraries as u64),
            ("packageName".into(), package as u64),
        ]);
        if let Some((app_meta, application, min_sdk, target_sdk)) =
            self.metadata.as_ref().map(|m| {
                (
                    if with_metadata {
                        m.app_meta.clone()
                    } else {
                        BTreeMap::new()
                    },
                    m.application.clone(),
                    m.min_sdk,
                    m.target_sdk,
                )
            })
        {
            if !app_meta.is_empty() {
                let bundle = self.metadata_bundle(app_meta)?;
                values.insert("metaData".into(), bundle as u64);
            }
            let name = if application.is_empty() {
                0
            } else {
                self.string(&application)?
            };
            values.extend([
                ("className".into(), name as u64),
                ("name".into(), name as u64),
                ("minSdkVersion".into(), min_sdk as u64),
                ("targetSdkVersion".into(), target_sdk as u64),
            ]);
        }
        self.allocate(
            "Landroid/content/pm/ApplicationInfo;",
            Payload::Record(values),
        )
    }
    fn check_guest_package(&self, id: u32) -> Result<()> {
        if self.text(id)? != self.package_name {
            return Err(fault(
                "Landroid/content/pm/PackageManager$NameNotFoundException;",
                "Package is not installed in this guest",
            ));
        }
        Ok(())
    }
    pub(super) fn metadata_bundle(
        &mut self,
        metadata: BTreeMap<String, rift_core::apk::MetaValue>,
    ) -> Result<u32> {
        let mut bundle = BTreeMap::new();
        for (key, value) in metadata {
            use rift_core::apk::MetaValue;
            let (kind, value) = match value {
                MetaValue::String(s) => ('S', self.string(&s)? as u64),
                MetaValue::Integer(v) => ('I', v as u32 as u64),
                MetaValue::Boolean(v) => ('Z', v as u64),
                MetaValue::FloatBits(v) => ('F', v as u64),
                MetaValue::Resource(v) => ('I', v as u64),
                MetaValue::Reference(v) => ('R', v as u64),
                MetaValue::Null => ('S', 0),
            };
            bundle.insert(
                Some(key.encode_utf16().collect()),
                objects::BundleValue { kind, value },
            );
        }
        self.allocate("Landroid/os/Bundle;", Payload::Bundle(bundle))
    }
    fn service_information(&mut self, component: u32, flags: u32) -> Result<u32> {
        let Payload::Component { package, name } = self.object(component)?.payload else {
            return Err("getServiceInfo requires ComponentName".into());
        };
        self.check_guest_package(package)?;
        let name = self.text(name)?;
        let service = self
            .metadata
            .as_ref()
            .and_then(|m| m.services.iter().find(|s| s.name == name))
            .cloned()
            .ok_or_else(|| {
                fault(
                    "Landroid/content/pm/PackageManager$NameNotFoundException;",
                    &name,
                )
            })?;
        let mut enabled = service.enabled;
        if let Some(id) = service.enabled_resource {
            self.apk_resources()?;
            let (_, value) = self.resource_value(id)?;
            if !(0x10..=0x1f).contains(&value.kind) {
                return Err("Service enabled resource is not boolean".into());
            }
            enabled &= value.data != 0;
        }
        if !enabled && flags & 512 == 0 {
            return Err(fault(
                "Landroid/content/pm/PackageManager$NameNotFoundException;",
                &name,
            ));
        }
        let name = self.string(&service.name)?;
        let package = self.string(&self.package_name.clone())?;
        let process = if service.process.is_empty() {
            self.guest_process_name()
        } else if service.process.starts_with(':') {
            format!("{}{}", self.package_name, service.process)
        } else {
            service.process
        };
        let process = self.string(&process)?;
        let permission = if service.permission.is_empty() {
            0
        } else {
            self.string(&service.permission)?
        };
        let app = self.new_application_info(flags & 128 != 0)?;
        let meta = if flags & 128 != 0 && !service.meta_data.is_empty() {
            self.metadata_bundle(service.meta_data)?
        } else {
            0
        };
        self.allocate(
            "Landroid/content/pm/ServiceInfo;",
            Payload::Record(BTreeMap::from([
                ("name".into(), name as u64),
                ("packageName".into(), package as u64),
                ("processName".into(), process as u64),
                ("permission".into(), permission as u64),
                ("applicationInfo".into(), app as u64),
                ("metaData".into(), meta as u64),
                ("enabled".into(), enabled as u64),
                ("directBootAware".into(), service.direct_boot_aware as u64),
                (
                    "exported".into(),
                    service.exported.unwrap_or(service.has_intent_filter) as u64,
                ),
            ])),
        )
    }
    pub(super) fn framework_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Framework signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Framework argument count");
        if method
            == "loadXmlMetaData(Landroid/content/pm/PackageManager;Ljava/lang/String;)Landroid/content/res/XmlResourceParser;"
        {
            let id = arg(0)?;
            let object = self.object(id)?;
            if self.subclass(&object.class, "Landroid/content/pm/PackageItemInfo;")? {
                let Payload::Record(fields) = &object.payload else {
                    return Err("Expected PackageItemInfo metadata".into());
                };
                let field = |name| fields.get(name).copied().unwrap_or(0) as u32;
                let metadata = field("metaData");
                if metadata == 0 {
                    return Ok(Some(0));
                }
                let package = field("packageName");
                let application =
                    if self.subclass(&object.class, "Landroid/content/pm/ApplicationInfo;")? {
                        id
                    } else {
                        field("applicationInfo")
                    };
                let res = self
                    .object_api(
                        "Landroid/os/Bundle;->getInt(Ljava/lang/String;)I",
                        &[metadata, arg(2)?],
                    )?
                    .ok_or("Package metadata resource ID")? as u32;
                if res == 0 {
                    return Ok(Some(0));
                }
                return self.collection_dispatch(
                    arg(1)?, "Landroid/content/pm/PackageManager;",
                    "getXml(Ljava/lang/String;ILandroid/content/pm/ApplicationInfo;)Landroid/content/res/XmlResourceParser;",
                    &[package, res, application],
                ).map(Some);
            }
        }
        if matches!(
            class,
            "Landroid/content/pm/ApplicationInfo;"
                | "Landroid/content/pm/PackageItemInfo;"
                | "Landroid/content/pm/PackageInfo;"
                | "Landroid/content/pm/ComponentInfo;"
                | "Landroid/content/pm/ProviderInfo;"
                | "Landroid/content/pm/ServiceInfo;"
        ) && method == "<init>()V"
        {
            self.object_mut(arg(0)?)?.payload = Payload::Record(BTreeMap::new());
            return Ok(Some(0));
        }
        if matches!(
            method,
            "getPackageManager()Landroid/content/pm/PackageManager;"
                | "getApplicationInfo()Landroid/content/pm/ApplicationInfo;"
        ) {
            let id = arg(0)?;
            if self.subclass(&self.object(id)?.class, "Landroid/content/Context;")? {
                if method.starts_with("getApplicationInfo") {
                    return Ok(Some(self.guest_application_info()? as u64));
                }
                if self.package_manager == 0 {
                    self.package_manager = self
                        .allocate("Landroid/app/ApplicationPackageManager;", Payload::Instance)?;
                }
                return Ok(Some(self.package_manager as u64));
            }
        }
        if matches!(
            class,
            "Landroid/content/pm/PackageManager;" | "Landroid/app/ApplicationPackageManager;"
        ) {
            let manager = arg(0)?;
            if manager == 0 {
                self.object(manager)?;
            }
            if manager != self.package_manager || manager == 0 {
                return Err("Unknown guest PackageManager".into());
            }
            match method {
                "hasSystemFeature(Ljava/lang/String;)Z"
                | "hasSystemFeature(Ljava/lang/String;I)Z" => {
                    let feature = arg(1)?;
                    let version = a.get(2).copied().unwrap_or(0) as i32;
                    // The virtual display has a portrait configuration. Hardware and
                    // vendor-specific services must be advertised by their implementations.
                    let portrait = feature != 0
                        && version <= 0
                        && self
                            .units(feature)?
                            .iter()
                            .copied()
                            .eq("android.hardware.screen.portrait".encode_utf16());
                    return Ok(Some(u64::from(portrait)));
                }
                "getXml(Ljava/lang/String;ILandroid/content/pm/ApplicationInfo;)Landroid/content/res/XmlResourceParser;" =>
                {
                    let info = arg(3)?;
                    let package = if info != 0 {
                        let Payload::Record(fields) = &self.object(info)?.payload else {
                            return Err("Expected ApplicationInfo for APK XML".into());
                        };
                        fields.get("packageName").copied().unwrap_or(0) as u32
                    } else {
                        arg(1)?
                    };
                    if package == 0 || self.text(package)? != self.package_name {
                        return Ok(Some(0));
                    }
                    return match self.apk_xml(arg(2)?) {
                        Ok(parser) => Ok(Some(parser as u64)),
                        Err(error)
                            if error.downcast_ref::<JavaFault>().is_some_and(|fault| {
                                fault.class == "Landroid/content/res/Resources$NotFoundException;"
                            }) =>
                        {
                            Ok(Some(0))
                        }
                        Err(error) => Err(error),
                    };
                }
                "resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;" => {
                    let authority = self.units(arg(1)?)?;
                    let flags = arg(2)?;
                    let provider = self
                        .metadata
                        .as_ref()
                        .and_then(|metadata| {
                            metadata.providers.iter().find(|p| {
                                p.authorities
                                    .split(';')
                                    .any(|a| a.encode_utf16().eq(authority.iter().copied()))
                            })
                        })
                        .cloned();
                    let Some(provider) = provider else {
                        return Ok(Some(0));
                    };
                    if !self.provider_enabled(&provider)? && flags & 512 == 0 {
                        return Ok(Some(0));
                    }
                    return Ok(Some(
                        self.new_provider_info(&provider, flags & 128 != 0)? as u64
                    ));
                }
                "getProviderInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ProviderInfo;" =>
                {
                    let Payload::Component { package, name } = self.object(arg(1)?)?.payload else {
                        return Err("getProviderInfo requires ComponentName".into());
                    };
                    self.check_guest_package(package)?;
                    let name = self.text(name)?;
                    let missing = || {
                        fault(
                            "Landroid/content/pm/PackageManager$NameNotFoundException;",
                            &name,
                        )
                    };
                    let provider = self
                        .metadata
                        .as_ref()
                        .and_then(|metadata| {
                            metadata
                                .providers
                                .iter()
                                .find(|provider| provider.name == name)
                        })
                        .cloned()
                        .ok_or_else(missing)?;
                    let flags = arg(2)?;
                    if !self.provider_enabled(&provider)? && flags & 512 == 0 {
                        return Err(missing());
                    }
                    return Ok(Some(
                        self.new_provider_info(&provider, flags & 128 != 0)? as u64
                    ));
                }
                "getServiceInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ServiceInfo;" =>
                {
                    return Ok(Some(self.service_information(arg(1)?, arg(2)?)? as u64));
                }
                "getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;" => {
                    self.check_guest_package(arg(1)?)?;
                    return Ok(Some(self.new_application_info(arg(2)? & 128 != 0)? as u64));
                }
                "getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;" => {
                    self.check_guest_package(arg(1)?)?;
                    let (package_name, version_name, code) = self
                        .metadata
                        .as_ref()
                        .map(|m| (m.package.clone(), m.version.clone(), m.code))
                        .ok_or("APK manifest metadata is not configured")?;
                    let package = self.string(&package_name)?;
                    let version = if version_name.is_empty() {
                        0
                    } else {
                        self.string(&version_name)?
                    };
                    let info = self.new_application_info(arg(2)? & 128 != 0)?;
                    let values = BTreeMap::from([
                        ("packageName".into(), package as u64),
                        ("versionName".into(), version as u64),
                        ("versionCode".into(), code as u32 as u64),
                        ("versionCodeMajor".into(), code >> 32),
                        ("applicationInfo".into(), info as u64),
                    ]);
                    return Ok(Some(
                        self.allocate("Landroid/content/pm/PackageInfo;", Payload::Record(values))?
                            as u64,
                    ));
                }
                "getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;" => {
                    self.check_guest_package(arg(1)?)?;
                    return Ok(Some(0));
                }
                _ => return Ok(None),
            }
        }
        if class == "Landroid/content/pm/PackageInfo;" && method == "getLongVersionCode()J" {
            let Payload::Record(fields) = &self.object(arg(0)?)?.payload else {
                return Err("PackageInfo payload".into());
            };
            return Ok(Some(
                fields.get("versionCode").copied().unwrap_or(0) as u32 as u64
                    | ((fields.get("versionCodeMajor").copied().unwrap_or(0) as u32 as u64) << 32),
            ));
        }
        Ok(None)
    }
}
