//! Capability to a single preopened APK, never an arbitrary host path.
use crate::{Result, dexfile::Dex};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs::File,
    io::{Read, Seek},
};
pub struct Assets {
    archive: zip::ZipArchive<rift_core::archive::CachedReader<File>>,
    fd: i32,
    libraries: BTreeMap<String, String>,
    remaining_dex: Vec<String>,
    class_index: BTreeMap<String, String>,
    loaded: BTreeSet<String>,
    pub dex_loaded: usize,
    pub libraries_loaded: usize,
}
pub fn member<R: Read + Seek>(
    zip: &mut zip::ZipArchive<R>,
    name: &str,
    limit: u64,
) -> Result<Vec<u8>> {
    let mut f = zip.by_name(name)?;
    if f.size() > limit {
        return Err(format!("APK member exceeds quota: {name}").into());
    }
    let mut b = Vec::new();
    b.try_reserve_exact(f.size() as usize).map_err(
        |_| "APK member allocation exceeds memory profile; select a larger profile if RAM permits",
    )?;
    f.by_ref().take(limit + 1).read_to_end(&mut b)?;
    if b.len() as u64 > limit {
        return Err("APK decompression quota".into());
    }
    Ok(b)
}
impl Assets {
    pub fn new(
        archive: zip::ZipArchive<rift_core::archive::CachedReader<File>>,
        fd: i32,
        libraries: BTreeMap<String, String>,
        mut dex: Vec<String>,
    ) -> Self {
        dex.retain(|n| n != "classes.dex");
        dex.reverse();
        Self {
            archive,
            fd,
            libraries,
            remaining_dex: dex,
            class_index: BTreeMap::new(),
            loaded: BTreeSet::from(["classes.dex".into()]),
            dex_loaded: 1,
            libraries_loaded: 0,
        }
    }
    pub fn fd(&self) -> i32 {
        self.fd
    }
    pub fn library_members(&mut self) -> Result<Vec<(String, String, usize)>> {
        self.libraries
            .iter()
            .map(|(name, member)| {
                let size = self.archive.by_name(member)?.size();
                Ok((name.clone(), member.clone(), usize::try_from(size)?))
            })
            .collect()
    }
    pub fn member_size(&mut self, name: &str) -> Result<usize> {
        let member = self.archive.by_name(name)?;
        if member.is_dir() {
            return Err("APK member is a directory".into());
        }
        Ok(usize::try_from(member.size())?)
    }
    pub fn read_range(&mut self, name: &str, position: u64, count: usize) -> Result<Vec<u8>> {
        let mut member = self.archive.by_name(name)?;
        if member.size() > 192 * 1024 * 1024 || position > 192 * 1024 * 1024 {
            return Err("APK stream size/seek quota (192 MiB)".into());
        }
        if position >= member.size() || count == 0 {
            return Ok(Vec::new());
        }
        // Reopen the bounded member at each read. This avoids copying a large
        // native library into the Java heap just to answer stat/read requests.
        let skipped = std::io::copy(&mut member.by_ref().take(position), &mut std::io::sink())?;
        if skipped != position {
            return Err("Truncated APK stream".into());
        }
        let mut out = Vec::new();
        member.take(count.min(65536) as u64).read_to_end(&mut out)?;
        Ok(out)
    }
    pub fn library(&mut self, name: &str) -> Result<Vec<u8>> {
        let path = self
            .libraries
            .get(name)
            .ok_or_else(|| format!("APK has no selected-ABI library {name}"))?
            .clone();
        let b = member(&mut self.archive, &path, 192 * 1024 * 1024)?;
        self.libraries_loaded += 1;
        Ok(b)
    }
    pub fn dex_for_class(&mut self, class: &str) -> Result<Option<Dex>> {
        // Framework classes cannot be supplied through this class loader.
        if class.starts_with("Ljava/")
            || class.starts_with("Landroid/")
            || class.starts_with("Lorg/kyvex/rift/internal/")
            || crate::android_json::is_platform_class(class)
        {
            return Ok(None);
        }
        loop {
            if let Some(name) = self.class_index.get(class) {
                let name = name.clone();
                if self.loaded.contains(&name) {
                    return Ok(None);
                }
                let b = member(&mut self.archive, &name, 32 * 1024 * 1024)?;
                let dex = Dex::parse(&b)?;
                self.loaded.insert(name);
                self.dex_loaded += 1;
                return Ok(Some(dex));
            }
            let Some(name) = self.remaining_dex.pop() else {
                return Ok(None);
            };
            let b = member(&mut self.archive, &name, 32 * 1024 * 1024)?;
            for class in Dex::class_names(&b)? {
                if crate::android_json::is_platform_class(&class) {
                    continue;
                }
                if self.class_index.insert(class, name.clone()).is_some() {
                    return Err("Duplicate class in multidex APK".into());
                }
            }
            if self.class_index.len() > 600000 {
                return Err("APK class index budget".into());
            }
        }
    }
    pub fn resource(&mut self, name: &str, limit: u64) -> Result<Vec<u8>> {
        if name.starts_with('/') || name.split('/').any(|p| p == "..") {
            return Err("Unsafe APK asset name".into());
        }
        member(&mut self.archive, name, limit)
    }
    pub fn resource_table(&mut self, limit: u64) -> Result<Option<Vec<u8>>> {
        match self.archive.by_name("resources.arsc") {
            Ok(_) => (),
            Err(zip::result::ZipError::FileNotFound) => return Ok(None),
            Err(e) => return Err(e.into()),
        }
        member(&mut self.archive, "resources.arsc", limit).map(Some)
    }
}
