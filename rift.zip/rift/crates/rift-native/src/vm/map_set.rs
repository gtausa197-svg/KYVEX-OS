//! Live map-backed sets; foreign DEX maps/iterators execute their actual methods.
use super::*;
const SET: &str = "Ljava/util/Collections$SetFromMap;";
impl Runtime {
    pub(super) fn collection_dispatch(
        &mut self,
        object: u32,
        owner: &str,
        method: &str,
        args: &[u32],
    ) -> Result<u64> {
        self.object(object)?;
        let (name, rest) = method
            .split_once('(')
            .ok_or("Collection callback descriptor")?;
        let descriptor = format!("({rest}");
        let mut words = Vec::with_capacity(args.len() + 1);
        words.push(object);
        words.extend(args);
        if let Some(index) = self.callback_method(object, name, &descriptor)? {
            self.invoke(index, &words, true)
        } else {
            self.hle(&format!("{owner}->{method}"), &words)
        }
    }
    pub(super) fn delegated_collection(&mut self, id: u32) -> Result<bool> {
        match self.object(id)?.payload {
            Payload::MapSet { .. } => Ok(true),
            Payload::CollectionWrapper { target, .. } => self.delegated_collection(target),
            _ => Ok(self
                .callback_method(id, "iterator", "()Ljava/util/Iterator;")?
                .is_some()),
        }
    }
    pub(super) fn map_set_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        if sig == "Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;" {
            let map = *a.first().ok_or("Map-backed set argument")?;
            if !self.subclass(&self.object(map)?.class, "Ljava/util/Map;")? {
                return Err("newSetFromMap requires a Map".into());
            }
            let mut roots = self.scoped_library_roots(&[map])?;
            if self.collection_dispatch(map, "Ljava/util/Map;", "isEmpty()Z", &[])? == 0 {
                return Err(fault(
                    "Ljava/lang/IllegalArgumentException;",
                    "Map is non-empty",
                ));
            }
            let keys =
                self.collection_dispatch(map, "Ljava/util/Map;", "keySet()Ljava/util/Set;", &[])?
                    as u32;
            roots.keep(keys)?;
            self.object(keys)?;
            return self
                .allocate(SET, Payload::MapSet { map, keys })
                .map(|id| Some(id as u64));
        }
        let Some(&id) = a.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        let (_, method) = sig.split_once("->").ok_or("Map-backed set signature")?;
        if let Payload::ReadOnlyIterator {
            iterator,
            protect_entries,
        } = object.payload
        {
            let result = match method {
                "hasNext()Z" => {
                    self.collection_dispatch(iterator, "Ljava/util/Iterator;", method, &[])?
                }
                "next()Ljava/lang/Object;" => {
                    let value =
                        self.collection_dispatch(iterator, "Ljava/util/Iterator;", method, &[])?;
                    if protect_entries {
                        let Payload::MapEntry { readonly, .. } =
                            &mut self.object_mut(value as u32)?.payload
                        else {
                            return Err("Read-only foreign map entries are not implemented".into());
                        };
                        *readonly = true;
                    }
                    value
                }
                "remove()V" => {
                    return Err(fault(
                        "Ljava/lang/UnsupportedOperationException;",
                        "Read-only iterator",
                    ));
                }
                _ => return Ok(None),
            };
            return Ok(Some(result));
        }
        let Payload::MapSet { map, keys } = object.payload else {
            return Ok(None);
        };
        let arg = |i: usize| a.get(i).copied().ok_or("Map-backed set argument count");
        let value = match method {
            "size()I" | "isEmpty()Z" | "clear()V" => {
                self.collection_dispatch(map, "Ljava/util/Map;", method, &[])?
            }
            "contains(Ljava/lang/Object;)Z" => self.collection_dispatch(
                map,
                "Ljava/util/Map;",
                "containsKey(Ljava/lang/Object;)Z",
                &[arg(1)?],
            )?,
            "remove(Ljava/lang/Object;)Z" => {
                (self.collection_dispatch(
                    map,
                    "Ljava/util/Map;",
                    "remove(Ljava/lang/Object;)Ljava/lang/Object;",
                    &[arg(1)?],
                )? != 0) as u64
            }
            "add(Ljava/lang/Object;)Z" => {
                let value = self.box_value('Z', 1)?;
                (self.collection_dispatch(
                    map,
                    "Ljava/util/Map;",
                    "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
                    &[arg(1)?, value],
                )? == 0) as u64
            }
            "addAll(Ljava/util/Collection;)Z" => {
                let incoming = arg(1)?;
                let mut roots = self.scoped_library_roots(&[id, incoming])?;
                let values = self.collection_values(incoming)?;
                for value in &values {
                    roots.keep(*value)?;
                }
                let yes = self.box_value('Z', 1)?;
                roots.keep(yes)?;
                let mut changed = false;
                for value in values {
                    changed |= self.collection_dispatch(
                        map,
                        "Ljava/util/Map;",
                        "put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
                        &[value, yes],
                    )? == 0;
                }
                changed as u64
            }
            "iterator()Ljava/util/Iterator;"
            | "toArray()[Ljava/lang/Object;"
            | "toArray([Ljava/lang/Object;)[Ljava/lang/Object;"
            | "toString()Ljava/lang/String;"
            | "hashCode()I"
            | "containsAll(Ljava/util/Collection;)Z"
            | "removeAll(Ljava/util/Collection;)Z"
            | "retainAll(Ljava/util/Collection;)Z"
            | "forEach(Ljava/util/function/Consumer;)V"
            | "removeIf(Ljava/util/function/Predicate;)Z" => {
                self.collection_dispatch(keys, "Ljava/util/Set;", method, &a[1..])?
            }
            "equals(Ljava/lang/Object;)Z" => {
                if arg(1)? == id {
                    1
                } else {
                    self.collection_dispatch(keys, "Ljava/util/Set;", method, &[arg(1)?])?
                }
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn runtime() -> Runtime {
        let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/built/rift-native-demo.apk");
        let package = crate::package::Package::open(&path, "auto").unwrap();
        Runtime::new(
            package.dex,
            Machine::new(64, 32, 8).unwrap(),
            package.libraries,
            4 * 1024 * 1024,
        )
    }
    fn set(vm: &mut Runtime) -> (u32, u32) {
        let map = vm.instantiate("Ljava/util/HashMap;").unwrap();
        let set = vm
            .hle(
                "Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;",
                &[map],
            )
            .unwrap() as u32;
        (map, set)
    }
    fn call(vm: &mut Runtime, id: u32, method: &str, args: &[u32]) -> u64 {
        vm.collection_dispatch(id, "Ljava/util/Set;", method, args)
            .unwrap()
    }
    #[test]
    fn wrapper_class_queries_keep_the_real_wrapper_and_reflected_mutex() {
        let mut vm = runtime();
        let list = vm.instantiate("Ljava/util/ArrayList;").unwrap();
        let wrapper = vm.hle("Ljava/util/Collections;->synchronizedCollection(Ljava/util/Collection;)Ljava/util/Collection;",&[list]).unwrap() as u32;
        for owner in [
            "Ljava/lang/Object;",
            "Ljava/util/Collections$SynchronizedCollection;",
            "Ljava/util/Collection;",
        ] {
            let class = vm
                .hle(&format!("{owner}->getClass()Ljava/lang/Class;"), &[wrapper])
                .unwrap() as u32;
            let Payload::Class(name) = &vm.object(class).unwrap().payload else {
                panic!()
            };
            assert_eq!(name, "Ljava/util/Collections$SynchronizedCollection;");
        }
        let class = vm
            .class_object("Ljava/util/Collections$SynchronizedCollection;")
            .unwrap();
        let name = vm.string("mutex").unwrap();
        let field = vm
            .hle(
                "Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;",
                &[class, name],
            )
            .unwrap() as u32;
        vm.hle("Ljava/lang/reflect/Field;->setAccessible(Z)V", &[field, 1])
            .unwrap();
        assert_eq!(
            vm.hle(
                "Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;",
                &[field, wrapper]
            )
            .unwrap(),
            wrapper as u64
        );
    }
    #[test]
    fn map_backed_set_keeps_the_actual_map_and_keys_alive_until_released() {
        let mut vm = runtime();
        let (map, set) = set(&mut vm);
        let key = vm.string("dynamic key").unwrap();
        assert_eq!(call(&mut vm, set, "add(Ljava/lang/Object;)Z", &[key]), 1);
        assert_eq!(call(&mut vm, set, "add(Ljava/lang/Object;)Z", &[key]), 0);
        let yes = vm.box_value('Z', 1).unwrap();
        assert_eq!(
            vm.collection_dispatch(
                map,
                "Ljava/util/Map;",
                "get(Ljava/lang/Object;)Ljava/lang/Object;",
                &[key]
            )
            .unwrap(),
            yes as u64
        );
        let Payload::MapSet { keys, .. } = vm.object(set).unwrap().payload else {
            panic!()
        };
        let roots = vm.scoped_library_roots(&[set]).unwrap();
        vm.collect().unwrap();
        for id in [map, set, keys, key] {
            assert!(vm.heap.contains_key(&id));
        }
        assert_eq!(call(&mut vm, set, "remove(Ljava/lang/Object;)Z", &[key]), 1);
        assert_eq!(call(&mut vm, set, "size()I", &[]), 0);
        drop(roots);
        vm.collect().unwrap();
        for id in [map, set, keys, key] {
            assert!(!vm.heap.contains_key(&id));
        }
        assert!(vm.execution_roots.borrow().is_empty());
    }
    #[test]
    fn read_only_iterator_keeps_its_real_backing_after_set_handles_are_collected() {
        let mut vm = runtime();
        let (map, set) = set(&mut vm);
        let key = vm.string("iterator owns backing").unwrap();
        call(&mut vm, set, "add(Ljava/lang/Object;)Z", &[key]);
        let wrapper = vm
            .hle(
                "Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;",
                &[set],
            )
            .unwrap() as u32;
        let iterator = call(&mut vm, wrapper, "iterator()Ljava/util/Iterator;", &[]) as u32;
        let roots = vm.scoped_library_roots(&[iterator]).unwrap();
        vm.collect().unwrap();
        assert!(!vm.heap.contains_key(&set) && !vm.heap.contains_key(&wrapper));
        assert!(vm.heap.contains_key(&map) && vm.heap.contains_key(&key));
        assert_eq!(
            vm.collection_dispatch(
                iterator,
                "Ljava/util/Iterator;",
                "next()Ljava/lang/Object;",
                &[]
            )
            .unwrap(),
            key as u64
        );
        let error = vm
            .collection_dispatch(iterator, "Ljava/util/Iterator;", "remove()V", &[])
            .unwrap_err();
        assert!(error.to_string().contains("UnsupportedOperationException"));
        assert_eq!(
            vm.collection_dispatch(map, "Ljava/util/Map;", "size()I", &[])
                .unwrap(),
            1
        );
        drop(roots);
        vm.collect().unwrap();
        for id in [iterator, map, key] {
            assert!(!vm.heap.contains_key(&id));
        }
    }
    #[test]
    fn scoped_library_roots_account_for_memory_and_release_on_error() {
        let mut vm = runtime();
        let before = vm.heap_bytes();
        let object = vm.string("temporary callback result").unwrap();
        let allocated = vm.heap_bytes();
        let mut roots = vm.scoped_library_roots(&[]).unwrap();
        roots.keep(object).unwrap();
        roots.keep(0).unwrap();
        assert!(vm.heap_bytes() > allocated && allocated > before);
        vm.collect().unwrap();
        assert!(vm.heap.contains_key(&object));
        for _ in 1..4112 {
            roots.keep(object).unwrap();
        }
        assert!(roots.keep(object).is_err());
        drop(roots);
        assert!(vm.execution_roots.borrow().is_empty());
        vm.collect().unwrap();
        assert!(!vm.heap.contains_key(&object));
    }
    #[test]
    fn typed_collection_arrays_check_components_and_preserve_oversized_tail() {
        let mut vm = runtime();
        let (_, set) = set(&mut vm);
        let value = vm.string("value").unwrap();
        call(&mut vm, set, "add(Ljava/lang/Object;)Z", &[value]);
        let wrong = vm
            .allocate("[Ljava/lang/Integer;", Payload::Array(Vec::new()))
            .unwrap();
        let error = vm
            .collection_dispatch(
                set,
                "Ljava/util/Set;",
                "toArray([Ljava/lang/Object;)[Ljava/lang/Object;",
                &[wrong],
            )
            .unwrap_err();
        assert!(error.to_string().contains("ArrayStoreException"));
        let tail = vm.string("tail").unwrap();
        let large = vm
            .allocate("[Ljava/lang/String;", Payload::Array(vec![tail as u64; 3]))
            .unwrap();
        assert_eq!(
            call(
                &mut vm,
                set,
                "toArray([Ljava/lang/Object;)[Ljava/lang/Object;",
                &[large]
            ),
            large as u64
        );
        let Payload::Array(values) = &vm.object(large).unwrap().payload else {
            panic!()
        };
        assert_eq!(values, &vec![value as u64, 0, tail as u64]);
        let empty = vm
            .allocate("[Ljava/lang/String;", Payload::Array(Vec::new()))
            .unwrap();
        let copied = call(
            &mut vm,
            set,
            "toArray([Ljava/lang/Object;)[Ljava/lang/Object;",
            &[empty],
        ) as u32;
        assert_ne!(copied, empty);
        assert_eq!(vm.object(copied).unwrap().class, "[Ljava/lang/String;");
    }
}
