package org.kyvex.extra;
import java.util.concurrent.atomic.*;
/** Runs unchanged on the stock JDK and on Native; no Android classes are used. */
public final class AtomicFieldChecks {
 private static int checks;
 public static final class Node {
  private volatile Object reference=new Object();
  public volatile String label="first";
  public volatile int number;
  public volatile long wide;
  public Object ordinary;
  public static volatile int shared;
  public volatile String[] array;
  public static AtomicReferenceFieldUpdater<Node,Object> referenceUpdater(){return AtomicReferenceFieldUpdater.newUpdater(Node.class,Object.class,"reference");}
 }
 public static final class ProtectedChild extends org.kyvex.other.UpdaterBase {
  static AtomicReferenceFieldUpdater<org.kyvex.other.UpdaterBase,String> updater(){return AtomicReferenceFieldUpdater.newUpdater(org.kyvex.other.UpdaterBase.class,String.class,"value");}
 }
 private static void check(boolean value,String reason){if(!value)throw new IllegalStateException(reason);checks++;}
 public static int verify(){
  checks=0;Node node=new Node();AtomicReferenceFieldUpdater<Node,Object> ref=Node.referenceUpdater();Object first=ref.get(node),second=new Object();
  check(first!=null&&first==node.reference,"updater reads actual private field");
  check(!ref.compareAndSet(node,second,null)&&node.reference==first,"failed CAS preserves actual field");
  check(ref.compareAndSet(node,first,second)&&node.reference==second,"successful identity CAS writes field");
  node.reference=first;check(ref.get(node)==first,"direct Java field writes visible to updater");
  check(ref.getAndSet(node,null)==first&&node.reference==null,"getAndSet returns old reference and accepts null");ref.lazySet(node,second);check(ref.get(node)==second,"lazySet writes reference");
  AtomicIntegerFieldUpdater<Node> ints=AtomicIntegerFieldUpdater.newUpdater(Node.class,"number");node.number=Integer.MAX_VALUE;check(ints.getAndIncrement(node)==Integer.MAX_VALUE&&node.number==Integer.MIN_VALUE,"integer updater wraps overflow");
  check(ints.compareAndSet(node,Integer.MIN_VALUE,4)&&ints.addAndGet(node,3)==7&&ints.getAndDecrement(node)==7&&node.number==6,"integer CAS and arithmetic use one real field");
  AtomicLongFieldUpdater<Node> longs=AtomicLongFieldUpdater.newUpdater(Node.class,"wide");node.wide=0x1122334455667788L;check(longs.get(node)==0x1122334455667788L&&longs.getAndAdd(node,3)==0x1122334455667788L&&node.wide==0x112233445566778bL,"long updater preserves all 64 bits");
  node.wide=Long.MAX_VALUE;check(longs.incrementAndGet(node)==Long.MIN_VALUE&&longs.compareAndSet(node,Long.MIN_VALUE,-1L)&&node.wide==-1L,"long overflow and wide CAS arguments");
  AtomicReferenceFieldUpdater<Node,Object> other=Node.referenceUpdater();check(other.get(node)==second&&other.compareAndSet(node,second,first)&&ref.get(node)==first,"two updaters share backing field");
  boolean rejected=false;try{AtomicReferenceFieldUpdater.newUpdater(Node.class,Integer.class,"label");}catch(ClassCastException expected){rejected=true;}check(rejected,"reference factory requires exact declared type");
  rejected=false;try{AtomicReferenceFieldUpdater.newUpdater(Node.class,Object.class,"ordinary");}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"nonvolatile field rejected");
  rejected=false;try{AtomicIntegerFieldUpdater.newUpdater(Node.class,"wide");}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"primitive field type mismatch rejected");
  rejected=false;try{AtomicIntegerFieldUpdater.newUpdater(Node.class,"shared");}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"static field rejected");
  rejected=false;try{AtomicIntegerFieldUpdater.newUpdater(Node.class,"missing");}catch(RuntimeException expected){rejected=expected.getCause() instanceof NoSuchFieldException;}check(rejected,"missing field preserves reflection cause");
  rejected=false;try{AtomicReferenceFieldUpdater.newUpdater(Node.class,Object.class,"reference");}catch(RuntimeException expected){rejected=expected.getCause() instanceof IllegalAccessException;}check(rejected,"private field access checked against actual Java caller");
  int blocked=0;try{((AtomicReferenceFieldUpdater)ref).get("wrong");}catch(ClassCastException expected){blocked++;}try{ref.get(null);}catch(ClassCastException expected){blocked++;}check(blocked==2,"invalid and null receivers rejected");
  AtomicReferenceFieldUpdater<Node,String> label=AtomicReferenceFieldUpdater.newUpdater(Node.class,String.class,"label");rejected=false;try{((AtomicReferenceFieldUpdater)label).set(node,Integer.valueOf(1));}catch(ClassCastException expected){rejected=true;}check(rejected&&"first".equals(node.label),"reference write type checked before mutation");
  check(!((AtomicReferenceFieldUpdater)label).compareAndSet(node,Integer.valueOf(1),"after")&&"first".equals(node.label),"expected reference compared by identity without a value cast");
  AtomicReferenceFieldUpdater<Node,String[]> arrays=AtomicReferenceFieldUpdater.newUpdater(Node.class,String[].class,"array");String[] actual={"array"};arrays.set(node,actual);rejected=false;try{((AtomicReferenceFieldUpdater)arrays).set(node,new Object[0]);}catch(ClassCastException expected){rejected=true;}check(rejected&&node.array==actual,"reference array component type enforced");
  ProtectedChild child=new ProtectedChild();AtomicReferenceFieldUpdater<org.kyvex.other.UpdaterBase,String> protectedField=ProtectedChild.updater();protectedField.set(child,"child");rejected=false;try{protectedField.get(new org.kyvex.other.UpdaterBase());}catch(RuntimeException expected){rejected=expected.getCause() instanceof IllegalAccessException;}check(rejected&&"child".equals(protectedField.get(child)),"cross-package protected updater restricts receiver to caller subclass");
  String[] source={"before"};AtomicReferenceArray<Object> references=new AtomicReferenceArray<Object>(source);source[0]="outside";check(references.length()==1&&"before".equals(references.get(0)),"atomic reference array copies constructor input");
  check(references.compareAndSet(0,"before",second)&&references.getAndSet(0,null)==second&&references.get(0)==null,"atomic array CAS and getAndSet preserve identity and null");references.lazySet(0,Integer.valueOf(9));
  blocked=0;try{references.get(-1);}catch(IndexOutOfBoundsException expected){blocked++;}try{references.set(1,null);}catch(IndexOutOfBoundsException expected){blocked++;}try{new AtomicReferenceArray<Object>(-1);}catch(NegativeArraySizeException expected){blocked++;}check(blocked==3&&references.get(0) instanceof Integer,"atomic array checks bounds and permits independent reference types");
  int[] sourceInts={Integer.MAX_VALUE};AtomicIntegerArray integerArray=new AtomicIntegerArray(sourceInts);check(integerArray.getAndIncrement(0)==Integer.MAX_VALUE&&integerArray.get(0)==Integer.MIN_VALUE&&integerArray.compareAndSet(0,Integer.MIN_VALUE,5)&&integerArray.addAndGet(0,-2)==3&&sourceInts[0]==Integer.MAX_VALUE,"atomic integer array copies input and wraps arithmetic");
  AtomicLongArray longArray=new AtomicLongArray(new long[]{0x1122334455667788L});check(longArray.getAndSet(0,Long.MAX_VALUE)==0x1122334455667788L&&longArray.incrementAndGet(0)==Long.MIN_VALUE&&longArray.compareAndSet(0,Long.MIN_VALUE,-1L)&&longArray.get(0)==-1L,"atomic long array uses full-width CAS and overflow");
  return checks;
 }
 public static void main(String[] args){System.out.println("Atomic field checks: "+verify());}
}
