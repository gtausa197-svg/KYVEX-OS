//! Zero-capacity queue. Values live only in waiting or matched guest calls.
use super::*;

enum Partner {
    Thread { id: u32, value: u32 },
    Worker(u32),
}

impl Runtime {
    pub(in crate::vm) fn transfer_now(&mut self, queue: u32, value: u32) -> Result<Option<u64>> {
        let Payload::HandoffQueue(Some(fair)) = self.object(queue)?.payload else {
            return Err("Expected initialized SynchronousQueue".into());
        };
        if value != 0 {
            self.object(value)?;
        }
        let now = Instant::now();
        let mut nearest = None;
        for (&thread, record) in &self.scheduler.records {
            if record.interrupted {
                continue;
            }
            let partner = match &record.state {
                State::Waiting(Wait::Handoff {
                    queue: waiting_queue,
                    value: waiting_value,
                    until,
                }) if *waiting_queue == queue
                    && (*waiting_value == 0) != (value == 0)
                    && until.is_none_or(|time| time > now) =>
                {
                    Partner::Thread {
                        id: thread,
                        value: *waiting_value,
                    }
                }
                State::Waiting(Wait::Executor { worker, until })
                    if value != 0
                        && until.is_none_or(|time| time > now)
                        && self.pool_accepts_handoff(*worker, queue)? =>
                {
                    Partner::Worker(*worker)
                }
                _ => continue,
            };
            let order = if fair {
                record.wait_order
            } else {
                u64::MAX - record.wait_order
            };
            if nearest.as_ref().is_none_or(|(best, _)| order < *best) {
                nearest = Some((order, partner));
            }
        }
        let Some((_, partner)) = nearest else {
            return Ok(None);
        };
        match partner {
            Partner::Thread { id, value: sent } if value == 0 => {
                self.ready_guest_thread(id, Completion::Value(1))?;
                Ok(Some(sent as u64))
            }
            Partner::Thread { id, .. } => {
                self.ready_guest_thread(id, Completion::Reference(value))?;
                Ok(Some(1))
            }
            Partner::Worker(worker) => {
                self.assign_pool_handoff(worker, value)?;
                Ok(Some(1))
            }
        }
    }

    fn transfer_wait(&mut self, queue: u32, value: u32, timeout: Option<i64>) -> Result<u64> {
        if let Some(result) = self.transfer_now(queue, value)? {
            return Ok(result);
        }
        self.check_interrupted()?;
        if timeout.is_some_and(|time| time <= 0) {
            return Ok(0);
        }
        let until = timeout
            .map(|time| Self::deadline(time as u64).ok_or("SynchronousQueue timeout range"))
            .transpose()?;
        self.suspend(Wait::Handoff {
            queue,
            value,
            until,
        })
    }

    fn drain_handoffs(&mut self, queue: u32, target: u32, limit: i32) -> Result<u64> {
        self.object(target)?;
        if target == queue {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Cannot drain into the same queue",
            ));
        }
        let _roots = self.scoped_library_roots(&[queue, target])?;
        let mut drained = 0;
        while drained < limit {
            let Some(value) = self.transfer_now(queue, 0)? else {
                break;
            };
            let _value_root = self.scoped_library_roots(&[value as u32])?;
            self.collection_dispatch(
                target,
                "Ljava/util/Collection;",
                "add(Ljava/lang/Object;)Z",
                &[value as u32],
            )?;
            drained += 1;
        }
        Ok(drained as u64)
    }

    pub(in crate::vm) fn handoff_queue_api(
        &mut self,
        sig: &str,
        args: &[u32],
    ) -> Result<Option<u64>> {
        let Some(&id) = args.first() else {
            return Ok(None);
        };
        let Some(object) = self.heap.get(&id) else {
            return Ok(None);
        };
        let (class, method) = sig.split_once("->").ok_or("SynchronousQueue signature")?;
        let arg = |i: usize| {
            args.get(i)
                .copied()
                .ok_or("SynchronousQueue argument count")
        };
        let send = |vm: &Self| -> Result<u32> {
            let value = arg(1)?;
            vm.object(value)?;
            Ok(value)
        };
        if class == HANDOFF_QUEUE && matches!(method, "<init>()V" | "<init>(Z)V") {
            if !self.subclass(&object.class, HANDOFF_QUEUE)? {
                return Err("Expected SynchronousQueue constructor receiver".into());
            }
            let fair = method == "<init>(Z)V" && arg(1)? != 0;
            self.object_mut(id)?.payload = Payload::HandoffQueue(Some(fair));
            return Ok(Some(0));
        }
        if !matches!(object.payload, Payload::HandoffQueue(Some(_))) {
            return Ok(None);
        }
        let nanos = |vm: &Self, index: usize| -> Result<i64> {
            let time = u64::from(arg(index)?) | (u64::from(arg(index + 1)?) << 32);
            vm.timeout_nanos(time as i64, arg(index + 2)?)
        };
        Ok(Some(match method {
            "offer(Ljava/lang/Object;)Z" => self.transfer_now(id, send(self)?)?.unwrap_or(0),
            "offer(Ljava/lang/Object;JLjava/util/concurrent/TimeUnit;)Z" => {
                self.transfer_wait(id, send(self)?, Some(nanos(self, 2)?))?
            }
            "put(Ljava/lang/Object;)V" => self.transfer_wait(id, send(self)?, None)?,
            "poll()Ljava/lang/Object;" => self.transfer_now(id, 0)?.unwrap_or(0),
            "poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;" => {
                self.transfer_wait(id, 0, Some(nanos(self, 1)?))?
            }
            "take()Ljava/lang/Object;" => self.transfer_wait(id, 0, None)?,
            "add(Ljava/lang/Object;)Z" => self
                .transfer_now(id, send(self)?)?
                .ok_or_else(|| fault("Ljava/lang/IllegalStateException;", "Queue full"))?,
            "remove()Ljava/lang/Object;" => self
                .transfer_now(id, 0)?
                .ok_or_else(|| fault("Ljava/util/NoSuchElementException;", "Queue empty"))?,
            "element()Ljava/lang/Object;" => {
                return Err(fault("Ljava/util/NoSuchElementException;", "Queue empty"));
            }
            "size()I"
            | "remainingCapacity()I"
            | "peek()Ljava/lang/Object;"
            | "contains(Ljava/lang/Object;)Z"
            | "remove(Ljava/lang/Object;)Z"
            | "clear()V" => 0,
            "isEmpty()Z" => 1,
            "toString()Ljava/lang/String;" => self.string("[]")? as u64,
            "iterator()Ljava/util/Iterator;" => {
                let empty = self
                    .collections_api("Ljava/util/Collections;->emptyList()Ljava/util/List;", &[])?
                    .ok_or("Empty collection for SynchronousQueue iterator")?
                    as u32;
                let _roots = self.scoped_library_roots(&[empty])?;
                self.collections_api("Ljava/util/List;->iterator()Ljava/util/Iterator;", &[empty])?
                    .ok_or("SynchronousQueue empty iterator")?
            }
            "toArray()[Ljava/lang/Object;" => {
                self.allocate("[Ljava/lang/Object;", Payload::Array(Vec::new()))? as u64
            }
            "toArray([Ljava/lang/Object;)[Ljava/lang/Object;" => {
                let array = arg(1)?;
                let object = self.object_mut(array)?;
                if !object.class.starts_with("[L") && !object.class.starts_with("[[") {
                    return Err("SynchronousQueue toArray requires a reference array".into());
                }
                let Payload::Array(values) = &mut object.payload else {
                    return Err("SynchronousQueue toArray requires an object array".into());
                };
                if let Some(first) = values.first_mut() {
                    *first = 0;
                }
                array as u64
            }
            "drainTo(Ljava/util/Collection;)I" => self.drain_handoffs(id, arg(1)?, i32::MAX)?,
            "drainTo(Ljava/util/Collection;I)I" => {
                self.drain_handoffs(id, arg(1)?, arg(2)? as i32)?
            }
            "containsAll(Ljava/util/Collection;)Z" => {
                self.collection_dispatch(arg(1)?, "Ljava/util/Collection;", "isEmpty()Z", &[])?
            }
            "hashCode()I" => id as u64,
            "equals(Ljava/lang/Object;)Z" => (arg(1)? == id) as u64,
            _ => return Ok(None),
        }))
    }
}
