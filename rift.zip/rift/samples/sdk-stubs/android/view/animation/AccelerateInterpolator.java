package android.view.animation;
public class AccelerateInterpolator extends BaseInterpolator {
    public AccelerateInterpolator() {}
    public AccelerateInterpolator(float amount) {}
    public float getInterpolation(float input) { return 0; }
}
