package org.kyvex.extra;

import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.regex.Pattern;

public final class ManagedTextChecks {
    private static int checks;

    private static void check(boolean condition, String name) {
        if (!condition) throw new IllegalStateException(name);
        checks++;
    }

    public static int verify() {
        checks = 0;
        DecimalFormat defaults = new DecimalFormat();
        check("1,234.5".equals(defaults.format(1234.5)), "Default decimal grouping and fraction");
        check("-9,223,372,036,854,775,808".equals(defaults.format(Long.MIN_VALUE)), "Exact long minimum");
        check("9,007,199,254,740,993".equals(defaults.format(9007199254740993L)), "No conversion of long to double");
        String nan = defaults.format(Double.NaN);
        check(("NaN".equals(nan) || "\uFFFD".equals(nan))
                && "-\u221e".equals(defaults.format(Double.NEGATIVE_INFINITY)),
                "Decimal special values");
        defaults.setGroupingUsed(false);
        check(!defaults.isGroupingUsed() && "1234.5".equals(defaults.format(1234.5)), "Independent grouping control");
        defaults.setMinimumFractionDigits(4);
        check(defaults.getMinimumFractionDigits() == 4 && defaults.getMaximumFractionDigits() == 4
                && "1234.5000".equals(defaults.format(1234.5)), "Minimum raises maximum");
        defaults.setMaximumFractionDigits(1);
        check(defaults.getMinimumFractionDigits() == 1 && defaults.getMaximumFractionDigits() == 1
                && "7.0".equals(defaults.format(7L)), "Maximum lowers minimum");
        DecimalFormat custom = new DecimalFormat("000.00;[000.00]");
        check("[012.50]".equals(custom.format(-12.5)), "Custom affixes and padding");
        custom.applyPattern("0.00E0");
        check("1.23E3".equals(custom.format(1230L)), "Scientific pattern");
        boolean badPattern = false;
        try { custom.applyPattern("0..00"); }
        catch (IllegalArgumentException expected) { badPattern = true; }
        check(badPattern, "Invalid pattern rejected");
        Format boxed = new DecimalFormat("00.0");
        check("07.0".equals(boxed.format(Long.valueOf(7))), "Boxed number through Format");
        NumberFormat integers = NumberFormat.getIntegerInstance(Locale.US);
        check(integers.isParseIntegerOnly() && "1,234".equals(integers.format(1234.25)), "Integer factory and locale");
        check("25%".equals(NumberFormat.getPercentInstance(Locale.US).format(0.25)), "Percent factory");
        check("$1,234.50".equals(NumberFormat.getCurrencyInstance(Locale.US).format(1234.5)), "Currency factory");
        check("ος".equals("ΟΣ".toLowerCase(Locale.US)) && "STRASSE".equals("Straße".toUpperCase(Locale.US)),
                "Contextual Unicode case conversion");
        check("en".equals(Locale.getDefault().getLanguage()) && "US".equals(Locale.US.getCountry()),
                "Virtual US locale");
        check("AЖ١漢".equals(Pattern.compile("[^\\p{Alnum}]", Pattern.UNICODE_CHARACTER_CLASS)
                .matcher(" AЖ²١漢-").replaceAll("")), "Unicode POSIX property with JDK flag");
        String literal = "[.\\E$]";
        check(literal.matches(Pattern.quote(literal)), "Pattern.quote handles a literal end marker");
        check("left/right".split(Pattern.quote("/")).length == 2, "Quoted literal in split");
        double random = Math.random();
        double strict = StrictMath.random();
        check(random >= 0.0 && random < 1.0 && strict >= 0.0 && strict < 1.0, "Random double range");
        return checks;
    }

    public static void main(String[] args) {
        System.out.println("Managed text checks: " + verify());
    }
}
