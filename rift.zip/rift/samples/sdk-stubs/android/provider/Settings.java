package android.provider;

import android.content.ContentResolver;

/** Compile-only declarations, excluded from the guest DEX. */
public final class Settings {
    public static final class Secure {
        public static final String ACCESSIBILITY_ENABLED = "accessibility_enabled";
        public static String getString(ContentResolver resolver, String name) { return null; }
        public static int getInt(ContentResolver resolver, String name) throws SettingNotFoundException { return 0; }
        public static int getInt(ContentResolver resolver, String name, int fallback) { return 0; }
    }

    public static final class System {
        public static final String FONT_SCALE = "font_scale";
        public static String getString(ContentResolver resolver, String name) { return null; }
        public static int getInt(ContentResolver resolver, String name, int fallback) { return 0; }
        public static float getFloat(ContentResolver resolver, String name) throws SettingNotFoundException { return 0; }
    }

    public static final class Global {
        public static String getString(ContentResolver resolver, String name) { return null; }
        public static long getLong(ContentResolver resolver, String name, long fallback) { return 0; }
        public static float getFloat(ContentResolver resolver, String name, float fallback) { return 0; }
    }

    public static class SettingNotFoundException extends Exception {
        public SettingNotFoundException(String name) { super(name); }
    }
}
