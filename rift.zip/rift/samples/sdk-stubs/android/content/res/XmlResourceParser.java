package android.content.res;

/** Compile-only Android SDK interface. */
public interface XmlResourceParser extends org.xmlpull.v1.XmlPullParser,
        android.util.AttributeSet, AutoCloseable {
    void close();
}
