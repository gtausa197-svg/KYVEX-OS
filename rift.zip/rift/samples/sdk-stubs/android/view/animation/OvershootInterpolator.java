package android.view.animation;
public class OvershootInterpolator extends BaseInterpolator {
    public OvershootInterpolator() {}
    public OvershootInterpolator(float amount) {}
    public float getInterpolation(float input) { return 0; }
}
