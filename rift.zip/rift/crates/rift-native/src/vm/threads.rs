//! Thread construction, identity and entry into the owned guest scheduler.
use super::*;
pub(super) const NAME: usize = usize::MAX - 50;
pub(super) const ID: usize = usize::MAX - 51;
pub(super) const PRIORITY: usize = usize::MAX - 52;
pub(super) const DAEMON: usize = usize::MAX - 53;
pub(super) const TARGET: usize = usize::MAX - 54;
pub(super) const HANDLER: usize = usize::MAX - 55;
pub(super) const GROUP: usize = usize::MAX - 56;
impl Runtime {
    pub(super) fn thread_metadata_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Thread signature")?;
        if class != "Ljava/lang/Thread;" {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Thread argument count");
        if matches!(
            method,
            "<init>()V"
                | "<init>(Ljava/lang/String;)V"
                | "<init>(Ljava/lang/Runnable;)V"
                | "<init>(Ljava/lang/Runnable;Ljava/lang/String;)V"
                | "<init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;)V"
                | "<init>(Ljava/lang/ThreadGroup;Ljava/lang/String;)V"
                | "<init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;)V"
                | "<init>(Ljava/lang/ThreadGroup;Ljava/lang/Runnable;Ljava/lang/String;J)V"
        ) {
            let id = arg(0)?;
            if self.object(id)?.fields.contains_key(&NAME) {
                return Err(fault(
                    "Ljava/lang/IllegalThreadStateException;",
                    "Thread is already initialized",
                ));
            }
            let current = self
                .lang_api("Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;", &[])?
                .ok_or("Main Thread identity")? as u32;
            let grouped = method.starts_with("<init>(Ljava/lang/ThreadGroup;");
            let group = if grouped && arg(1)? != 0 {
                arg(1)?
            } else {
                self.thread_group(current)?
            };
            if self.group(group)?.destroyed {
                return Err(fault(
                    "Ljava/lang/IllegalThreadStateException;",
                    "ThreadGroup is destroyed",
                ));
            }
            let named = method.contains("Ljava/lang/String;");
            let target_index = 1 + grouped as usize;
            let target = if method.contains("Ljava/lang/Runnable;") {
                arg(target_index)?
            } else {
                0
            };
            let name = if named {
                let name_index = target_index + method.contains("Ljava/lang/Runnable;") as usize;
                let value = arg(name_index)?;
                self.units(value)?;
                value
            } else {
                let name = self.string(&format!("Thread-{}", self.next_thread_name))?;
                self.next_thread_name = self
                    .next_thread_name
                    .checked_add(1)
                    .ok_or("Thread name sequence exhausted")?;
                name
            };
            if method.ends_with(";J)V") {
                wide(a, 4)?;
            } // A Java VM stack-size hint, not a host stack allocation.
            if target != 0 {
                self.object(target)?;
            }
            let parent = self.object(current)?;
            let priority = parent
                .fields
                .get(&PRIORITY)
                .copied()
                .unwrap_or(5)
                .min(self.group(group)?.max_priority as u64);
            let daemon = parent.fields.get(&DAEMON).copied().unwrap_or(0);
            let thread_id = self.next_thread_id;
            self.next_thread_id = self
                .next_thread_id
                .checked_add(1)
                .ok_or("Thread id sequence exhausted")?;
            self.object_mut(id)?.fields.extend([
                (NAME, name as u64),
                (ID, thread_id),
                (PRIORITY, priority),
                (DAEMON, daemon),
                (TARGET, target as u64),
                (GROUP, group as u64),
            ]);
            self.register_thread(id)?;
            self.group_add_unstarted(group)?;
            return Ok(Some(0));
        }
        if !matches!(
            method,
            "getId()J"
                | "getThreadGroup()Ljava/lang/ThreadGroup;"
                | "isAlive()Z"
                | "getPriority()I"
                | "setPriority(I)V"
                | "isDaemon()Z"
                | "setDaemon(Z)V"
                | "start()V"
                | "run()V"
        ) {
            return Ok(None);
        }
        let id = arg(0)?;
        let object = self.object(id)?;
        if !object.fields.contains_key(&ID) {
            return Err("Uninitialized guest Thread".into());
        }
        let value = match method {
            "getId()J" => *object.fields.get(&ID).ok_or("Thread id")?,
            "getThreadGroup()Ljava/lang/ThreadGroup;" => self.thread_group(id)? as u64,
            "isAlive()Z" => self
                .scheduler
                .records
                .get(&id)
                .is_some_and(scheduler::Record::alive) as u64,
            "getPriority()I" => object.fields.get(&PRIORITY).copied().unwrap_or(5),
            "isDaemon()Z" => object.fields.get(&DAEMON).copied().unwrap_or(0),
            "setPriority(I)V" => {
                let priority = arg(1)?;
                if !(1..=10).contains(&priority) {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Thread priority must be 1..10",
                    ));
                }
                let group = self.thread_group(id)?;
                if group != 0 {
                    let priority = priority.min(self.group(group)?.max_priority);
                    self.object_mut(id)?
                        .fields
                        .insert(PRIORITY, priority as u64);
                }
                0
            }
            "setDaemon(Z)V" => {
                if self
                    .scheduler
                    .records
                    .get(&id)
                    .is_some_and(scheduler::Record::alive)
                {
                    return Err(fault(
                        "Ljava/lang/IllegalThreadStateException;",
                        "A live Thread cannot change daemon status",
                    ));
                }
                self.object_mut(id)?
                    .fields
                    .insert(DAEMON, (arg(1)? != 0) as u64);
                0
            }
            "run()V" => {
                let target = object.fields.get(&TARGET).copied().unwrap_or(0) as u32;
                if target != 0 {
                    let method = self
                        .callback_method(target, "run", "()V")?
                        .ok_or("Runnable.run is not implemented")?;
                    self.invoke(method, &[target], true)?;
                }
                0
            }
            "start()V" => {
                return self.start_guest_thread(id).map(Some);
            }
            _ => return Ok(None),
        };
        Ok(Some(value))
    }
}
