package android.telephony;
public class PhoneStateListener {public PhoneStateListener(){}public void onCallStateChanged(int state,String number){}}
