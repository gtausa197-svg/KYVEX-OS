//! One supervised native app per desktop user. No root or shell execution.
use rift_core::Result;
use serde_json::{Value, json};
use std::{
    io::{Read, Write},
    os::fd::AsRawFd,
    path::Path,
    process::{Child, ChildStdin, ChildStdout, Command, Stdio},
    time::{Duration, Instant},
};
pub struct Session {
    child: Child,
    input: ChildStdin,
    output: ChildStdout,
    buffer: Vec<u8>,
    pub owner: String,
    pub package: String,
    pub id: u64,
}
impl Session {
    pub fn start(
        path: &Path,
        abi: &str,
        memory: &str,
        owner: &str,
        package: &str,
        id: u64,
    ) -> Result<(Self, Value)> {
        let mut child = Command::new("/usr/lib/kyvex/rift-native")
            .args(["--apk"])
            .arg(path)
            .args(["--abi", abi, "--memory", memory])
            .arg("--state")
            .arg(path.with_extension("preferences"))
            .env_clear()
            .env("LANG", "C.UTF-8")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()?;
        let input = child.stdin.take().ok_or("Native worker input pipe")?;
        let output = child.stdout.take().ok_or("Native worker output pipe")?;
        let fd = output.as_raw_fd();
        let flags = unsafe { libc::fcntl(fd, libc::F_GETFL) };
        if flags < 0 || unsafe { libc::fcntl(fd, libc::F_SETFL, flags | libc::O_NONBLOCK) } < 0 {
            let _ = child.kill();
            let _ = child.wait();
            return Err("Cannot configure native worker pipe".into());
        }
        let mut session = Self {
            child,
            input,
            output,
            buffer: Vec::new(),
            owner: owner.into(),
            package: package.into(),
            id,
        };
        let value = session.frame(Duration::from_secs(45))?;
        Ok((session, value))
    }
    fn frame(&mut self, timeout: Duration) -> Result<Value> {
        let deadline = Instant::now() + timeout;
        loop {
            if let Some(end) = self.buffer.iter().position(|b| *b == b'\n') {
                if end > 65536 {
                    return Err("Native worker response exceeds 64 KiB".into());
                }
                let packet: Value = serde_json::from_slice(&self.buffer[..end])?;
                self.buffer.drain(..=end);
                if packet["protocol"] != 1 {
                    return Err("Unsupported native worker protocol".into());
                }
                if packet["ok"] != true {
                    return Err(packet["error"]
                        .as_str()
                        .unwrap_or("Native worker failed")
                        .to_owned()
                        .into());
                }
                let mut packet = packet;
                packet["native_session"] = json!(self.id);
                return Ok(packet);
            }
            if self.buffer.len() > 65536 {
                return Err("Native worker response exceeds 64 KiB".into());
            }
            let remaining = deadline.saturating_duration_since(Instant::now());
            if remaining.is_zero() {
                return Err("Native application exceeded its response time limit".into());
            }
            let mut p = libc::pollfd {
                fd: self.output.as_raw_fd(),
                events: libc::POLLIN,
                revents: 0,
            };
            let ready = unsafe { libc::poll(&mut p, 1, remaining.as_millis().min(1000) as i32) };
            if ready < 0 {
                let e = std::io::Error::last_os_error();
                if e.kind() == std::io::ErrorKind::Interrupted {
                    continue;
                }
                return Err(e.into());
            }
            if ready == 0 {
                continue;
            }
            let mut bytes = [0; 4096];
            match self.output.read(&mut bytes) {
                Ok(0) => {
                    return Err(format!(
                        "Native worker closed unexpectedly ({:?})",
                        self.child.try_wait()?
                    )
                    .into());
                }
                Ok(n) => self.buffer.extend_from_slice(&bytes[..n]),
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => continue,
                Err(e) => return Err(e.into()),
            }
        }
    }
    pub fn request(&mut self, value: Value) -> Result<Value> {
        let bytes = serde_json::to_vec(&value)?;
        if bytes.len() > 1024 {
            return Err("Native event quota".into());
        }
        self.input.write_all(&bytes)?;
        self.input.write_all(b"\n")?;
        self.input.flush()?;
        self.frame(Duration::from_secs(2))
    }
    pub fn authorized(&self, owner: &str, id: u64) -> Result<()> {
        if self.owner != owner || self.id != id {
            return Err("This native window belongs to a different or expired session".into());
        }
        Ok(())
    }
    pub fn status(&mut self) -> Value {
        json!({"package":self.package,"session":self.id,"running":matches!(self.child.try_wait(),Ok(None))})
    }
}
impl Drop for Session {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}
