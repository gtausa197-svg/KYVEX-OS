package android.util;
/** Compile-only signature; excluded from APK. */
public final class Xml {public static org.xmlpull.v1.XmlPullParser newPullParser(){return null;}}
