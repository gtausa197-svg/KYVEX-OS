package android.content.pm;
public abstract class PackageManager {
    public abstract boolean hasSystemFeature(String name);
    public abstract boolean hasSystemFeature(String name, int version);
    public abstract android.content.res.XmlResourceParser getXml(String packageName,int id,ApplicationInfo application);
    public abstract ProviderInfo resolveContentProvider(String authority,int flags);
    public abstract ProviderInfo getProviderInfo(android.content.ComponentName component,int flags) throws NameNotFoundException;
    public abstract ServiceInfo getServiceInfo(android.content.ComponentName component,int flags) throws NameNotFoundException;
    public static class NameNotFoundException extends Exception {}
    public abstract PackageInfo getPackageInfo(String packageName,int flags) throws NameNotFoundException;
    public abstract ApplicationInfo getApplicationInfo(String packageName,int flags) throws NameNotFoundException;
}
