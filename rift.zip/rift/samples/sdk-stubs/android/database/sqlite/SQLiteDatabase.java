package android.database.sqlite;
public final class SQLiteDatabase implements AutoCloseable {
 public interface CursorFactory {}
 public native void close();public native boolean isOpen();public native boolean isReadOnly();public native boolean isWriteAheadLoggingEnabled();
 public native String getPath();public native int getVersion();public native void setVersion(int version);public native void setForeignKeyConstraintsEnabled(boolean enabled);
 public native void execSQL(String sql);public native void execSQL(String sql,Object[] values);
 public native android.database.Cursor rawQuery(String sql,String[] args);
 public native void beginTransaction();public native void beginTransactionNonExclusive();public native void setTransactionSuccessful();public native void endTransaction();public native boolean inTransaction();
}
