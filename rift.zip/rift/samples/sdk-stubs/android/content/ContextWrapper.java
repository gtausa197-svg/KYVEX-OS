package android.content;
public class ContextWrapper extends Context {
 public ContextWrapper(Context base){}
 protected void attachBaseContext(Context base){}
 public Context getBaseContext(){return null;}
}
