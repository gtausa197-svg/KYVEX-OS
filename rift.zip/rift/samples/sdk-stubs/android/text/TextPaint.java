package android.text;

import android.graphics.Paint;

/** Compile-time API signatures. This class is excluded from the fixture APK. */
public class TextPaint extends Paint {
    public TextPaint() {}
    public TextPaint(int flags) { super(flags); }
    public TextPaint(Paint source) { super(source); }
}
