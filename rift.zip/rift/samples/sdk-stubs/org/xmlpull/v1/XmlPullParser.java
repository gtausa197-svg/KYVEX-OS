package org.xmlpull.v1;
/** Compile-only signatures; excluded from APK. */
public interface XmlPullParser {
 int START_DOCUMENT=0,END_DOCUMENT=1,START_TAG=2,END_TAG=3,TEXT=4,CDSECT=5,ENTITY_REF=6,IGNORABLE_WHITESPACE=7,PROCESSING_INSTRUCTION=8,COMMENT=9,DOCDECL=10;
 String FEATURE_PROCESS_NAMESPACES="http://xmlpull.org/v1/doc/features.html#process-namespaces";
 void setInput(java.io.Reader reader)throws XmlPullParserException;
 void setInput(java.io.InputStream input,String encoding)throws XmlPullParserException;
 int next()throws XmlPullParserException,java.io.IOException;
 int nextToken()throws XmlPullParserException,java.io.IOException;
 int nextTag()throws XmlPullParserException,java.io.IOException;
 String nextText()throws XmlPullParserException,java.io.IOException;
 int getEventType()throws XmlPullParserException;
 int getDepth();int getLineNumber();int getColumnNumber();
 String getName();String getPrefix();String getNamespace();String getText();String getInputEncoding();String getPositionDescription();
 boolean isEmptyElementTag()throws XmlPullParserException;
 boolean isWhitespace()throws XmlPullParserException;
 int getAttributeCount();String getAttributeName(int i);String getAttributeNamespace(int i);String getAttributePrefix(int i);String getAttributeValue(int i);String getAttributeType(int i);boolean isAttributeDefault(int i);
 String getAttributeValue(String namespace,String name);
 String getNamespace(String prefix);int getNamespaceCount(int depth)throws XmlPullParserException;String getNamespacePrefix(int i)throws XmlPullParserException;String getNamespaceUri(int i)throws XmlPullParserException;
 boolean getFeature(String name);void setFeature(String name,boolean value)throws XmlPullParserException;
 void require(int type,String namespace,String name)throws XmlPullParserException;
}
