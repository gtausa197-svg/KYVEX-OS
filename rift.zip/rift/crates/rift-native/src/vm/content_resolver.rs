//! Read-only settings for the virtual Android device.
use super::*;

pub(super) const RESOLVER: &str = "Landroid/content/ContentResolver;";
pub(super) const APPLICATION_RESOLVER: &str =
    "Landroid/app/ContextImpl$ApplicationContentResolver;";
pub(super) const SETTINGS: &str = "Landroid/provider/Settings;";
pub(super) const NAME_VALUE_TABLE: &str = "Landroid/provider/Settings$NameValueTable;";
pub(super) const SECURE: &str = "Landroid/provider/Settings$Secure;";
pub(super) const SYSTEM: &str = "Landroid/provider/Settings$System;";
pub(super) const GLOBAL: &str = "Landroid/provider/Settings$Global;";
pub(super) const NOT_FOUND: &str = "Landroid/provider/Settings$SettingNotFoundException;";
pub(super) const ANDROID_EXCEPTION: &str = "Landroid/util/AndroidException;";
pub(super) const FONT_SCALE: f32 = 1.0;

const CONTEXT: &str = "Landroid/content/Context;";
const CONTEXT_IMPL: &str = "Landroid/app/ContextImpl;";
const CONTEXT_WRAPPER: &str = "Landroid/content/ContextWrapper;";
const BASE_CONTEXT: usize = usize::MAX - 1;
const CONTEXT_RESOLVER: usize = usize::MAX - 142;
const RESOLVER_CONTEXT: usize = usize::MAX - 143;
const GET_RESOLVER: &str = "()Landroid/content/ContentResolver;";

fn guest_setting(class: &str, name: &str) -> Option<&'static str> {
    match (class, name) {
        (SYSTEM, "font_scale") => Some("1.0"),
        (SECURE, "accessibility_enabled") => Some("0"),
        _ => None,
    }
}

impl Runtime {
    fn context_resolver(&mut self, mut context: u32) -> Result<u64> {
        for _ in 0..128 {
            let object = self.object(context)?;
            if self.subclass(&object.class, CONTEXT_WRAPPER)? {
                context = object.fields.get(&BASE_CONTEXT).copied().unwrap_or(0) as u32;
                if let Some(method) =
                    self.callback_method(context, "getContentResolver", GET_RESOLVER)?
                {
                    return self.invoke(method, &[context], true);
                }
                continue;
            }
            if object.class != CONTEXT_IMPL {
                return Err(fault(
                    "Ljava/lang/AbstractMethodError;",
                    "Context.getContentResolver",
                ));
            }
            if let Some(&resolver) = object.fields.get(&CONTEXT_RESOLVER) {
                return Ok(resolver);
            }
            let resolver = self.allocate(APPLICATION_RESOLVER, Payload::Instance)?;
            self.object_mut(resolver)?
                .fields
                .insert(RESOLVER_CONTEXT, u64::from(context));
            self.object_mut(context)?
                .fields
                .insert(CONTEXT_RESOLVER, u64::from(resolver));
            return Ok(u64::from(resolver));
        }
        Err("ContextWrapper delegation depth exceeded".into())
    }

    pub(super) fn content_resolver_api(
        &mut self,
        signature: &str,
        args: &[u32],
    ) -> Result<Option<u64>> {
        let (class, method) = signature
            .split_once("->")
            .ok_or("ContentResolver signature")?;
        let arg = |index: usize| args.get(index).copied().ok_or("Settings argument count");
        if method == "getContentResolver()Landroid/content/ContentResolver;"
            && self.subclass(class, CONTEXT)?
        {
            return self.context_resolver(arg(0)?).map(Some);
        }
        if !matches!(class, SECURE | SYSTEM | GLOBAL) {
            return Ok(None);
        }
        let (getter, descriptor) = method.split_once('(').ok_or("Settings method signature")?;
        let Some(tail) =
            descriptor.strip_prefix("Landroid/content/ContentResolver;Ljava/lang/String;")
        else {
            return Ok(None);
        };
        if !matches!(
            (getter, tail),
            ("getString", ")Ljava/lang/String;")
                | ("getInt", ")I" | "I)I")
                | ("getLong", ")J" | "J)J")
                | ("getFloat", ")F" | "F)F")
        ) {
            return Ok(None);
        }
        if !self.subclass(&self.object(arg(0)?)?.class, RESOLVER)? {
            return Err(fault(
                "Ljava/lang/ClassCastException;",
                "Expected ContentResolver",
            ));
        }
        let name = self.text(arg(1)?)?;
        let setting = guest_setting(class, &name);
        let value = match (getter, tail) {
            ("getString", _) => {
                return Ok(Some(match setting {
                    Some(text) => u64::from(self.string(text)?),
                    None => 0,
                }));
            }
            ("getInt", _) => setting
                .and_then(|text| text.parse::<i32>().ok())
                .map(|n| u64::from(n as u32)),
            ("getLong", _) => setting
                .and_then(|text| text.parse::<i64>().ok())
                .map(|n| n as u64),
            ("getFloat", _) => setting
                .and_then(|text| text.parse::<f32>().ok())
                .map(|n| u64::from(n.to_bits())),
            _ => unreachable!("validated Settings getter"),
        };
        if let Some(value) = value {
            return Ok(Some(value));
        }
        match tail {
            "I)I" | "F)F" => Ok(Some(u64::from(arg(2)?))),
            "J)J" => Ok(Some(u64::from(arg(2)?) | (u64::from(arg(3)?) << 32))),
            _ => Err(fault(NOT_FOUND, &name)),
        }
    }
}
