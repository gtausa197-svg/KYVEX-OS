//! Bounded C-locale sscanf/vsscanf over copies of guest strings.
use super::{c_format::Arguments, *};
use std::{ffi::c_char, iter::Peekable, ptr};

const INPUT_LIMIT: usize = 16384;
const NUMERIC_LIMIT: usize = 512;

#[derive(Clone, Copy)]
enum Length {
    Default,
    Byte,
    Short,
    Long,
    Wide,
    Pointer,
    LongDouble,
}

impl Length {
    fn bytes(self, arch: u32) -> Result<usize> {
        Ok(match self {
            Self::Default => 4,
            Self::Byte => 1,
            Self::Short => 2,
            Self::Long | Self::Pointer => (arch / 8) as usize,
            Self::Wide => 8,
            Self::LongDouble => return Err("Invalid scanf integer length".into()),
        })
    }
}

struct Field {
    kind: u8,
    width: usize,
    length: Length,
    discard: bool,
}

impl Field {
    fn read(format: &mut Peekable<impl Iterator<Item = u8>>) -> Result<Self> {
        let discard = format.next_if_eq(&b'*').is_some();
        let mut width = 0usize;
        while let Some(byte) = format.next_if(u8::is_ascii_digit) {
            width = (width * 10 + usize::from(byte - b'0')).min(INPUT_LIMIT);
        }
        let length = match format.next_if(|byte| b"hljztL".contains(byte)) {
            Some(b'h') if format.next_if_eq(&b'h').is_some() => Length::Byte,
            Some(b'h') => Length::Short,
            Some(b'l') if format.next_if_eq(&b'l').is_some() => Length::Wide,
            Some(b'l') => Length::Long,
            Some(b'j') => Length::Wide,
            Some(b'z' | b't') => Length::Pointer,
            Some(b'L') => Length::LongDouble,
            _ => Length::Default,
        };
        let kind = format.next().ok_or("Unterminated scanf conversion")?;
        Ok(Self {
            kind,
            width,
            length,
            discard,
        })
    }

    fn limit(&self, maximum: usize) -> usize {
        if self.width == 0 {
            maximum
        } else {
            maximum.min(self.width)
        }
    }
}

fn space(byte: u8) -> bool {
    matches!(byte, b' ' | 9..=13)
}

fn scanset(format: &mut Peekable<impl Iterator<Item = u8>>) -> Result<[bool; 256]> {
    let invert = format.next_if_eq(&b'^').is_some();
    let mut accepted = [invert; 256];
    let mut previous = format.next().ok_or("Unterminated scanf scanset")?;
    accepted[previous as usize] = !invert;
    while let Some(byte) = format.next() {
        if byte == b']' {
            return Ok(accepted);
        }
        if byte == b'-'
            && let Some(end) = format.next_if(|&end| end != b']' && end >= previous)
        {
            accepted[previous as usize..=end as usize].fill(!invert);
            previous = end;
        } else {
            accepted[byte as usize] = !invert;
            previous = byte;
        }
    }
    Err("Unterminated scanf scanset".into())
}

unsafe extern "C" {
    fn strtod_l(text: *const c_char, end: *mut *mut c_char, locale: libc::locale_t) -> f64;
    fn strtof_l(text: *const c_char, end: *mut *mut c_char, locale: libc::locale_t) -> f32;
}

pub(super) struct NumericLocale(libc::locale_t);

impl NumericLocale {
    pub(super) fn open() -> Result<Self> {
        let locale =
            unsafe { libc::newlocale(libc::LC_NUMERIC_MASK, c"C".as_ptr(), ptr::null_mut()) };
        if locale.is_null() {
            return Err("C scanf numeric locale unavailable".into());
        }
        Ok(Self(locale))
    }

    pub(super) fn parse(&self, input: &[u8], double: bool) -> (usize, Vec<u8>, Option<i32>) {
        let mut text = input.to_vec();
        text.push(0);
        let start = text.as_ptr().cast::<c_char>();
        let mut end = ptr::null_mut();
        // Only the bounded host-owned numeric token reaches libc.
        unsafe {
            let errno = libc::__errno_location();
            let saved = *errno;
            *errno = 0;
            let bytes = if double {
                strtod_l(start, &mut end, self.0).to_le_bytes().to_vec()
            } else {
                strtof_l(start, &mut end, self.0).to_le_bytes().to_vec()
            };
            let range = (*errno == libc::ERANGE).then_some(libc::ERANGE);
            *errno = saved;
            (end.offset_from(start) as usize, bytes, range)
        }
    }
}

impl Drop for NumericLocale {
    fn drop(&mut self) {
        unsafe { libc::freelocale(self.0) }
    }
}

struct Scan {
    assigned: i32,
    errno: Option<i32>,
    writes: Vec<(u64, Vec<u8>)>,
}

fn scan(
    input: &[u8],
    format: &[u8],
    arch: u32,
    mut pointer: impl FnMut() -> Result<u64>,
) -> Result<Scan> {
    let mut result = Scan {
        assigned: 0,
        errno: None,
        writes: Vec::new(),
    };
    let mut format = format.iter().copied().peekable();
    let mut cursor = 0usize;
    let mut locale = None;
    let mut input_failure = false;
    while let Some(byte) = format.next() {
        if space(byte) {
            cursor += input[cursor..]
                .iter()
                .take_while(|&&byte| space(byte))
                .count();
            continue;
        }
        if byte != b'%' || format.next_if_eq(&b'%').is_some() {
            match input.get(cursor) {
                Some(&next) if next == byte => cursor += 1,
                other => {
                    input_failure = other.is_none();
                    break;
                }
            }
            continue;
        }
        let field = Field::read(&mut format)?;
        if field.kind == b'n' {
            if !field.discard {
                let size = field.length.bytes(arch)?;
                result
                    .writes
                    .push((pointer()?, (cursor as u64).to_le_bytes()[..size].to_vec()));
            }
            continue;
        }
        let set = if field.kind == b'[' {
            Some(scanset(&mut format)?)
        } else {
            None
        };
        if !matches!(field.kind, b'c' | b'[') {
            cursor += input[cursor..]
                .iter()
                .take_while(|&&byte| space(byte))
                .count();
        }
        if cursor == input.len() {
            input_failure = true;
            break;
        }
        let remaining = &input[cursor..];
        let (count, bytes, errno) = match field.kind {
            b'c' | b's' | b'[' if matches!(field.length, Length::Default) => {
                let limit = if field.kind == b'c' && field.width == 0 {
                    1
                } else {
                    field.limit(remaining.len())
                };
                let count = remaining[..limit]
                    .iter()
                    .take_while(|&&byte| match field.kind {
                        b'c' => true,
                        b's' => !space(byte),
                        _ => set.as_ref().is_some_and(|set| set[byte as usize]),
                    })
                    .count();
                let mut bytes = remaining[..count].to_vec();
                if field.kind != b'c' {
                    bytes.push(0);
                }
                (count, bytes, None)
            }
            b'd' | b'i' | b'o' | b'u' | b'x' | b'X' | b'p' => {
                let base = match field.kind {
                    b'i' => 0,
                    b'o' => 8,
                    b'x' | b'X' | b'p' => 16,
                    _ => 10,
                };
                let token = &remaining[..field.limit(remaining.len().min(NUMERIC_LIMIT))];
                let conversion = integer::convert(
                    |index| Ok(token.get(index).copied().unwrap_or(0)),
                    base,
                    64,
                    matches!(field.kind, b'd' | b'i'),
                )?;
                let size = if field.kind == b'p' {
                    (arch / 8) as usize
                } else {
                    field.length.bytes(arch)?
                };
                (
                    conversion.end,
                    conversion.value.to_le_bytes()[..size].to_vec(),
                    conversion.error,
                )
            }
            b'a' | b'A' | b'e' | b'E' | b'f' | b'F' | b'g' | b'G' => {
                let double = match field.length {
                    Length::Default => false,
                    Length::Long => true,
                    Length::LongDouble if arch == 32 => true,
                    _ => return Err("Unsupported scanf floating-point destination type".into()),
                };
                if locale.is_none() {
                    locale = Some(NumericLocale::open()?);
                }
                let token = &remaining[..field.limit(remaining.len().min(NUMERIC_LIMIT))];
                locale
                    .as_ref()
                    .ok_or("Missing C scanf locale")?
                    .parse(token, double)
            }
            _ => {
                return Err(format!("Unsupported scanf conversion %{}", field.kind as char).into());
            }
        };
        if count == 0 {
            break;
        }
        cursor += count;
        if !field.discard {
            result.writes.push((pointer()?, bytes));
            result.assigned += 1;
            if let Some(errno) = errno {
                result.errno = Some(errno);
            }
        }
    }
    if input_failure && result.assigned == 0 {
        result.assigned = -1;
    }
    Ok(result)
}

impl Machine {
    pub(super) fn scanf_call(&mut self, function: &str, state: &State) -> Result<u64> {
        let [input, format, list, ..] = state.regs;
        let input = self.cbytes(input, INPUT_LIMIT + 1)?;
        let format = self.cbytes(format, 4096)?;
        let mut args = if function == "vsscanf" {
            Arguments::list(self, list)?
        } else {
            Arguments::call(self, state, 2)
        };
        let scanned = scan(&input, &format, self.arch, || args.next(self.arch))?;
        for (address, bytes) in scanned.writes {
            self.cpu.memory_mut().write(address, &bytes)?;
        }
        if let Some(errno) = scanned.errno {
            self.set_guest_errno(errno)?;
        }
        Ok(scanned.assigned as i64 as u64)
    }
}
