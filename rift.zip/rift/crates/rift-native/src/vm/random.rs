//! java.util.Random's specified 48-bit generator; independent of SecureRandom.
use super::*;
const MULT: u64 = 0x5deece66d;
const MASK: u64 = (1 << 48) - 1;
#[derive(Clone)]
pub(super) struct Random {
    seed: u64,
    gaussian: Option<f64>,
}
impl Random {
    fn from_system() -> Result<Self> {
        let mut bytes = [0u8; 8];
        if unsafe { libc::getrandom(bytes.as_mut_ptr().cast(), bytes.len(), 0) } != 8 {
            return Err("Random seed entropy unavailable".into());
        }
        Ok(Self::seeded(u64::from_le_bytes(bytes)))
    }

    pub fn seeded(seed: u64) -> Self {
        Self {
            seed: (seed ^ MULT) & MASK,
            gaussian: None,
        }
    }
    fn bits(&mut self, n: u32) -> u32 {
        self.seed = self.seed.wrapping_mul(MULT).wrapping_add(11) & MASK;
        (self.seed >> (48 - n)) as u32
    }
    fn int(&mut self, bound: u32) -> Result<u32> {
        if bound == 0 || bound > i32::MAX as u32 {
            return Err(fault(
                "Ljava/lang/IllegalArgumentException;",
                "Random bound must be positive",
            ));
        }
        if bound.is_power_of_two() {
            return Ok(((bound as u64 * self.bits(31) as u64) >> 31) as u32);
        }
        for _ in 0..4096 {
            let bits = self.bits(31);
            let value = bits % bound;
            if bits.wrapping_sub(value).wrapping_add(bound - 1) as i32 >= 0 {
                return Ok(value);
            }
        }
        Err("Random rejection sampling quota".into())
    }
    fn long(&mut self) -> u64 {
        ((self.bits(32) as i32 as i64) << 32).wrapping_add(self.bits(32) as i32 as i64) as u64
    }
    fn double(&mut self) -> f64 {
        ((self.bits(26) as u64) << 27 | self.bits(27) as u64) as f64 / 9007199254740992.0
    }
    fn gaussian(&mut self) -> Result<f64> {
        if let Some(value) = self.gaussian.take() {
            return Ok(value);
        }
        for _ in 0..4096 {
            let x = 2.0 * self.double() - 1.0;
            let y = 2.0 * self.double() - 1.0;
            let s = x * x + y * y;
            if s >= 1.0 || s == 0.0 {
                continue;
            }
            let scale = (-2.0 * s.ln() / s).sqrt();
            self.gaussian = Some(y * scale);
            return Ok(x * scale);
        }
        Err("Random Gaussian sampling quota".into())
    }
}
impl Runtime {
    pub(super) fn next_math_random(&mut self) -> Result<u64> {
        let random = match &mut self.math_random {
            Some(random) => random,
            None => self.math_random.insert(Random::from_system()?),
        };
        Ok(random.double().to_bits())
    }

    pub(super) fn random_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Random signature")?;
        if class != "Ljava/util/Random;" {
            return Ok(None);
        }
        let arg = |i: usize| a.get(i).copied().ok_or("Random argument count");
        let id = arg(0)?;
        let Payload::Random(random) = &self.object(id)?.payload else {
            return Err("Expected Random instance".into());
        };
        let mut random = random.clone();
        let value = match method {
            "<init>()V" => {
                random = Random::from_system()?;
                0
            }
            "<init>(J)V" | "setSeed(J)V" => {
                random = Random::seeded(arg(1)? as u64 | ((arg(2)? as u64) << 32));
                0
            }
            "next(I)I" => {
                let n = arg(1)?;
                if !(1..=32).contains(&n) {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Random bit count",
                    ));
                }
                random.bits(n) as u64
            }
            "nextInt()I" => random.bits(32) as u64,
            "nextInt(I)I" => random.int(arg(1)?)? as u64,
            "nextLong()J" => random.long(),
            "nextBoolean()Z" => random.bits(1) as u64,
            "nextFloat()F" => (random.bits(24) as f32 / 16777216.0).to_bits() as u64,
            "nextDouble()D" => random.double().to_bits(),
            "nextGaussian()D" => random.gaussian()?.to_bits(),
            "nextBytes([B)V" => {
                let array = arg(1)?;
                if self.object(array)?.class != "[B" {
                    return Err("Random byte array type".into());
                }
                let Payload::Array(values) = &mut self.object_mut(array)?.payload else {
                    unreachable!()
                };
                for chunk in values.chunks_mut(4) {
                    let bytes = random.bits(32).to_le_bytes();
                    for (value, byte) in chunk.iter_mut().zip(bytes) {
                        *value = byte as u64;
                    }
                }
                0
            }
            _ => return Ok(None),
        };
        self.object_mut(id)?.payload = Payload::Random(random);
        Ok(Some(value))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn seeded_sequences_match_jdk_oracle_including_signed_long_and_rejection() {
        let rows: serde_json::Value = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../samples/oracles/random-oracle.json"
        )))
        .unwrap();
        for row in rows.as_array().unwrap() {
            let mut r =
                Random::seeded(row["seed"].as_str().unwrap().parse::<i64>().unwrap() as u64);
            assert_eq!(r.bits(32) as u64, row["int"].as_u64().unwrap());
            for (i, bound) in [1, 2, 37, 2147483647, 1073741825].iter().enumerate() {
                assert_eq!(
                    r.int(*bound).unwrap() as u64,
                    row["bounded"][i].as_u64().unwrap()
                );
            }
            assert_eq!(
                r.long(),
                row["long"].as_str().unwrap().parse::<u64>().unwrap()
            );
            assert_eq!(
                (r.bits(24) as f32 / 16777216.0).to_bits() as u64,
                row["float_bits"].as_u64().unwrap()
            );
            assert_eq!(
                r.double().to_bits(),
                row["double_bits"].as_str().unwrap().parse::<u64>().unwrap()
            );
            for i in 0..2 {
                assert!(
                    (r.gaussian().unwrap() - row["gaussian"][i].as_f64().unwrap()).abs() < 1e-12
                );
            }
        }
        assert!(Random::seeded(0).int(0).is_err());
        assert!(Random::seeded(0).int(u32::MAX).is_err());
    }
}
