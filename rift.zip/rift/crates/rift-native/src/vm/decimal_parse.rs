//! Java Double parsing with an exact binary round for hexadecimal input.
use super::*;

fn signed(text: &str) -> (bool, &str) {
    if let Some(rest) = text.strip_prefix('-') {
        (true, rest)
    } else {
        (false, text.strip_prefix('+').unwrap_or(text))
    }
}

fn binary_exponent(text: &str) -> Option<i64> {
    let (negative, digits) = signed(text);
    if digits.is_empty() || !digits.bytes().all(|digit| digit.is_ascii_digit()) {
        return None;
    }
    // Larger magnitudes already underflow or overflow every accepted string.
    let magnitude = digits.bytes().fold(0i64, |acc, digit| {
        (acc * 10 + i64::from(digit - b'0')).min(1_000_000)
    });
    Some(if negative { -magnitude } else { magnitude })
}

fn hexadecimal(text: &str) -> Option<u64> {
    let (mantissa, exponent) = text.split_once(['p', 'P'])?;
    let exponent = binary_exponent(exponent)?;
    let (whole, fraction) = mantissa.split_once('.').unwrap_or((mantissa, ""));
    if whole.is_empty() && fraction.is_empty() {
        return None;
    }
    // At most 53 retained bits and one rounding bit. Keep a sticky bit for
    // the remaining low bits so a value exactly halfway rounds to even.
    let mut prefix = 0u64;
    let mut width = 0i64;
    let mut sticky = false;
    for digit in whole.chars().chain(fraction.chars()) {
        let digit = digit.to_digit(16)?;
        for shift in (0..4).rev() {
            let bit = (digit >> shift) & 1;
            if width == 0 && bit == 0 {
                continue;
            }
            width += 1;
            if width <= 54 {
                prefix = prefix * 2 + u64::from(bit);
            } else {
                sticky |= bit != 0;
            }
        }
    }
    if width == 0 {
        return Some(0);
    }
    let highest = width - 1 + exponent - 4 * fraction.len() as i64;
    if highest > 1023 {
        return Some(f64::INFINITY.to_bits());
    }
    if highest < -1075 {
        return Some(0);
    }
    let keep = (highest + 1075).min(53) as u32;
    let captured = width.min(54) as u32;
    let coefficient = if captured <= keep {
        prefix << (keep - captured)
    } else {
        let discard = captured - keep;
        let halfway = 1u64 << (discard - 1);
        let remainder = prefix & ((1u64 << discard) - 1);
        let result = prefix >> discard;
        result
            + u64::from(
                remainder > halfway || (remainder == halfway && (sticky || result & 1 != 0)),
            )
    };
    if highest < -1022 {
        Some(coefficient)
    } else {
        // Adding the rounded coefficient also carries into the exponent when needed.
        Some((((highest + 1022) as u64) << 52) + coefficient)
    }
}

fn parse(text: &str) -> Option<u64> {
    let text = text.trim_matches(|ch| ch <= '\u{20}');
    let (negative, magnitude) = signed(text);
    let sign = u64::from(negative) << 63;
    match magnitude {
        "NaN" => return Some(0x7ff8000000000000),
        "Infinity" => return Some(sign | f64::INFINITY.to_bits()),
        _ => {}
    }
    let magnitude = magnitude
        .strip_suffix(['d', 'D', 'f', 'F'])
        .unwrap_or(magnitude);
    if let Some(hex) = magnitude
        .strip_prefix("0x")
        .or_else(|| magnitude.strip_prefix("0X"))
    {
        return Some(sign | hexadecimal(hex)?);
    }
    if !magnitude
        .as_bytes()
        .first()
        .is_some_and(|b| b.is_ascii_digit() || *b == b'.')
        || !magnitude
            .bytes()
            .all(|b| b.is_ascii_digit() || matches!(b, b'.' | b'e' | b'E' | b'+' | b'-'))
    {
        return None;
    }
    Some(sign | magnitude.parse::<f64>().ok()?.to_bits())
}

pub(super) fn display(value: f64) -> String {
    if value.is_nan() {
        return "NaN".into();
    }
    if value.is_infinite() {
        return if value.is_sign_negative() {
            "-Infinity"
        } else {
            "Infinity"
        }
        .into();
    }
    let magnitude = value.abs();
    let mut text = if magnitude != 0.0 && !(0.001..10_000_000.0).contains(&magnitude) {
        format!("{value:E}")
    } else {
        value.to_string()
    };
    if !text.contains('.') {
        let end = text.find('E').unwrap_or(text.len());
        text.insert_str(end, ".0");
    }
    text
}

impl Runtime {
    pub(super) fn double_parse_api(&mut self, sig: &str, args: &[u32]) -> Result<Option<u64>> {
        let arg = |i: usize| args.get(i).copied().ok_or("Double argument count");
        Ok(Some(match sig {
            "Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D"
            | "Ljava/lang/Double;->valueOf(Ljava/lang/String;)Ljava/lang/Double;" => {
                let input = self.units(arg(0)?)?;
                let bits = parse(&String::from_utf16_lossy(&input)).ok_or_else(|| {
                    fault(
                        "Ljava/lang/NumberFormatException;",
                        "Invalid floating-point literal",
                    )
                })?;
                if sig.contains("->valueOf") {
                    self.box_value('D', bits)? as u64
                } else {
                    bits
                }
            }
            "Ljava/lang/Double;->isInfinite(D)Z" => {
                f64::from_bits(u64::from(arg(0)?) | (u64::from(arg(1)?) << 32)).is_infinite() as u64
            }
            "Ljava/lang/Double;->isNaN(D)Z" => {
                f64::from_bits(u64::from(arg(0)?) | (u64::from(arg(1)?) << 32)).is_nan() as u64
            }
            _ => return Ok(None),
        }))
    }
}
