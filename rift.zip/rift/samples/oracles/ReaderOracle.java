import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** Stock-JDK oracle; no Android or KYVEX implementation is on this classpath. */
public final class ReaderOracle {
 static byte[] bytes(String text){byte[] out=new byte[text.length()/2];for(int i=0;i<out.length;i++)out[i]=(byte)Integer.parseInt(text.substring(i*2,i*2+2),16);return out;}
 static String hex(byte[] data){StringBuilder s=new StringBuilder();for(byte b:data)s.append(String.format("%02x",b&255));return s.toString();}
 static String decoded(byte[] data,final boolean single)throws Exception {
  ByteArrayInputStream original=new ByteArrayInputStream(data);
  InputStream input=single?new FilterInputStream(original){public int read(byte[] b,int off,int n)throws IOException{return super.read(b,off,Math.min(n,1));}}:original;
  Reader reader=new InputStreamReader(input,StandardCharsets.UTF_8);StringBuilder out=new StringBuilder();int c;
  while((c=reader.read())!=-1)out.append(String.format("%04x",c));reader.close();return out.toString();
 }
 static String decodedCharset(byte[] data,String charset)throws Exception {
  Reader reader=new InputStreamReader(new ByteArrayInputStream(data),charset);StringBuilder out=new StringBuilder();int c;
  while((c=reader.read())!=-1)out.append(String.format("%04x",c));reader.close();return out.toString();
 }
 public static void main(String[] args)throws Exception {
  List<String> vectors=new ArrayList<String>(Arrays.asList("","41","c3a9","f09f9880","eda080","eda080eda080","eda041","eda0","e282","c080","e08080","f0808080","f4908080","f5808080","e228a1","f0904180","eea080","ffedb08000","efbbbf41"));
  Random random=new Random(0x4b59564558L);for(int i=0;i<512;i++){byte[] input=new byte[random.nextInt(33)];random.nextBytes(input);vectors.add(hex(input));}
  StringBuilder json=new StringBuilder("{\"jdk_version\":\"").append(System.getProperty("java.runtime.version")).append("\",\"cases\":[");boolean first=true;
  for(String vector:vectors){byte[] input=bytes(vector);String expected=decoded(input,false);if(!expected.equals(decoded(input,true)))throw new IllegalStateException("JDK chunk-dependent result "+vector);
   if(!first)json.append(',');first=false;json.append("{\"input\":\"").append(vector).append("\",\"utf16\":\"").append(expected).append("\"}");}
  StringReader eof=new StringReader("x");eof.read();eof.read();long skip=eof.skip(-1);
  byte[] every=new byte[256];for(int i=0;i<256;i++)every[i]=(byte)i;
  json.append("],\"negative_skip_at_eof\":").append(skip).append(",\"latin1_utf16\":\"").append(decodedCharset(every,"ISO-8859-1")).append("\",\"ascii_utf16\":\"").append(decodedCharset(every,"US-ASCII")).append("\"}");System.out.println(json);
 }
}
