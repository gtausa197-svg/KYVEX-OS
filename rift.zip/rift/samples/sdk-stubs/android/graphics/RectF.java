package android.graphics;
public class RectF implements android.os.Parcelable {
    public float left, top, right, bottom;
    public RectF() {}
    public RectF(float left, float top, float right, float bottom) {}
    public RectF(Rect rect) {}
    public RectF(RectF rect) {}
    public void set(float left, float top, float right, float bottom) {}
    public void set(Rect rect) {}
    public void set(RectF rect) {}
    public void setEmpty() {}
    public float width() { return 0; }
    public float height() { return 0; }
    public float centerX() { return 0; }
    public float centerY() { return 0; }
    public boolean isEmpty() { return false; }
    public boolean contains(float x, float y) { return false; }
    public boolean contains(RectF rect) { return false; }
    public boolean intersect(RectF rect) { return false; }
    public boolean setIntersect(RectF a, RectF b) { return false; }
    public static boolean intersects(RectF a, RectF b) { return false; }
    public void union(float left, float top, float right, float bottom) {}
    public void union(float x, float y) {}
    public void union(RectF rect) {}
    public void round(Rect dst) {}
    public void roundOut(Rect dst) {}
    public int describeContents() { return 0; }
}
