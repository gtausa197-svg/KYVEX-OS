#!/usr/bin/env python3
"""Run local APKs in the actual unprivileged Native worker; never call a fallback.

A success means an initial supported UI scene, not a gameplay/login certificate.
User APKs are read in place, hashed, never bundled with KYVEX release artifacts.
"""
import argparse,hashlib,json,os,pathlib,subprocess,time

def ordinary():
    if os.geteuid()==0:os.setgroups([]);os.setgid(65534);os.setuid(65534)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('folder',type=pathlib.Path)
    p.add_argument('--worker',default='/usr/lib/kyvex/rift-native')
    p.add_argument('--report',required=True,type=pathlib.Path)
    p.add_argument('--memory',default='large',choices=['light','balanced','large'])
    p.add_argument('--timeout',type=int,default=60)
    args=p.parse_args();records=[]
    worker=pathlib.Path(args.worker).resolve()
    worker_sha=hashlib.sha256(worker.read_bytes()).hexdigest()
    caps=subprocess.run([str(worker),'--capabilities'],capture_output=True,text=True,timeout=10)
    capabilities=json.loads(caps.stdout) if caps.returncode==0 else {}
    for path in sorted(args.folder.glob('*.apk')):
        h=hashlib.sha256()
        with path.open('rb') as f:
            while b:=f.read(1024*1024):h.update(b)
        started=time.monotonic()
        proc=subprocess.Popen([args.worker,'--apk',str(path.resolve()),'--memory',args.memory],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=ordinary,env={'LANG':'C.UTF-8'})
        timed_out=False
        try:out,err=proc.communicate(b'',timeout=args.timeout)
        except subprocess.TimeoutExpired:
            timed_out=True;proc.kill();out,err=proc.communicate()
        packets=[]
        for line in out.splitlines():
            try:packets.append(json.loads(line))
            except (ValueError,UnicodeError):pass
        success=bool(packets and packets[0].get('ok') and packets[0].get('scene'))
        record=dict(file=path.name,sha256=h.hexdigest(),bytes=path.stat().st_size,memory=args.memory,returncode=proc.returncode,seconds=round(time.monotonic()-started,3),timed_out=timed_out,status='initial_ui' if success else 'unsupported',packets=packets,stderr=err[:4096].decode('utf-8','replace'),full_application_certified=False)
        records.append(record)
        args.report.write_text(json.dumps({'backend':'native','worker_sha256':worker_sha,'capabilities':capabilities,'fallback_used':False,'results':records},indent=2,ensure_ascii=False))
        print(json.dumps(record,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
