//! Decimal and NumberFormat instances backed by ICU's per-object formatter state.
use super::*;
use std::{
    ffi::{CStr, c_char, c_void},
    ptr::{self, NonNull},
};

pub(super) const DECIMAL: &str = "Ljava/text/DecimalFormat;";
pub(super) const NUMBER: &str = "Ljava/text/NumberFormat;";
pub(super) const FORMAT: &str = "Ljava/text/Format;";

const MAX_PATTERN: usize = 2048;
const MAX_OUTPUT: usize = 4096;

unsafe extern "C" {
    fn rift_decimal_open(
        style: i32,
        pattern: *const u16,
        length: i32,
        locale: *const c_char,
        error: *mut i32,
    ) -> *mut c_void;
    fn rift_decimal_close(format: *mut c_void);
    fn rift_decimal_apply(
        format: *const c_void,
        pattern: *const u16,
        length: i32,
        error: *mut i32,
    ) -> *mut c_void;
    fn rift_decimal_format(
        format: *const c_void,
        integer: i32,
        bits: i64,
        floating: f64,
        out: *mut u16,
        capacity: i32,
    ) -> i32;
    fn rift_decimal_get(format: *const c_void, attr: i32) -> i32;
    fn rift_decimal_set(format: *mut c_void, attr: i32, value: i32);
    fn rift_decimal_rounding(format: *const c_void) -> i32;
    fn rift_decimal_set_rounding(format: *mut c_void, ordinal: i32);
}

#[derive(Clone, Copy)]
#[repr(i32)]
enum Style {
    Decimal,
    Integer,
    Percent,
    Currency,
    Pattern,
}

#[derive(Clone, Copy)]
#[repr(i32)]
enum Attr {
    Grouping,
    MinInteger,
    MaxInteger,
    MinFraction,
    MaxFraction,
    ParseInteger,
    AlwaysDecimal,
    GroupSize,
    Multiplier,
}

enum Value {
    Integer(i64),
    Floating(f64),
}

pub(super) struct Decimal(NonNull<c_void>);

impl Drop for Decimal {
    fn drop(&mut self) {
        unsafe { rift_decimal_close(self.0.as_ptr()) }
    }
}

fn invalid_pattern(error: i32) -> Box<dyn std::error::Error + Send + Sync> {
    fault(
        "Ljava/lang/IllegalArgumentException;",
        &format!("Invalid decimal pattern (ICU {error})"),
    )
}

impl Decimal {
    fn open(style: Style, locale: &CStr, pattern: Option<&[u16]>) -> Result<Self> {
        let (text, length) = match pattern {
            Some(pattern) if pattern.len() <= MAX_PATTERN => {
                (pattern.as_ptr(), pattern.len() as i32)
            }
            Some(_) => return Err("DecimalFormat pattern quota".into()),
            None => (ptr::null(), 0),
        };
        let mut error = 0;
        let handle =
            unsafe { rift_decimal_open(style as i32, text, length, locale.as_ptr(), &mut error) };
        NonNull::new(handle)
            .map(Self)
            .ok_or_else(|| invalid_pattern(error))
    }

    fn apply(&mut self, pattern: &[u16]) -> Result<()> {
        if pattern.len() > MAX_PATTERN {
            return Err("DecimalFormat pattern quota".into());
        }
        let mut error = 0;
        let handle = unsafe {
            rift_decimal_apply(
                self.0.as_ptr(),
                pattern.as_ptr(),
                pattern.len() as i32,
                &mut error,
            )
        };
        *self = Self(NonNull::new(handle).ok_or_else(|| invalid_pattern(error))?);
        Ok(())
    }

    fn format(&self, value: Value) -> Result<Vec<u16>> {
        let (integer, bits, floating) = match value {
            Value::Integer(bits) => (1, bits, 0.0),
            Value::Floating(floating) => (0, 0, floating),
        };
        let mut output = vec![0; MAX_OUTPUT];
        let length = unsafe {
            rift_decimal_format(
                self.0.as_ptr(),
                integer,
                bits,
                floating,
                output.as_mut_ptr(),
                MAX_OUTPUT as i32,
            )
        };
        if length == i32::MIN {
            return Err(fault(
                "Ljava/lang/ArithmeticException;",
                "Rounding necessary",
            ));
        }
        if length < 0 || length as usize > output.len() {
            return Err(format!("DecimalFormat output capability/budget error {length}").into());
        }
        output.truncate(length as usize);
        Ok(output)
    }

    fn get(&self, attr: Attr) -> i32 {
        unsafe { rift_decimal_get(self.0.as_ptr(), attr as i32) }
    }

    fn set(&mut self, attr: Attr, value: i32) -> Result<()> {
        let value = match attr {
            Attr::MinInteger | Attr::MaxInteger => value.clamp(0, 309),
            Attr::MinFraction | Attr::MaxFraction => value.clamp(0, 340),
            Attr::GroupSize if !(0..=127).contains(&value) => {
                return Err(fault(
                    "Ljava/lang/IllegalArgumentException;",
                    "DecimalFormat grouping size",
                ));
            }
            Attr::Grouping | Attr::ParseInteger | Attr::AlwaysDecimal => i32::from(value != 0),
            _ => value,
        };
        let peer = match attr {
            Attr::MinInteger if value > self.get(Attr::MaxInteger) => Some(Attr::MaxInteger),
            Attr::MaxInteger if value < self.get(Attr::MinInteger) => Some(Attr::MinInteger),
            Attr::MinFraction if value > self.get(Attr::MaxFraction) => Some(Attr::MaxFraction),
            Attr::MaxFraction if value < self.get(Attr::MinFraction) => Some(Attr::MinFraction),
            _ => None,
        };
        unsafe {
            if let Some(peer) = peer {
                rift_decimal_set(self.0.as_ptr(), peer as i32, value);
            }
            rift_decimal_set(self.0.as_ptr(), attr as i32, value);
        }
        Ok(())
    }
}

fn attribute(method: &str) -> Option<(Attr, bool)> {
    let (name, signature) = method.split_once('(')?;
    let (name, set) = if let Some(name) = name.strip_prefix("set") {
        (name, true)
    } else {
        (
            name.strip_prefix("get")
                .or_else(|| name.strip_prefix("is"))?,
            false,
        )
    };
    let (attr, kind) = match name {
        "GroupingUsed" => (Attr::Grouping, "Z"),
        "ParseIntegerOnly" => (Attr::ParseInteger, "Z"),
        "DecimalSeparatorAlwaysShown" => (Attr::AlwaysDecimal, "Z"),
        "MinimumIntegerDigits" => (Attr::MinInteger, "I"),
        "MaximumIntegerDigits" => (Attr::MaxInteger, "I"),
        "MinimumFractionDigits" => (Attr::MinFraction, "I"),
        "MaximumFractionDigits" => (Attr::MaxFraction, "I"),
        "GroupingSize" => (Attr::GroupSize, "I"),
        "Multiplier" => (Attr::Multiplier, "I"),
        _ => return None,
    };
    let valid = if set {
        signature.strip_suffix(")V") == Some(kind)
    } else {
        signature.strip_prefix(')') == Some(kind)
    };
    valid.then_some((attr, set))
}

impl Runtime {
    fn decimal(&self, id: u32) -> Result<&Decimal> {
        match &self.object(id)?.payload {
            Payload::Decimal(Some(format)) => Ok(format),
            _ => Err("Expected an initialized DecimalFormat".into()),
        }
    }

    fn decimal_mut(&mut self, id: u32) -> Result<&mut Decimal> {
        match &mut self.object_mut(id)?.payload {
            Payload::Decimal(Some(format)) => Ok(format),
            _ => Err("Expected an initialized DecimalFormat".into()),
        }
    }

    pub(super) fn decimal_format_api(&mut self, sig: &str, args: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("NumberFormat signature")?;
        if !matches!(class, DECIMAL | NUMBER | FORMAT) {
            return Ok(None);
        }
        let arg = |index: usize| {
            args.get(index)
                .copied()
                .ok_or("NumberFormat argument count")
        };
        if class == NUMBER
            && let Some((name, descriptor)) = method.split_once('(')
            && matches!(
                descriptor,
                ")Ljava/text/NumberFormat;" | "Ljava/util/Locale;)Ljava/text/NumberFormat;"
            )
        {
            let style = match name {
                "getInstance" | "getNumberInstance" => Style::Decimal,
                "getIntegerInstance" => Style::Integer,
                "getPercentInstance" => Style::Percent,
                "getCurrencyInstance" => Style::Currency,
                _ => return Ok(None),
            };
            let locale = args.first().map(|&id| self.locale_id(id)).transpose()?;
            let format = Decimal::open(style, locale.as_deref().unwrap_or(locale::DEFAULT), None)?;
            return Ok(Some(u64::from(
                self.allocate(DECIMAL, Payload::Decimal(Some(format)))?,
            )));
        }
        let id = arg(0)?;
        match method {
            "getRoundingMode()Ljava/math/RoundingMode;" => {
                let mode = unsafe { rift_decimal_rounding(self.decimal(id)?.0.as_ptr()) };
                return Ok(Some(u64::from(self.rounding_mode(mode as u32)?)));
            }
            "setRoundingMode(Ljava/math/RoundingMode;)V" => {
                let mode = self.rounding_ordinal(arg(1)?)?;
                unsafe { rift_decimal_set_rounding(self.decimal_mut(id)?.0.as_ptr(), mode) };
                return Ok(Some(0));
            }
            _ => {}
        }
        if class == DECIMAL && matches!(method, "<init>()V" | "<init>(Ljava/lang/String;)V") {
            let format = if method == "<init>()V" {
                Decimal::open(Style::Decimal, locale::DEFAULT, None)?
            } else {
                Decimal::open(Style::Pattern, locale::DEFAULT, Some(&self.units(arg(1)?)?))?
            };
            self.object_mut(id)?.payload = Payload::Decimal(Some(format));
            return Ok(Some(0));
        }
        if method == "applyPattern(Ljava/lang/String;)V" && class == DECIMAL {
            let pattern = self.units(arg(1)?)?;
            self.decimal_mut(id)?.apply(&pattern)?;
            return Ok(Some(0));
        }
        if let Some((attr, set)) = attribute(method) {
            let result = if set {
                self.decimal_mut(id)?.set(attr, arg(1)? as i32)?;
                0
            } else {
                self.decimal(id)?.get(attr) as u32 as u64
            };
            return Ok(Some(result));
        }
        let wide = || -> Result<u64> { Ok(u64::from(arg(1)?) | (u64::from(arg(2)?) << 32)) };
        let value = match method {
            "format(J)Ljava/lang/String;" => Value::Integer(wide()? as i64),
            "format(D)Ljava/lang/String;" => Value::Floating(f64::from_bits(wide()?)),
            "format(Ljava/lang/Object;)Ljava/lang/String;" => match self.object(arg(1)?)?.payload {
                Payload::Boxed {
                    kind: 'B' | 'S' | 'I',
                    bits,
                } => Value::Integer(bits as u32 as i32 as i64),
                Payload::Boxed { kind: 'J', bits } => Value::Integer(bits as i64),
                Payload::Boxed { kind: 'F', bits } => {
                    Value::Floating(f32::from_bits(bits as u32) as f64)
                }
                Payload::Boxed { kind: 'D', bits } => Value::Floating(f64::from_bits(bits)),
                _ => {
                    return Err(fault(
                        "Ljava/lang/IllegalArgumentException;",
                        "Expected a numeric value",
                    ));
                }
            },
            _ => return Ok(None),
        };
        let units = self.decimal(id)?.format(value)?;
        Ok(Some(u64::from(self.string_units(units)?)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn failed_pattern_change_preserves_the_formatter() {
        let pattern: Vec<u16> = "0.00E0".encode_utf16().collect();
        let mut format = Decimal::open(Style::Pattern, locale::DEFAULT, Some(&pattern)).unwrap();
        let invalid: Vec<u16> = "0..00".encode_utf16().collect();
        assert!(format.apply(&invalid).is_err());
        let formatted = format.format(Value::Integer(1230)).unwrap();
        assert_eq!(String::from_utf16(&formatted).unwrap(), "1.23E3");
    }
}
