//! Private, unprivileged worker. The daemon owns its pipes and lifetime.
use rift_native::{
    Result,
    machine::{Machine, Trap},
    package::Package,
    sandbox,
    vm::Runtime,
};
use serde_json::{Value, json};
use std::{
    io::{self, BufRead, Read, Write},
    path::PathBuf,
    time::Instant,
};
// An APK may stay open indefinitely; each operation still has a hard deadline.
// Waiting for the next desktop event consumes no operation budget.
struct Deadline;
impl Deadline {
    fn start(seconds: u32) -> Self {
        unsafe { libc::alarm(seconds) };
        Self
    }
}
impl Drop for Deadline {
    fn drop(&mut self) {
        unsafe { libc::alarm(0) };
    }
}
fn emit(v: &Value) -> Result<()> {
    let mut out = io::stdout().lock();
    let mut v = v.clone();
    v["protocol"] = json!(1);
    let bytes = serde_json::to_vec(&v)?;
    if bytes.len() > 65536 {
        return Err("Native UI/diagnostic packet exceeds 64 KiB".into());
    }
    out.write_all(&bytes)?;
    out.write_all(b"\n")?;
    out.flush()?;
    Ok(())
}
fn metrics(vm: &Runtime, started: Instant, abi: &str) -> Value {
    json!({"engine":"Rift Native 0.3","abi":abi,"sandbox":sandbox::active(),"peak_rss_kib":sandbox::peak_rss_kib(),"guest_mapped_bytes":vm.machine.cpu.memory().mapped(),"guest_peak_bytes":vm.machine.cpu.memory().peak,"java_heap_bytes":vm.heap_bytes(),"virtual_file_bytes":vm.virtual_file_bytes(),"loaded_dex":vm.loaded_dex(),"dex_instructions":vm.instructions,"bit_operations":vm.bit_operations,"arm_ticks":vm.machine.ticks,"jni_calls":vm.machine.calls,"events":vm.events,"pending_events":vm.pending_events(),"guest_threads":vm.guest_threads(),"thread_switches":vm.thread_switches(),"elapsed_ms":started.elapsed().as_millis(),"app_logs":vm.logs})
}
fn main() {
    if let Err(e) = run() {
        let mut message = e.to_string();
        if message.chars().count() > 8000 {
            let first = message.chars().take(2000).collect::<String>();
            let last = message
                .chars()
                .rev()
                .take(5800)
                .collect::<Vec<_>>()
                .into_iter()
                .rev()
                .collect::<String>();
            message = format!("{first} … [trace shortened] … {last}");
        }
        let _ = emit(
            &json!({"ok":false,"error":message,"backend":"native","peak_rss_kib":sandbox::peak_rss_kib()}),
        );
        std::process::exit(1)
    }
}
fn run() -> Result<()> {
    let mut args = std::env::args().skip(1);
    let mut apk = None;
    let mut elf = None;
    let mut abi = "auto".to_owned();
    let mut memory = "light".to_owned();
    let mut probe = false;
    let mut trace_startup = false;
    let mut state = None;
    while let Some(a) = args.next() {
        match a.as_str() {
            "--apk" => apk = Some(PathBuf::from(args.next().ok_or("--apk needs a path")?)),
            "--elf" => elf = Some(PathBuf::from(args.next().ok_or("--elf needs a path")?)),
            "--abi" => abi = args.next().ok_or("--abi needs a value")?,
            "--memory" => memory = args.next().ok_or("--memory needs a value")?,
            "--state" => state = Some(PathBuf::from(args.next().ok_or("--state needs a path")?)),
            "--probe-sandbox" => probe = true,
            "--trace-startup" => trace_startup = true,
            "--capabilities" => {
                let unsupported = [
                    "full ART/Android Framework",
                    "Unity/OpenGL/Vulkan",
                    "most Android services",
                    "general network/media APIs",
                    "persistent general-purpose app files",
                    "JNI Java method calls",
                    "Android x86 libraries",
                    "native pthreads/general ELF TLS",
                    "blocking inside synchronous library callbacks",
                    "worker Loopers, standalone FutureTask and submit on ordinary pools",
                    "custom ClassLoaders",
                ];
                let mut capabilities = json!({
                    "engine":"Rift Native 0.3", "experimental":true, "backend":"native",
                    "cpu":"Dynarmic ARM32/Thumb/ARM64",
                    "dex":"lazy multidex, typed exceptions, numeric/array/control interpreter subset",
                    "jni":"typed scalar ARM32/64 ABI, static exports, JavaVM.GetEnv, JNI_OnLoad, RegisterNatives and selected JNIEnv APIs",
                    "elf":"transactional APK DT_NEEDED linking, breadth-first dependency symbols and ordered constructors; REL/RELA/APS2/RELR and JNI load rollback; general ELF TLS modules, cyclic dependencies and native pthreads remain unsupported",
                    "ui":"Activity, vertical LinearLayout, TextView, Button",
                    "resources":"bounded APK resources.arsc scalars, arrays, references, names and typed values; fixed en-US API28 virtual display; no layout inflation",
                    "lifecycle":"manifest provider startup and real Activity create/start/resume/pause/stop/destroy callbacks",
                    "events":"bounded main-thread Handler/Message queue, delayed callbacks, cancellation; worker Loopers are not implemented",
                    "execution":"owned resumable DEX stacks, cooperative Thread.start/join/sleep/interrupt, owned monitors, wait/notify, locks/latches/parking, per-thread locals/JNIEnv/TLS; one execution lane, 64 live threads",
                    "initialization":"owned class initialization, superclass/default-interface order, per-thread ownership, noninterruptible class wait, once publication and persistent erroneous state; deferred static fields/new/invocations/reflection",
                    "stack_traces":"actual guest construction/fault snapshots, copied StackTraceElement arrays, fill/set/suppression, live/paused guest Thread snapshots; JNI native markers; source file/line debug metadata remains unknown",
                    "atomics":"checked volatile field updaters and reference/int/long atomic arrays in one serialized execution lane; no functional update operators",
                    "runtime_info":"one guest Runtime, one execution lane, heap budget and estimated free memory; advisory GC",
                    "filesystem":"read-only APK streams/library mounts; bounded session-memory files and private emulated storage with application files/cache/media directories; persistent SharedPreferences journal",
                    "readers":"StringReader, buffered lines and UTF-8/ISO-8859-1/US-ASCII over guest files; no custom Reader adapters",
                    "charsets":"six standard charsets with canonical aliases and String byte conversion, backed ByteArrayInputStream; UTF-8/Latin-1/ASCII Charset reader overloads; no NIO encoder/decoder objects or UTF-16 streaming readers",
                    "map_sets":"live map-backed sets dispatch actual DEX maps/key iterators with scoped GC roots; HashMap and LinkedHashMap use actual guest hashCode, cached insertion hashes and collision equality; read-only iterator mutation is denied",
                    "base64":"Android encode/decode byte and String APIs, checked slices, URL-safe alphabet, padding and LF/CRLF flags; original Android API28 oracle verified",
                    "integer_parsing":"checked signed Byte/Short/Integer/Long parse APIs, radix 2..36, Java8 BMP Character.digit ranges, exact narrow/wide returns and NumberFormatException",
                    "guest_call_depth":128,
                    "sqlite":"real bounded SQLite memory connections and private session-file images; helper callbacks, schema migrations, transactions, typed cursor snapshots; no cross-process DB persistence, WAL, custom factories/handlers or simultaneous helpers for one named DB",
                    "sqlite_version":rusqlite::version(),
                    "logging":"guest Logger namespace, real parent/level inheritance, standard/custom Level values and filtered diagnostic messages bounded to32 entries/2048 characters/16KiB escaped JSON; no custom Handlers, Filters, ResourceBundles, LogRecords or Suppliers",
                    "executor_tasks":"real Runnable execution through own resumable DEX loop and reusable cooperative guest threads; actual ThreadFactory wrappers/hooks, bounded native linked queues, cached pools with direct handoffs, rejection, live core/keepalive configuration, failure replacement, shutdown/termination; custom blocking queues and suspension inside synchronous hooks/factories are outside this subset",
                    "handoff_queue":"zero-capacity SynchronousQueue with real producer/consumer and idle worker transfers, fair order, interruptible waits and timeouts; pending results retain their original Java references",
                    "scheduled_executor":"real delayed, fixed-rate and fixed-delay Runnable work and delayed Callable results on reusable guest workers. Supports interruptible Future waits, cancellation and shutdown policies with at most 1024 queued tasks per pool. General FutureTask and replacement task decorators are outside this subset.",
                    "string_format":"bounded Java8 en-US static String.format with UTF16 string, boolean, hash, character, integral, percent and newline conversions. Supports argument indexes, widths, precision and actual object callbacks. Locale overloads, Formatter objects, floating/date conversions and BigInteger are outside this subset.",
                    "messenger":"local Messenger endpoints share Binder identity per Handler and deliver real Message requests and replies on the main Looper. Remote Binder, Android system services and parceling are outside this subset.",
                    "xml":"bounded XMLPull text and compiled APK resources, typed AttributeSet values, resource IDs and manifest provider metadata; read-only APK access; DTD and external entities unavailable",
                    "java_libraries":"selected UTF-16 search/replace, typed Arrays.copyOf and copyOfRange, backed/unmodifiable collections, ArrayList.removeIf, Objects.requireNonNull, primitive abs/integer min/max, Date epoch milliseconds, class assignability and reflection; calendar and general Java APIs remain partial",
                    "services":"isolated guest ActivityManager, single unlocked guest UserManager and current-APK component metadata only",
                    "host":"x86-64 Linux", "full_android_framework":false, "android_identity_profile":28,
                    "memory_profiles":["light","balanced","large"],
                    "unsupported":unsupported
                });
                capabilities["storage_contexts"] = json!(
                    "separate ordinary and device-protected guest file, SQLite and preference namespaces; legacy journal compatibility; no guest lock state or credential encryption"
                );
                capabilities["android_json"] = json!(
                    "pinned AOSP API28 org.json DEX in the guest VM; tested nested parsing, lookup and mutation, compact and indented output and typed JSON faults"
                );
                capabilities["native_platform"] = json!(
                    "guest Android log, Adler-32 and ARM32 EABI memory operations; C-locale strto*, bounded sscanf/vsscanf, Bionic standard streams, allocated scalar formatting, ARM32/64 va_list, byte and wide strings, UTF-8 multibyte state and strftime"
                );
                capabilities["native_threads"] = json!(
                    "bounded cooperative Bionic pthread creation, join, detach, exit, mutex ownership and pthread_once; separate guest stacks and TLS, default pthread attributes, JavaVM GetEnv reports detached workers"
                );
                capabilities["regex_replacement"] = json!(
                    "ICU Android Unicode regex, Pattern.quote, String and Matcher replaceAll/replaceFirst, UTF-16, numbered and named captures"
                );
                capabilities["managed_text"] = json!(
                    "ICU DecimalFormat, Java RoundingMode, NumberFormat factories and US-locale Unicode case mapping; bounded patterns and output"
                );
                capabilities["text_paint"] = json!(
                    "Paint and TextPaint state, HarfBuzz glyph and ligature coverage over the prepared system font fallback chain"
                );
                capabilities["read_write_locks"] = json!(
                    "shared readers, reentrant writers, optional fair ordering, timeout and interruption on the guest scheduler"
                );
                capabilities["android_coordination"] = json!(
                    "virtual display feature queries, Point coordinates, local Binder interface identity and bounded exception logs"
                );
                capabilities["android_display"] = json!(
                    "one virtual display and stable WindowManager, display metrics, input thresholds, Rect and RectF geometry, three Android interpolators"
                );
                capabilities["android_settings"] = json!(
                    "per-context guest ContentResolver, read-only settings from the virtual profile, absent advertising identifiers and typed missing-setting results"
                );
                capabilities["executor_facades"] = json!(
                    "ordinary and scheduled executor delegation preserves actual guest overrides, cooperative waits and object identity"
                );
                capabilities["native_heap"] = json!(
                    "bounded guest malloc, calloc, realloc, free, aligned blocks and per-thread errno; reusable holes and reclaimed trailing pages"
                );
                capabilities["strict_mode"] = json!(
                    "Android 28 ThreadPolicy builders and immutable per-thread snapshots; slow-call and private file I/O diagnostics; network and resource detector flags are retained"
                );
                emit(&capabilities)?;
                return Ok(());
            }
            _ => return Err(format!("Unknown worker argument {a}").into()),
        }
    }
    if unsafe { libc::geteuid() } == 0 {
        return Err("Rift Native guest execution must run as an ordinary user".into());
    }
    let (guest, cache, heap, address_space) = match memory.as_str() {
        "light" => (32, 8, 4 * 1024 * 1024, 192),
        "balanced" => (96, 16, 16 * 1024 * 1024, 768),
        "large" => (256, 32, 64 * 1024 * 1024, 3072),
        _ => return Err("Unknown native memory profile".into()),
    };
    let interactive = apk.is_some() && elf.is_none() && !probe;
    sandbox::resources(address_space, (!interactive).then_some(30))?;
    if probe {
        sandbox::restrict()?;
        let path = c"/etc/passwd";
        let fd = unsafe { libc::open(path.as_ptr(), libc::O_RDONLY) };
        let open_errno = io::Error::last_os_error().raw_os_error();
        if fd >= 0 {
            unsafe { libc::close(fd) };
        }
        let socket = unsafe { libc::socket(libc::AF_INET, libc::SOCK_STREAM, 0) };
        let socket_errno = io::Error::last_os_error().raw_os_error();
        let mut byte = 0u8;
        let inherited = unsafe { libc::read(3, (&mut byte as *mut u8).cast(), 1) };
        let inherited_errno = io::Error::last_os_error().raw_os_error();
        let command = c"/usr/bin/true";
        let arguments = [command.as_ptr(), std::ptr::null()];
        let environment = [std::ptr::null::<libc::c_char>()];
        let execute =
            unsafe { libc::execve(command.as_ptr(), arguments.as_ptr(), environment.as_ptr()) };
        let execute_errno = io::Error::last_os_error().raw_os_error();
        emit(
            &json!({"ok":fd<0&&socket<0&&inherited<0&&execute<0,"sandbox":sandbox::active(),"open_errno":open_errno,"socket_errno":socket_errno,"inherited_errno":inherited_errno,"execute_errno":execute_errno}),
        )?;
        return Ok(());
    }
    let started = Instant::now();
    if let Some(path) = elf {
        if apk.is_some() {
            return Err("Choose either an ELF or an APK".into());
        }
        let file = std::fs::File::open(path)?;
        if file.metadata()?.len() > 32 * 1024 * 1024 {
            return Err("ELF size quota (32 MiB)".into());
        }
        let mut bytes = Vec::new();
        file.take(32 * 1024 * 1024 + 1).read_to_end(&mut bytes)?;
        let arch = match bytes.get(4) {
            Some(1) => 32,
            Some(2) => 64,
            _ => return Err("Invalid ELF class".into()),
        };
        let mut machine = Machine::new(arch, guest, cache)?;
        machine.load("program", &bytes)?;
        let entry = machine.images["program"].entry;
        let mut state = machine.prepare(entry, &[])?;
        sandbox::restrict()?;
        let exit = match machine.advance(&mut state)? {
            Trap::Exit(v) => v,
            _ => return Err("Static ELF did not exit through its guest syscall interface".into()),
        };
        emit(
            &json!({"ok":exit==0,"exit":exit,"stdout":String::from_utf8_lossy(&machine.stdout),"arch":arch,"sandbox":sandbox::active(),"peak_rss_kib":sandbox::peak_rss_kib(),"arm_ticks":machine.ticks}),
        )?;
        return Ok(());
    }
    let startup_deadline = Deadline::start(45);
    let trace_phase = |phase: &str| {
        if trace_startup {
            eprintln!(
                "{}",
                json!({"rift_startup_trace":"phase","phase":phase,"elapsed_ms":started.elapsed().as_millis()})
            );
        }
    };
    trace_phase("package_open_begin");
    let package = Package::open(&apk.ok_or("Choose --apk or --elf")?, &abi)?;
    trace_phase("package_open_end");
    let machine = Machine::new(package.arch, guest, cache)?;
    trace_phase("machine_ready");
    let info = package.info;
    let abi = package.abi;
    let mut vm = Runtime::new(package.dex, machine, package.libraries, heap);
    vm.prepare_system_fonts();
    if trace_startup {
        vm.enable_startup_trace(started);
    }
    vm.configure_package(&info)?;
    let application = info.application;
    let launcher = info.launcher;
    let package_name = info.package;
    if let Some(path) = state {
        vm.preferences_file(&path)?;
    }
    let mut files = vec![vm.apk_fd()];
    files.extend(vm.preferences_fd());
    sandbox::restrict_with_files(&files)?;
    trace_phase("application_begin");
    vm.start_application(&package_name, &application)?;
    trace_phase("activity_begin");
    let scene = vm.start(&launcher)?;
    trace_phase("activity_ready");
    vm.finish_startup_trace();
    let startup_ms = started.elapsed().as_millis();
    emit(
        &json!({"ok":true,"backend":"native","package":package_name,"scene":scene,"startup_ms":startup_ms,"metrics":metrics(&vm,started,&abi)}),
    )?;
    drop(startup_deadline);
    let input = io::stdin();
    let mut input = input.lock();
    let mut line = Vec::new();
    loop {
        line.clear();
        let n = Read::by_ref(&mut input)
            .take(65537)
            .read_until(b'\n', &mut line)?;
        if n == 0 {
            break;
        }
        if n > 65536 || line.last() != Some(&b'\n') {
            return Err("Native worker request exceeds 64 KiB".into());
        }
        let _deadline = Deadline::start(2);
        let r: Value = serde_json::from_slice(&line)?;
        match r["method"].as_str() {
            Some("click") => {
                let id = u32::try_from(r["id"].as_u64().ok_or("Widget ID required")?)?;
                let scene = vm.click(id)?;
                emit(
                    &json!({"ok":true,"backend":"native","scene":scene,"metrics":metrics(&vm,started,&abi)}),
                )?
            }
            Some("close") => {
                vm.close_activity()?;
                emit(&json!({"ok":true,"closed":true,"metrics":metrics(&vm,started,&abi)}))?;
                break;
            }
            Some("status") => {
                emit(&json!({"ok":true,"scene":vm.scene,"metrics":metrics(&vm,started,&abi)}))?
            }
            Some("tick") => {
                let scene = vm.tick()?;
                emit(
                    &json!({"ok":true,"backend":"native","scene":scene,"metrics":metrics(&vm,started,&abi)}),
                )?;
            }
            _ => return Err("Unknown native worker request".into()),
        }
    }
    let _deadline = Deadline::start(2);
    vm.close_activity()?;
    Ok(())
}
