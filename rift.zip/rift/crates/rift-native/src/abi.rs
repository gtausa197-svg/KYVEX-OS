//! AAPCS32 (Android softfp) and AAPCS64 scalar JNI argument placement.
use crate::{Result, cpu::State, machine::Machine};
#[derive(Clone, Copy)]
pub enum Value {
    Word(u32),
    Wide(u64),
    Float(u32),
    Double(u64),
}
impl Value {
    fn bits(self) -> u64 {
        match self {
            Self::Word(v) | Self::Float(v) => v as u64,
            Self::Wide(v) | Self::Double(v) => v,
        }
    }
}
pub fn prepare(
    machine: &mut Machine,
    address: u64,
    env: u64,
    receiver: u64,
    args: &[Value],
) -> Result<State> {
    if args.len() > 64 {
        return Err("JNI scalar argument quota (64)".into());
    }
    let mut gp = vec![env, receiver];
    let mut fp = Vec::new();
    let mut stack = Vec::new();
    if machine.arch == 64 {
        for value in args {
            if matches!(value, Value::Float(_) | Value::Double(_)) && fp.len() < 8 {
                fp.push(value.bits());
            } else if matches!(value, Value::Word(_) | Value::Wide(_)) && gp.len() < 8 {
                gp.push(value.bits());
            } else {
                stack.extend_from_slice(&value.bits().to_le_bytes());
            }
        }
    } else {
        let mut exhausted = false;
        for value in args {
            let wide = matches!(value, Value::Wide(_) | Value::Double(_));
            let words = if wide { 2 } else { 1 };
            if !exhausted && wide && !gp.len().is_multiple_of(2) {
                gp.push(0);
            }
            if !exhausted && gp.len() + words <= 4 {
                gp.push(value.bits() as u32 as u64);
                if wide {
                    gp.push(value.bits() >> 32);
                }
            } else {
                exhausted = true;
                gp.resize(4, 0);
                if wide {
                    stack.resize(stack.len().div_ceil(8) * 8, 0);
                    stack.extend_from_slice(&value.bits().to_le_bytes());
                } else {
                    stack.extend_from_slice(&(value.bits() as u32).to_le_bytes());
                }
            }
        }
    }
    machine.prepare_abi(address, &gp, &fp, &stack)
}
pub fn returned(state: &State, arch: u32, kind: &str) -> u64 {
    match kind {
        "V" => 0,
        "F" if arch == 64 => state.vectors[0] as u32 as u64,
        "D" if arch == 64 => state.vectors[0],
        "J" | "D" if arch == 32 => {
            state.regs[0] as u32 as u64 | ((state.regs[1] as u32 as u64) << 32)
        }
        "J" => state.regs[0],
        _ => state.regs[0] as u32 as u64,
    }
}
