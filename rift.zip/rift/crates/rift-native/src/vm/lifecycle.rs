//! Execute callbacks for actual guest Activity transitions, without synthetic pressure events.
use super::*;
impl Runtime {
    pub(super) fn lifecycle_api(&mut self, sig: &str, a: &[u32]) -> Result<Option<u64>> {
        let (class, method) = sig.split_once("->").ok_or("Lifecycle signature")?;
        let arg = |i: usize| a.get(i).copied().ok_or("Lifecycle argument count");
        if class == "Landroid/app/Application;" && method == "getProcessName()Ljava/lang/String;" {
            return Ok(Some(self.string(&self.guest_process_name())? as u64));
        }
        if self.subclass(class, "Landroid/app/Application;")?
            && matches!(
                method,
                "registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V"
                    | "unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V"
                    | "registerComponentCallbacks(Landroid/content/ComponentCallbacks;)V"
                    | "unregisterComponentCallbacks(Landroid/content/ComponentCallbacks;)V"
            )
        {
            if arg(0)? != self.application || self.application == 0 {
                return Err("Only the current guest Application owns callbacks".into());
            }
            let listener = arg(1)?;
            self.object(listener)?;
            let activity = method.contains("ActivityLifecycleCallbacks");
            let interface = if activity {
                "Landroid/app/Application$ActivityLifecycleCallbacks;"
            } else {
                "Landroid/content/ComponentCallbacks;"
            };
            if !self.subclass(&self.object(listener)?.class, interface)? {
                return Err("Application callback interface type".into());
            }
            let listeners = if activity {
                &mut self.activity_callbacks
            } else {
                &mut self.component_callbacks
            };
            if method.starts_with("register") {
                if listeners.len() >= 256 {
                    return Err("Application callback registration quota".into());
                }
                listeners.push(listener);
            } else if let Some(i) = listeners.iter().position(|id| *id == listener) {
                listeners.remove(i);
            }
            return Ok(Some(0));
        }
        if class == "Landroid/app/Activity;" {
            let (stage, name, descriptor) = match method {
                "onCreate(Landroid/os/Bundle;)V" => (
                    1,
                    "onActivityCreated",
                    "(Landroid/app/Activity;Landroid/os/Bundle;)V",
                ),
                "onStart()V" => (2, "onActivityStarted", "(Landroid/app/Activity;)V"),
                "onResume()V" => (3, "onActivityResumed", "(Landroid/app/Activity;)V"),
                "onPause()V" => (4, "onActivityPaused", "(Landroid/app/Activity;)V"),
                "onStop()V" => (5, "onActivityStopped", "(Landroid/app/Activity;)V"),
                "onDestroy()V" => (6, "onActivityDestroyed", "(Landroid/app/Activity;)V"),
                _ => return Ok(None),
            };
            let activity = arg(0)?;
            if activity != self.activity || activity == 0 {
                return Err("Activity lifecycle belongs to current guest window".into());
            }
            self.activity_stage = stage;
            for listener in self.activity_callbacks.clone() {
                let actual = self.object(listener)?.class.clone();
                let index = self.dex.find(&actual, name, descriptor).ok_or_else(|| {
                    format!("Missing lifecycle callback {actual}->{name}{descriptor}")
                })?;
                let mut args = vec![listener, activity];
                if stage == 1 {
                    args.push(arg(1)?);
                }
                self.invoke(index, &args, true)?;
                self.events += 1;
            }
            return Ok(Some(0));
        }
        Ok(None)
    }
    pub(super) fn activity_transition(&mut self, name: &str, expected: u8) -> Result<()> {
        let actual = self.object(self.activity)?.class.clone();
        if let Some(index) = self.dex.find(&actual, name, "()V")
            && self.dex.bodies.contains_key(&index)
        {
            self.invoke(index, &[self.activity], true)?;
        } else {
            self.hle(
                &format!("Landroid/app/Activity;->{name}()V"),
                &[self.activity],
            )?;
        }
        if self.activity_stage != expected {
            return Err(fault(
                "Landroid/util/SuperNotCalledException;",
                &format!("Activity did not call super.{name}"),
            ));
        }
        Ok(())
    }
    pub fn close_activity(&mut self) -> Result<()> {
        self.reset_budget();
        if self.activity == 0 || self.activity_stage == 0 || self.activity_stage == 6 {
            return Ok(());
        }
        if self.activity_stage == 3 {
            self.activity_transition("onPause", 4)?;
        }
        if matches!(self.activity_stage, 2 | 4) {
            self.activity_transition("onStop", 5)?;
        }
        self.activity_transition("onDestroy", 6)?;
        self.shutdown_guest_threads()
    }
}
